import React from 'react';
import Modal from './Modal';
import { Box, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

const AppOverlays = ({
  isLoading,
  isAnalyzing,
  isBatchRunning,
  showSuccess,
  setShowSuccess,
  showError,
  setShowError,
  showOnboarding,
  setShowOnboarding,
  showProgressionModal,
  setShowProgressionModal,
  progressionData,
  progressionDataset
}) => {
  return (
    <>
      {isLoading && (
        <Box sx={{ position: 'fixed', zIndex: 2000, inset: 0, bgcolor: 'rgba(255,255,255,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img src="/img/loading.gif" alt="Loading..." style={{ width: 80, height: 80 }} />
        </Box>
      )}
      {isAnalyzing && (
        <Box sx={{ position: 'fixed', zIndex: 2000, inset: 0, bgcolor: 'rgba(255,255,255,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img src="/img/analyze.gif" alt="Analyzing..." style={{ width: 80, height: 80 }} />
        </Box>
      )}
      {isBatchRunning && (
        <Box sx={{ position: 'fixed', zIndex: 2000, inset: 0, bgcolor: 'rgba(255,255,255,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img src="/img/analyze_alt.gif" alt="Batch Job Running..." style={{ width: 80, height: 80 }} />
        </Box>
      )}
      {showSuccess && (
        <Modal isOpen={showSuccess} onClose={() => setShowSuccess(false)} title="Success">
          <Box sx={{ textAlign: 'center', py: 2 }}>
            <img src="/img/success.gif" alt="Success" style={{ width: 80, marginBottom: 8 }} />
            <Typography variant="h6" sx={{ mt: 1 }}>Operation successful!</Typography>
          </Box>
        </Modal>
      )}
      {showError && (
        <Modal isOpen={showError} onClose={() => setShowError(false)} title="Error">
          <Box sx={{ textAlign: 'center', py: 2 }}>
            <img src="/img/error.gif" alt="Error" style={{ width: 80, marginBottom: 8 }} />
            <Typography variant="h6" sx={{ mt: 1 }}>Operation failed. Please try again.</Typography>
          </Box>
        </Modal>
      )}
      {showOnboarding && (
        <Box sx={{ position: 'fixed', zIndex: 2000, inset: 0, bgcolor: 'rgba(255,255,255,0.9)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }} onClick={() => setShowOnboarding(false)}>
          {/* Animated Red Ripple */}
          <Box
            sx={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              width: '100vw',
              height: '100vh',
              pointerEvents: 'none',
              zIndex: 0,
            }}
          >
            <span className="red-ripple" style={{ animationDelay: '0s' }} />
            <span className="red-ripple" style={{ animationDelay: '2s' }} />
            <span className="red-ripple" style={{ animationDelay: '4s' }} />
            <style>{`
              .red-ripple {
                position: absolute;
                top: 50%;
                left: 50%;
                width: 300px;
                height: 300px;
                transform: translate(-50%, -50%);
                border-radius: 50%;
                background: radial-gradient(circle, rgba(220,38,38,0.18) 0%, rgba(220,38,38,0.08) 60%, rgba(220,38,38,0) 100%);
                animation: ripple-wave 6s cubic-bezier(0.4,0,0.2,1) infinite;
              }
              @keyframes ripple-wave {
                0% {
                  opacity: 0.4;
                  transform: translate(-50%, -50%) scale(1);
                }
                70% {
                  opacity: 0.08;
                  transform: translate(-50%, -50%) scale(6);
                }
                100% {
                  opacity: 0;
                  transform: translate(-50%, -50%) scale(8);
                }
              }
            `}</style>
          </Box>
          <img src="/img/data.gif" alt="Welcome to ADW Data Modeller!" style={{ width: 120, marginBottom: 16, zIndex: 1 }} />
          <Typography variant="h4" sx={{ fontWeight: 'bold', mb: 1, zIndex: 1 }}>
            <span style={{ color: '#000' }}>Welcome to ADW </span>
            <span style={{ color: '#dc2626' }}>Data Modeller</span>
          </Typography>
          <Typography variant="body1" sx={{ zIndex: 1 }}>Click anywhere to get started!</Typography>
        </Box>
      )}
      {showProgressionModal && (
        <Modal isOpen={showProgressionModal} onClose={() => setShowProgressionModal(false)} title={`Tier Progression: ${progressionDataset}`}>
          <Box sx={{ textAlign: 'center', mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'center', gap: 2, mb: 1 }}>
              {progressionData.map((step, idx) => (
                <React.Fragment key={step.date}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 70 }}>
                    <img src={`/img/${step.tier.toLowerCase()}.png`} alt={step.tier + ' icon'} style={{ width: 32, height: 32, marginBottom: 2 }} />
                    <Typography sx={{ fontWeight: 600, mb: 0.5 }}>{step.tier}</Typography>
                    <Typography sx={{ fontSize: 12, color: '#888', mt: 0.5 }}>{step.date}</Typography>
                  </Box>
                  {idx < progressionData.length - 1 && (
                    <Typography sx={{ fontSize: 24, color: '#888', mx: 1, alignSelf: 'center' }}>&#8594;</Typography>
                  )}
                </React.Fragment>
              ))}
            </Box>
          </Box>
          <TableContainer component={Paper} sx={{ maxWidth: 400, mx: 'auto' }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Date</TableCell>
                  <TableCell>Tier</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {progressionData.map((step, idx) => (
                  <TableRow key={step.date}>
                    <TableCell>{step.date}</TableCell>
                    <TableCell>{step.tier}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Modal>
      )}
    </>
  );
};

export default AppOverlays; 