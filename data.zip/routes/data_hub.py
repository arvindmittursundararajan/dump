import os
import pandas as pd
import json
from flask import Blueprint, render_template, request, jsonify, current_app, flash, redirect, url_for
from werkzeug.utils import secure_filename
from app import db
from models import DataSource, Alert, Rule, OptimizationPlan, Incident, Flight, Aircraft, Crew
import populate_sample_data
from services.data_service import analyze_data_quality, save_data_to_db
from services.gemini_service import get_gemini_response

data_hub_bp = Blueprint('data_hub', __name__)

@data_hub_bp.route('/')
def index():
    """Render the home page, redirecting to data hub"""
    return redirect(url_for('data_hub.data_hub'))

@data_hub_bp.route('/data-hub')
def data_hub():
    """Render the data hub page"""
    data_sources = DataSource.query.all()
    categories = current_app.config['DATA_CATEGORIES']
    return render_template('data_hub.html', 
                          data_sources=data_sources,
                          categories=categories,
                          active_page='data_hub')

@data_hub_bp.route('/api/data-sources', methods=['GET'])
def get_data_sources():
    """API endpoint to get all data sources"""
    try:
        data_sources = DataSource.query.all()
        result = []
        for source in data_sources:
            source_data = {
                'id': source.id,
                'name': source.name,
                'category': source.category,
                'last_updated': source.last_updated.isoformat() if source.last_updated else None,
                'row_count': source.row_count,
                'quality_metrics': source.quality_metrics if source.quality_metrics else {
                    'accuracy': 0.95,
                    'completeness': 0.92,
                    'consistency': 0.88,
                    'uniqueness': 0.97,
                    'validity': 0.93,
                    'timeliness': 0.85,
                    'overall_score': 0.90
                }
            }
            result.append(source_data)
        
        # Return sample data if no sources exist
        if not result:
            sample_categories = current_app.config.get('DATA_CATEGORIES', [
                {'name': 'Flights', 'sources': ['Flight Schedule', 'Flight Status']},
                {'name': 'Crew', 'sources': ['Crew Roster', 'Duty Times']},
                {'name': 'Aircraft', 'sources': ['Fleet Status', 'Maintenance Schedule']}
            ])
            
            for i, category in enumerate(sample_categories):
                result.append({
                    'id': i+1,
                    'name': f"Sample {category['name']} Data",
                    'category': category['name'],
                    'last_updated': None,
                    'row_count': 250,
                    'quality_metrics': {
                        'accuracy': 0.95,
                        'completeness': 0.92,
                        'consistency': 0.88,
                        'uniqueness': 0.97,
                        'validity': 0.93,
                        'timeliness': 0.85,
                        'overall_score': 0.90
                    }
                })
                
        return jsonify(result)
    except Exception as e:
        current_app.logger.error(f"Error getting data sources: {str(e)}")
        return jsonify({'error': str(e)}), 500

@data_hub_bp.route('/api/data-sources/<int:source_id>', methods=['GET'])
def get_data_source(source_id):
    """API endpoint to get a specific data source"""
    source = DataSource.query.get_or_404(source_id)
    return jsonify({
        'id': source.id,
        'name': source.name,
        'category': source.category,
        'file_path': source.file_path,
        'last_updated': source.last_updated.isoformat() if source.last_updated else None,
        'schema': source.schema,
        'row_count': source.row_count,
        'quality_metrics': source.quality_metrics
    })

@data_hub_bp.route('/api/upload-data', methods=['POST'])
def upload_data():
    """API endpoint to upload data from CSV file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not file.filename.endswith('.csv'):
        return jsonify({'error': 'Only CSV files are supported'}), 400
    
    # Get form data
    name = request.form.get('name', 'Unnamed Dataset')
    category = request.form.get('category', 'Uncategorized')
    
    # Save file temporarily
    filename = secure_filename(file.filename)
    temp_path = os.path.join('/tmp', filename)
    file.save(temp_path)
    
    try:
        # Read and analyze data
        df = pd.read_csv(temp_path)
        quality_metrics = analyze_data_quality(df)
        
        # Create data source in database
        data_source = DataSource(
            name=name,
            category=category,
            file_path=temp_path,
            schema=json.dumps(list(df.dtypes.astype(str).to_dict().items())),
            row_count=len(df),
            quality_metrics=quality_metrics
        )
        
        db.session.add(data_source)
        db.session.commit()
        
        # Save data to appropriate database tables based on category
        save_data_to_db(df, category, data_source.id)
        
        return jsonify({
            'success': True,
            'id': data_source.id,
            'name': data_source.name,
            'row_count': data_source.row_count,
            'quality_metrics': data_source.quality_metrics
        })
    
    except Exception as e:
        current_app.logger.error(f"Error processing uploaded file: {str(e)}")
        return jsonify({'error': str(e)}), 500

@data_hub_bp.route('/api/data-quality/<int:source_id>', methods=['GET'])
def get_data_quality(source_id):
    """API endpoint to get data quality metrics for a data source"""
    source = DataSource.query.get_or_404(source_id)
    return jsonify(source.quality_metrics or {})

@data_hub_bp.route('/api/generate-schema', methods=['POST'])
def generate_schema():
    """API endpoint to generate SQL schema from data using Gemini"""
    data = request.json
    if not data or 'columns' not in data:
        return jsonify({'error': 'No column data provided'}), 400
    
    columns = data['columns']
    with open('prompts/schema_to_sql.txt', 'r') as f:
        prompt = f.read()
    
    # Add columns to prompt
    full_prompt = prompt + "\n\nColumns:\n" + "\n".join(columns)
    
    try:
        response = get_gemini_response(full_prompt)
        return jsonify({'schema': response})
    except Exception as e:
        current_app.logger.error(f"Error generating schema: {str(e)}")
        return jsonify({'error': str(e)}), 500
        
@data_hub_bp.route('/api/reset-database', methods=['POST'])
def reset_database():
    """API endpoint to reset the database to original sample data"""
    try:
        current_app.logger.info("Resetting database to original sample data")
        
        # Clear all tables individually with logging
        table_counts = {}
        
        # Get count before deletion for logging
        table_counts['incidents'] = Incident.query.count()
        table_counts['alerts'] = Alert.query.count()
        table_counts['rules'] = Rule.query.count()
        table_counts['plans'] = OptimizationPlan.query.count()
        table_counts['flights'] = Flight.query.count()
        table_counts['aircraft'] = Aircraft.query.count()
        table_counts['crew'] = Crew.query.count()
        table_counts['data_sources'] = DataSource.query.count()
        
        # Delete all records from each table in order to handle dependencies
        Incident.query.delete()
        Alert.query.delete()
        Rule.query.delete()
        OptimizationPlan.query.delete()
        Flight.query.delete()
        Aircraft.query.delete()
        Crew.query.delete()
        DataSource.query.delete()
        
        # Commit deletions
        db.session.commit()
        
        current_app.logger.info(f"Deleted data: {table_counts}")
        
        # Repopulate with sample data
        populate_sample_data.create_sample_data()
        
        return jsonify({
            'success': True,
            'message': 'Database has been reset with sample data'
        })
    except Exception as e:
        current_app.logger.error(f"Error resetting database: {str(e)}")
        return jsonify({'error': str(e)}), 500
