import os

DATABRICKS_SERVER = "dbc-87c01ec6-8141.cloud.databricks.com"
DATABRICKS_HTTP_PATH = "/sql/1.0/warehouses/b8bcb7dafd785617"
DATABRICKS_TOKEN = "dapicfa88eff994131b784e22e6a06b500b7"

# Gemini API configuration
GEMINI_API_KEY = "AIzaSyAH7T_xWoXJpKALT1InmvLsEloTKE0hp34"

# SQLite database configuration
DATABASE_PATH = "adw_workbench.db"

# Analysis types displayed in the UI (from analysis_prompts.py)
ANALYSIS_TYPES = [
    {"value": "general", "name": "General Schema Analysis", "description": "Overall assessment of schema design, normalization, and relationships"},
    {"value": "performance", "name": "Performance Analysis", "description": "Evaluation of schema for performance optimization opportunities"},
    {"value": "normalization", "name": "Normalization Analysis", "description": "Assessment of normalization levels and potential data redundancy"},
    {"value": "relationships", "name": "Relationships Analysis", "description": "Focus on entity relationships, foreign keys, and referential integrity"},
    {"value": "naming", "name": "Naming Convention Analysis", "description": "Review of naming patterns for tables, columns, and constraints"},
    {"value": "standards", "name": "Standards Compliance", "description": "Evaluation against industry standard practices and patterns"}
]

# Diagram types displayed in the UI (from analysis_prompts.py)
DIAGRAM_TYPES = [
    {"value": "conceptual", "name": "Conceptual ERD", "description": "High-level view showing entities and relationships without attributes"},
    {"value": "logical", "name": "Logical ERD", "description": "Detailed diagram showing entities, attributes, and relationships without physical implementation details"},
    {"value": "physical", "name": "Physical ERD", "description": "Complete diagram showing tables, columns, data types, and all constraints"},
    {"value": "dependency", "name": "Dependency Diagram", "description": "Shows tables as nodes with dependencies flowing in direction of foreign key relationships"},
    {"value": "hierarchical", "name": "Hierarchical Diagram", "description": "Organizes tables in a hierarchical structure with parent/child relationships"}
]
