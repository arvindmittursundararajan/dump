from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
import json
import re
from datetime import datetime
import os
import logging
from extensions import db
from models import Message, Customer, Supplier

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'whatsapp-style-app'

# Database path configuration
DB_PATH = 'instance/inventory_new.db' if os.path.exists('instance/inventory_new.db') else 'inventory_new.db'

# ----- DATABASE FUNCTIONS -----
def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def execute_db(query, params=(), commit=False):
    """Execute database query and return results"""
    conn = get_db()
    cursor = conn.cursor()
    result = cursor.execute(query, params)
    
    if commit:
        conn.commit()
        last_id = cursor.lastrowid
        conn.close()
        return last_id
    
    rows = result.fetchall()
    conn.close()
    return rows

# ----- HELPER FUNCTIONS -----
def init_chat_db():
    """Initialize chat database tables"""
    try:
        db.create_all()
        logger.info("Chat database tables initialized successfully")
        return True
    except Exception as e:
        logger.error(f"Error initializing chat database: {str(e)}")
        return False

def add_message(user_id, content, user_type='customer', is_sent_by_admin=False, is_from_system=False):
    """Add a new message to the chat history"""
    try:
        # Create new message
        message = Message(
            content=content,
            customer_id=user_id if user_type == 'customer' else None,
            supplier_id=user_id if user_type == 'supplier' else None,
            is_sent_by_admin=is_sent_by_admin,
            is_from_system=is_from_system,
            timestamp=datetime.utcnow()
        )
        
        db.session.add(message)
        db.session.commit()
        logger.info(f"Added message for {user_type} {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error adding message: {str(e)}")
        db.session.rollback()
        return False

def get_chat_messages(user_id, user_type='customer'):
    """Get chat messages for a user"""
    try:
        if user_type == 'customer':
            messages = Message.query.filter_by(customer_id=user_id).order_by(Message.timestamp.asc()).all()
        else:
            messages = Message.query.filter_by(supplier_id=user_id).order_by(Message.timestamp.asc()).all()
        
        return [
            {
                'from': 'user' if not msg.is_sent_by_admin and not msg.is_from_system else 'bot',
                'text': msg.content,
                'timestamp': msg.timestamp,
                'is_system': msg.is_from_system
            }
            for msg in messages
        ]
    except Exception as e:
        logger.error(f"Error getting chat messages: {str(e)}")
        return []

def handle_chat_message(message, user_id, user_type, products, cart_session_key):
    """Handle incoming chat messages and generate responses"""
    show_order_actions = False
    
    # Add the user's message to history
    add_message(user_id, message, user_type)
    
    # Add placeholder response
    response = "I'll help you with that. What would you like to know about our products?"
    add_message(user_id, response, user_type, is_sent_by_admin=True)
    
    return [
        {
            'from': 'bot',
            'text': response,
            'timestamp': datetime.utcnow(),
            'is_system': False
        }
    ], show_order_actions

# ----- ROUTES -----
@app.route('/')
def home():
    return redirect('/customers')

def get_user_overview(user_type):
    """Common handler for customer/supplier overview pages"""
    try:
        users_db = execute_db(f"SELECT * FROM {user_type}")
        users = []
        
        for user in users_db:
            user_dict = dict(user)
            last_msg = execute_db(
                f"SELECT content, timestamp FROM message WHERE {user_type}_id=? ORDER BY timestamp DESC LIMIT 1",
                (user['id'],)
            )
            
            if last_msg:
                user_dict['last_message'] = last_msg[0]['content']
                user_dict['last_message_time'] = (
                    datetime.fromisoformat(last_msg[0]['timestamp']) 
                    if last_msg[0]['timestamp'] else None
                )
            else:
                user_dict['last_message'] = None
                user_dict['last_message_time'] = None
                
            users.append(user_dict)
        
        return render_template('chat/overview.html', users=users, user_type=user_type)
    except Exception as e:
        return str(e)

def handle_chat(user_id, user_type):
    """Common handler for customer/supplier chat pages"""
    try:
        # Initialize chat session
        session_key = f'{user_type}_{user_id}_messages'
        if session_key not in session:
            session[session_key] = []
        
        # Get user
        user_rows = execute_db(f"SELECT * FROM {user_type} WHERE id=?", (user_id,))
        if not user_rows:
            return f"{user_type.title()} not found", 404
        
        user = dict(user_rows[0])
        show_order_actions = False
        
        # Get existing messages
        messages = []
        db_messages = get_chat_messages(user_id, user_type)
        
        for msg in db_messages:
            messages.append({
                'from': 'user' if not msg['is_sent_by_admin'] and not msg['is_from_system'] else 'bot',
                'text': msg['content'],
                'timestamp': datetime.fromisoformat(msg['timestamp']) if msg['timestamp'] else datetime.now(),
                'is_system': msg['is_from_system'],
                'is_product_list': False
            })
        
        # Handle new messages
        if request.method == 'POST':
            message = request.form.get('message', '').strip()
            
            if message:
                # Get products based on user type
                if user_type == 'customer':
                    products = execute_db("SELECT * FROM product WHERE quantity > 0")
                else:
                    products = execute_db("SELECT * FROM product")
                
                cart_session_key = f'{user_type}_{user_id}_cart'
                new_messages, show_actions = handle_chat_message(
                    message,
                    user_id,
                    user_type,
                    products,
                    cart_session_key
                )
                messages.extend(new_messages)
                show_order_actions = show_actions
        
        # Get product data for rendering
        products = execute_db(
            "SELECT * FROM product WHERE quantity > 0"
            if user_type == 'customer'
            else "SELECT * FROM product"
        )
        
        return render_template(
            'chat/chat.html',
            user=user,
            messages=messages,
            user_type=user_type,
            products=products,
            show_order_actions=show_order_actions
        )
    except Exception as e:
        return str(e)

# Chat route handlers
@app.route('/api/chat/send', methods=['POST'])
def send_chat_message():
    """Handle chat messages and prevent duplication"""
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        user_type = data.get('user_type', 'customer')
        user_id = data.get('user_id', 1)
        
        if not message:
            return jsonify({'status': 'error', 'message': 'No message provided'})
            
        # Add user message to database
        add_message(user_id, message, user_type)
        
        # Generate response using AI/business logic
        if 'order' in message.lower():
            response = "I can help you place an order. What would you like to order?"
        elif 'product' in message.lower():
            response = "I can help you find product information. Which product are you interested in?"
        else:
            response = "How can I assist you today?"
            
        # Add bot response to database
        add_message(user_id, response, user_type, is_sent_by_admin=True)
        
        return jsonify({
            'status': 'success',
            'response': response
        })
        
    except Exception as e:
        logger.error(f"Error processing chat message: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

# Customer routes
@app.route('/customers')
def customers():
    return get_user_overview('customer')

@app.route('/customer/<int:id>', methods=['GET', 'POST'])
def customer_chat(id):
    return handle_chat(id, 'customer')

# Supplier routes
@app.route('/suppliers')
def suppliers():
    return get_user_overview('supplier')

@app.route('/supplier/<int:id>', methods=['GET', 'POST'])
def supplier_chat(id):
    return handle_chat(id, 'supplier')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)