# Data Hub

## Overview
The Data Hub module serves as the central repository for all operational data within the AeroOptima.ai platform. It provides tools for data import, quality assessment, and management, ensuring that decision-makers have access to high-quality, up-to-date information.

## URL Route
- Main URL: `/data-hub`
- Default landing page for the application

## Key Features

### 1. Data Source Management
- **View Data Sources**: Browse all available data sources categorized by type
- **Data Quality Metrics**: Visual indicators of completeness, accuracy, and timeliness
- **Detailed Statistics**: Row counts, last updated timestamps, and schema information

### 2. Data Upload Capabilities
- **CSV Import**: Upload flight, crew, or aircraft data via CSV files
- **Data Validation**: Automatic validation against expected schemas
- **Error Handling**: Clear error messages for invalid data formats

### 3. Data Quality Analysis
- **Quality Scoring**: Automatic calculation of data quality metrics
- **Missing Value Detection**: Identification of gaps in critical data
- **Anomaly Highlighting**: Flagging of potential data issues

### 4. Schema Generation
- **AI-Powered Schema Creation**: Generate SQL schemas using natural language descriptions
- **Schema Validation**: Ensure uploaded data matches expected formats
- **Schema Evolution Tracking**: Monitor changes to data structures over time

## User Interface Components

### Data Source Cards
Each data source is represented by a card showing:
- Source name
- Category (Flights, Crew, Aircraft, etc.)
- Last updated timestamp
- Row count
- Quality score with visual indicator

### Data Upload Form
- File selection input
- Category dropdown
- Upload progress indicator
- Success/failure notifications

### Quality Metrics Display
- Radar charts showing completeness, consistency, and timeliness
- Color-coded indicators (red, yellow, green)
- Detailed breakdown available on hover/click

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/data-sources` | GET | Retrieve all data sources |
| `/api/data-sources/<id>` | GET | Get specific data source details |
| `/api/upload-data` | POST | Upload new data file |
| `/api/data-quality/<id>` | GET | Get quality metrics for a data source |
| `/api/generate-schema` | POST | Generate SQL schema from description |
| `/api/reset-database` | POST | Reset database to sample data |

## Database Models
The Data Hub uses the `DataSource` model with the following key fields:
- `id`: Unique identifier
- `name`: Display name
- `category`: Type categorization
- `file_path`: Source file location
- `last_updated`: Timestamp of last update
- `schema`: JSON representation of data structure
- `row_count`: Number of records
- `quality_metrics`: JSON object with quality scores

## Interactions with Other Modules
- Provides base data for **Monitoring** alert rules
- Supplies operational data for **Optimizer** scenarios
- Feeds historical information to **Debrief** incidents

## Technical Implementation
- Uses Flask routes in `routes/data_hub.py`
- Leverages Pandas for data processing
- Stores data in SQLite database (configurable to PostgreSQL)
- Client-side rendering with Bootstrap and custom JavaScript

## Best Practices
1. Regularly upload fresh data to ensure accuracy
2. Review quality metrics before using data for decision-making
3. Use consistent naming conventions for related data sources
4. Utilize the schema generator for complex data structures