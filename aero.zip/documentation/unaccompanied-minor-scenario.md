# Unaccompanied Minor Scenario

## Overview
The Unaccompanied Minor (UM) scenario is a specialized optimization and monitoring framework within AeroOptima.ai designed to ensure the safe and efficient handling of minors traveling alone. This scenario incorporates specialized rules, constraints, and optimization algorithms to prioritize the welfare of these vulnerable passengers during normal operations and especially during disruptions.

## Business Context
Airlines have a special duty of care for unaccompanied minors, who are typically children aged 5-14 traveling without an adult guardian. These passengers require:

- Dedicated staff supervision during connections
- Carefully managed itineraries to avoid risky situations
- Priority handling during irregular operations
- Clear communication with guardians
- Compliance with specific airline and regulatory policies

## Integration Points

### Monitoring Module
- **Specialized UM Alert Rules**: Automatically detect situations that could impact UMs
- **Staff Availability Tracking**: Monitor staffing levels at connection stations
- **Connection Risk Assessment**: Evaluate the risk level of connections for UMs
- **Guardian Communication Alerts**: Prompt for required communications

### Optimizer Module
- **UM-Specific Constraints**: Additional safety constraints for UM itineraries
- **Staff Allocation Optimization**: Ensure proper staffing for UM handling
- **Recovery Prioritization**: Place UMs at the top of recovery priority list
- **Connection Planning**: Create safe connection plans during disruptions

### Debrief Module
- **UM Handling Analysis**: Special focus on UM experience during incidents
- **Safety Measure Effectiveness**: Review of safety protocols for UMs
- **Communication Evaluation**: Assessment of guardian communications
- **Policy Compliance Verification**: Confirm adherence to UM policies

## Key Business Rules

### Safety Rules
1. **No Overnight Transit**: UMs must not stay overnight at a connecting station
2. **Maximum Connections**: UMs are limited to at most one connection per journey
3. **Minimum Staff Requirements**: At least two qualified staff must be available at transit stations
4. **Protected Connection Time**: Minimum 45-minute, maximum 90-minute connections
5. **Daylight Operations**: When possible, schedule UMs on daytime flights only
6. **Guardian Contact Requirements**: Guardians must be contactable throughout journey

### Optimization Priorities
1. **Safety Score**: Primary metric based on compliance with safety rules
2. **Satisfaction Score**: Secondary metric for passenger experience
3. **Cost Considerations**: Tertiary concern after safety and satisfaction
4. **Recovery Speed**: Quick resolution of disruptions affecting UMs

## Technical Implementation

### Data Models
The system utilizes several data fields specifically for UM handling:

```python
# In Flight model
is_um_on_board = db.Column(db.Boolean, default=False)
um_count = db.Column(db.Integer, default=0)
um_details = db.Column(JSON, nullable=True)  # List of UM records

# In Airport model
um_staff_count = db.Column(db.Integer, default=0)
um_facilities = db.Column(db.Boolean, default=False)

# In Crew model
um_qualified = db.Column(db.Boolean, default=False)
```

### Rule Implementation
Example of a UM-specific monitoring rule:

```python
# Detection rule for insufficient staff
{
    "name": "Insufficient UM Staff at Connection",
    "rule_text": "flight.um_count > 0 and flight.is_connection and airport.um_staff_count < 2",
    "severity": "critical",
    "category": "unaccompanied_minor"
}

# Detection rule for at-risk connections
{
    "name": "UM at Risk of Missed Connection",
    "rule_text": "flight.um_count > 0 and flight.arrival_delay > 15 and flight.has_connections",
    "severity": "critical",
    "category": "unaccompanied_minor"
}
```

### Optimization Algorithm
The UM optimization uses a specialized algorithm:

```python
def optimize_unaccompanied_minor_scenario(flights, connections, staff, constraints):
    """
    Specialized optimization for unaccompanied minor scenarios
    
    Args:
        flights: List of flight objects
        connections: Dictionary of connection information
        staff: Staff availability by station
        constraints: Dictionary of constraint parameters
    
    Returns:
        Dictionary with optimized solution
    """
    # Create PuLP model
    model = LpProblem("UM_Optimization", LpMaximize)
    
    # Key constraints
    no_overnight_transit = constraints.get('no_overnight_transit', True)
    max_connections = constraints.get('max_connections', 1)
    min_staff_at_transit = constraints.get('min_staff_at_transit', 2)
    
    # Decision variables
    # ... (implementation details)
    
    # Objective function
    # Primary: safety score
    # Secondary: passenger satisfaction
    # Tertiary: operational cost
    
    # Model constraints
    # ... (implementation details)
    
    # Solve model
    model.solve()
    
    # Process results
    # ... (implementation details)
    
    return results
```

## User Interface Elements

### Monitoring Dashboard UM Indicators
- **UM Flight Tags**: Visual indicators on flights with UMs
- **Staff Level Indicator**: Shows station staffing status for UM handling
- **Connection Risk Meter**: Displays risk level for UM connections

### Optimizer UM Constraints Panel
- **UM Safety Toggles**: Enable/disable specific safety constraints
- **Staff Allocation Slider**: Adjust minimum staff requirements
- **Connection Time Controls**: Set allowable connection time ranges
- **Priority Weighting**: Balance safety, satisfaction, and cost

### Debrief UM Analysis Section
- **UM Safety Compliance**: Verification of safety protocol adherence
- **Guardian Communication Log**: Record of communications with guardians
- **Staff Intervention Timeline**: Documentation of staff assistance
- **Satisfaction Evaluation**: Assessment of UM experience during incident

## Workflow Example: Winter Storm Scenario

### 1. Triggering Event
- Winter storm impacts Chicago O'Hare (ORD)
- Cascading flight delays affect multiple connecting UMs

### 2. System Response
- **Monitoring**: Alerts triggered for UMs at risk of missing connections
- **Alerts**: Notifications for operations team and UM staff

### 3. Optimization Process
- **Constraint Activation**: UM safety constraints given highest priority
- **Solution Generation**: Alternative routing options identified
- **Staff Allocation**: UM staff reallocated to accommodate new plan
- **Communication Plan**: Guardian notification sequence prepared

### 4. Implementation Actions
- Rebook UMs on appropriate flights
- Ensure staff coverage at all connection points
- Communicate changes to guardians with clear instructions
- Document all actions for compliance purposes

### 5. Debrief Analysis
- Review effectiveness of UM handling during disruption
- Identify any process improvements or training needs
- Document lessons learned for future incidents
- Update rules and constraints based on findings

## Key Performance Indicators

### Safety Metrics
- **UM Overnight Rate**: Percentage of UMs requiring overnight stay (target: 0%)
- **Supervision Coverage**: Percentage of UMs with proper staff supervision (target: 100%)
- **Guardian Communication Rate**: Percentage of guardians contacted within 15 minutes of disruption (target: 100%)

### Satisfaction Metrics
- **UM Delay Time**: Average delay time for UMs vs. regular passengers
- **Itinerary Change Count**: Number of rebookings required per UM
- **Journey Completion Rate**: Percentage of UMs reaching final destination within 12 hours of schedule

### Operational Metrics
- **UM Recovery Cost**: Additional cost to prioritize UM handling
- **Staff Utilization**: Efficiency of UM staff allocation
- **Process Compliance**: Adherence to all UM handling protocols

## Best Practices

### For Operations Controllers
1. Always verify UM status on affected flights before making changes
2. Prioritize UM handling in any recovery scenario
3. Ensure continuous communication with guardians
4. Document all decisions regarding UM itineraries
5. Verify staff availability before finalizing any UM plans

### For System Administrators
1. Regularly update UM handling rules as policies change
2. Set appropriate alert thresholds to avoid false positives
3. Ensure UM constraints are properly weighted in optimization models
4. Create dedicated reporting for UM handling performance
5. Maintain updated contact information for guardians and staff

## Training Resources
- UM Handling Procedures Guide
- Staff Certification Requirements
- Guardian Communication Templates
- Regulatory Compliance Documentation
- Incident Response Protocols