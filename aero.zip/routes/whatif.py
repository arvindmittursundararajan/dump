from flask import Blueprint, render_template, request, jsonify, current_app
from models import Incident, OptimizationPlan, Flight, Aircraft, Crew
from app import db
from datetime import datetime, timedelta
import json
from services.gemini_service import get_gemini_response, clean_text
from services.optimization_service import run_optimization, calculate_optimization_score

whatif_bp = Blueprint('whatif', __name__)

@whatif_bp.route('/whatif')
def whatif():
    """Render the what-if analysis page"""
    incidents = Incident.query.order_by(Incident.start_time.desc()).limit(10).all()
    
    # Get referenced optimization plans
    plan_ids = [incident.optimization_plan_id for incident in incidents if incident.optimization_plan_id]
    plans = OptimizationPlan.query.filter(OptimizationPlan.id.in_(plan_ids)).all() if plan_ids else []
    
    return render_template('whatif.html', 
                         incidents=incidents,
                         plans=plans,
                         active_page='whatif')

@whatif_bp.route('/api/whatif/scenarios', methods=['POST'])
def generate_whatif_scenarios():
    """API endpoint to generate what-if scenarios based on an incident"""
    data = request.json
    
    if not data or 'incident_id' not in data:
        return jsonify({'error': 'Missing incident ID'}), 400
    
    # Get the incident
    incident_id = data['incident_id']
    incident = Incident.query.get_or_404(incident_id)
    
    # Get the parameters for what-if analysis
    params = {
        'delay_minutes': data.get('delay_minutes', 0),
        'um_count': data.get('um_count', 0),
        'aircraft_availability': data.get('aircraft_availability', 100),
        'crew_availability': data.get('crew_availability', 100),
        'weather_severity': data.get('weather_severity', 0)
    }
    
    try:
        # Generate scenarios using Gemini
        scenarios = generate_scenarios(incident, params)
        
        # Return the generated scenarios
        return jsonify({'scenarios': scenarios})
    except Exception as e:
        current_app.logger.error(f"Error generating what-if scenarios: {str(e)}")
        return jsonify({'error': str(e)}), 500

@whatif_bp.route('/api/whatif/visualize', methods=['POST'])
def visualize_scenario():
    """API endpoint to generate a visualization for a what-if scenario"""
    data = request.json
    
    if not data or 'scenario' not in data:
        return jsonify({'error': 'No scenario provided'}), 400
    
    scenario = data['scenario']
    
    with open('prompts/whatif_visualization.txt', 'r') as f:
        prompt = f.read()
    
    full_prompt = prompt + "\n\nScenario: " + json.dumps(scenario)
    
    try:
        # Get the raw response
        raw_response = get_gemini_response(full_prompt)
        
        # Apply special Mermaid-specific cleaning
        cleaned_diagram = clean_text(raw_response, is_mermaid=True)
        
        # Log the generated diagram for debugging
        current_app.logger.info(f"Generated what-if diagram (first 100 chars): {cleaned_diagram[:100]}...")
        
        return jsonify({'diagram': cleaned_diagram})
    except Exception as e:
        current_app.logger.error(f"Error generating what-if visualization: {str(e)}")
        return jsonify({'error': str(e)}), 500

@whatif_bp.route('/api/whatif/simulate', methods=['POST'])
def simulate_scenario():
    """API endpoint to simulate a what-if scenario and calculate metrics"""
    data = request.json
    
    if not data or 'scenario' not in data:
        return jsonify({'error': 'No scenario provided'}), 400
    
    scenario = data['scenario']
    
    try:
        # Create a new optimization plan based on the scenario
        plan = OptimizationPlan(
            name=f"What-If: {scenario.get('name', 'Scenario')}",
            description=scenario.get('description', ''),
            scenario=json.dumps(scenario),
            constraints=scenario.get('constraints', {}),
            objective_weights={
                'delay_cost': 0.3,
                'passenger_impact': 0.3,
                'operational_feasibility': 0.2,
                'crew_impact': 0.1,
                'aircraft_utilization': 0.1
            },
            status="draft"
        )
        
        # Calculate the metrics for this scenario without saving to DB
        results, score, execution_time = run_optimization(plan)
        
        # Return the simulation results
        return jsonify({
            'results': results,
            'score': score,
            'execution_time': execution_time,
            'metrics': calculate_scenario_metrics(scenario, results)
        })
    except Exception as e:
        current_app.logger.error(f"Error simulating what-if scenario: {str(e)}")
        return jsonify({'error': str(e)}), 500

def generate_scenarios(incident, params):
    """Generate what-if scenarios using Gemini"""
    # Prepare incident data and parameters
    incident_data = {
        'title': incident.title,
        'description': incident.description,
        'timeline': incident.timeline,
        'affected_entities': incident.affected_entities,
        'root_cause': incident.root_cause,
        'parameters': params
    }
    
    with open('prompts/whatif_scenarios.txt', 'r') as f:
        prompt = f.read()
    
    full_prompt = prompt + "\n\nIncident Data: " + json.dumps(incident_data)
    
    # Get response from Gemini
    response = get_gemini_response(full_prompt)
    
    try:
        # Parse the response as JSON
        scenarios = json.loads(response)
        return scenarios
    except json.JSONDecodeError:
        # If not valid JSON, try to extract JSON from the text
        try:
            json_start = response.find('[')
            json_end = response.rfind(']') + 1
            if json_start >= 0 and json_end > json_start:
                scenarios = json.loads(response[json_start:json_end])
                return scenarios
        except:
            pass
        # Return a simple format as fallback
        return [{'name': 'Error parsing scenarios', 'description': response}]

def calculate_scenario_metrics(scenario, results):
    """Calculate metrics for a what-if scenario"""
    # This would be replaced with actual calculations based on your specific metrics
    metrics = {
        'passenger_impact': {
            'stranded_passengers': results.get('affected_passengers', 0),
            'um_impact': results.get('affected_um', 0),
            'missed_connections': results.get('missed_connections', 0)
        },
        'operational_impact': {
            'total_delay_minutes': results.get('total_delay_minutes', 0),
            'cancellations': results.get('cancellations', 0),
            'aircraft_swaps': results.get('aircraft_swaps', 0)
        },
        'cost_impact': {
            'delay_cost': results.get('delay_cost', 0),
            'passenger_compensation': results.get('passenger_compensation', 0),
            'crew_overtime': results.get('crew_overtime', 0)
        }
    }
    return metrics