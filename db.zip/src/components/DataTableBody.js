import React from 'react';
import { IconButton, Button, TableRow, TableCell } from '@mui/material';
import { EditIcon, DeleteIcon, PlayIcon, PauseIcon } from './DataTableIcons';

const DataTableBody = ({ 
  currentData, 
  columns, 
  onEdit, 
  onDelete, 
  onRun, 
  onToggle,
  searchTerm,
  useMui = true
}) => {
  if (currentData.length === 0) {
    if (useMui) {
      return (
        <TableRow>
          <TableCell colSpan={columns.length + (onEdit || onDelete || onRun || onToggle ? 1 : 0)} align="center">
            {searchTerm ? 'No results found for your search.' : 'No data available.'}
          </TableCell>
        </TableRow>
      );
    } else {
      return (
        <tr>
          <td colSpan={columns.length + (onEdit || onDelete || onRun || onToggle ? 1 : 0)} className="no-data">
            {searchTerm ? 'No results found for your search.' : 'No data available.'}
          </td>
        </tr>
      );
    }
  }

  return currentData.map((item, index) => (
    useMui ? (
      <TableRow key={item.id || index}>
        {columns.map((column) => (
          <TableCell key={column.key}>
            {column.render ? column.render(item[column.key], item) : item[column.key]}
          </TableCell>
        ))}
        {(onEdit || onDelete || onRun || onToggle) && (
          <TableCell align="center">
            {onRun && (
              <IconButton color="primary" onClick={() => onRun(item)} title="Run">
                <PlayIcon />
              </IconButton>
            )}
            {onToggle && (
              <IconButton color="warning" onClick={() => onToggle(item)} title={item.active ? 'Pause' : 'Resume'}>
                {item.active ? <PauseIcon /> : <PlayIcon />}
              </IconButton>
            )}
            {onEdit && (
              <IconButton color="secondary" onClick={() => onEdit(item)} title="Edit">
                <EditIcon />
              </IconButton>
            )}
            {onDelete && (
              <IconButton color="error" onClick={() => onDelete(item)} title="Delete">
                <DeleteIcon />
              </IconButton>
            )}
          </TableCell>
        )}
      </TableRow>
    ) : (
      <tr key={item.id || index}>
        {columns.map((column) => (
          <td key={column.key}>
            {column.render ? column.render(item[column.key], item) : item[column.key]}
          </td>
        ))}
        {(onEdit || onDelete || onRun || onToggle) && (
          <td className="actions-cell">
            <div className="action-buttons">
              {onRun && (
                <button
                  className="btn btn-sm btn-outline-primary"
                  onClick={() => onRun(item)}
                  title="Run"
                >
                  <PlayIcon />
                </button>
              )}
              {onToggle && (
                <button
                  className="btn btn-sm btn-outline-warning"
                  onClick={() => onToggle(item)}
                  title={item.active ? 'Pause' : 'Resume'}
                >
                  {item.active ? <PauseIcon /> : <PlayIcon />}
                </button>
              )}
              {onEdit && (
                <button
                  className="btn btn-sm btn-outline-secondary"
                  onClick={() => onEdit(item)}
                  title="Edit"
                >
                  <EditIcon />
                </button>
              )}
              {onDelete && (
                <button
                  className="btn btn-sm btn-outline-danger"
                  onClick={() => onDelete(item)}
                  title="Delete"
                >
                  <DeleteIcon />
                </button>
              )}
            </div>
          </td>
        )}
      </tr>
    )
  ));
};

export default DataTableBody; 