import os
from pathlib import Path

# API Keys and credentials
DATABRICKS_SERVER = os.environ.get('DATABRICKS_SERVER', 'dbc-41318e58-8d93.cloud.databricks.com')
DATABRICKS_HTTP_PATH = os.environ.get('DATABRICKS_HTTP_PATH', 'sql/1.0/warehouses/c78e7c7680632b7c')
DATABRICKS_TOKEN = os.environ.get('DATABRICKS_TOKEN', 'dapi70ab1da3cf69bf63da76c6770872c219')

# Google Gemini API integration settings
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyDGxIRaPUWoDsNvMbFJ0qx_WZOd72CbeTY')

# Database settings
DATABASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'adw_workbench.db')

# Cache settings
CACHE_TTL_SECONDS = 3600  # 1 hour

# Analysis types available in the application
ANALYSIS_TYPES = {
    'general': {
        'name': 'General Schema Analysis', 
        'value': 'general',
        'description': 'Overview of tables, relationships, primary/foreign keys, and general recommendations.'
    },
    'performance': {
        'name': 'Performance Optimization', 
        'value': 'performance',
        'description': 'Identifies performance bottlenecks, indexing opportunities, and query optimization suggestions.'
    },
    'normalization': {
        'name': 'Normalization Assessment', 
        'value': 'normalization',
        'description': 'Evaluates database normalization, identifies redundancies, and suggests improvements.'
    },
    'relationships': {
        'name': 'Relationship Analysis', 
        'value': 'relationships',
        'description': 'Focuses on entity relationships, cardinality, and referential integrity issues.'
    },
    'naming': {
        'name': 'Naming Convention Review', 
        'value': 'naming',
        'description': 'Reviews consistency of naming patterns and suggests standards-based improvements.'
    },
    'standards': {
        'name': 'Standards Compliance', 
        'value': 'standards',
        'description': 'Checks adherence to industry best practices and Databricks-specific conventions.'
    }
}