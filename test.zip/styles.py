# styles.py

STYLES = {
    "font_family": "'Segoe UI', Arial, sans-serif",
    "base_font_size": "16px",
    "heading_font_size": "2em",
    "heading_color": "#C8102E",  # Standard and Poor Red
    "text_color": "#111",
    "background_color": "#fff",
    "secondary_text_color": "#333",
    "link_color": "#007acc",
    "blockquote_bg": "#f9f9f9",
    "blockquote_border": "#C8102E",
    "code_bg": "#222",
    "code_color": "#fff",
    "border_radius": "8px",
    "button_bg": "#C8102E",
    "button_color": "#fff",
    "button_radius": "4px",
}

def style_description():
    """
    Returns a string describing the style guidelines for the LLM prompt.
    """
    return (
        "Use the following style guidelines for all generated HTML content: "
        "- Headings must use 'Standard and Poor Red' (#C8102E). "
        "- Use a lot of black (#111) and white (#fff) for text and backgrounds. "
        "- Font family: Segoe UI, Arial, sans-serif. "
        "- Base font size: 16px. "
        "- Headings: 2em, bold, red. "
        "- Body text: #111, 16px. "
        "- Links: #007acc. "
        "- Blockquotes: light gray background, red border. "
        "- Code: dark background, white text. "
        "- Buttons: red background, white text, rounded corners. "
        "- Use semantic HTML tags. "
        "- All styles must be inline or in a <style> block in the <head>. "
    ) 