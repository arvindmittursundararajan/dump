from flask import Blueprint, request, jsonify, current_app
import json
import logging
from datetime import datetime
from services.gemini_service import get_gemini_response

# Configure logging
logger = logging.getLogger(__name__)

# Create blueprint
chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/api/chat', methods=['POST'])
def chat():
    """API endpoint for chatting with Gemini"""
    try:
        data = request.json
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        message = data.get('message')
        context = data.get('context', {})
        
        if not message:
            return jsonify({'error': 'No message provided'}), 400
        
        # Log the request
        logger.info(f"Chat request: {message[:100]}...")
        
        # Create an enhanced prompt with context information
        prompt = create_enhanced_prompt(message, context)
        
        # Get response from Gemini
        response = get_gemini_response(prompt)
        
        # Return the response
        return jsonify({
            'response': response,
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.exception(f"Error in chat endpoint: {str(e)}")
        return jsonify({'error': str(e)}), 500

def create_enhanced_prompt(message, context):
    """Create an enhanced prompt with context information"""
    
    # Base prompt with system instruction
    base_prompt = """You are Gemini, an AI assistant for AeroOptima.ai, an airline operations optimization platform. 
    Your goal is to help airline staff analyze data, optimize operations, and respond to disruptions.
    You should provide clear, concise answers focused on airline operations and optimization.
    When appropriate, reference specific metrics, KPIs, or aviation industry standards.
    """
    
    # Add page-specific context
    page_context = ""
    if context and 'page' in context:
        page = context.get('page')
        
        if page == 'data_hub':
            page_context = "The user is currently in the Data Hub module, where they can view and manage data sources for aircraft, crew, flights, and other airline data."
            
            # Add information about available data sources
            if 'dataSources' in context and context['dataSources']:
                data_sources = context['dataSources']
                page_context += f"\nThe user has access to {len(data_sources)} data sources:"
                for source in data_sources[:5]:  # Limit to first 5 to avoid overly long prompts
                    page_context += f"\n- {source.get('name')} ({source.get('category')})"
                if len(data_sources) > 5:
                    page_context += f"\n- And {len(data_sources) - 5} more data sources"
                    
        elif page == 'live_watch':
            page_context = "The user is currently in the Live Watch module, where they can monitor real-time alerts and events for their airline operations."
            
            # Add information about active alerts
            if 'alerts' in context and context['alerts']:
                alerts = context['alerts']
                page_context += f"\nThere are currently {len(alerts)} active alerts:"
                for alert in alerts[:3]:  # Limit to first 3
                    page_context += f"\n- {alert.get('title')} ({alert.get('severity')})"
                if len(alerts) > 3:
                    page_context += f"\n- And {len(alerts) - 3} more alerts"
            
        elif page == 'optimizer':
            page_context = "The user is currently in the Optimizer module, where they can create and run optimization plans for different airline disruption scenarios."
            
            # Add information about optimization plans
            if 'plans' in context and context['plans']:
                plans = context['plans']
                page_context += f"\nThe user has {len(plans)} optimization plans:"
                for plan in plans[:3]:  # Limit to first 3
                    page_context += f"\n- {plan.get('name')} (Scenario: {plan.get('scenario')}, Status: {plan.get('status')})"
                if len(plans) > 3:
                    page_context += f"\n- And {len(plans) - 3} more plans"
            
        elif page == 'debrief':
            page_context = "The user is currently in the Debrief module, where they can analyze past incidents and create postmortem reports."
            
            # Add information about incidents
            if 'incidents' in context and context['incidents']:
                incidents = context['incidents']
                page_context += f"\nThe user has {len(incidents)} incidents to analyze:"
                for incident in incidents[:3]:  # Limit to first 3
                    page_context += f"\n- {incident.get('title')} (Category: {incident.get('category')}, Severity: {incident.get('severity')})"
                if len(incidents) > 3:
                    page_context += f"\n- And {len(incidents) - 3} more incidents"
    
    # Combine all parts into the final prompt
    final_prompt = f"{base_prompt}\n\n{page_context}\n\nUser question: {message}\n\nPlease provide a helpful response:"
    
    return final_prompt