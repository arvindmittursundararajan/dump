"""
Analysis prompts for ADW Workbench data modeling tool.
These prompts are used with the Google Gemini API to analyze database schemas.
"""

# General schema analysis prompt
ANALYSIS_PROMPT = """
You are a data modeling expert analyzing a database schema. Provide a detailed analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Analysis Type: {analysis_type}

Please provide a thorough analysis focusing on the {analysis_type} aspects. Format your response using Markdown, including headers, bullet points, and code blocks where appropriate.

Include the following sections in your analysis:
1. Overview of the schema
2. Key entities and relationships
3. Strengths of the current schema
4. Potential issues or weaknesses
5. Recommendations for improvement

Focus specifically on {analysis_type} considerations.
"""

# Diagram generation prompt
DIAGRAM_PROMPT = """
You are a data modeling expert generating a database diagram. Create a {0} diagram for the following database schema using mermaid.js syntax:

Database: {1}
Tables: {2}

Schema Information:
{3}

Instructions for diagram type: {0}

If the diagram type is conceptual, logical, physical, or erd:
- Use erDiagram syntax (starts with 'erDiagram')
- For conceptual: Show only entity names and relationships, no attributes
- For logical: Show entity names, primary keys, and relationships
- For physical: Include all columns with data types and constraints
- Use proper cardinality notation (||--o|, etc.)

If the diagram type is dependency:
- Use flowchart syntax (starts with 'flowchart TD')
- Show tables as nodes with dependencies flowing in direction of foreign key relationships
- Use different node shapes for different types of tables
- Connect related tables with arrows indicating dependency direction

If the diagram type is hierarchical:
- Use classDiagram syntax (starts with 'classDiagram')
- Organize tables in a hierarchical structure with parent/child relationships
- Show inheritance or composition relationships where appropriate
- Include key fields and relationships

Return ONLY the mermaid.js code without any explanation or additional text. The code should be in a format that can be directly used with mermaid.js.
"""

# Mapping sheet generation prompt
MAPPING_SHEET_PROMPT = """
You are a data governance specialist creating a comprehensive data mapping sheet. Generate detailed metadata for each table in the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

For each table, provide the following information in a structured format:
1. Technical name (the actual table name)
2. Business name (a user-friendly name for the table)
3. Description (purpose and contents of the table)
4. Entity type (transactional, master data, reference, etc.)
5. Classification (public, internal, confidential, restricted)
6. List of columns, each with:
   - Technical name
   - Business name
   - Data type
   - Description
   - Domain values (possible values or constraints)
   - Business rules
   - Sample values (2-3 example values)

Format your response as a structured JSON object that can be easily parsed. Use the following schema:
{
  "tables": [
    {
      "technical_name": "string",
      "business_name": "string",
      "description": "string",
      "entity_type": "string",
      "classification": "string", 
      "columns": [
        {
          "technical_name": "string",
          "business_name": "string",
          "data_type": "string",
          "description": "string",
          "domain_values": "string",
          "business_rules": "string",
          "sample_values": ["string", "string"]
        }
      ]
    }
  ]
}

Make educated guesses where necessary based on column names and data types, but keep them plausible.
"""

# CASTLE compliance assessment prompt
COMPLIANCE_PROMPT = """
You are a data compliance and governance expert. Perform a CASTLE (Compliance, Auditability, Security, Traceability, Lineage, Ethics) assessment on the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

For each dimension of the CASTLE framework, provide:
1. A score from 1 (Poor) to 5 (Excellent)
2. Key strengths (2-3 points)
3. Key weaknesses (2-3 points)
4. Specific recommendations for improvement (2-3 points)

Also provide an overall weighted score for the entire schema.

Additionally, include the following readability scores for the schema:
1. Flesch-Kincaid Readability Score (0-100, where higher means more readable)
2. Gunning Fog Index (measures text complexity, where lower means more readable)

These scores should evaluate the naming conventions, descriptions, and overall clarity of the database schema.

Format your response as a structured JSON object that can be easily parsed. Use the following schema:
{
  "overall_score": float,
  "readability_scores": {
    "flesch_kincaid": float,
    "gunning_fog": float,
    "summary": "string"
  },
  "compliance": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "auditability": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "security": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "traceability": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "lineage": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "ethics": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  }
}

Base your assessment on industry standards and best practices for data governance and management.
"""

# SQL query generation prompt
QUERY_PROMPT = """
You are a SQL expert with deep knowledge of database schemas. Generate a SQL query for the following natural language prompt:

Database: {database}
Natural Language Query: {prompt}

Schema Information:
{schema_info}

Generate a valid SQL query that answers the user's question. Consider:
1. The appropriate tables to query
2. Required joins to connect related tables
3. Proper filtering conditions
4. Any aggregations or calculations needed
5. Sorting or limiting results as appropriate

Return ONLY the SQL query without any explanation or additional text. The query should be executable against the provided schema.
"""

# Query hints generation prompt
QUERY_HINTS_PROMPT = """
You are an expert SQL query generator. Based on the following database schema, generate 5 natural language questions
that a user might want to ask about this database. Focus on questions that would be useful for exploring the data.

Database: {database}

Schema Information:
{schema_info}

Generate 5 different types of questions, such as:
1. Simple queries about one table
2. Complex queries joining multiple tables
3. Aggregation queries with grouping
4. Filtering queries with conditions
5. Analytical questions about the data

Format your response as a JSON array of strings, with each string being a natural language question.
ONLY return the JSON array, nothing else.
"""

# Domain analysis prompt (for workspace visualization)
DOMAIN_ANALYSIS_PROMPT = """
You are a data modeling expert analyzing database schemas. Generate:
1. A brief 2-3 sentence overview of what this database represents
2. A simple conceptual diagram showing key entities and relationships

Database(s): {databases}
Tables: {tables}

Schema Information:
{schema_info}

For the domain description:
- Keep it extremely concise (2-3 short sentences maximum)
- Use simple everyday language for non-technical users
- Mention only the main purpose and key entities
- Avoid all technical terms

For the diagram:
- Create a minimalist mermaid.js flowchart diagram
- Use flowchart LR syntax (left-to-right orientation)
- Include only 4-6 most important entities
- Use simple labels and relationship descriptions
- Keep it black and white with simple styling
- Example styling: classDef default fill:#fff,stroke:#000,stroke-width:1px;

Format your response with the description first, followed by the mermaid diagram code in a code block.
"""

# Analysis types for dropdown
ANALYSIS_TYPES = [
    {"value": "general", "name": "General Schema Analysis", "description": "Overall assessment of schema design, normalization, and relationships"},
    {"value": "performance", "name": "Performance Analysis", "description": "Evaluation of schema for performance optimization opportunities"},
    {"value": "normalization", "name": "Normalization Analysis", "description": "Assessment of normalization levels and potential data redundancy"},
    {"value": "relationships", "name": "Relationships Analysis", "description": "Focus on entity relationships, foreign keys, and referential integrity"},
    {"value": "naming", "name": "Naming Convention Analysis", "description": "Review of naming patterns for tables, columns, and constraints"},
    {"value": "standards", "name": "Standards Compliance", "description": "Evaluation against industry standard practices and patterns"}
]

# Diagram types for dropdown
DIAGRAM_TYPES = [
    {"value": "conceptual", "name": "Conceptual ERD", "description": "High-level view showing entities and relationships without attributes"},
    {"value": "logical", "name": "Logical ERD", "description": "Detailed diagram showing entities, attributes, and relationships without physical implementation details"},
    {"value": "physical", "name": "Physical ERD", "description": "Complete diagram showing tables, columns, data types, and all constraints"},
    {"value": "dependency", "name": "Dependency Diagram", "description": "Shows tables as nodes with dependencies flowing in direction of foreign key relationships"},
    {"value": "hierarchical", "name": "Hierarchical Diagram", "description": "Organizes tables in a hierarchical structure with parent/child relationships"}
]