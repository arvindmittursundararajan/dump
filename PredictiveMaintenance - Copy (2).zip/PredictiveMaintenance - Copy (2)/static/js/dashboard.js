// Dashboard JavaScript

// Initialize the application when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the asset tree (using jsTree)
    initializeAssetTree();
    
    // Set up event listeners
    setupEventListeners();
    
    // Load initial dashboard data
    loadDashboardData();
});

// Initialize the asset tree view
function initializeAssetTree() {
    // Fetch asset tree data from the API
    fetch('/api/asset-tree')
        .then(response => response.json())
        .then(data => {
            // Initialize jsTree with health status icons in node text
            $('#asset-tree').jstree('destroy');
            // Add delete button (X) to each node with a machine_id or part_id
            function addDeleteButton(nodes) {
                return nodes.map(node => {
                    let deleteBtn = '';
                    if (node.type === 'machine' || node.type === 'part') {
                        deleteBtn = `<span class="delete-node-btn ml-1" data-type="${node.type}" data-id="${node.machine_id || node.part_id}" style="color:#dc3545;cursor:pointer;font-weight:bold;">&times;</span>`;
                    }
                    node.text = node.text + deleteBtn;
                    if (node.children && node.children.length > 0) {
                        node.children = addDeleteButton(node.children);
                    }
                    return node;
                });
            }
            const treeWithDelete = addDeleteButton(data);
            $('#asset-tree').jstree({
                core: {
                    data: treeWithDelete,
                    themes: {
                        icons: false
                    }
                },
                plugins: ['wholerow']
            });
            // Handle node selection
            $('#asset-tree').off('select_node.jstree').on('select_node.jstree', function(e, data) {
                const nodeType = data.node.original.type;
                const assetId = nodeType === 'machine'
                    ? data.node.original.machine_id
                    : data.node.original.part_id;
                if (nodeType && assetId) {
                    loadAssetDetails(nodeType, assetId);
                }
            });
            // Delete button click
            $('#asset-tree').off('click', '.delete-node-btn').on('click', '.delete-node-btn', function(e) {
                e.stopPropagation();
                const type = $(this).data('type');
                const id = $(this).data('id');
                if (confirm('Are you sure you want to delete this ' + type + ' and all its children?')) {
                    deleteAssetTreeNode(type, id);
                }
            });
        })
        .catch(error => {
            console.error('Error loading asset tree:', error);
            displayError('Failed to load asset hierarchy. Please try refreshing the page.');
        });
}

// Function to refresh the asset tree without page reload
function refreshAssetTree() {
    // Fetch updated asset tree data
    fetch('/api/asset-tree')
        .then(response => response.json())
        .then(data => {
            // Initialize jsTree with updated data
            $('#asset-tree').jstree('destroy');
            $('#asset-tree').jstree({
                core: {
                    data: data,
                    themes: {
                        icons: false
                    }
                },
                plugins: ['wholerow']
            });
        })
        .catch(error => {
            console.error('Error refreshing asset tree:', error);
        });
}

// Delete a node from the asset tree
function deleteAssetTreeNode(type, id) {
    let url = '';
    if (type === 'machine') url = `/api/machine/${id}`;
    else if (type === 'part') url = `/api/part/${id}`;
    else return;
    fetch(url, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                displaySuccess(type.charAt(0).toUpperCase() + type.slice(1) + ' deleted successfully.');
                refreshAssetTree();
            } else {
                displayError('Failed to delete ' + type + ': ' + (data.message || 'Unknown error'));
            }
        })
        .catch(() => displayError('Failed to delete ' + type + '.'));
}

// Set up event listeners for the dashboard
function setupEventListeners() {
    // Alert click handler
    const alertItems = document.querySelectorAll('.alert-item');
    alertItems.forEach(item => {
        item.addEventListener('click', function() {
            const assetType = this.dataset.assetType;
            const assetId = this.dataset.assetId;
            
            if (assetType && assetId) {
                loadAssetDetails(assetType, assetId);
                
                // Highlight the corresponding node in the tree
                highlightTreeNode(assetType, assetId);
            }
        });
    });
    
    // Add machine button click handler
    const addMachineBtn = document.getElementById('add-machine-btn');
    if (addMachineBtn) {
        addMachineBtn.addEventListener('click', showAddMachineModal);
    }
    
    // Add part button click handler
    const addPartBtn = document.getElementById('add-part-btn');
    if (addPartBtn) {
        addPartBtn.addEventListener('click', showAddPartModal);
    }
    
    // AI chat submit handler
    const aiForm = document.getElementById('ai-question-form');
    if (aiForm) {
        aiForm.addEventListener('submit', handleAiQuestion);
    }
}

// Load basic dashboard data
function loadDashboardData() {
    // Update status counts
    updateStatusCounts();
    
    // Update recent alerts (if any new ones)
    updateRecentAlerts();
}

// Load asset details
function loadAssetDetails(assetType, assetId) {
    // Show loading state
    const assetContainer = document.getElementById('asset-details-container');
    assetContainer.innerHTML = '<div class="text-center p-5"><div class="spinner-border text-danger" role="status"></div><p class="mt-2">Loading asset details...</p></div>';
    
    // Fetch asset details from the API
    fetch(`/api/asset/${assetType}/${assetId}`)
        .then(response => response.json())
        .then(data => {
            // Render asset details
            renderAssetDetails(assetType, data);
            
            // Render charts
            renderAssetCharts(data.chart_data);
        })
        .catch(error => {
            console.error('Error loading asset details:', error);
            assetContainer.innerHTML = '<div class="alert alert-danger">Failed to load asset details. Please try again.</div>';
        });
}

// Render asset details
function renderAssetDetails(assetType, data) {
    const assetContainer = document.getElementById('asset-details-container');
    let html = '';
    
    // Create header based on asset type
    if (assetType === 'machine') {
        html += `
            <div class="asset-header">
                <h1>${data.name}</h1>
                <span class="asset-status status-${data.status}">${data.status.toUpperCase()}</span>
            </div>
            <div class="row asset-details-row">
                <div class="col-md-6">
                    <p><span class="asset-details-label">Type:</span> ${data.asset_type}</p>
                    <p><span class="asset-details-label">Location:</span> ${data.description}</p>
                </div>
                <div class="col-md-6">
                    <p><span class="asset-details-label">Parts:</span> ${data.parts.length}</p>
                    <button class="btn btn-sm btn-outline-primary" onclick="showAddPartModal(${data.id})">Add Part</button>
                </div>
            </div>
        `;
    } else {
        html += `
            <div class="asset-header">
                <h1>${data.name}</h1>
                <span class="asset-status status-${data.status}">${data.status.toUpperCase()}</span>
            </div>
            <div class="row asset-details-row">
                <div class="col-md-6">
                    <p><span class="asset-details-label">Type:</span> ${data.part_type}</p>
                    <p><span class="asset-details-label">Machine:</span> ${data.machine_name}</p>
                </div>
                <div class="col-md-6">
                    <p><span class="asset-details-label">Installed:</span> ${data.installation_date || 'N/A'}</p>
                    <p><span class="asset-details-label">Expected lifetime:</span> ${data.expected_lifetime_hours} hours</p>
                </div>
            </div>
        `;
    }
    
    // Add charts container
    html += `
        <div class="card mt-4">
            <div class="card-header">Sensor Data</div>
            <div class="card-body">
                <div id="sensor-charts" class="chart-container"></div>
            </div>
        </div>
    `;
    
    // Add alerts section
    html += `
        <div class="card mt-4">
            <div class="card-header">Recent Alerts</div>
            <div class="card-body">
                <div id="asset-alerts">
                    ${renderAlertsList(data.alerts)}
                </div>
            </div>
        </div>
    `;
    
    // Add AI recommendations
    html += `
        <div class="card mt-4">
            <div class="card-header">AI Recommendations</div>
            <div class="card-body">
                <div id="ai-recommendation">
                    ${data.ai_recommendation || 'No recommendations available yet.'}
                </div>
                <div class="mt-3">
                    <form id="ai-question-form" class="d-flex">
                        <input type="hidden" id="ai-asset-type" value="${assetType}">
                        <input type="hidden" id="ai-asset-id" value="${data.id}">
                        <input type="text" class="form-control" id="ai-question" placeholder="Ask a question about this ${assetType}...">
                        <button type="submit" class="btn btn-primary ml-2">Ask</button>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    // Update the container
    assetContainer.innerHTML = html;
    
    // Re-attach event listeners
    const aiForm = document.getElementById('ai-question-form');
    if (aiForm) {
        aiForm.addEventListener('submit', handleAiQuestion);
    }
}

// Render a list of alerts
function renderAlertsList(alerts) {
    if (!alerts || alerts.length === 0) {
        return '<p>No recent alerts.</p>';
    }
    
    let html = '';
    alerts.forEach(alert => {
        html += `
            <div class="alert-item ${alert.severity}">
                <h5>${alert.type}</h5>
                <p>${alert.message}</p>
                <div class="timestamp">${alert.timestamp}</div>
            </div>
        `;
    });
    
    return html;
}

// Render charts for asset sensor data
function renderAssetCharts(chartData) {
    const chartContainer = document.getElementById('sensor-charts');
    
    // Clear any existing charts
    chartContainer.innerHTML = '';
    
    // Check if we have data to display
    if (!chartData || Object.keys(chartData).length === 0) {
        chartContainer.innerHTML = '<p>No sensor data available for this asset.</p>';
        return;
    }
    
    // Create a chart for each sensor type
    Object.keys(chartData).forEach((sensorType, index) => {
        const data = chartData[sensorType];
        
        // Create a canvas for this chart
        const chartId = `chart-${sensorType.replace(/\s+/g, '-')}`;
        const chartDiv = document.createElement('div');
        chartDiv.className = 'mb-4';
        chartDiv.innerHTML = `
            <h5>${sensorType.toUpperCase()}</h5>
            <canvas id="${chartId}" height="200"></canvas>
        `;
        chartContainer.appendChild(chartDiv);
        
        // Create the chart
        const ctx = document.getElementById(chartId).getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: sensorType,
                    data: data.values,
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    borderColor: 'rgba(220, 53, 69, 1)',
                    borderWidth: 2,
                    pointBackgroundColor: data.anomalies.map(isAnomaly => 
                        isAnomaly ? 'rgba(220, 53, 69, 1)' : 'rgba(220, 53, 69, 0.5)'
                    ),
                    pointRadius: data.anomalies.map(isAnomaly => isAnomaly ? 6 : 3),
                    pointHoverRadius: data.anomalies.map(isAnomaly => isAnomaly ? 8 : 5),
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: false
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.parsed.y;
                                if (data.anomalies[context.dataIndex]) {
                                    label += ' (ANOMALY)';
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    });
}

// Update the status counts on the dashboard
function updateStatusCounts() {
    // This would typically be a periodic API call to get latest counts
    // For now, we'll just use the data from the page
}

// Update recent alerts 
function updateRecentAlerts() {
    // This would typically be a periodic API call to get latest alerts
    // For now, we'll just use the data from the page
}

// Highlight a node in the asset tree
function highlightTreeNode(assetType, assetId) {
    const tree = $('#asset-tree').jstree(true);
    if (!tree) return;
    
    const nodeId = `${assetType}-${assetId}`;
    tree.deselect_all();
    tree.select_node(nodeId);
}

// Handle AI question submission
function handleAiQuestion(e) {
    e.preventDefault();
    
    const questionInput = document.getElementById('ai-question');
    const question = questionInput.value.trim();
    
    if (!question) return;
    
    const assetType = document.getElementById('ai-asset-type').value;
    const assetId = document.getElementById('ai-asset-id').value;
    
    // Clear the input
    questionInput.value = '';
    
    // Show loading indicator
    const recommendationDiv = document.getElementById('ai-recommendation');
    recommendationDiv.innerHTML = '<div class="text-center"><div class="spinner-border text-danger" role="status"></div><p class="mt-2">Analyzing your question...</p></div>';
    
    // Send the question to the API
    fetch('/api/ask-ai', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            question: question,
            [assetType + '_id']: assetId
        })
    })
    .then(response => response.json())
    .then(data => {
        recommendationDiv.innerHTML = data.response || 'No response received.';
    })
    .catch(error => {
        console.error('Error asking AI:', error);
        recommendationDiv.innerHTML = 'Failed to get a response. Please try again.';
    });
}

// Show the add machine modal
function showAddMachineModal() {
    // Show the modal
    $('#add-machine-modal').modal('show');
    
    // Set up the save button handler
    $('#save-machine-btn').off('click').on('click', function() {
        saveMachine();
    });
}

// Show the add part modal
function showAddPartModal(machineId) {
    // Show the modal
    $('#add-part-modal').modal('show');
    
    // Set the machine ID in the hidden field
    $('#part-machine-id').val(machineId);
    
    // Load parts for parent part dropdown
    if (machineId) {
        loadMachineParts(machineId);
    }
    
    // Set up the save button handler
    $('#save-part-btn').off('click').on('click', function() {
        savePart();
    });
}

// Load parts for a machine (to populate parent part dropdown)
function loadMachineParts(machineId) {
    fetch(`/api/machine/${machineId}/parts`)
        .then(response => response.json())
        .then(data => {
            const parentSelect = document.getElementById('part-parent');
            parentSelect.innerHTML = '<option value="">None (Top-level part)</option>';
            
            if (data && data.length > 0) {
                data.forEach(part => {
                    const option = document.createElement('option');
                    option.value = part.id;
                    option.textContent = part.name;
                    parentSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error('Error loading machine parts:', error);
        });
}

// Save a new machine
function saveMachine() {
    // Validate the form
    const nameInput = document.getElementById('machine-name');
    if (!nameInput.value.trim()) {
        alert('Machine name is required');
        return;
    }
    
    // Get form values
    const data = {
        name: document.getElementById('machine-name').value,
        asset_type: document.getElementById('machine-type').value,
        location: document.getElementById('machine-location').value,
        description: document.getElementById('machine-description').value,
        installation_date: document.getElementById('machine-installation-date').value
    };
    
    // Send data to the server
    fetch('/api/machine', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Close the modal
        $('#add-machine-modal').modal('hide');
        
        // Clear the form
        document.getElementById('add-machine-form').reset();
        
        // Show success message
        displaySuccess('Machine added successfully');
        
        // Refresh the asset tree without page reload
        refreshAssetTree();
    })
    .catch(error => {
        console.error('Error adding machine:', error);
        alert('Failed to add machine. Please try again.');
    });
}

// Save a new part
function savePart() {
    // Validate the form
    const nameInput = document.getElementById('part-name');
    if (!nameInput.value.trim()) {
        alert('Part name is required');
        return;
    }
    
    const machineId = document.getElementById('part-machine-id').value;
    if (!machineId) {
        alert('Machine ID is required');
        return;
    }
    
    // Get form values
    const data = {
        name: document.getElementById('part-name').value,
        machine_id: parseInt(machineId),
        part_type: document.getElementById('part-type').value,
        parent_part_id: document.getElementById('part-parent').value || null,
        description: document.getElementById('part-description').value,
        expected_lifetime_hours: document.getElementById('part-expected-lifetime').value || null
    };
    
    // Send data to the server
    fetch('/api/part', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Close the modal
        $('#add-part-modal').modal('hide');
        
        // Clear the form
        document.getElementById('add-part-form').reset();
        
        // Show success message
        displaySuccess('Part added successfully');
        
        // Refresh the asset tree without page reload
        refreshAssetTree();
    })
    .catch(error => {
        console.error('Error adding part:', error);
        alert('Failed to add part. Please try again.');
    });
}

// Display a success message
function displaySuccess(message) {
    const container = document.getElementById('error-container');
    if (container) {
        container.innerHTML = `<div class="alert alert-success alert-dismissible fade show">
            ${message}
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>`;
    }
}

// Display an error message
function displayError(message) {
    const container = document.getElementById('error-container');
    if (container) {
        container.innerHTML = `<div class="alert alert-danger">${message}</div>`;
    } else {
        console.error(message);
    }
}
