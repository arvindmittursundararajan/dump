from datetime import datetime
import json
from app import db
from sqlalchemy import JSON

class DataSource(db.Model):
    """Model for data sources in the system"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    file_path = db.Column(db.String(255), nullable=True)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    schema = db.Column(JSON, nullable=True)
    row_count = db.Column(db.Integer, default=0)
    quality_metrics = db.Column(JSON, nullable=True)
    
    def __repr__(self):
        return f"<DataSource {self.name}>"

class Alert(db.Model):
    """Model for alerts in the live watch system"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    severity = db.Column(db.String(50), nullable=False)  # critical, warning, info
    category = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(100), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolution_notes = db.Column(db.Text, nullable=True)
    affected_entities = db.Column(JSON, nullable=True)  # flights, crew, etc.
    additional_data = db.Column(JSON, nullable=True)  # additional data
    
    def __repr__(self):
        return f"<Alert {self.title}>"

class Rule(db.Model):
    """Model for rules in the rule engine"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    rule_text = db.Column(db.Text, nullable=False)  # The rule expression
    category = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(50), nullable=False)  # critical, warning, info
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    rule_config = db.Column(JSON, nullable=True)  # additional configuration
    
    def __repr__(self):
        return f"<Rule {self.name}>"

class OptimizationPlan(db.Model):
    """Model for optimization plans"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    scenario = db.Column(db.String(255), nullable=False)
    constraints = db.Column(JSON, nullable=False)
    objective_weights = db.Column(JSON, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default="draft")  # draft, running, completed, failed
    results = db.Column(JSON, nullable=True)
    score = db.Column(db.Float, nullable=True)
    execution_time = db.Column(db.Float, nullable=True)  # in seconds
    version = db.Column(db.Integer, default=1)
    
    def __repr__(self):
        return f"<OptimizationPlan {self.name} v{self.version}>"

class Incident(db.Model):
    """Model for incidents to be analyzed in debrief"""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=True)
    category = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(50), nullable=False)
    timeline = db.Column(JSON, nullable=True)  # Events during the incident
    affected_entities = db.Column(JSON, nullable=True)  # flights, crew, etc.
    root_cause = db.Column(db.Text, nullable=True)
    resolution = db.Column(db.Text, nullable=True)
    lessons_learned = db.Column(db.Text, nullable=True)
    optimization_plan_id = db.Column(db.Integer, db.ForeignKey('optimization_plan.id'), nullable=True)
    
    optimization_plan = db.relationship('OptimizationPlan', backref='incidents')
    
    def __repr__(self):
        return f"<Incident {self.title}>"

class Flight(db.Model):
    """Model for flight data"""
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(20), nullable=False)
    origin = db.Column(db.String(5), nullable=False)
    destination = db.Column(db.String(5), nullable=False)
    scheduled_departure = db.Column(db.DateTime, nullable=False)
    scheduled_arrival = db.Column(db.DateTime, nullable=False)
    actual_departure = db.Column(db.DateTime, nullable=True)
    actual_arrival = db.Column(db.DateTime, nullable=True)
    aircraft_id = db.Column(db.String(20), nullable=True)
    status = db.Column(db.String(50), default="scheduled")
    flight_data = db.Column(JSON, nullable=True)  # Additional flight data
    
    def __repr__(self):
        return f"<Flight {self.flight_number}>"

class Aircraft(db.Model):
    """Model for aircraft data"""
    id = db.Column(db.Integer, primary_key=True)
    registration = db.Column(db.String(20), nullable=False)
    aircraft_type = db.Column(db.String(50), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    range_nm = db.Column(db.Float, nullable=True)  # Range in nautical miles
    status = db.Column(db.String(50), default="active")
    maintenance_status = db.Column(db.String(50), default="operational")
    next_maintenance = db.Column(db.DateTime, nullable=True)
    aircraft_data = db.Column(JSON, nullable=True)  # Additional aircraft data
    
    def __repr__(self):
        return f"<Aircraft {self.registration}>"

class Crew(db.Model):
    """Model for crew data"""
    id = db.Column(db.Integer, primary_key=True)
    staff_id = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    position = db.Column(db.String(50), nullable=False)  # Pilot, First Officer, Flight Attendant, etc.
    qualifications = db.Column(JSON, nullable=True)
    base = db.Column(db.String(5), nullable=False)  # Airport code of crew base
    status = db.Column(db.String(50), default="active")
    duty_time_remaining = db.Column(db.Float, nullable=True)  # Hours of duty time remaining
    rest_required = db.Column(db.Float, nullable=True)  # Hours of rest required
    crew_data = db.Column(JSON, nullable=True)  # Additional crew data
    
    def __repr__(self):
        return f"<Crew {self.staff_id}>"
