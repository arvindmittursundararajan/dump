import os
import json
import requests
from config import TOGETHER_API_KEY, TOGETHER_MODEL

TOGETHER_API_URL = "https://api.together.xyz/v1/chat/completions"

# Analysis prompts for different types of analysis
ANALYSIS_PROMPT = """
You are a data modeling expert analyzing a database schema. Provide a detailed analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Analysis Type: {analysis_type}

Please provide a thorough analysis focusing on the {analysis_type} aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Overview of the schema 📊</h2>
<h2>Key entities and relationships 🔑</h2>
<h2>Strengths of the current schema ✅</h2>
<h2>Potential issues or weaknesses ⚠️</h2>
<h2>Recommendations for improvement 💡</h2>

Focus specifically on {analysis_type} considerations. Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color)
- Tables for structured data (use <table>, <tr>, <td> tags)
- Lists for enumeration (use <ul>, <ol>, <li> tags)
- Code blocks for SQL examples (use <pre><code> tags)
- Colored sections for important notes (use <div> with background-color)

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

PERFORMANCE_PROMPT = """
You are a data performance optimization expert analyzing Databricks tables. Provide a detailed performance analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Please provide a thorough analysis focusing on performance aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Performance Overview 🚀</h2>
<h2>Potential Bottlenecks ⏱️</h2>
<h2>Storage Optimization Opportunities 💾</h2>
<h2>Query Optimization Recommendations 📈</h2>
<h2>Materialized Views Strategy 📊</h2>

Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color style attributes)
- Tables for performance metrics (use <table>, <tr>, <td> tags)
- Lists for optimization tips (use <ul>, <ol>, <li> tags)
- Code blocks for SQL optimization examples (use <pre><code> tags)
- Colored sections for high impact recommendations (use <div> with background-color style)

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

NORMALIZATION_PROMPT = """
You are a database normalization expert analyzing a database schema. Provide a detailed normalization analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Please provide a thorough analysis focusing on normalization aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Normalization Overview 📊</h2>
<h2>Current Normalization Level Assessment 📏</h2>
<h2>Normalization Strengths ✅</h2>
<h2>Normalization Issues ⚠️</h2>
<h2>Recommendations for Improvement 💡</h2>

Evaluate the schema against 1NF, 2NF, 3NF, BCNF, and 4NF. Identify any denormalization patterns and whether they are justified. 

Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color style attributes)
- Tables for normalization forms (use <table>, <tr>, <td> tags)
- Lists for normalization rules (use <ul>, <ol>, <li> tags)
- Code blocks for SQL examples (use <pre><code> tags)
- Colored sections for normalization levels (use <div> with background-color style)

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

RELATIONSHIPS_PROMPT = """
You are a data modeling expert analyzing relationships in a database schema. Provide a detailed relationship analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Please provide a thorough analysis focusing on relationship aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Relationship Overview 🔄</h2>
<h2>Key Entity Relationships 🔑</h2>
<h2>Relationship Types Assessment 🌐</h2>
<h2>Relationship Strengths ✅</h2>
<h2>Relationship Issues ⚠️</h2>
<h2>Recommendations for Improvement 💡</h2>

Analyze different types of relationships (one-to-one, one-to-many, many-to-many), identify missing relationships, and suggest improvements.

Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color style attributes)
- Tables for relationship mapping (use <table>, <tr>, <td> tags)
- Lists for relationship types (use <ul>, <ol>, <li> tags)
- Code blocks for SQL relationship examples (use <pre><code> tags)
- Colored sections for relationship categories (use <div> with background-color style)
- Entity relationship diagrams described in HTML format

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

NAMING_PROMPT = """
You are a database naming convention expert analyzing a database schema. Provide a detailed naming convention analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Please provide a thorough analysis focusing on naming convention aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Naming Convention Overview 📝</h2>
<h2>Table Naming Patterns 📋</h2>
<h2>Column Naming Patterns 📊</h2>
<h2>Naming Strengths ✅</h2>
<h2>Naming Issues ⚠️</h2>
<h2>Recommendations for Improvement 💡</h2>

Evaluate consistency, clarity, and industry best practices in the naming conventions.

Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color style attributes)
- Tables for naming patterns (use <table>, <tr>, <td> tags)
- Lists for naming rules (use <ul>, <ol>, <li> tags)
- Code blocks for SQL examples (use <pre><code> tags)
- Colored sections for naming categories (use <div> with background-color style)

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

STANDARDS_PROMPT = """
You are a database standards compliance expert analyzing a database schema. Provide a detailed standards compliance analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Please provide a thorough analysis focusing on standards compliance aspects. Format your response using ONLY valid HTML with appropriate styling. Your entire response must be valid HTML ready to be inserted into a webpage with no markdown, no prefixes, and no explanation text.

Include the following sections in your analysis:
<h2>Standards Compliance Overview 📚</h2>
<h2>Industry Best Practices Assessment 🌐</h2>
<h2>Compliance Strengths ✅</h2>
<h2>Compliance Issues ⚠️</h2>
<h2>Recommendations for Improvement 💡</h2>

Evaluate against common data modeling standards and best practices.

Make your response visually appealing with:
- Professional typography (use <h1>, <h2>, <h3> headers)
- Colorful icons/emojis (use span with color style attributes) 
- Tables for compliance metrics (use <table>, <tr>, <td> tags)
- Lists for standards requirements (use <ul>, <ol>, <li> tags)
- Code blocks for SQL examples (use <pre><code> tags)
- Colored sections for compliance levels (use <div> with background-color style)

Return ONLY the HTML - no explanations before or after. Do not include any markdown or text outside of the HTML tags.
"""

def get_prompt_for_analysis_type(analysis_type):
    """Get the correct prompt for a given analysis type."""
    prompts = {
        "general": ANALYSIS_PROMPT,
        "performance": PERFORMANCE_PROMPT,
        "normalization": NORMALIZATION_PROMPT,
        "relationships": RELATIONSHIPS_PROMPT,
        "naming": NAMING_PROMPT,
        "standards": STANDARDS_PROMPT
    }
    
    return prompts.get(analysis_type, ANALYSIS_PROMPT)

def send_to_together(prompt, api_key=TOGETHER_API_KEY, model=TOGETHER_MODEL):
    """Send a prompt to Together.xyz API and get a response."""
    if not api_key:
        return "<h2>⚠️ API Key Missing</h2><p>No Together API key provided. Please configure the TOGETHER_API_KEY in config.py or environment variables.</p>"
    
    try:
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        request_body = {
            "model": model,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.2,
            "top_p": 0.95,
            "max_tokens": 4096,
            "stream": False
        }
        
        response = requests.post(
            TOGETHER_API_URL,
            headers=headers,
            json=request_body
        )
        
        if response.status_code == 200:
            response_json = response.json()
            if 'choices' in response_json and len(response_json['choices']) > 0:
                return response_json['choices'][0]['message']['content']
            else:
                return "<h2>⚠️ Invalid Response</h2><p>No valid response from Together.xyz API.</p>"
        else:
            return f"<h2>⚠️ API Error</h2><p>Error from Together.xyz API: {response.status_code} - {response.text}</p>"
    
    except Exception as e:
        return f"<h2>⚠️ Error</h2><p>Error calling Together.xyz API: {str(e)}</p>"

def analyze_schema(database_name, tables, schema_info, analysis_type="general", output_format="html"):
    """Analyze the schema using the Together.xyz API."""
    prompt = get_prompt_for_analysis_type(analysis_type)
    
    # Format the schema info for the prompt
    schema_info_str = json.dumps(schema_info, indent=2)
    
    # Add SQL query to the prompt if available
    sql_query = schema_info.pop('sql_query', None) if isinstance(schema_info, dict) else None
    if sql_query:
        schema_info_str += f"\n\nSQL Query:\n{sql_query}"
    
    # Fill in the prompt template
    filled_prompt = prompt.format(
        database=database_name,
        tables=tables,
        schema_info=schema_info_str,
        analysis_type=analysis_type
    )
    
    # Send to Together.xyz API
    result = send_to_together(filled_prompt)
    
    # Format the result for the desired output format
    if output_format == 'html':
        # If the result doesn't already have HTML formatting, wrap it in basic HTML
        if not result.strip().startswith('<'):
            result = f"<div class='together-analysis'>{result}</div>"
    
    return result