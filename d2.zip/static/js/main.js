/**
 * ADW Workbench - Main JavaScript
 * Provides functionality for schema selection, table viewing, and analysis
 */

(function() {
    // Store selected tables for analysis
    let selectedTables = [];
    
    /**
     * Initialize UI elements and set up any required event handlers
     */
    function initializeUI() {
        // Catalog selection change
        document.getElementById('catalog-select')?.addEventListener('change', handleCatalogChange);
        
        // Schema selection change
        document.getElementById('schema-select')?.addEventListener('change', handleSchemaChange);
        
        // Table selection change
        document.getElementById('table-select')?.addEventListener('change', function() {
            updateAddTableButton();
        });
        
        // Add table button
        document.getElementById('add-table-btn')?.addEventListener('click', addTableToSelection);
        
        // Clear selection button
        document.getElementById('clear-selection-btn')?.addEventListener('click', clearTableSelection);
        
        // Run analysis button
        document.getElementById('run-analysis-btn')?.addEventListener('click', runAnalysis);
    }
    
    /**
     * Handle catalog selection change
     */
    function handleCatalogChange() {
        const catalogSelect = document.getElementById('catalog-select');
        const schemaSelect = document.getElementById('schema-select');
        const tableSelect = document.getElementById('table-select');
        
        // Clear schema and table selects
        schemaSelect.innerHTML = '<option value="">Select a schema</option>';
        tableSelect.innerHTML = '<option value="">Select a table</option>';
        
        // Update both button states
        updateAddTableButton();
        updateRunAnalysisButton();
        
        const selectedCatalog = catalogSelect.value;
        
        if (selectedCatalog) {
            // Show loading state
            const schemaContainer = document.getElementById('schema-select-container');
            schemaContainer.innerHTML = '<div class="d-flex align-items-center"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading schemas...</div>';
            
            // Fetch schemas for the selected catalog
            fetch(`/get_schemas/${selectedCatalog}`)
                .then(response => response.json())
                .then(data => {
                    let html = '<select id="schema-select" class="form-select animated-select">';
                    html += '<option value="">Select a schema</option>';
                    if (data && data.length > 0) {
                        data.forEach(schema => {
                            html += `<option value="${schema.name}">${schema.name}</option>`;
                        });
                    } else {
                        html += '<option value="" disabled>(No schemas found)</option>';
                    }
                    html += '</select>';
                    schemaContainer.innerHTML = html;
                    document.getElementById('schema-select').addEventListener('change', handleSchemaChange);
                })
                .catch(error => {
                    console.error('Error fetching schemas:', error);
                    schemaContainer.innerHTML = '<div class="alert alert-danger">Error loading schemas</div>';
                });
        }
    }
    
    /**
     * Handle schema selection change
     */
    function handleSchemaChange() {
        const catalogSelect = document.getElementById('catalog-select');
        const schemaSelect = document.getElementById('schema-select');
        const tableSelect = document.getElementById('table-select');
        
        // Clear table select
        tableSelect.innerHTML = '<option value="">Select a table</option>';
        
        // Update button states
        updateAddTableButton();
        updateRunAnalysisButton();
        
        const selectedCatalog = catalogSelect.value;
        const selectedSchema = schemaSelect.value;
        
        if (selectedCatalog && selectedSchema) {
            // Show loading state
            const tableContainer = document.getElementById('table-select-container');
            tableContainer.innerHTML = '<div class="d-flex align-items-center"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading tables...</div>';
            
            // Fetch tables for the selected schema
            fetch(`/get_tables/${selectedCatalog}/${selectedSchema}`)
                .then(response => response.json())
                .then(data => {
                    let html = '<select id="table-select" class="form-select animated-select">';
                    html += '<option value="">Select a table</option>';
                    if (data && data.length > 0) {
                        data.forEach(table => {
                            html += `<option value="${table.name}" data-id="${table.id}" data-full-name="${selectedCatalog}.${selectedSchema}.${table.name}">${table.name} (${table.type})</option>`;
                        });
                    } else {
                        html += '<option value="" disabled>(No tables found)</option>';
                    }
                    html += '</select>';
                    tableContainer.innerHTML = html;
                    document.getElementById('table-select').addEventListener('change', function() {
                        updateAddTableButton();
                    });
                })
                .catch(error => {
                    console.error('Error fetching tables:', error);
                    tableContainer.innerHTML = '<div class="alert alert-danger">Error loading tables</div>';
                });
        }
    }
    
    /**
     * Update the Add Table button state
     */
    function updateAddTableButton() {
        const tableSelect = document.getElementById('table-select');
        const addTableBtn = document.getElementById('add-table-btn');
        
        if (tableSelect && addTableBtn) {
            addTableBtn.disabled = !tableSelect.value;
        }
    }
    
    /**
     * Update the Run Analysis button state
     */
    function updateRunAnalysisButton() {
        const runAnalysisBtn = document.getElementById('run-analysis-btn');
        
        if (runAnalysisBtn) {
            runAnalysisBtn.disabled = selectedTables.length === 0;
        }
    }
    
    /**
     * Add a selected table to the list
     */
    function addTableToSelection() {
        const tableSelect = document.getElementById('table-select');
        
        if (!tableSelect.value) return;
        
        const selectedOption = tableSelect.options[tableSelect.selectedIndex];
        const tableId = selectedOption.dataset.id;
        const tableName = selectedOption.value;
        const fullName = selectedOption.dataset.fullName;
        
        // Check if this table is already selected (use fullName for uniqueness)
        if (selectedTables.some(t => t.fullName === fullName)) {
            showToast(`Table "${tableName}" is already in your selection.`, 'warning');
            return;
        }
        
        // Get catalog and schema from fullName
        const parts = fullName.split('.');
        
        // Add table to our array
        selectedTables.push({
            id: tableId,
            name: tableName,
            fullName: fullName,
            catalog: parts[0],
            schema: parts[1]
        });
        
        // Save selection to server
        saveTableSelection(tableId);
        
        // Update the UI
        refreshSelectedTablesList();
        
        // Enable analysis button
        updateRunAnalysisButton();
        
        // Show confirmation
        showToast(`Added table "${tableName}" to selection.`, 'success');
    }
    
    /**
     * Save a table selection to the server
     */
    function saveTableSelection(tableId) {
        // Make API call to save selection
        fetch('/select_table', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ table_id: tableId })
        });
    }
    
    /**
     * Refresh the list of selected tables in the UI
     */
    function refreshSelectedTablesList() {
        const selectedTablesContainer = document.getElementById('selected-tables');
        const emptySelection = document.getElementById('empty-selection');
        
        if (selectedTables.length === 0) {
            // Show empty state
            if (emptySelection) {
                emptySelection.style.display = 'block';
            }
            return;
        }
        
        // Hide empty state
        if (emptySelection) {
            emptySelection.style.display = 'none';
        }
        
        // Build HTML for selected tables
        let html = '';
        
        selectedTables.forEach((table, index) => {
            html += `
                <div class="selected-table mb-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-medium">${table.name}</span>
                        <button class="btn btn-sm btn-outline-danger remove-table-btn" 
                                data-index="${index}">
                            <i class="bi bi-x"></i>
                        </button>
                    </div>
                    <small class="text-muted">${table.fullName}</small>
                </div>
            `;
        });
        
        selectedTablesContainer.innerHTML = html;
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-table-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = this.dataset.index;
                removeTableFromSelection(index);
            });
        });
    }
    
    /**
     * Remove a table from the selection
     */
    function removeTableFromSelection(index) {
        const tableToRemove = selectedTables[index];
        
        if (!tableToRemove) return;
        
        // Remove from server
        fetch('/select_table', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ table_id: tableToRemove.id })
        });
        
        // Remove from array
        selectedTables.splice(index, 1);
        
        // Update UI
        refreshSelectedTablesList();
        
        // Update button state
        updateRunAnalysisButton();
        
        // Show toast
        showToast(`Removed "${tableToRemove.name}" from selection.`, 'info');
    }
    
    /**
     * Clear all selected tables
     */
    function clearTableSelection() {
        if (selectedTables.length === 0) return;
        
        // Clear on server
        fetch('/clear_selection', {
            method: 'POST'
        });
        
        // Clear array
        selectedTables = [];
        
        // Update UI
        refreshSelectedTablesList();
        
        // Update button state
        updateRunAnalysisButton();
        
        // Show toast
        showToast('Cleared table selection.', 'info');
    }
    
    /**
     * Run the analysis on selected tables
     */
    function runAnalysis() {
        if (selectedTables.length === 0) {
            showToast('Please select at least one table to analyze.', 'warning');
            return;
        }
        // Hide any previous results
        const resultsPanel = document.getElementById('results-panel');
        const emptyState = resultsPanel.querySelector('.empty-state');
        if (emptyState) {
            emptyState.style.display = 'none';
        }
        // Show loading spinner and message
        resultsPanel.innerHTML = `
            <h4 class="mb-4 border-bottom pb-2 text-primary">
                <i class="bi bi-bar-chart"></i> Analysis Results
            </h4>
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 200px;">
                <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
                <p class="mt-3">Analyzing your schema. Please wait...</p>
            </div>
        `;
        // Get analysis options
        const analysisType = document.getElementById('analysis-type').value;
        const sqlQuery = document.getElementById('sql-input').value;
        // Create formatted table information
        const tableNames = selectedTables.map(table => table.name).join(', ');
        // Make an AJAX request to get real analysis from server
        fetch('/analysis', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                selected_tables: selectedTables,
                analysis_type: analysisType,
                sql_query: sqlQuery
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Display the analysis from the server
            resultsPanel.innerHTML = `
                <h4 class="mb-4 border-bottom pb-2 text-primary">
                    <i class="bi bi-bar-chart"></i> Analysis Results
                </h4>
                <div class="analysis-result p-4">
                    ${data.analysis_result}
                </div>
                <div class="mt-4 text-center">
                    <p class="text-muted">Analysis generated for tables: ${tableNames}</p>
                    <p class="text-muted">Analysis ID: ${data.analysis_id}</p>
                    <a href="/history" class="btn btn-outline-primary">
                        <i class="bi bi-clock-history"></i> View History
                    </a>
                </div>
            `;
        })
        .catch(error => {
            // Show error message
            resultsPanel.innerHTML = `
                <h4 class="mb-4 border-bottom pb-2 text-primary">
                    <i class="bi bi-bar-chart"></i> Analysis Results
                </h4>
                <div class="alert alert-danger">
                    <h5><i class="bi bi-exclamation-triangle"></i> Error Connecting to API</h5>
                    <p>There was an error connecting to the Gemini API for analysis.</p>
                    <p>Error details: ${error.message}</p>
                    <p>Please ensure your API credentials are set correctly and try again.</p>
                </div>
            `;
        });
    }
    
    /**
     * Show a toast notification
     */
    function showToast(message, type = 'success') {
        const toastContainer = document.getElementById('toast-container');
        
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, {
            autohide: true,
            delay: 3000
        });
        
        bsToast.show();
        
        // Remove from DOM after hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
    
    // Load existing selections when the page loads
    function loadExistingSelections() {
        fetch('/get_selected_tables')
            .then(response => response.json())
            .then(data => {
                if (data && data.length > 0) {
                    // Add tables to our array
                    selectedTables = data.map(table => ({
                        id: table.id,
                        name: table.name,
                        fullName: table.full_name
                    }));
                    
                    // Refresh the UI
                    refreshSelectedTablesList();
                    
                    // Update button state
                    updateRunAnalysisButton();
                }
            })
            .catch(error => {
                console.error('Error loading selected tables:', error);
            });
    }
    
    // Initialize when the DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        initializeUI();
        loadExistingSelections();
    });
})();