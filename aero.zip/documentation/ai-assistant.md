# Gemini AI Assistant

## Overview
The Gemini AI Assistant provides natural language interaction capabilities throughout the AeroOptima.ai platform. This AI-powered chat interface allows users to ask questions, get insights, and perform actions using conversational language rather than navigating through traditional interfaces.

## Access Points
- **Chat Button**: Available in the top navigation bar of every page
- **Modal Interface**: Opens as an overlay on the current page
- **Context-aware**: Adapts to the current module being used

## Key Features

### 1. Natural Language Query Processing
- **Conversational Interface**: Ask questions in plain English
- **Context Awareness**: Assistant understands the current module and data
- **History Retention**: Maintains conversation context for follow-up questions
- **Smart Suggestions**: Offers relevant question prompts based on current page

### 2. Operational Insights
- **Data Analysis**: Extract patterns and trends from operational data
- **Alert Interpretation**: Explain the meaning and impact of active alerts
- **Optimization Assistance**: Suggest optimization strategies for scenarios
- **Incident Understanding**: Summarize key points from incident records

### 3. Decision Support
- **Impact Assessment**: Estimate effects of potential decisions
- **Historical Comparison**: Relate current situations to past incidents
- **Regulatory Guidance**: Provide information on relevant regulations
- **Best Practice Recommendations**: Suggest industry standard approaches

### 4. Dynamic Assistance
- **Page-Specific Help**: Offer guidance relevant to current module
- **Feature Explanation**: Describe how to use platform capabilities
- **Process Guidance**: Walk through complex workflows
- **Error Resolution**: Help troubleshoot issues

## UI Components

### Chat Toggle Button
- Located in the top navigation bar
- Shows/hides the chat interface
- Indicates when assistant is active

### Chat Modal
- Overlay that appears on top of current content
- Draggable and resizable interface
- Minimize, expand, and close controls
- Semi-transparent background maintains context

### Message Interface
- Chat message history with scrollable view
- User messages right-aligned with distinct styling
- Assistant messages left-aligned with Gemini branding
- Typing indicator shows when assistant is processing

### Input Area
- Text input field for questions and commands
- Send button with paper plane icon
- Microphone button for voice input (when available)
- Message character count and limits

### Suggested Questions
- Quick-access question bubbles
- Context-sensitive suggestions based on current page
- Click to automatically enter the question
- Shown primarily to new users and when conversation resets

## Technical Implementation
- Uses the Gemini API for natural language processing
- Implemented in `routes/chat.py` and `services/gemini_service.py`
- Front-end functionality in `static/js/gemini_chat.js`
- Styling defined in `static/css/main.css`

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | Send message to Gemini and get response |

## Context Awareness
The assistant gathers context information based on the current page:

### Data Hub Context
- Available data sources and their quality metrics
- Recently uploaded data
- Schema information

### Monitoring Context
- Active alerts and their severities
- Configured rules
- Related operational entities

### Optimizer Context
- Current optimization plans
- Selected scenario details
- Constraints and objectives
- Results and scores

### Debrief Context
- Current incident details
- Timeline events
- Root cause information
- Affected entities

## Example Use Cases

### General Questions
- "What does AeroOptima.ai do?"
- "How do I upload new flight data?"
- "Explain how the optimization engine works"
- "What are the key features of the monitoring system?"

### Data Hub Assistance
- "What's the quality of my crew data?"
- "Show me the schema for flight data"
- "When was the aircraft data last updated?"
- "How many flights are in the database?"

### Monitoring Support
- "Explain the critical alerts"
- "What does the crew duty time alert mean?"
- "How do I create a rule for unaccompanied minors?"
- "Which flights are affected by the current alerts?"

### Optimization Guidance
- "Help me optimize for an aircraft maintenance issue"
- "What's the best strategy for crew recovery?"
- "Compare the results of these two optimization plans"
- "What constraints should I use for unaccompanied minors?"

### Debrief Analysis
- "Summarize this incident for me"
- "What were the main factors in this delay?"
- "Generate lessons learned from this incident"
- "How does this compare to similar past incidents?"

## Best Practices
1. Ask specific questions for more precise answers
2. Provide context in your questions when needed
3. Use the assistant to explore platform capabilities
4. Phrase requests as natural questions rather than commands
5. Review AI-generated content for accuracy before taking action
6. Use suggested questions to discover assistant capabilities
7. Remember that all assistant interactions are logged for quality improvement