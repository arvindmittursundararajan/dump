// Monitoring Page JavaScript

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Load initial data
    loadAlerts();
    loadRules();
    
    // Set up auto-refresh every 30 seconds
    setInterval(loadAlerts, 30000);
    
    // Initialize form handlers
    initializeFormHandlers();
});

// Load alerts from the server
function loadAlerts() {
    const alertsContainer = document.getElementById('alerts-container');
    if (!alertsContainer) return;
    
    // Show loading state
    alertsContainer.innerHTML = `
        <div class="spinner"></div>
        <p class="text-center">Loading alerts...</p>
    `;
    
    // Fetch alerts from server
    fetch('/api/alerts')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Handle both array and object with alerts property
            const alerts = Array.isArray(data) ? data : (data.alerts || []);
            
            if (alerts.length > 0) {
                displayAlerts(alerts);
            } else {
                alertsContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-1"></i> No active alerts
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading alerts:', error);
            alertsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-1"></i> Error loading alerts: ${error.message}
                </div>
            `;
        });
}

// Display alerts in the container
function displayAlerts(alerts) {
    const alertsContainer = document.getElementById('alerts-container');
    if (!alertsContainer) return;
    
    alertsContainer.innerHTML = alerts.map(alert => `
        <div class="alert alert-${getSeverityClass(alert.severity)} mb-2" role="alert">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <strong>${alert.title}</strong>
                    <p class="mb-0 small">${alert.description}</p>
                    <div class="mt-1">
                        <span class="badge bg-${getSeverityClass(alert.severity)} me-1">${alert.severity}</span>
                        <span class="badge bg-secondary me-1">${alert.category}</span>
                        <small class="text-muted">${formatTimestamp(alert.timestamp)}</small>
                    </div>
                </div>
                <div>
                    <button class="btn btn-sm btn-outline-secondary" onclick="showAlertDetails('${alert.id}')">
                        <i class="fas fa-info-circle"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Load rules from the server
function loadRules() {
    const rulesContainer = document.getElementById('rules-container');
    if (!rulesContainer) return;
    
    // Show loading state
    rulesContainer.innerHTML = `
        <div class="spinner"></div>
        <p class="text-center">Loading rules...</p>
    `;
    
    // Fetch rules from server
    fetch('/api/rules')
        .then(response => response.json())
        .then(data => {
            if (data.rules && data.rules.length > 0) {
                displayRules(data.rules);
            } else {
                rulesContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-1"></i> No active rules
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading rules:', error);
            rulesContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-1"></i> Error loading rules
                </div>
            `;
        });
}

// Display rules in the container
function displayRules(rules) {
    const rulesContainer = document.getElementById('rules-container');
    if (!rulesContainer) return;
    
    rulesContainer.innerHTML = rules.map(rule => `
        <div class="card mb-2">
            <div class="card-body p-2">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h6 class="mb-1">${rule.name}</h6>
                        <p class="mb-1 small">${rule.description}</p>
                        <div>
                            <span class="badge bg-${getSeverityClass(rule.severity)} me-1">${rule.severity}</span>
                            <span class="badge bg-secondary">${rule.category}</span>
                        </div>
                    </div>
                    <button class="btn btn-sm btn-outline-secondary" onclick="showRuleDetails('${rule.id}')">
                        <i class="fas fa-info-circle"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Initialize form handlers
function initializeFormHandlers() {
    // Alert filter form
    const filterForm = document.getElementById('alert-filter-form');
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            loadAlerts(); // Reload with filters
        });
    }
    
    // Rule creation form
    const ruleForm = document.getElementById('rule-form');
    if (ruleForm) {
        ruleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            createRule();
        });
    }
    
    // Natural language query form
    const nlQueryForm = document.getElementById('nl-query-form');
    if (nlQueryForm) {
        nlQueryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            processNLQuery();
        });
    }
}

// Show alert details in modal
function showAlertDetails(alertId) {
    fetch(`/api/alerts/${alertId}`)
        .then(response => response.json())
        .then(alert => {
            const container = document.getElementById('alert-details-container');
            const title = document.getElementById('alert-detail-title');
            
            if (container && title) {
                title.textContent = alert.title;
                container.innerHTML = `
                    <div class="mb-3">
                        <h6>Description</h6>
                        <p>${alert.description}</p>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Details</h6>
                            <ul class="list-unstyled">
                                <li><strong>Severity:</strong> ${alert.severity}</li>
                                <li><strong>Category:</strong> ${alert.category}</li>
                                <li><strong>Status:</strong> ${alert.status}</li>
                                <li><strong>Created:</strong> ${formatTimestamp(alert.timestamp)}</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6>Impact</h6>
                            <ul class="list-unstyled">
                                <li><strong>Affected Flights:</strong> ${alert.affected_flights || 'None'}</li>
                                <li><strong>Affected Passengers:</strong> ${alert.affected_passengers || 'None'}</li>
                                <li><strong>Cost Impact:</strong> ${alert.cost_impact || 'None'}</li>
                            </ul>
                        </div>
                    </div>
                `;
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('alert-details-modal'));
                modal.show();
            }
        })
        .catch(error => {
            console.error('Error loading alert details:', error);
            showToast('Error loading alert details', 'danger');
        });
}

// Show rule details in modal
function showRuleDetails(ruleId) {
    fetch(`/api/rules/${ruleId}`)
        .then(response => response.json())
        .then(rule => {
            const container = document.getElementById('rule-details-container');
            const title = document.getElementById('rule-detail-title');
            
            if (container && title) {
                title.textContent = rule.name;
                container.innerHTML = `
                    <div class="mb-3">
                        <h6>Description</h6>
                        <p>${rule.description}</p>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Details</h6>
                            <ul class="list-unstyled">
                                <li><strong>Category:</strong> ${rule.category}</li>
                                <li><strong>Severity:</strong> ${rule.severity}</li>
                                <li><strong>Status:</strong> ${rule.status}</li>
                                <li><strong>Created:</strong> ${formatTimestamp(rule.created_at)}</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6>Expression</h6>
                            <pre class="bg-light p-2 rounded"><code>${rule.expression}</code></pre>
                        </div>
                    </div>
                `;
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('rule-details-modal'));
                modal.show();
            }
        })
        .catch(error => {
            console.error('Error loading rule details:', error);
            showToast('Error loading rule details', 'danger');
        });
}

// Create a new rule
function createRule() {
    const form = document.getElementById('rule-form');
    if (!form) return;
    
    const formData = {
        name: document.getElementById('rule-name').value,
        description: document.getElementById('rule-description').value,
        category: document.getElementById('rule-category').value,
        severity: document.getElementById('rule-severity').value,
        expression: document.getElementById('rule-expression').value
    };
    
    fetch('/api/rules', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Close modal and reload rules
            const modal = bootstrap.Modal.getInstance(document.getElementById('new-rule-modal'));
            modal.hide();
            loadRules();
            showToast('Rule created successfully', 'success');
        } else {
            showToast(data.message || 'Error creating rule', 'danger');
        }
    })
    .catch(error => {
        console.error('Error creating rule:', error);
        showToast('Error creating rule', 'danger');
    });
}

// Process natural language query
function processNLQuery() {
    const queryInput = document.getElementById('query-input');
    if (!queryInput) return;
    
    const query = queryInput.value.trim();
    if (!query) return;
    
    // Show loading state
    const resultsContainer = document.getElementById('nl-query-results');
    if (resultsContainer) {
        resultsContainer.innerHTML = `
            <div class="spinner"></div>
            <p class="text-center">Processing query...</p>
        `;
    }
    
    fetch('/api/nl-query', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query })
    })
    .then(response => response.json())
    .then(data => {
        if (resultsContainer) {
            if (data.results && data.results.length > 0) {
                displayQueryResults(data.results);
            } else {
                resultsContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-1"></i> No results found
                    </div>
                `;
            }
        }
    })
    .catch(error => {
        console.error('Error processing query:', error);
        if (resultsContainer) {
            resultsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-1"></i> Error processing query
                </div>
            `;
        }
    });
}

// Display query results
function displayQueryResults(results) {
    const resultsContainer = document.getElementById('nl-query-results');
    if (!resultsContainer) return;
    
    resultsContainer.innerHTML = results.map(result => `
        <div class="card mb-2">
            <div class="card-body p-2">
                <h6 class="mb-1">${result.title}</h6>
                <p class="mb-1 small">${result.description}</p>
                <div class="mt-1">
                    ${result.metrics ? `
                        <div class="d-flex flex-wrap">
                            ${Object.entries(result.metrics).map(([key, value]) => `
                                <div class="me-3">
                                    <small class="text-muted">${key}:</small>
                                    <strong>${value}</strong>
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `).join('');
}

// Utility functions
function getSeverityClass(severity) {
    switch (severity.toLowerCase()) {
        case 'critical':
            return 'danger';
        case 'warning':
            return 'warning';
        case 'info':
            return 'info';
        default:
            return 'secondary';
    }
}

function formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString();
}

function showToast(message, type = 'info') {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) return;
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
} 