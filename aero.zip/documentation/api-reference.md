# API Reference

## Overview
AeroOptima.ai provides a comprehensive set of API endpoints to interact with the platform's functionality. These endpoints are organized by module and follow RESTful design principles.

## Authentication
Currently, the API does not implement authentication, as it is designed for internal use within the airline operations environment. For production deployment, appropriate authentication mechanisms should be implemented.

## Response Format
All API responses follow a standard JSON format:

For successful responses:
```json
{
  "data": [result_object_or_array],
  "message": "Optional success message"
}
```

For error responses:
```json
{
  "error": "Error message",
  "details": "Optional additional error details"
}
```

## Data Hub API

### Get All Data Sources
Retrieves all available data sources.

- **URL**: `/api/data-sources`
- **Method**: `GET`
- **URL Parameters**: None
- **Query Parameters**:
  - `category` (optional): Filter by category
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": [
        {
          "id": 1,
          "name": "Flight Schedule",
          "category": "flights",
          "last_updated": "2025-05-01T14:30:00Z",
          "row_count": 1250,
          "quality_metrics": {
            "completeness": 0.98,
            "consistency": 0.95,
            "timeliness": 0.99
          }
        },
        ...
      ]
    }
    ```

### Get Specific Data Source
Retrieves details for a specific data source.

- **URL**: `/api/data-sources/:id`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the data source
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 1,
        "name": "Flight Schedule",
        "category": "flights",
        "last_updated": "2025-05-01T14:30:00Z",
        "row_count": 1250,
        "file_path": "uploads/flight_schedule.csv",
        "schema": { ... },
        "quality_metrics": { ... }
      }
    }
    ```
- **Error Response**:
  - Code: 404
  - Content: `{"error": "Data source not found"}`

### Upload Data
Uploads a new data file to the system.

- **URL**: `/api/upload-data`
- **Method**: `POST`
- **Content-Type**: `multipart/form-data`
- **Form Parameters**:
  - `file`: The data file to upload (CSV format)
  - `category`: Category of the data (flights, crew, aircraft)
  - `name`: Display name for the data source
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "name": "Updated Flight Schedule",
        "category": "flights",
        "row_count": 1300
      },
      "message": "Data uploaded successfully"
    }
    ```
- **Error Response**:
  - Code: 400
  - Content: `{"error": "Invalid file format"}`

### Get Data Quality
Retrieves quality metrics for a specific data source.

- **URL**: `/api/data-quality/:id`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the data source
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "completeness": 0.98,
        "consistency": 0.95,
        "timeliness": 0.99,
        "detailed_metrics": {
          "missing_values": 2.1,
          "duplicate_records": 0.5,
          "outliers": 1.2
        }
      }
    }
    ```

### Generate Schema
Generates SQL schema from a natural language description.

- **URL**: `/api/generate-schema`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "description": "Create a table for flight crew with name, position, qualifications, and duty time remaining"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "schema": "CREATE TABLE crew (\n  id INTEGER PRIMARY KEY,\n  name TEXT NOT NULL,\n  position TEXT NOT NULL,\n  qualifications JSON,\n  duty_time_remaining REAL\n);"
      }
    }
    ```

### Reset Database
Resets the database to its initial sample data state.

- **URL**: `/api/reset-database`
- **Method**: `POST`
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "message": "Database reset successfully"
    }
    ```

## Monitoring API

### Get All Alerts
Retrieves all alerts in the system.

- **URL**: `/api/alerts`
- **Method**: `GET`
- **Query Parameters**:
  - `active` (optional): Filter by active status (true/false)
  - `severity` (optional): Filter by severity (critical, major, info)
  - `category` (optional): Filter by category
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": [
        {
          "id": 1,
          "title": "Crew Duty Time Violation",
          "description": "Crew on flight AO123 will exceed duty time limits",
          "severity": "critical",
          "category": "crew",
          "timestamp": "2025-05-06T10:23:45Z",
          "is_active": true
        },
        ...
      ]
    }
    ```

### Get Specific Alert
Retrieves details for a specific alert.

- **URL**: `/api/alerts/:id`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the alert
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 1,
        "title": "Crew Duty Time Violation",
        "description": "Crew on flight AO123 will exceed duty time limits",
        "severity": "critical",
        "category": "crew",
        "source": "rule_engine",
        "timestamp": "2025-05-06T10:23:45Z",
        "is_active": true,
        "affected_entities": {
          "flights": ["AO123"],
          "crew": ["C12345", "C12346"]
        },
        "additional_data": { ... }
      }
    }
    ```

### Resolve Alert
Marks an alert as resolved.

- **URL**: `/api/alerts/:id/resolve`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the alert
- **Request Body**:
  ```json
  {
    "resolution_notes": "Crew reassigned to alternate flight"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 1,
        "is_active": false,
        "resolved_at": "2025-05-06T11:30:00Z",
        "resolution_notes": "Crew reassigned to alternate flight"
      },
      "message": "Alert resolved successfully"
    }
    ```

### Get All Rules
Retrieves all rules defined in the system.

- **URL**: `/api/rules`
- **Method**: `GET`
- **Query Parameters**:
  - `active` (optional): Filter by active status (true/false)
  - `category` (optional): Filter by category
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": [
        {
          "id": 1,
          "name": "Crew Duty Time",
          "description": "Alert when crew approaches maximum duty time",
          "category": "crew",
          "severity": "critical",
          "is_active": true
        },
        ...
      ]
    }
    ```

### Create Rule
Creates a new rule in the system.

- **URL**: `/api/rules`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "name": "Unaccompanied Minor Connection Risk",
    "description": "Alert when unaccompanied minors have less than 45 minutes for connection",
    "rule_text": "flight.has_um == true and flight.next_connection_time < 45",
    "category": "unaccompanied_minor",
    "severity": "critical"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "name": "Unaccompanied Minor Connection Risk",
        ...
      },
      "message": "Rule created successfully"
    }
    ```

### Update Rule
Updates an existing rule.

- **URL**: `/api/rules/:id`
- **Method**: `PUT`
- **URL Parameters**:
  - `id`: ID of the rule
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "rule_text": "flight.has_um == true and flight.next_connection_time < 50",
    "severity": "critical",
    "is_active": true
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "updated_at": "2025-05-06T15:30:00Z",
        ...
      },
      "message": "Rule updated successfully"
    }
    ```

### Evaluate Rule
Tests a rule against provided data.

- **URL**: `/api/evaluate-rule/:id`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the rule
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "data": {
      "flight": {
        "has_um": true,
        "next_connection_time": 30
      }
    }
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "result": true,
        "matched": true,
        "details": "Rule would trigger an alert for this data"
      }
    }
    ```

### Natural Language Query
Converts natural language to rule or SQL syntax.

- **URL**: `/api/natural-language-query`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "query": "Show me all flights with unaccompanied minors having tight connections"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "rule_text": "flight.has_um == true and flight.next_connection_time < 60",
        "sql_query": "SELECT * FROM flights WHERE has_um = 1 AND next_connection_time < 60"
      }
    }
    ```

## Optimizer API

### Get All Optimization Plans
Retrieves all optimization plans in the system.

- **URL**: `/api/plans`
- **Method**: `GET`
- **Query Parameters**:
  - `scenario` (optional): Filter by scenario type
  - `status` (optional): Filter by status (draft, running, completed, failed)
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": [
        {
          "id": 1,
          "name": "Crew Recovery Plan A",
          "scenario": "crew_recovery",
          "status": "completed",
          "score": 85.4,
          "created_at": "2025-05-05T09:30:00Z"
        },
        ...
      ]
    }
    ```

### Get Specific Plan
Retrieves details for a specific optimization plan.

- **URL**: `/api/plans/:id`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the plan
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 1,
        "name": "Crew Recovery Plan A",
        "description": "Recovery plan for crew affected by JFK groundstop",
        "scenario": "crew_recovery",
        "constraints": { ... },
        "objective_weights": { ... },
        "created_at": "2025-05-05T09:30:00Z",
        "status": "completed",
        "results": { ... },
        "score": 85.4,
        "execution_time": 3.2,
        "version": 1
      }
    }
    ```

### Create Plan
Creates a new optimization plan.

- **URL**: `/api/plans`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "name": "UM Protection Plan",
    "description": "Plan to protect unaccompanied minors during weather disruption",
    "scenario": "unaccompanied_minor",
    "constraints": {
      "no_overnight_transit": true,
      "max_connections": 1,
      "min_staff_at_transit": 2
    },
    "objective_weights": {
      "safety": 0.7,
      "passenger_satisfaction": 0.2,
      "cost": 0.1
    }
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "name": "UM Protection Plan",
        "status": "draft",
        ...
      },
      "message": "Plan created successfully"
    }
    ```

### Run Plan
Executes an optimization plan.

- **URL**: `/api/plans/:id/run`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the plan
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "status": "completed",
        "results": { ... },
        "score": 92.7,
        "execution_time": 2.8
      },
      "message": "Plan executed successfully"
    }
    ```

### Clone Plan
Creates a new version of an existing plan.

- **URL**: `/api/plans/:id/clone`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the plan to clone
- **Request Body**:
  ```json
  {
    "name": "UM Protection Plan V2",
    "description": "Updated version with adjusted constraints"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 6,
        "name": "UM Protection Plan V2",
        "version": 2,
        ...
      },
      "message": "Plan cloned successfully"
    }
    ```

### Get Plan Summary
Retrieves an AI-generated summary of a plan.

- **URL**: `/api/plans/:id/summary`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the plan
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "summary": "This unaccompanied minor protection plan prioritizes passenger safety with a 70% weighting, focusing on maintaining staff presence at all connection points and preventing overnight stays. The plan achieves a 92.7% overall score with excellent safety metrics but moderate cost efficiency."
      }
    }
    ```

### Generate Flowchart
Generates a visualization for an optimization scenario.

- **URL**: `/api/generate-flowchart`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "scenario": "unaccompanied_minor",
    "constraints": {
      "no_overnight_transit": true,
      "max_connections": 1
    }
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "chart": "graph TD\n  A[Start] --> B{UM Present?}\n  B -->|Yes| C[Check Connection Time]\n  ..."
      }
    }
    ```

## Debrief API

### Get All Incidents
Retrieves all incidents in the system.

- **URL**: `/api/incidents`
- **Method**: `GET`
- **Query Parameters**:
  - `category` (optional): Filter by category
  - `severity` (optional): Filter by severity
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": [
        {
          "id": 1,
          "title": "JFK Ground Stop",
          "start_time": "2025-05-01T14:00:00Z",
          "end_time": "2025-05-01T18:30:00Z",
          "category": "weather",
          "severity": "major"
        },
        ...
      ]
    }
    ```

### Get Specific Incident
Retrieves details for a specific incident.

- **URL**: `/api/incidents/:id`
- **Method**: `GET`
- **URL Parameters**:
  - `id`: ID of the incident
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 1,
        "title": "JFK Ground Stop",
        "description": "ATC ground stop due to severe winter storm",
        "start_time": "2025-05-01T14:00:00Z",
        "end_time": "2025-05-01T18:30:00Z",
        "category": "weather",
        "severity": "major",
        "timeline": [ ... ],
        "affected_entities": { ... },
        "root_cause": "...",
        "resolution": "...",
        "lessons_learned": "..."
      }
    }
    ```

### Create Incident
Creates a new incident record.

- **URL**: `/api/incidents`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "title": "Crew Scheduling System Outage",
    "description": "Complete loss of crew scheduling system functionality",
    "start_time": "2025-05-06T08:15:00Z",
    "end_time": "2025-05-06T10:30:00Z",
    "category": "system",
    "severity": "critical"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "id": 5,
        "title": "Crew Scheduling System Outage",
        ...
      },
      "message": "Incident created successfully"
    }
    ```

### Add Timeline Event
Adds an event to an incident timeline.

- **URL**: `/api/incidents/:id/timeline`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the incident
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "event": "Manual crew assignment process initiated",
    "timestamp": "2025-05-06T08:30:00Z",
    "category": "recovery"
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "timeline": [ ... updated timeline array ... ]
      },
      "message": "Event added successfully"
    }
    ```

### Generate Root Cause Analysis
Generates AI-powered root cause analysis for an incident.

- **URL**: `/api/incidents/:id/root-cause`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the incident
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "root_cause": "The crew scheduling system outage was caused by an unplanned database failover that occurred during a routine maintenance window. The primary cause was insufficient testing of the failover mechanism combined with unexpected data volume."
      },
      "message": "Root cause analysis generated successfully"
    }
    ```

### Generate Postmortem
Generates AI-powered postmortem report for an incident.

- **URL**: `/api/incidents/:id/postmortem`
- **Method**: `POST`
- **URL Parameters**:
  - `id`: ID of the incident
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "lessons_learned": "1. Implement more comprehensive failover testing procedures\n2. Create redundant access methods for critical crew data\n3. Improve communication protocols during system outages\n4. Review manual backup procedures for all critical systems"
      },
      "message": "Postmortem generated successfully"
    }
    ```

### Generate Timeline Chart
Creates a Mermaid.js visualization of an incident timeline.

- **URL**: `/api/generate-timeline-chart`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "events": [
      {
        "timestamp": "2025-05-06T08:15:00Z",
        "event": "System outage detected",
        "category": "incident"
      },
      {
        "timestamp": "2025-05-06T08:30:00Z",
        "event": "Manual crew assignment process initiated",
        "category": "recovery"
      },
      ...
    ]
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "chart": "graph LR\n  A[08:15 - System outage detected] --> B[08:30 - Manual crew assignment process initiated]\n  ..."
      }
    }
    ```

## Chat API

### Send Chat Message
Sends a message to the Gemini AI assistant.

- **URL**: `/api/chat`
- **Method**: `POST`
- **Content-Type**: `application/json`
- **Request Body**:
  ```json
  {
    "message": "What's the best way to handle unaccompanied minors during a weather disruption?",
    "history": [ ... previous messages ... ],
    "context": {
      "page": "optimizer",
      "selectedPlan": 5
    }
  }
  ```
- **Success Response**: 
  - Code: 200
  - Content:
    ```json
    {
      "data": {
        "response": "When handling unaccompanied minors during weather disruptions, prioritize their safety above all else. The best approach includes: 1) Ensuring continuous supervision by qualified staff, 2) Maintaining clear communication with guardians, 3) Avoiding overnight connections, and 4) Limiting to a maximum of one connection. Your current optimization plan already incorporates these safety constraints."
      }
    }
    ```

## Error Codes
- **400 Bad Request**: Invalid parameters or request format
- **404 Not Found**: Requested resource does not exist
- **405 Method Not Allowed**: HTTP method not supported for this endpoint
- **422 Unprocessable Entity**: Request format correct but semantically invalid
- **500 Internal Server Error**: Unexpected server error