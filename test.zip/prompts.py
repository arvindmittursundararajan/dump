from styles import style_description

def recommendation_prompt(content):
    return (
        "You are an expert content editor. Read the following HTML content and suggest 9-10 specific, actionable improvement ideas to enhance clarity, engagement, completeness, and SEO. "
        "Each idea must be a concise phrase of 4-6 words, not a full sentence. "
        "Return ONLY a plain numbered list of improvement ideas, with each item on a new line, and nothing else. "
        "Do NOT include explanations, markdown, code blocks, or any extra text.\n"
        "Here is an example of the format you MUST use:\n"
        "1. Add meta description\n"
        "2. Use semantic HTML tags\n"
        "3. Add alt text to images\n"
        "4. Clarify list context\n"
        "5. Shorten intro paragraph\n"
        "6. Descriptive external links\n"
        "7. Semantic HTML for quotes\n"
        "8. Define target audience\n"
        "9. Add political SEO keywords\n"
        "10. Add internal blog links\n"
        "Repeat ONLY the numbered list as shown above, with no explanations, markdown, or extra text.\n\n"
        "Content:\n" + content
    )

def rewrite_prompt(content, selected_recommendations, additional_points=None):
    return (
        "You are an expert content editor. Given the following HTML content, apply these improvement ideas (only the ones checked):\n"
        + "\n".join(f"- {r}" for r in selected_recommendations) +
        (f"\n\nAdditionally, address these points: {additional_points}" if additional_points else "") +
        f"\n\n{style_description()}"
        "\n\nReturn the improved content as a complete, valid HTML page (including <html>, <head>, and <body> tags) only. Do not include any explanations, markdown, or extra text.\n\nContent:\n" + content
    ) 