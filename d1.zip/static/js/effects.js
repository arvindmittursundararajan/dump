/**
 * ADW Dashboard Advanced UI Effects
 * This file contains JavaScript functionality to enhance the UI experience
 */

// Counter animation for metrics
function animateMetricCounters() {
    const countElements = document.querySelectorAll('.metric-value');
    
    countElements.forEach(el => {
        const content = el.textContent;
        // Only apply to numeric content
        if (/\d/.test(content)) {
            // Add animation class
            el.classList.add('count-animation');
            
            // For elements containing MB, KB, etc.
            if (content.includes('MB') || content.includes('s')) {
                const num = parseFloat(content);
                if (!isNaN(num)) {
                    // Create counter animation
                    const countUp = { value: 0 };
                    const targetValue = num;
                    const format = content.replace(/[\d\.]+/, '##');
                    
                    // Animate
                    anime({
                        targets: countUp,
                        value: targetValue,
                        duration: 1500,
                        easing: 'easeOutExpo',
                        round: 100,
                        update: function() {
                            el.textContent = format.replace('##', countUp.value.toFixed(2));
                        }
                    });
                }
            } else {
                // For integer values
                const num = parseInt(content, 10);
                if (!isNaN(num)) {
                    const countUp = { value: 0 };
                    
                    anime({
                        targets: countUp,
                        value: num,
                        duration: 1500,
                        easing: 'easeOutExpo',
                        round: 1,
                        update: function() {
                            el.textContent = countUp.value;
                        }
                    });
                }
            }
        }
    });
}

// Loading spinners for data fetching
function showLoadingSpinner(targetElement) {
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner-container';
    spinner.innerHTML = `
        <div class="loading-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-inner"></div>
        </div>
        <div class="spinner-text">Loading data...</div>
    `;
    
    targetElement.innerHTML = '';
    targetElement.appendChild(spinner);
}

function removeLoadingSpinner(targetElement) {
    const spinner = targetElement.querySelector('.loading-spinner-container');
    if (spinner) {
        // Add fade-out animation
        spinner.classList.add('fade-out');
        setTimeout(() => {
            if (spinner.parentNode === targetElement) {
                targetElement.removeChild(spinner);
            }
        }, 300);
    }
}

// Advanced loading spinner for AJAX requests
let activeRequests = 0;
function setupAjaxLoadingIndicator() {
    $(document).ajaxStart(function() {
        activeRequests++;
        if (!$('#global-loading-indicator').length) {
            $('body').append('<div id="global-loading-indicator"><div class="spinner-ring"></div></div>');
        }
        $('#global-loading-indicator').show();
    });
    
    $(document).ajaxStop(function() {
        activeRequests--;
        if (activeRequests <= 0) {
            $('#global-loading-indicator').fadeOut(300);
        }
    });
}

// Glass effect parallax for cards
function setupParallaxEffects() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const xPercent = x / rect.width;
            const yPercent = y / rect.height;
            
            // Calculate rotation and transform
            const rotateX = (0.5 - yPercent) * 4;
            const rotateY = (xPercent - 0.5) * 4;
            const brightness = 1 + (xPercent * yPercent) * 0.1;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            card.style.filter = `brightness(${brightness})`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
            card.style.filter = 'brightness(1)';
        });
    });
}

// Add particle background effect
function initParticleBackground() {
    if (window.innerWidth < 768) return; // Skip on mobile
    
    const particleContainer = document.createElement('div');
    particleContainer.id = 'particles-background';
    document.body.appendChild(particleContainer);
    
    particlesJS('particles-background', {
        particles: {
            number: {
                value: 20,
                density: { enable: true, value_area: 800 }
            },
            color: { value: "#e63946" },
            shape: {
                type: "circle",
                stroke: { width: 0, color: "#000000" }
            },
            opacity: {
                value: 0.1,
                random: true,
                anim: { enable: true, speed: 0.5, opacity_min: 0.1, sync: false }
            },
            size: {
                value: 5,
                random: true,
                anim: { enable: true, speed: 2, size_min: 1, sync: false }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: "#e63946",
                opacity: 0.1,
                width: 1
            },
            move: {
                enable: true,
                speed: 1,
                direction: "none",
                random: true,
                straight: false,
                out_mode: "out",
                bounce: false
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: { enable: true, mode: "grab" },
                onclick: { enable: true, mode: "push" },
                resize: true
            },
            modes: {
                grab: { distance: 140, line_linked: { opacity: 0.3 } },
                push: { particles_nb: 3 }
            }
        },
        retina_detect: true
    });
}

// Setup selection dropdown animations
function setupSelectAnimations() {
    const selects = document.querySelectorAll('select');
    
    selects.forEach(select => {
        // Add styling to select elements
        select.classList.add('animated-select');
        
        // Add event listeners for change
        select.addEventListener('change', function() {
            this.classList.add('select-changed');
            setTimeout(() => this.classList.remove('select-changed'), 500);
            
            // Find the target for the spinner
            let targetElement;
            if (this.id === 'catalog-select') {
                targetElement = document.getElementById('schema-select-container');
                showLoadingSpinner(targetElement);
            } else if (this.id === 'schema-select') {
                targetElement = document.getElementById('table-select-container');
                showLoadingSpinner(targetElement);
            }
        });
    });
}

// Initialize all UI enhancements
function initUIEnhancements() {
    // Run on document ready
    document.addEventListener('DOMContentLoaded', function() {
        // Setup loading indicators for AJAX
        setupAjaxLoadingIndicator();
        
        // Setup animations for select dropdowns
        setupSelectAnimations();
        
        // Setup parallax effects
        setupParallaxEffects();
        
        // Initialize particle background if available
        if (typeof particlesJS !== 'undefined') {
            initParticleBackground();
        }
        
        // Run metric counter animations if on analysis page
        if (document.querySelector('.metrics-card')) {
            animateMetricCounters();
        }
    });
}

// Call initialization
initUIEnhancements();