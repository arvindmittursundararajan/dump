import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Create the Flask application
app = Flask(__name__)

# Load configuration from config.py
app.config.from_pyfile('config.py')
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Configure SQLAlchemy
# Force SQLite database usage as per requirements
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///predictive_maintenance.db"

# Initialize SQLAlchemy with the app
db.init_app(app)

# Create upload directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Initialize the database
with app.app_context():
    import models
    from routes import register_routes
    
    # Register routes
    register_routes(app)
    
    # Create database tables
    db.create_all()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
