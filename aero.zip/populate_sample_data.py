from app import app, db
from models import Flight, Aircraft, Crew, Rule, Alert, Incident, OptimizationPlan, DataSource
from datetime import datetime, timedelta
import json
import random

def create_sample_data():
    """Create sample data for the AeroOptima.ai platform"""
    with app.app_context():
        print("Creating sample data for AeroOptima.ai...")
        
        # Clean existing data
        db.session.query(Flight).delete()
        db.session.query(Aircraft).delete()
        db.session.query(Crew).delete()
        db.session.query(Rule).delete()
        db.session.query(Alert).delete()
        db.session.query(Incident).delete()
        db.session.query(OptimizationPlan).delete()
        db.session.query(DataSource).delete()
        db.session.commit()
        
        # Create data sources
        create_data_sources()
        
        # Create aircraft
        create_aircraft()
        
        # Create crew
        create_crew()
        
        # Create flights
        create_flights()
        
        # Create rules for various scenarios
        create_rules()
        
        # Create alerts based on those rules
        create_alerts()
        
        # Create incidents for analysis
        create_incidents()
        
        # Create optimization plans
        create_optimization_plans()
        
        print("Sample data creation complete!")

def create_data_sources():
    """Create sample data sources"""
    sources = [
        {
            "name": "Crew Duty Time Feed",
            "category": "Crew Schedules",
            "quality_metrics": {
                "accuracy": 0.97,
                "completeness": 0.99,
                "validity": 0.98,
                "timeliness": 0.95
            },
            "row_count": 1250
        },
        {
            "name": "Flight Schedule",
            "category": "Flight Schedules",
            "quality_metrics": {
                "accuracy": 0.99,
                "completeness": 0.98,
                "validity": 0.97,
                "timeliness": 0.96
            },
            "row_count": 875
        },
        {
            "name": "Aircraft Maintenance Feed",
            "category": "Aircraft Operations",
            "quality_metrics": {
                "accuracy": 0.96,
                "completeness": 0.94,
                "validity": 0.98,
                "timeliness": 0.93
            },
            "row_count": 320
        },
        {
            "name": "Passenger Booking Data",
            "category": "Passenger Data",
            "quality_metrics": {
                "accuracy": 0.98,
                "completeness": 0.95,
                "validity": 0.96,
                "timeliness": 0.92
            },
            "row_count": 5420
        },
        {
            "name": "Weather Alerts Feed",
            "category": "Weather Data",
            "quality_metrics": {
                "accuracy": 0.91,
                "completeness": 0.97,
                "validity": 0.93,
                "timeliness": 0.99
            },
            "row_count": 148
        },
        {
            "name": "Station Resource Allocation",
            "category": "Station Operations",
            "quality_metrics": {
                "accuracy": 0.94,
                "completeness": 0.92,
                "validity": 0.95,
                "timeliness": 0.93
            },
            "row_count": 78
        },
    ]
    
    for source_data in sources:
        source = DataSource(
            name=source_data["name"],
            category=source_data["category"],
            last_updated=datetime.utcnow() - timedelta(hours=random.randint(1, 24)),
            row_count=source_data["row_count"],
            quality_metrics=source_data["quality_metrics"]
        )
        db.session.add(source)
    
    db.session.commit()
    print("Created sample data sources")

def create_aircraft():
    """Create sample aircraft"""
    aircraft_types = [
        ("A320", 180, 3300),
        ("A321", 220, 3200),
        ("B737", 189, 3300),
        ("B787", 296, 7635),
        ("A350", 325, 8100),
        ("E190", 114, 2450),
        ("B777", 396, 7370)
    ]
    
    registrations = ["N", "G-", "VT-", "A6-", "F-", "JA-", "D-"]
    
    aircraft = []
    for i in range(25):
        reg_prefix = random.choice(registrations)
        aircraft_type, capacity, range_nm = random.choice(aircraft_types)
        reg_suffix = ''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZ', k=3))
        registration = f"{reg_prefix}{reg_suffix}"
        
        # Set some aircraft to maintenance
        if i % 8 == 0:
            status = "maintenance"
            maintenance_status = "scheduled maintenance"
            next_maintenance = datetime.utcnow() + timedelta(days=random.randint(1, 10))
        else:
            status = "active"
            maintenance_status = "operational"
            next_maintenance = datetime.utcnow() + timedelta(days=random.randint(20, 60))
        
        aircraft_data = {
            "manufacturer": "Airbus" if aircraft_type.startswith("A") else ("Boeing" if aircraft_type.startswith("B") else "Embraer"),
            "year": random.randint(2010, 2023),
            "engines": 2,
            "fuel_efficiency_rating": round(random.uniform(4.0, 4.9), 1),
            "last_c_check": (datetime.utcnow() - timedelta(days=random.randint(30, 300))).isoformat()
        }
        
        ac = Aircraft(
            registration=registration,
            aircraft_type=aircraft_type,
            capacity=capacity,
            range_nm=range_nm,
            status=status,
            maintenance_status=maintenance_status,
            next_maintenance=next_maintenance,
            aircraft_data=aircraft_data
        )
        db.session.add(ac)
        aircraft.append(ac)
    
    db.session.commit()
    print(f"Created {len(aircraft)} sample aircraft")
    return aircraft

def create_crew():
    """Create sample crew members"""
    positions = [
        "Captain", "First Officer", "Flight Attendant", "Purser", "Relief Pilot"
    ]
    
    bases = ["JFK", "LAX", "ORD", "DFW", "ATL", "LHR", "DXB", "SIN", "DEL", "FRA"]
    
    first_names = ["James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", 
                  "William", "Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
                  "Thomas", "Sarah", "Charles", "Margaret", "Christopher", "Karen", "Daniel", "Nancy",
                  "Matthew", "Lisa", "Anthony", "Betty", "Mark", "Sandra", "Donald", "Ashley",
                  "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna"]
    
    last_names = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson",
                 "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris", "Martin",
                 "Thompson", "Garcia", "Martinez", "Robinson", "Clark", "Rodriguez", "Lewis", "Lee",
                 "Walker", "Hall", "Allen", "Young", "Hernandez", "King", "Wright", "Lopez", "Hill",
                 "Scott", "Green", "Adams", "Baker", "Gonzalez", "Nelson", "Carter", "Mitchell", "Perez"]
    
    crew = []
    for i in range(80):
        position = positions[random.randint(0, len(positions)-1)]
        base = bases[random.randint(0, len(bases)-1)]
        
        # Create more varied duty time remaining and rest required values
        # Lower values will trigger alerts for crew duty time violations
        if i % 10 == 0:  # 10% of crew with low duty time
            duty_time_remaining = random.uniform(0.5, 1.5)
            rest_required = random.uniform(10.0, 12.0)
        else:
            duty_time_remaining = random.uniform(4.0, 9.0)
            rest_required = random.uniform(0.0, 8.0)
        
        # Qualifications based on position
        if position == "Captain" or position == "First Officer":
            qualifications = {
                "aircraft_types": random.sample(["A320", "A321", "B737", "B787", "A350", "E190", "B777"], k=random.randint(1, 3)),
                "instrument_rating": True,
                "medical_expiry": (datetime.utcnow() + timedelta(days=random.randint(30, 360))).isoformat(),
                "route_qualifications": random.sample(["NAT", "PAC", "EUR", "ASI", "AFR"], k=random.randint(1, 3)),
                "language_proficiency": random.sample(["English", "Spanish", "French", "German", "Arabic", "Mandarin"], k=random.randint(1, 3)),
                "training_complete": True
            }
        else:  # Flight attendants and pursers
            qualifications = {
                "emergency_training": True,
                "medical_training": random.choice([True, False]),
                "language_proficiency": random.sample(["English", "Spanish", "French", "German", "Arabic", "Mandarin"], k=random.randint(1, 4)),
                "service_training": True,
                "years_experience": random.randint(1, 20)
            }
        
        # Status - some crew will be on leave, sick, etc.
        status_options = ["active", "active", "active", "active", "leave", "training", "sick"]
        status = random.choice(status_options)
        
        first_name = random.choice(first_names)
        last_name = random.choice(last_names)
        name = f"{first_name} {last_name}"
        
        # Create a unique staff ID
        staff_id = f"C{random.randint(10000, 99999)}"
        
        crew_data = {
            "nationality": random.choice(["US", "UK", "UAE", "SG", "IN", "DE", "FR", "ES", "JP", "AU"]),
            "joined_date": (datetime.utcnow() - timedelta(days=random.randint(90, 3650))).isoformat(),
            "seniority_number": random.randint(1, 1000),
            "recurrent_training_due": (datetime.utcnow() + timedelta(days=random.randint(-30, 180))).isoformat()
        }
        
        c = Crew(
            staff_id=staff_id,
            name=name,
            position=position,
            base=base,
            status=status,
            duty_time_remaining=duty_time_remaining,
            rest_required=rest_required,
            qualifications=qualifications,
            crew_data=crew_data
        )
        db.session.add(c)
        crew.append(c)
    
    db.session.commit()
    print(f"Created {len(crew)} sample crew members")
    return crew

def create_flights():
    """Create sample flights"""
    airports = ["JFK", "LAX", "ORD", "DFW", "ATL", "LHR", "DXB", "SIN", "DEL", "FRA", 
               "HKG", "ICN", "NRT", "SYD", "YYZ", "MEX", "GRU", "MAD", "AMS", "CDG"]
    
    aircraft = Aircraft.query.all()
    aircraft_ids = [a.registration for a in aircraft]
    
    flights = []
    for i in range(200):
        # Determine origin and destination
        origin = random.choice(airports)
        destination = random.choice([a for a in airports if a != origin])
        
        # Create flight number
        flight_number = f"AO{random.randint(100, 999)}"
        
        # Scheduled times
        now = datetime.utcnow()
        scheduled_departure = now + timedelta(days=random.randint(-2, 5),
                                            hours=random.randint(0, 23),
                                            minutes=random.randint(0, 59))
        
        # Flight duration between 1-15 hours
        flight_duration = timedelta(hours=random.randint(1, 15),
                                   minutes=random.randint(0, 59))
        
        scheduled_arrival = scheduled_departure + flight_duration
        
        # Actual times - some flights will be delayed or on time
        if random.random() < 0.25:  # 25% chance of delay
            delay_minutes = random.randint(15, 240)
            actual_departure = scheduled_departure + timedelta(minutes=delay_minutes)
            
            # 10% chance of extended flight time
            if random.random() < 0.1:
                actual_arrival = scheduled_arrival + timedelta(minutes=delay_minutes + random.randint(10, 60))
            else:
                actual_arrival = scheduled_arrival + timedelta(minutes=delay_minutes)
        else:
            # 80% of on-time flights have actual times, 20% don't (not departed yet)
            if random.random() < 0.8 and scheduled_departure < now:
                actual_departure = scheduled_departure + timedelta(minutes=random.randint(-10, 10))
                actual_arrival = scheduled_arrival + timedelta(minutes=random.randint(-15, 15))
            else:
                actual_departure = None
                actual_arrival = None
        
        # Flight status
        if scheduled_departure > now:
            status = "scheduled"
        elif actual_departure is None:
            status = "scheduled"
        elif actual_arrival is None:
            status = "in-air"
        else:
            status = "completed"
        
        # 5% chance of cancellation
        if random.random() < 0.05:
            status = "cancelled"
            actual_departure = None
            actual_arrival = None
        
        # 3% chance of diversion
        diversion = False
        diverted_to = None
        if status == "in-air" and random.random() < 0.03:
            status = "diverted"
            diversion = True
            diverted_to = random.choice([a for a in airports if a != origin and a != destination])
        
        # Aircraft assignment
        aircraft_id = random.choice(aircraft_ids)
        
        # Additional flight data
        flight_data = {
            "scheduled_duration_mins": int(flight_duration.total_seconds() / 60),
            "passenger_count": random.randint(50, 400),
            "load_factor": round(random.uniform(0.65, 0.95), 2),
            "meal_service": random.choice([True, False]),
            "tail_wind": random.randint(-50, 100),
            "cruising_altitude": random.randint(30000, 42000)
        }
        
        if diversion:
            flight_data["diversion"] = {
                "diverted_to": diverted_to,
                "reason": random.choice(["Weather", "Medical Emergency", "Technical Issue", "Security"]),
                "estimated_arrival": (scheduled_departure + timedelta(hours=random.randint(1, 5))).isoformat()
            }
        
        f = Flight(
            flight_number=flight_number,
            origin=origin,
            destination=destination,
            scheduled_departure=scheduled_departure,
            scheduled_arrival=scheduled_arrival,
            actual_departure=actual_departure,
            actual_arrival=actual_arrival,
            aircraft_id=aircraft_id,
            status=status,
            flight_data=flight_data
        )
        db.session.add(f)
        flights.append(f)
    
    db.session.commit()
    print(f"Created {len(flights)} sample flights")
    return flights

def create_rules():
    """Create sample rules for different scenarios"""
    rules = [
        # 1. Unaccompanied Minor Disruptions
        {
            "name": "Unaccompanied Minor Connection Risk",
            "description": "Alerts when an unaccompanied minor has less than 45 minutes to make a connection",
            "rule_text": "passenger.type == 'UM' and connection.minutes < 45",
            "category": "Passenger Service",
            "severity": "critical",
            "rule_config": {
                "required_action": "Assign escort",
                "notification_to": ["Station Manager", "Customer Service"],
                "compliance_ref": "UM-CONNECT-45"
            }
        },
        {
            "name": "Stranded UM Detection",
            "description": "Detects unaccompanied minors affected by flight cancellations or severe delays",
            "rule_text": "passenger.type == 'UM' and (flight.status == 'cancelled' or flight.delay_minutes > 180)",
            "category": "Passenger Service",
            "severity": "critical",
            "rule_config": {
                "required_action": "Immediate care protocol",
                "notification_to": ["OCC Manager", "Station Manager", "Customer Service"],
                "compliance_ref": "UM-STRANDED-CARE"
            }
        },
        {
            "name": "UM Staff Coverage Rule",
            "description": "Ensures proper staff-to-UM ratio is maintained at all stations with unaccompanied minors",
            "rule_text": "station.um_count > 0 and station.um_staff_ratio < 0.5",
            "category": "Passenger Service",
            "severity": "warning",
            "rule_config": {
                "required_action": "Assign additional staff",
                "notification_to": ["Station Manager", "Crew Scheduling"],
                "staff_ratio_minimum": 0.5
            }
        },
        
        {
            "name": "UM Overnight Transit Alert",
            "description": "Detects when an unaccompanied minor might have an overnight connection at a transit station",
            "rule_text": "passenger.type == 'UM' and flight.connection_overnight == true",
            "category": "Passenger Service",
            "severity": "critical",
            "rule_config": {
                "required_action": "Reroute passenger or provide overnight care",
                "notification_to": ["OCC Manager", "Station Manager", "Customer Service"],
                "compliance_ref": "UM-NO-OVERNIGHT-POLICY",
                "special_handling": "Follow UM overnight accommodation protocol"
            }
        },
        
        # 2. Flight Delays/Cancellations
        {
            "name": "Flight Delayed > 60 minutes",
            "description": "Alerts when a flight is delayed by more than 60 minutes",
            "rule_text": "flight.delay_minutes > 60",
            "category": "Flight Operations",
            "severity": "warning",
            "rule_config": {
                "required_action": "Passenger notification",
                "escalation_threshold_minutes": 120,
                "recovery_options": ["Rebooking", "Refreshments"]
            }
        },
        {
            "name": "Cascading Delay Risk",
            "description": "Alerts when a delayed aircraft may impact subsequent flights in its rotation",
            "rule_text": "flight.delay_minutes > 30 and aircraft.subsequent_flights > 0",
            "category": "Flight Operations",
            "severity": "warning", 
            "rule_config": {
                "look_ahead_hours": 24,
                "impact_threshold": "High",
                "recovery_actions": ["Aircraft swap", "Delay mitigation"]
            }
        },
        
        # 3. Crew Duty Time Violations
        {
            "name": "Crew Duty Time Limit Approaching",
            "description": "Alerts when crew duty time remaining is less than 60 minutes",
            "rule_text": "crew.duty_time_remaining < 1.0",
            "category": "Crew Operations",
            "severity": "critical",
            "rule_config": {
                "regulatory_reference": "FAR 117.13",
                "consequences": "Regulatory violation if exceeded",
                "required_action": "Crew replacement required"
            }
        },
        {
            "name": "Crew Rest Violation Risk",
            "description": "Alerts when minimum crew rest cannot be achieved before next duty",
            "rule_text": "crew.rest_required > 10.0 and crew.rest_available < crew.rest_required",
            "category": "Crew Operations",
            "severity": "critical",
            "rule_config": {
                "regulatory_reference": "FAR 117.25",
                "compliance_required": True,
                "required_action": "Reschedule next duty"
            }
        },
        
        # 4. Aircraft Swaps / Maintenance
        {
            "name": "Aircraft Maintenance Due",
            "description": "Alerts when an aircraft is approaching scheduled maintenance",
            "rule_text": "aircraft.hours_to_maintenance < 24",
            "category": "Maintenance",
            "severity": "warning",
            "rule_config": {
                "maintenance_types": ["A Check", "Line Maintenance"],
                "planning_lead_time": "24h",
                "impact": "Potential aircraft unavailability"
            }
        },
        {
            "name": "Aircraft Capacity Mismatch",
            "description": "Alerts when a flight has more bookings than replacement aircraft capacity",
            "rule_text": "flight.booked_passengers > aircraft.capacity",
            "category": "Flight Operations",
            "severity": "critical",
            "rule_config": {
                "overbooking_threshold": 0,
                "required_action": "Passenger rebooking",
                "compensation_required": True
            }
        },
        
        # 5. Station Resource Constraints
        {
            "name": "Station Ground Staff Shortage",
            "description": "Alerts when a station has inadequate ground staff for scheduled flights",
            "rule_text": "station.staff_count < station.required_staff",
            "category": "Station Operations",
            "severity": "warning",
            "rule_config": {
                "staff_types": ["Ramp", "Customer Service", "Baggage Handling"],
                "impact": "Potential delays",
                "mitigation": "Staff reallocation"
            }
        },
        {
            "name": "Gate Conflict Detected",
            "description": "Alerts when multiple flights are assigned to the same gate with conflicting times",
            "rule_text": "station.gate_conflicts > 0",
            "category": "Station Operations",
            "severity": "warning",
            "rule_config": {
                "buffer_minutes": 30,
                "required_action": "Gate reassignment",
                "impact": "Potential boarding delays"
            }
        },
        
        # 6. Irregular Operations (IROPS)
        {
            "name": "Weather Impact - Multiple Flights",
            "description": "Alerts when weather conditions impact multiple flights at a station",
            "rule_text": "weather.severity == 'severe' and station.affected_flights > 3",
            "category": "IROPS",
            "severity": "critical",
            "rule_config": {
                "weather_types": ["Thunderstorm", "Snow", "Fog", "Hurricane"],
                "activation_threshold": "Severe",
                "response_plan": "IROPS-1A"
            }
        },
        {
            "name": "Mass Flight Cancellations",
            "description": "Alerts when more than 5 flights are cancelled in a 6-hour period",
            "rule_text": "system.cancelled_flights_6h > 5",
            "category": "IROPS",
            "severity": "critical",
            "rule_config": {
                "time_window_hours": 6,
                "recovery_plan": "Mass cancellation protocol",
                "passenger_handling": "Hotel and rebooking required"
            }
        },
        
        # 7. Continuous Learning / Audits
        {
            "name": "Repeated Delay Pattern",
            "description": "Alerts when a flight has been delayed more than 3 times in the past week",
            "rule_text": "flight.delay_count_7d > 3",
            "category": "Performance Monitoring",
            "severity": "warning",
            "rule_config": {
                "time_window_days": 7,
                "required_action": "Root cause analysis",
                "review_required_by": "Network Operations"
            }
        },
        {
            "name": "Fuel Consumption Anomaly",
            "description": "Alerts when a flight's fuel consumption is 15% above planned",
            "rule_text": "flight.fuel_consumption_variance > 0.15",
            "category": "Performance Monitoring",
            "severity": "info",
            "rule_config": {
                "threshold_percent": 15,
                "factors_to_review": ["Routing", "Aircraft performance", "Weather"],
                "reporting_required": True
            }
        }
    ]
    
    for rule_data in rules:
        rule = Rule(
            name=rule_data["name"],
            description=rule_data["description"],
            rule_text=rule_data["rule_text"],
            category=rule_data["category"],
            severity=rule_data["severity"],
            is_active=True,
            rule_config=rule_data["rule_config"]
        )
        db.session.add(rule)
    
    db.session.commit()
    print(f"Created {len(rules)} sample rules")
    
def create_alerts():
    """Create sample alerts"""
    # List of sample alert data
    alerts_data = [
        # 1. Unaccompanied Minor Disruptions
        {
            "title": "Unaccompanied Minor: Connection Risk",
            "description": "Flight AO345 with UM passenger has 35 min connection to AO122",
            "severity": "critical",
            "category": "Passenger Service",
            "source": "Connection Scanner",
            "affected_entities": {
                "flights": ["AO345", "AO122"],
                "passenger": "UM87652",
                "connection_airport": "ORD"
            },
            "additional_data": {
                "passenger_name": "Alex Johnson",
                "age": 9,
                "guardian_contact": "+1-212-555-0198",
                "meeting_guardian": "Susan Johnson",
                "connection_minutes": 35,
                "required_minutes": 45
            }
        },
        {
            "title": "Unaccompanied Minor: Overnight Connection Risk",
            "description": "Flight AO876 from LAX to JFK with UM passenger has an overnight connection in ORD",
            "severity": "critical",
            "category": "Passenger Service",
            "source": "Overnight Connection Scanner",
            "affected_entities": {
                "flights": ["AO876", "AO233"],
                "passenger": "UM92145",
                "connection_airport": "ORD"
            },
            "additional_data": {
                "passenger_name": "Emma Wilson",
                "age": 10,
                "guardian_contact": "+1-310-555-0671",
                "meeting_guardian": "James Wilson",
                "arrival_time": "20:45",
                "next_flight_time": "08:15",
                "overnight_hours": 11.5,
                "violates_policy": True,
                "recommended_action": "Reroute on direct flight AO199 (LAX-JFK 14:30)"
            }
        },
        
        # 2. Flight Delays / Cancellations
        {
            "title": "Flight Delayed > 120 minutes",
            "description": "Flight AO237 JFK-LHR delayed 155 minutes due to late inbound aircraft",
            "severity": "warning",
            "category": "Flight Operations",
            "source": "Flight Scanner",
            "affected_entities": {
                "flight": "AO237",
                "origin": "JFK",
                "destination": "LHR"
            },
            "additional_data": {
                "scheduled_departure": (datetime.utcnow() + timedelta(hours=2)).isoformat(),
                "new_departure": (datetime.utcnow() + timedelta(hours=4, minutes=35)).isoformat(),
                "delay_minutes": 155,
                "delay_reason": "Late inbound aircraft",
                "affected_passengers": 223,
                "connecting_passengers": 87
            }
        },
        {
            "title": "Cascading Delay: 4 Flights Affected",
            "description": "Aircraft N-ABC123 delay will impact 4 subsequent flights",
            "severity": "warning",
            "category": "Flight Operations",
            "source": "Rotation Scanner",
            "affected_entities": {
                "aircraft": "N-ABC123",
                "flights": ["AO456", "AO457", "AO512", "AO513"]
            },
            "additional_data": {
                "initial_delay_minutes": 95,
                "cause": "ATC congestion at JFK",
                "estimated_impact": {
                    "AO456": "95 min delay",
                    "AO457": "80 min delay",
                    "AO512": "60 min delay",
                    "AO513": "40 min delay"
                },
                "passengers_affected": 743,
                "recommended_action": "Aircraft swap with N-DEF456"
            }
        },
        
        # 3. Crew Duty Time Violations
        {
            "title": "Crew Duty Time Violation Imminent",
            "description": "Captain on AO789 will exceed duty time limits in 45 minutes",
            "severity": "critical",
            "category": "Crew Operations",
            "source": "Crew Alert System",
            "affected_entities": {
                "crew": "C12345",
                "flight": "AO789"
            },
            "additional_data": {
                "crew_name": "Richard Wilson",
                "position": "Captain",
                "duty_start": (datetime.utcnow() - timedelta(hours=11, minutes=15)).isoformat(),
                "max_duty_hours": 12,
                "duty_time_remaining_mins": 45,
                "flight_time_remaining_mins": 90,
                "required_action": "Immediate crew replacement",
                "available_crew": ["C34567", "C45678"]
            }
        },
        {
            "title": "Insufficient Rest Period: 3 Crew Members",
            "description": "Cabin crew scheduled without minimum rest period between duties",
            "severity": "critical",
            "category": "Crew Operations",
            "source": "Crew Rest Monitor",
            "affected_entities": {
                "crew": ["C23456", "C34567", "C45678"],
                "flights": ["AO234", "AO345"]
            },
            "additional_data": {
                "rest_hours_available": 8.5,
                "minimum_rest_required": 10,
                "regulatory_reference": "FAR 117.25",
                "required_action": "Reschedule next duty or replace crew",
                "violation_type": "Anticipatory"
            }
        },
        
        # 4. Aircraft Swaps / Maintenance
        {
            "title": "Aircraft Maintenance Due",
            "description": "Aircraft G-ABCD due for A-check in 18 hours",
            "severity": "warning",
            "category": "Maintenance",
            "source": "Maintenance Tracker",
            "affected_entities": {
                "aircraft": "G-ABCD",
                "flights": ["AO876", "AO877"]
            },
            "additional_data": {
                "maintenance_type": "A-Check",
                "hours_remaining": 18,
                "component_hours": {
                    "engine_1": 342,
                    "engine_2": 356
                },
                "scheduled_time": (datetime.utcnow() + timedelta(hours=24)).isoformat(),
                "facility": "MRO-JFK-03",
                "estimated_downtime_hours": 12
            }
        },
        {
            "title": "Aircraft Capacity Downgrade",
            "description": "Flight AO654 has 212 passengers but replacement aircraft has capacity of 180",
            "severity": "critical",
            "category": "Flight Operations",
            "source": "Schedule Change Monitor",
            "affected_entities": {
                "flight": "AO654",
                "origin": "LAX",
                "destination": "JFK",
                "original_aircraft": "N-UVW789",
                "replacement_aircraft": "N-XYZ123"
            },
            "additional_data": {
                "scheduled_departure": (datetime.utcnow() + timedelta(hours=3)).isoformat(),
                "booked_passengers": 212,
                "new_capacity": 180,
                "shortage": 32,
                "reason": "Unscheduled aircraft maintenance",
                "rebooking_options": [
                    "AO658 (+4 hours)",
                    "AO661 (+8 hours)"
                ],
                "compensation_required": True
            }
        },
        
        # 5. Station Resource Constraints
        {
            "title": "Ground Staff Shortage: LAX",
            "description": "LAX station has 8 agents for 12 required positions during peak period",
            "severity": "warning",
            "category": "Station Operations",
            "source": "Resource Manager",
            "affected_entities": {
                "station": "LAX",
                "flights": ["AO221", "AO543", "AO876", "AO908"]
            },
            "additional_data": {
                "time_period": "1400-1700 local",
                "staff_available": 8,
                "staff_required": 12,
                "shortage_areas": ["Check-in", "Boarding", "Transfer Desk"],
                "impacted_flights": 4,
                "passengers_affected": 876,
                "proposed_solution": "Temporary staff reallocation from cargo operations"
            }
        },
        {
            "title": "Gate Conflict: DFW Terminal A",
            "description": "Gates A12 and A14 have concurrent arrivals with insufficient handling resources",
            "severity": "warning",
            "category": "Station Operations",
            "source": "Gate Manager",
            "affected_entities": {
                "station": "DFW",
                "gates": ["A12", "A14"],
                "flights": ["AO336", "AO442"]
            },
            "additional_data": {
                "arrival_times": {
                    "AO336": (datetime.utcnow() + timedelta(hours=2, minutes=15)).isoformat(),
                    "AO442": (datetime.utcnow() + timedelta(hours=2, minutes=20)).isoformat()
                },
                "handling_agent": "GlobalGround Services",
                "staff_available": 4,
                "staff_required": 6,
                "proposed_solution": "Reassign AO442 to gate B22",
                "estimated_delay_risk": "25 minutes ground handling delay"
            }
        },
        
        # 6. Irregular Operations (IROPS)
        {
            "title": "Weather Impact: Chicago (ORD)",
            "description": "Severe thunderstorms affecting 9 flights at ORD",
            "severity": "critical",
            "category": "IROPS",
            "source": "Weather Alert System",
            "affected_entities": {
                "station": "ORD",
                "flights": ["AO222", "AO223", "AO456", "AO457", "AO556", "AO557", "AO654", "AO655", "AO777"]
            },
            "additional_data": {
                "weather_condition": "Thunderstorms with lightning",
                "start_time": (datetime.utcnow() - timedelta(minutes=45)).isoformat(),
                "expected_duration": "3 hours",
                "current_delays": "Ground stop for all arrivals",
                "ramp_operations": "Suspended due to lightning",
                "passengers_affected": 1457,
                "diversion_candidates": ["MDW", "MKE", "DTW"],
                "recovery_plan": "IROPS-SEV-ORD-1"
            }
        },
        {
            "title": "Multiple Cancellations: ATC Strike",
            "description": "8 flights cancelled due to ATC industrial action at FRA",
            "severity": "critical",
            "category": "IROPS",
            "source": "Operations Control",
            "affected_entities": {
                "station": "FRA",
                "flights": ["AO450", "AO451", "AO452", "AO453", "AO550", "AO551", "AO650", "AO651"]
            },
            "additional_data": {
                "cancellation_cause": "ATC industrial action",
                "expected_duration": "24 hours",
                "start_time": (datetime.utcnow() - timedelta(hours=3)).isoformat(),
                "end_time": (datetime.utcnow() + timedelta(hours=21)).isoformat(),
                "passengers_affected": 1248,
                "rebooking_status": "Auto-rebooking in progress",
                "hotel_vouchers_required": 837,
                "estimated_cost": "€245,000",
                "recovery_plan": "Mass Cancellation Protocol B-4"
            }
        },
        
        # 7. Continuous Learning / Audits
        {
            "title": "Recurring Delay: Flight AO234",
            "description": "Flight AO234 LAX-JFK has been delayed 4 times in the past 7 days",
            "severity": "info",
            "category": "Performance Monitoring",
            "source": "Performance Analyzer",
            "affected_entities": {
                "flight": "AO234",
                "route": "LAX-JFK"
            },
            "additional_data": {
                "delay_pattern": {
                    "2023-05-01": "45 minutes - ATC",
                    "2023-05-03": "32 minutes - Late connecting passengers",
                    "2023-05-05": "67 minutes - Crew availability",
                    "2023-05-06": "28 minutes - Baggage loading"
                },
                "scheduled_time": "08:25 local",
                "recommended_action": "Schedule adjustment and crew briefing",
                "responsible_team": "Network Planning"
            }
        },
        {
            "title": "Fuel Consumption Anomaly",
            "description": "Flight AO789 used 17.5% more fuel than planned on DXB-LHR route",
            "severity": "info",
            "category": "Performance Monitoring",
            "source": "Fuel Analyzer",
            "affected_entities": {
                "flight": "AO789",
                "aircraft": "A6-XYZ"
            },
            "additional_data": {
                "flight_date": (datetime.utcnow() - timedelta(days=1)).isoformat(),
                "planned_fuel": "78,500 kg",
                "actual_fuel": "92,230 kg",
                "variance_percent": 17.5,
                "route": "DXB-LHR",
                "aircraft_type": "B777-300ER",
                "contributing_factors": [
                    "Stronger than forecast headwinds",
                    "Extended holding pattern at LHR",
                    "Higher than optimal cruising altitude"
                ],
                "cost_impact": "$12,450",
                "recurring_pattern": False
            }
        }
    ]
    
    # Adjust timestamps to be recent
    now = datetime.utcnow()
    alerts = []
    
    for i, alert_data in enumerate(alerts_data):
        # Stagger the alerts across the last 48 hours
        hours_ago = random.randint(0, 48)
        timestamp = now - timedelta(hours=hours_ago)
        
        # Set some alerts as resolved
        is_active = True
        resolved_at = None
        resolution_notes = None
        
        if random.random() < 0.3:  # 30% of alerts are resolved
            is_active = False
            resolved_at = timestamp + timedelta(hours=random.randint(1, 8))
            resolution_notes = random.choice([
                "Issue addressed through aircraft swap",
                "Crew replacement completed",
                "Weather conditions improved",
                "Passengers rebooked on alternative flights",
                "Additional staff allocated to gate",
                "Maintenance rescheduled",
                "Problem resolved automatically"
            ])
        
        alert = Alert(
            title=alert_data["title"],
            description=alert_data["description"],
            severity=alert_data["severity"],
            category=alert_data["category"],
            source=alert_data["source"],
            timestamp=timestamp,
            is_active=is_active,
            resolved_at=resolved_at,
            resolution_notes=resolution_notes,
            affected_entities=alert_data["affected_entities"],
            additional_data=alert_data["additional_data"]
        )
        
        db.session.add(alert)
        alerts.append(alert)
    
    db.session.commit()
    print(f"Created {len(alerts)} sample alerts")

def create_incidents():
    """Create sample incidents for analysis"""
    incidents_data = [
        # Unaccompanied Minor Disruption
        {
            "title": "Unaccompanied Minor Missed Connection",
            "description": "9-year-old UM passenger missed connection due to late inbound flight at ORD",
            "start_time": datetime.utcnow() - timedelta(days=5, hours=8),
            "end_time": datetime.utcnow() - timedelta(days=5, hours=2),
            "category": "Passenger Service",
            "severity": "high",
            "timeline": [
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=8)).isoformat(),
                    "event": "Flight AO345 departed LAX with 55-minute delay"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=4, minutes=30)).isoformat(),
                    "event": "UM Alert triggered for connection risk at ORD"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=4)).isoformat(),
                    "event": "Flight AO345 arrived at ORD with 75-minute delay"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=3, minutes=50)).isoformat(),
                    "event": "UM passenger Alex Johnson deplaned with escort"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=3, minutes=40)).isoformat(),
                    "event": "Connecting flight AO122 closed gates"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=3, minutes=30)).isoformat(),
                    "event": "UM passenger could not be accommodated on AO122"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=3)).isoformat(),
                    "event": "Guardian notified of missed connection"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=2, minutes=30)).isoformat(),
                    "event": "UM rebooked on flight AO126 departing 3 hours later"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=5, hours=2)).isoformat(),
                    "event": "UM taken to dedicated lounge with supervision"
                }
            ],
            "affected_entities": {
                "passenger": "UM87652",
                "passenger_name": "Alex Johnson",
                "flights": ["AO345", "AO122", "AO126"],
                "stations": ["LAX", "ORD", "JFK"]
            },
            "root_cause": "Initial flight delay combined with inadequate connection time buffer for UM passenger",
            "resolution": "Passenger rebooked and provided supervised care until next flight. Guardian kept informed throughout process.",
            "lessons_learned": "1. Increase minimum connection time for UM passengers to 90 minutes\n2. Implement priority deplaning for UM passengers when connections are tight\n3. Establish dedicated UM coordination role at major hubs"
        },
        
        # Flight Delay/Cancellation
        {
            "title": "Multiple Flight Cancellations Due to Weather at JFK",
            "description": "Severe winter storm led to cancellation of 12 flights and extensive rebooking operation",
            "start_time": datetime.utcnow() - timedelta(days=14, hours=18),
            "end_time": datetime.utcnow() - timedelta(days=13, hours=6),
            "category": "IROPS",
            "severity": "critical",
            "timeline": [
                {
                    "time": (datetime.utcnow() - timedelta(days=15, hours=12)).isoformat(),
                    "event": "Weather alert received for JFK area: winter storm warning"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=18)).isoformat(),
                    "event": "JFK airport announced 50% capacity reduction"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=17)).isoformat(),
                    "event": "Crisis team activated IROPS protocol WINTER-JFK-1"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=16)).isoformat(),
                    "event": "Decision made to cancel 12 flights proactively"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=15)).isoformat(),
                    "event": "Passenger notifications started via SMS and email"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=14)).isoformat(),
                    "event": "Hotel accommodation secured for 342 stranded passengers"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=10)).isoformat(),
                    "event": "Automated rebooking system activated for all affected passengers"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=14, hours=4)).isoformat(),
                    "event": "78% of passengers successfully rebooked on flights within 24 hours"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=13, hours=18)).isoformat(),
                    "event": "Weather conditions improved, airport returning to normal operations"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=13, hours=12)).isoformat(),
                    "event": "Recovery flights scheduled for remaining passengers"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=13, hours=6)).isoformat(),
                    "event": "All affected passengers accommodated, incident closed"
                }
            ],
            "affected_entities": {
                "flights": ["AO201", "AO202", "AO203", "AO204", "AO301", "AO302", "AO303", "AO304", "AO401", "AO402", "AO403", "AO404"],
                "passengers": 1823,
                "stations": ["JFK", "BOS", "ORD", "LAX", "MIA", "DFW"]
            },
            "root_cause": "Severe winter storm with heavy snowfall and high winds reduced airport capacity. The need to clear runways and ensure safe operations necessitated flight cancellations.",
            "resolution": "Proactive cancellation with comprehensive rebooking and accommodation provided to affected passengers. Recovery flights operated as soon as weather permitted.",
            "lessons_learned": "1. Early proactive cancellations resulted in better passenger satisfaction than multiple delays followed by cancellation\n2. Automatic rebooking system handled 80% of cases effectively, reducing call center load\n3. More hotel partnerships needed in JFK area for similar future events\n4. Need for improved communication between airport authority and airlines during capacity restrictions"
        },
        
        # Crew Duty Time Violation
        {
            "title": "Crew Duty Time Violation on International Flight",
            "description": "Captain exceeded maximum duty time due to extended delays and insufficient crew planning",
            "start_time": datetime.utcnow() - timedelta(days=21, hours=10),
            "end_time": datetime.utcnow() - timedelta(days=20, hours=18),
            "category": "Crew Operations",
            "severity": "critical",
            "timeline": [
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=10)).isoformat(),
                    "event": "Flight AO789 crew signed in at LHR for duty"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=8)).isoformat(),
                    "event": "Flight delayed due to technical issue with aircraft door"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=6)).isoformat(),
                    "event": "Maintenance extended, additional 2-hour delay announced"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=4)).isoformat(),
                    "event": "Crew duty time alert triggered - will exceed limits during flight"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=3, minutes=30)).isoformat(),
                    "event": "Crew scheduling contacted to arrange replacement crew"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=3)).isoformat(),
                    "event": "No standby crew available at LHR within required timeframe"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=2)).isoformat(),
                    "event": "Decision made to proceed with flight despite projected duty time violation"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=21, hours=1)).isoformat(),
                    "event": "Flight AO789 departed LHR after 7-hour delay"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=20, hours=23)).isoformat(),
                    "event": "Captain's duty time exceeded maximum limit during flight"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=20, hours=19)).isoformat(),
                    "event": "Flight arrived at JFK with duty time violation confirmed"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=20, hours=18)).isoformat(),
                    "event": "Regulatory violation report filed, investigation initiated"
                }
            ],
            "affected_entities": {
                "crew": ["C12345", "C23456", "C34567", "C45678"],
                "flight": "AO789",
                "route": "LHR-JFK"
            },
            "root_cause": "Insufficient crew recovery planning for the LHR station, combined with maintenance delay and inadequate decision-making protocols for duty time violations.",
            "resolution": "Regulatory report filed and crew provided extended rest period. Full investigation conducted with regulatory authority.",
            "lessons_learned": "1. Establish absolute no-go policy for predicted duty time violations\n2. Increase standby crew coverage at LHR\n3. Implement better predictive alerting for potential duty time violations\n4. Create clear escalation procedure for duty time issues\n5. Additional training for Operations Control on regulatory requirements"
        },
        
        # IROPS Scenario
        {
            "title": "System-Wide Disruption Due to IT Outage",
            "description": "Critical reservation and operations systems unavailable for 4.5 hours affecting global operations",
            "start_time": datetime.utcnow() - timedelta(days=9, hours=14),
            "end_time": datetime.utcnow() - timedelta(days=9, hours=6),
            "category": "System Outage",
            "severity": "critical",
            "timeline": [
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=14)).isoformat(),
                    "event": "Reservation system and DCS became unresponsive"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=13, minutes=50)).isoformat(),
                    "event": "IT declared major incident and began investigation"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=13, minutes=30)).isoformat(),
                    "event": "Manual check-in procedures implemented at all stations"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=13)).isoformat(),
                    "event": "Crisis management team activated"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=12)).isoformat(),
                    "event": "Flight delays beginning at all stations due to manual processes"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=11)).isoformat(),
                    "event": "Root cause identified: database corruption after failed update"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=10)).isoformat(),
                    "event": "Decision made to roll back to previous version"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=9, minutes=30)).isoformat(),
                    "event": "System restoration began"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=9)).isoformat(),
                    "event": "18 flights delayed by more than 60 minutes"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=8)).isoformat(),
                    "event": "Systems back online, testing and validation began"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=7)).isoformat(),
                    "event": "Normal operations resumed, beginning recovery process"
                },
                {
                    "time": (datetime.utcnow() - timedelta(days=9, hours=6)).isoformat(),
                    "event": "Recovery plan implemented for delayed flights"
                }
            ],
            "affected_entities": {
                "flights": 87,
                "stations": 32,
                "systems": ["Reservations", "DCS", "Crew Management", "Flight Planning"]
            },
            "root_cause": "Database corruption occurred during scheduled system update. Inadequate testing of the update in staging environment and lack of automated rollback procedures extended the outage duration.",
            "resolution": "System restored via rollback to previous version. All delayed flights recovered within 12 hours.",
            "lessons_learned": "1. Implement more comprehensive testing procedures for system updates\n2. Create automated rollback capability for critical systems\n3. Improve manual operation procedures at stations\n4. Develop redundant access method for critical operational data\n5. Conduct regular drills for system outage scenarios"
        }
    ]
    
    for incident_data in incidents_data:
        # Create optimization plan for some incidents
        optimization_plan = None
        if random.random() < 0.7:  # 70% of incidents have optimization plans
            plan = OptimizationPlan(
                name=f"Recovery Plan for {incident_data['title']}",
                description=f"Optimization plan to address {incident_data['category']} incident",
                scenario=incident_data['category'],
                constraints={
                    "max_delay_minutes": random.randint(120, 480),
                    "max_passenger_disruption": random.randint(100, 500),
                    "crew_legality": "must_maintain",
                    "aircraft_limitations": incident_data.get('affected_entities', {}).get('flights', [])
                },
                objective_weights={
                    "minimize_delays": 0.3,
                    "minimize_cancellations": 0.3,
                    "minimize_passenger_impact": 0.25,
                    "minimize_cost": 0.15
                },
                status="completed",
                results={
                    "action_count": random.randint(5, 25),
                    "flights_delayed": random.randint(3, 15),
                    "flights_cancelled": random.randint(0, 5),
                    "crew_reassignments": random.randint(2, 10),
                    "aircraft_swaps": random.randint(1, 8),
                    "passengers_reaccommodated": random.randint(50, 500)
                },
                score=round(random.uniform(0.65, 0.95), 2),
                execution_time=round(random.uniform(2.5, 45.8), 1),
                version=1
            )
            db.session.add(plan)
            db.session.flush()  # Get ID without committing
            optimization_plan_id = plan.id
        else:
            optimization_plan_id = None
        
        incident = Incident(
            title=incident_data["title"],
            description=incident_data["description"],
            start_time=incident_data["start_time"],
            end_time=incident_data["end_time"],
            category=incident_data["category"],
            severity=incident_data["severity"],
            timeline=incident_data["timeline"],
            affected_entities=incident_data["affected_entities"],
            root_cause=incident_data["root_cause"],
            resolution=incident_data["resolution"],
            lessons_learned=incident_data["lessons_learned"],
            optimization_plan_id=optimization_plan_id
        )
        db.session.add(incident)
    
    db.session.commit()
    print(f"Created {len(incidents_data)} sample incidents and related optimization plans")

def create_optimization_plans():
    """Create additional sample optimization plans"""
    scenarios = ["Crew Reassignment", "Aircraft Swap", "Flight Rescheduling", 
                "Passenger Rebooking", "Airport Closure", "Weather Diversion", 
                "Unaccompanied Minor Protection"]
    
    # First create dedicated UM plans
    
    # Plan 1: UM Winter Storm Recovery Plan
    um_constraints_1 = {
        "no_overnight_transit_um": True,
        "max_connections_um": 1,
        "min_staff_at_transit": 2,
        "max_delay_minutes": 180,
        "prioritize_um_rebooking": True,
        "allow_flight_holds": True,
        "max_um_delay_hours": 6
    }
    
    um_weights_1 = {
        "safety": 0.4,
        "passenger_satisfaction": 0.25,
        "delay_cost": 0.15,
        "passenger_impact": 0.1,
        "operational_feasibility": 0.05,
        "crew_impact": 0.03,
        "aircraft_utilization": 0.02
    }
    
    um_results_1 = {
        "solution_type": "um_recovery",
        "affected_um": 8,
        "um_rebooking_priority": "high",
        "um_staff_assigned": 4,
        "um_overnight_stays": 0,
        "um_max_connections": 1,
        "um_actual_connections": 1,
        "um_alternative_routing": 5,
        "delayed_flights_for_um": 2,
        "total_delay_minutes": 85,
        "affected_passengers": 247,
        "missed_connections": 18,
        "cancellations": 0,
        "aircraft_swaps": 1,
        "delay_cost": 17500,
        "passenger_compensation": 5200,
        "crew_overtime": 3800,
        "um_protection_score": 0.92,
        "um_routings": [
            {
                "um_id": "UM1",
                "origin": "DEN",
                "destination": "JFK",
                "connection": "ORD",
                "staff_assigned": 2,
                "original_flight": "AO876",
                "new_flight": "AO233",
                "overnight_stay": False
            },
            {
                "um_id": "UM2",
                "origin": "DEN",
                "destination": "MIA",
                "connection": "DFW",
                "staff_assigned": 2,
                "original_flight": "AO324",
                "new_flight": "AO451",
                "overnight_stay": False
            }
        ]
    }
    
    um_plan_1 = OptimizationPlan(
        name="Winter Storm UM Protection - Denver",
        description="Plan for protecting 8 unaccompanied minors stranded at Denver due to winter storm",
        scenario="Unaccompanied Minor Protection",
        constraints=um_constraints_1,
        objective_weights=um_weights_1,
        status="completed",
        results=um_results_1,
        score=0.87,
        execution_time=45.3,
        version=1
    )
    db.session.add(um_plan_1)
    
    # Plan 2: UM Protection with No Overnight Policy
    um_constraints_2 = {
        "no_overnight_transit_um": True,
        "max_connections_um": 0,  # Direct flights only
        "min_staff_at_transit": 3,
        "max_delay_minutes": 360,
        "prioritize_um_rebooking": True,
        "allow_flight_holds": True,
        "max_rebooking_cost": 1500
    }
    
    um_weights_2 = {
        "safety": 0.5,  # Maximum safety priority
        "passenger_satisfaction": 0.2,
        "delay_cost": 0.1,
        "passenger_impact": 0.1,
        "operational_feasibility": 0.05,
        "crew_impact": 0.03,
        "aircraft_utilization": 0.02
    }
    
    um_results_2 = {
        "solution_type": "um_recovery",
        "affected_um": 3,
        "um_rebooking_priority": "highest",
        "um_staff_assigned": 3,
        "um_overnight_stays": 0,
        "um_max_connections": 0,
        "um_actual_connections": 0,
        "um_alternative_routing": 3,
        "delayed_flights_for_um": 1,
        "total_delay_minutes": 45,
        "affected_passengers": 186,
        "missed_connections": 12,
        "cancellations": 0,
        "aircraft_swaps": 1,
        "delay_cost": 22800,
        "passenger_compensation": 3600,
        "crew_overtime": 2500,
        "um_protection_score": 0.97,
        "um_routings": [
            {
                "um_id": "UM1",
                "origin": "ORD",
                "destination": "LAX",
                "connection": None,
                "staff_assigned": 1,
                "original_flight": "AO555",
                "new_flight": "AO557",
                "overnight_stay": False
            },
            {
                "um_id": "UM2",
                "origin": "ORD",
                "destination": "SFO",
                "connection": None,
                "staff_assigned": 1,
                "original_flight": "AO671",
                "new_flight": "AO673",
                "overnight_stay": False
            }
        ]
    }
    
    um_plan_2 = OptimizationPlan(
        name="Direct Flights Only - UM Protection",
        description="Special protection plan requiring direct flights only for UMs stranded at ORD",
        scenario="Unaccompanied Minor Protection",
        constraints=um_constraints_2,
        objective_weights=um_weights_2,
        status="completed",
        results=um_results_2,
        score=0.92,
        execution_time=36.7,
        version=1
    )
    db.session.add(um_plan_2)
    
    # Now create regular plans
    for i in range(5):  # Create 5 standalone optimization plans
        scenario = random.choice(scenarios)
        
        # Create constraints based on scenario
        if scenario == "Crew Reassignment":
            constraints = {
                "max_duty_hours": 12,
                "min_rest_hours": 10,
                "qualification_requirements": True,
                "max_deadhead_segments": 2,
                "base_return_priority": "medium"
            }
        elif scenario == "Aircraft Swap":
            constraints = {
                "must_maintain_capacity": random.choice([True, False]),
                "compatible_aircraft_only": True,
                "maintenance_requirements": "must_honor",
                "max_swaps_per_aircraft": random.randint(1, 3)
            }
        elif scenario == "Flight Rescheduling":
            constraints = {
                "max_delay_minutes": random.randint(120, 360),
                "must_maintain_connections": random.choice([True, False]),
                "allow_cancellations": random.choice([True, False]),
                "slot_constraints": random.choice([True, False])
            }
        elif scenario == "Unaccompanied Minor Protection":
            constraints = {
                "no_overnight_transit_um": True,
                "max_connections_um": random.choice([0, 1]),
                "min_staff_at_transit": random.randint(1, 3),
                "max_delay_minutes": random.randint(60, 240),
                "prioritize_um_rebooking": True
            }
            
            # Special weights for UM scenarios
            w_safety = round(random.uniform(0.3, 0.5), 2)
            w_satisfaction = round(random.uniform(0.2, 0.3), 2)
            w_delay = round(random.uniform(0.1, 0.2), 2)
            w_impact = round(random.uniform(0.05, 0.15), 2)
            w_rest = round(1.0 - (w_safety + w_satisfaction + w_delay + w_impact), 2)
            
            objective_weights = {
                "safety": w_safety,
                "passenger_satisfaction": w_satisfaction,
                "delay_cost": w_delay,
                "passenger_impact": w_impact,
                "operational_feasibility": w_rest / 3,
                "crew_impact": w_rest / 3,
                "aircraft_utilization": w_rest / 3
            }
        else:
            constraints = {
                "max_passenger_delay_hours": random.randint(12, 48),
                "prioritize_premium_passengers": random.choice([True, False]),
                "allow_downgrade": random.choice([True, False]),
                "max_rebooking_cost": random.randint(300, 1000),
                "hotel_if_overnight": True
            }
        
        # Randomize objective weights but ensure they sum to 1.0 (if not already set for UM)
        if scenario != "Unaccompanied Minor Protection":
            w1 = round(random.uniform(0.1, 0.4), 2)
            w2 = round(random.uniform(0.1, 0.4), 2)
            w3 = round(random.uniform(0.1, 0.4), 2)
            w4 = round(1.0 - (w1 + w2 + w3), 2)
            
            objective_weights = {
                "minimize_cost": w1,
                "minimize_passenger_impact": w2,
                "maximize_on_time_performance": w3,
                "maintain_crew_satisfaction": w4
            }
        
        # Generate results for completed plans
        status = random.choice(["draft", "running", "completed", "completed", "completed"])
        
        if status == "completed":
            if scenario == "Unaccompanied Minor Protection":
                um_count = random.randint(1, 5)
                results = {
                    "solution_type": "um_recovery",
                    "affected_um": um_count,
                    "um_rebooking_priority": "high",
                    "um_staff_assigned": random.randint(um_count, um_count + 2),
                    "um_overnight_stays": 0,
                    "um_max_connections": constraints["max_connections_um"],
                    "um_actual_connections": constraints["max_connections_um"],
                    "um_alternative_routing": random.randint(0, um_count),
                    "delayed_flights_for_um": random.randint(0, 2),
                    "total_delay_minutes": random.randint(30, 120),
                    "affected_passengers": random.randint(50, 300),
                    "missed_connections": random.randint(5, 50),
                    "cancellations": random.randint(0, 1),
                    "aircraft_swaps": random.randint(0, 1),
                    "delay_cost": random.randint(8000, 25000),
                    "passenger_compensation": random.randint(2000, 15000),
                    "crew_overtime": random.randint(1000, 5000),
                    "um_protection_score": round(random.uniform(0.8, 0.98), 2)
                }
                score = round(random.uniform(0.75, 0.95), 2)
            else:
                results = {
                    "flight_changes": random.randint(3, 20),
                    "crew_changes": random.randint(5, 30),
                    "passenger_impact": {
                        "delayed": random.randint(50, 500),
                        "rebooked": random.randint(20, 200),
                        "compensated": random.randint(10, 100)
                    },
                    "cost_impact": {
                        "additional_crew_cost": random.randint(5000, 50000),
                        "passenger_compensation": random.randint(10000, 100000),
                        "operational_cost": random.randint(20000, 200000)
                    },
                    "operational_impact": {
                        "on_time_performance_change": round(random.uniform(-0.05, 0.02), 3),
                        "completion_factor_change": round(random.uniform(-0.03, 0.01), 3)
                    }
                }
                score = round(random.uniform(0.65, 0.95), 2)
                
            execution_time = round(random.uniform(10.5, 120.8), 1)
        else:
            results = None
            score = None
            execution_time = None
        
        location = random.choice(['JFK', 'LAX', 'ORD', 'DFW', 'LHR', 'DXB', 'DEN', 'SEA'])
        
        plan = OptimizationPlan(
            name=f"{scenario} Plan - {location}",
            description=f"Optimization plan for {scenario.lower()} scenario",
            scenario=scenario,
            constraints=constraints,
            objective_weights=objective_weights,
            status=status,
            results=results,
            score=score,
            execution_time=execution_time,
            version=random.randint(1, 3)
        )
        db.session.add(plan)
    
    db.session.commit()
    print("Created additional optimization plans")

if __name__ == "__main__":
    create_sample_data()