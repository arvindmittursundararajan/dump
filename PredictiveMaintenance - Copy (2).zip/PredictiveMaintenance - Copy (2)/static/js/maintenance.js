// Maintenance page JavaScript

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize date pickers
    initializeDatePickers();
    
    // Load machines for dropdown
    loadMachines();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize tooltips
    initializeTooltips();

    const searchForm = document.getElementById('maintenance-search-form');
    const searchInput = document.getElementById('maintenance-search-input');
    const searchResults = document.getElementById('maintenance-search-results');
    const searchClear = document.getElementById('maintenance-search-clear');

    if (searchForm && searchInput && searchResults) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const q = searchInput.value.trim();
            if (!q) return;
            searchResults.innerHTML = '<div class="text-center p-3"><div class="spinner-border text-danger" role="status"></div> Searching...</div>';
            fetch(`/maintenance/search?q=${encodeURIComponent(q)}`)
                .then(res => res.json())
                .then(data => {
                    if (!data.length) {
                        searchResults.innerHTML = '<div class="alert alert-info">No matching maintenance records found.</div>';
                        return;
                    }
                    let html = '<table class="table table-striped table-bordered"><thead><tr>' +
                        '<th>ID</th><th>Machine</th><th>Type</th><th>Technician</th><th>Status</th><th>Start</th><th>End</th><th>Cost</th><th>Description</th><th>Notes</th></tr></thead><tbody>';
                    data.forEach(r => {
                        html += `<tr><td>${r.id}</td><td>${r.machine_id || ''}</td><td>${r.maintenance_type || ''}</td><td>${r.technician || ''}</td><td>${r.status || ''}</td><td>${r.start_date ? (r.start_date.substring(0,10)) : ''}</td><td>${r.end_date ? (r.end_date.substring(0,10)) : ''}</td><td>${r.cost != null ? r.cost : ''}</td><td>${r.description || ''}</td><td>${r.notes || ''}</td></tr>`;
                    });
                    html += '</tbody></table>';
                    searchResults.innerHTML = html;
                })
                .catch(() => {
                    searchResults.innerHTML = '<div class="alert alert-danger">Error searching maintenance records.</div>';
                });
        });
        if (searchClear) {
            searchClear.addEventListener('click', function() {
                searchInput.value = '';
                searchResults.innerHTML = '';
            });
        }
    }
});

// Initialize date pickers
function initializeDatePickers() {
    // Use native date inputs
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    // Set default start date to today for new maintenance records
    const startDateInput = document.getElementById('maintenance-start-date');
    if (startDateInput) {
        startDateInput.valueAsDate = today;
    }
    
    // Set default end date to tomorrow
    const endDateInput = document.getElementById('maintenance-end-date');
    if (endDateInput) {
        endDateInput.valueAsDate = tomorrow;
    }
}

// Load machines for dropdown
function loadMachines() {
    const machineSelect = document.getElementById('maintenance-machine');
    
    if (!machineSelect) return;
    
    // Show loading state
    machineSelect.innerHTML = '<option value="">Loading machines...</option>';
    
    // Fetch machines from API
    fetch('/api/machines')
        .then(response => response.json())
        .then(data => {
            machineSelect.innerHTML = '<option value="">Select a machine</option>';
            
            data.forEach(machine => {
                const option = document.createElement('option');
                option.value = machine.id;
                option.textContent = machine.name;
                machineSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading machines:', error);
            machineSelect.innerHTML = '<option value="">Failed to load machines</option>';
        });
}

// Set up event listeners
function setupEventListeners() {
    // Add maintenance form submission
    const maintenanceForm = document.getElementById('add-maintenance-form');
    if (maintenanceForm) {
        maintenanceForm.addEventListener('submit', handleMaintenanceSubmit);
    }
    
    // Machine selection change to load parts
    const machineSelect = document.getElementById('maintenance-machine');
    if (machineSelect) {
        machineSelect.addEventListener('change', function() {
            loadPartsForMachine(this.value);
        });
    }
    
    // Status filter buttons
    const statusFilters = document.querySelectorAll('.status-filter');
    statusFilters.forEach(button => {
        button.addEventListener('click', function() {
            const status = this.dataset.status;
            filterMaintenanceByStatus(status);
            
            // Update active state
            statusFilters.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Add new maintenance button
    const addButton = document.getElementById('add-maintenance-button');
    if (addButton) {
        addButton.addEventListener('click', function() {
            // Show the maintenance form modal
            $('#add-maintenance-modal').modal('show');
        });
    }
}

// Load parts for the selected machine
function loadPartsForMachine(machineId) {
    const partSelect = document.getElementById('maintenance-part');
    
    if (!partSelect) return;
    
    // Clear and disable part select if no machine is selected
    if (!machineId) {
        partSelect.innerHTML = '<option value="">Select a machine first</option>';
        partSelect.disabled = true;
        return;
    }
    
    // Show loading state
    partSelect.innerHTML = '<option value="">Loading parts...</option>';
    partSelect.disabled = true;
    
    // Fetch parts for the selected machine
    fetch(`/api/machine/${machineId}/parts`)
        .then(response => response.json())
        .then(data => {
            partSelect.innerHTML = '<option value="">Machine-level maintenance</option>';
            
            data.forEach(part => {
                const option = document.createElement('option');
                option.value = part.id;
                option.textContent = part.name;
                partSelect.appendChild(option);
            });
            
            partSelect.disabled = false;
        })
        .catch(error => {
            console.error('Error loading parts:', error);
            partSelect.innerHTML = '<option value="">Failed to load parts</option>';
            partSelect.disabled = true;
        });
}

// Handle maintenance form submission
function handleMaintenanceSubmit(e) {
    e.preventDefault();
    
    // Get form data
    const machineId = document.getElementById('maintenance-machine').value;
    const partId = document.getElementById('maintenance-part').value;
    const maintenanceType = document.getElementById('maintenance-type').value;
    const startDate = document.getElementById('maintenance-start-date').value;
    const endDate = document.getElementById('maintenance-end-date').value;
    const technician = document.getElementById('maintenance-technician').value;
    const status = document.getElementById('maintenance-status').value;
    const cost = document.getElementById('maintenance-cost').value;
    const description = document.getElementById('maintenance-description').value;
    const notes = document.getElementById('maintenance-notes').value;
    
    // Validate required fields
    if (!machineId || !maintenanceType || !startDate || !technician || !status) {
        showMessage('Please fill out all required fields.', 'error');
        return;
    }
    
    // Prepare data
    const data = {
        machine_id: machineId,
        maintenance_type: maintenanceType,
        start_date: startDate,
        technician: technician,
        status: status,
        description: description,
        notes: notes
    };
    
    // Add optional fields
    if (partId) data.part_id = partId;
    if (endDate) data.end_date = endDate;
    if (cost) data.cost = parseFloat(cost);
    
    // Show loading state
    document.getElementById('maintenance-submit').disabled = true;
    document.getElementById('maintenance-submit').innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
    
    // Send to API
    fetch('/api/maintenance', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        // Reset loading state
        document.getElementById('maintenance-submit').disabled = false;
        document.getElementById('maintenance-submit').innerHTML = 'Save Maintenance Record';
        
        if (result.success) {
            // Show success message
            showMessage('Maintenance record added successfully!', 'success');
            
            // Close the modal
            $('#add-maintenance-modal').modal('hide');
            
            // Reset the form
            document.getElementById('add-maintenance-form').reset();
            
            // Reload the page to show the new record
            window.location.reload();
        } else {
            // Show error message
            showMessage(`Error: ${result.message}`, 'error');
        }
    })
    .catch(error => {
        console.error('Error adding maintenance record:', error);
        
        // Reset loading state
        document.getElementById('maintenance-submit').disabled = false;
        document.getElementById('maintenance-submit').innerHTML = 'Save Maintenance Record';
        
        // Show error message
        showMessage('An error occurred while saving the maintenance record.', 'error');
    });
}

// Filter maintenance records by status
function filterMaintenanceByStatus(status) {
    const records = document.querySelectorAll('.maintenance-row');
    
    if (status === 'all') {
        // Show all records
        records.forEach(record => {
            record.style.display = '';
        });
    } else {
        // Show only records with matching status
        records.forEach(record => {
            if (record.dataset.status === status) {
                record.style.display = '';
            } else {
                record.style.display = 'none';
            }
        });
    }
    
    // Update count of visible records
    const visibleCount = Array.from(records).filter(el => el.style.display !== 'none').length;
    document.getElementById('record-count').textContent = visibleCount;
}

// Show a message to the user
function showMessage(message, type) {
    const messageContainer = document.getElementById('message-container');
    
    if (!messageContainer) return;
    
    // Create alert element
    const alertElement = document.createElement('div');
    alertElement.className = `alert alert-${type === 'error' ? 'danger' : 'success'} alert-dismissible fade show`;
    alertElement.role = 'alert';
    
    // Add message text
    alertElement.textContent = message;
    
    // Add dismiss button
    const dismissButton = document.createElement('button');
    dismissButton.type = 'button';
    dismissButton.className = 'close';
    dismissButton.setAttribute('data-dismiss', 'alert');
    dismissButton.setAttribute('aria-label', 'Close');
    dismissButton.innerHTML = '<span aria-hidden="true">&times;</span>';
    
    alertElement.appendChild(dismissButton);
    
    // Clear existing messages
    messageContainer.innerHTML = '';
    
    // Add the new message
    messageContainer.appendChild(alertElement);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertElement.classList.remove('show');
        setTimeout(() => alertElement.remove(), 500);
    }, 5000);
}

// Initialize tooltips
function initializeTooltips() {
    $('[data-toggle="tooltip"]').tooltip();
}

// Show maintenance details in a modal
function showMaintenanceDetails(id) {
    // This would typically fetch the record details from API
    // For now, just show a message
    alert(`View details for maintenance record ${id}`);
}

// Edit maintenance record
function editMaintenanceRecord(id) {
    fetch(`/api/maintenance/${id}`)
        .then(response => response.json())
        .then(data => {
            // Populate the form with the record data
            document.getElementById('maintenance-machine').value = data.machine_id;
            loadPartsForMachine(data.machine_id);
            setTimeout(() => {
                document.getElementById('maintenance-part').value = data.part_id || '';
            }, 300);
            document.getElementById('maintenance-type').value = data.maintenance_type;
            document.getElementById('maintenance-start-date').value = data.start_date;
            document.getElementById('maintenance-end-date').value = data.end_date || '';
            document.getElementById('maintenance-technician').value = data.technician;
            document.getElementById('maintenance-status').value = data.status;
            document.getElementById('maintenance-cost').value = data.cost || '';
            document.getElementById('maintenance-description').value = data.description || '';
            document.getElementById('maintenance-notes').value = data.notes || '';
            document.getElementById('add-maintenance-form').setAttribute('data-edit-id', id);
            $('#add-maintenance-modal').modal('show');
        });
}

// Delete maintenance record
function deleteMaintenanceRecord(id) {
    if (confirm('Are you sure you want to delete this maintenance record?')) {
        fetch(`/api/maintenance/${id}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showMessage('Maintenance record deleted successfully!', 'success');
                    window.location.reload();
                } else {
                    showMessage('Failed to delete maintenance record.', 'error');
                }
            });
    }
}

// Intercept form submit for edit
const form = document.getElementById('add-maintenance-form');
if (form) {
    form.addEventListener('submit', function(e) {
        const editId = form.getAttribute('data-edit-id');
        if (editId) {
            e.preventDefault();
            // Gather form data (reuse handleMaintenanceSubmit logic)
            const machineId = document.getElementById('maintenance-machine').value;
            const partId = document.getElementById('maintenance-part').value;
            const maintenanceType = document.getElementById('maintenance-type').value;
            const startDate = document.getElementById('maintenance-start-date').value;
            const endDate = document.getElementById('maintenance-end-date').value;
            const technician = document.getElementById('maintenance-technician').value;
            const status = document.getElementById('maintenance-status').value;
            const cost = document.getElementById('maintenance-cost').value;
            const description = document.getElementById('maintenance-description').value;
            const notes = document.getElementById('maintenance-notes').value;
            const data = {
                machine_id: machineId,
                maintenance_type: maintenanceType,
                start_date: startDate,
                technician: technician,
                status: status,
                description: description,
                notes: notes
            };
            if (partId) data.part_id = partId;
            if (endDate) data.end_date = endDate;
            if (cost) data.cost = parseFloat(cost);
            fetch(`/api/maintenance/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showMessage('Maintenance record updated successfully!', 'success');
                    $('#add-maintenance-modal').modal('hide');
                    window.location.reload();
                } else {
                    showMessage('Failed to update maintenance record.', 'error');
                }
            });
            form.removeAttribute('data-edit-id');
        }
    });
}
