/**
 * Ultravox Voice Chat Application
 * Handles the client-side functionality for the voice chat application.
 */

// Global variables
let uvSession = null;
let callActive = false;
const DEFAULT_VOICE = "Mark";

// DOM elements
let startCallButton;
let endCallButton;
let callStatusValue;
let callIdValue;
let transcriptContent;
let loadingSpinner;

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Get DOM elements
    startCallButton = document.getElementById('startCallButton');
    endCallButton = document.getElementById('endCallButton');
    callStatusValue = document.getElementById('callStatusValue');
    callIdValue = document.getElementById('callIdValue');
    transcriptContent = document.getElementById('transcriptContent');
    loadingSpinner = document.getElementById('loadingSpinner');
    
    // Initialize UltravoxSession after a small delay to ensure the module is loaded
    setTimeout(() => {
        initializeUltravox();
        setupEventListeners();
    }, 500);
});

/**
 * Initialize the Ultravox session
 */
function initializeUltravox() {
    try {
        const debugMessages = new Set(["debug"]);
        
        // Create the Ultravox session
        if (window.UltravoxSession) {
            uvSession = new window.UltravoxSession({ experimentalMessages: debugMessages });
            console.log("Ultravox session initialized successfully");
            setupUltravoxEventListeners();
        } else {
            console.error('UltravoxSession is not defined. Make sure the script is loaded.');
            setTimeout(initializeUltravox, 1000); // Retry after 1 second
        }
    } catch (error) {
        console.error('Error initializing Ultravox session:', error);
    }
}

/**
 * Set up event listeners for UI elements
 */
function setupEventListeners() {
    // Start call button event listener
    startCallButton.addEventListener('click', startCall);
    
    // End call button event listener
    endCallButton.addEventListener('click', endCall);
}

/**
 * Set up event listeners for the Ultravox session
 */
function setupUltravoxEventListeners() {
    if (!uvSession) return;
    
    // Status event listener
    uvSession.addEventListener('status', (e) => {
        updateCallStatus(e.target._status);
    });
    
    // Transcripts event listener
    uvSession.addEventListener('transcripts', (e) => {
        updateTranscript(e.target._transcripts);
    });
    
    // Debug messages event listener
    uvSession.addEventListener('experimental_message', (msg) => {
        console.log('Debug: ', JSON.stringify(msg));
    });
}

/**
 * Display an error message to the user
 * @param {string} message - The error message to display
 * @param {string} type - The type of error ('api', 'subscription', 'connection', etc.)
 */
function showErrorMessage(message, type = 'error') {
    // Create or get error element
    let errorContainer = document.getElementById('errorContainer');
    if (!errorContainer) {
        errorContainer = document.createElement('div');
        errorContainer.id = 'errorContainer';
        errorContainer.className = 'error-container';
        
        // Add it after call-control section
        const callControlSection = document.querySelector('.call-control');
        callControlSection.parentNode.insertBefore(errorContainer, callControlSection.nextSibling);
    }
    
    // Set error class based on type
    errorContainer.className = 'error-container';
    errorContainer.classList.add(`error-${type}`);
    
    // Set error message
    errorContainer.innerHTML = `
        <div class="error-icon">⚠️</div>
        <div class="error-message">${message}</div>
        <button class="error-dismiss">×</button>
    `;
    
    // Add event listener to dismiss button
    const dismissButton = errorContainer.querySelector('.error-dismiss');
    dismissButton.addEventListener('click', () => {
        errorContainer.style.display = 'none';
    });
    
    // Show the error
    errorContainer.style.display = 'flex';
}

/**
 * Handle API errors based on response status
 * @param {Response} response - The fetch API response object
 */
async function handleApiError(response) {
    let errorData;
    
    try {
        errorData = await response.json();
    } catch (e) {
        errorData = { error: `Error ${response.status}: ${response.statusText}` };
    }
    
    const errorMessage = errorData.error || 'Unknown error occurred';
    
    // Show appropriate error message based on status code
    switch (response.status) {
        case 402:
            showErrorMessage(
                'Your API key has reached its usage limit or requires a subscription. Please update your Ultravox API key.',
                'subscription'
            );
            break;
        case 403:
            showErrorMessage(
                'API key is invalid or has expired. Please check your Ultravox API credentials.',
                'api'
            );
            break;
        case 429:
            showErrorMessage(
                'Rate limit exceeded. Please try again later.',
                'rate-limit'
            );
            break;
        default:
            showErrorMessage(errorMessage, 'api');
    }
    
    throw new Error(errorMessage);
}

/**
 * Start a new call
 */
async function startCall() {
    if (callActive) return;
    
    try {
        // Hide any previous error messages
        const errorContainer = document.getElementById('errorContainer');
        if (errorContainer) {
            errorContainer.style.display = 'none';
        }
        
        // Show loading state
        startCallButton.disabled = true;
        loadingSpinner.classList.remove('hidden');
        updateCallStatus('Initializing');
        
        // Get selected voice
        const voiceSelect = document.getElementById('voice-select');
        const selectedVoice = voiceSelect ? voiceSelect.value : DEFAULT_VOICE;
        console.log("Selected voice:", selectedVoice);
        
        // Check and initialize uvSession if needed
        if (!uvSession) {
            console.log("Ultravox session not initialized yet, attempting to initialize");
            if (window.UltravoxSession) {
                const debugMessages = new Set(["debug"]);
                uvSession = new window.UltravoxSession({ experimentalMessages: debugMessages });
                setupUltravoxEventListeners();
                console.log("Ultravox session initialized on-demand");
            } else {
                throw new Error("UltravoxSession is not available. Please refresh the page.");
            }
        }
        
        // Request a new call from the server
        const response = await fetch('/start_call', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                voice: selectedVoice
            }),
            verify: false
        });
        
        if (!response.ok) {
            let errorMessage = `Error ${response.status}: ${response.statusText}`;
            try {
                const errorData = await response.json();
                if (errorData.error) {
                    errorMessage = errorData.error;
                    // Display appropriate error based on status
                    switch (response.status) {
                        case 402:
                            showErrorMessage(errorMessage, 'subscription');
                            break;
                        case 403:
                            showErrorMessage(errorMessage, 'api');
                            break;
                        default:
                            showErrorMessage(errorMessage, 'error');
                    }
                }
            } catch (e) {
                showErrorMessage(errorMessage, 'error');
            }
            updateCallStatus('Error');
            loadingSpinner.classList.add('hidden');
            startCallButton.disabled = false;
            return;
        }
        const callDetails = await response.json();
        console.log("Call details received:", callDetails);
        
        // Update UI with call information
        callIdValue.textContent = callDetails.callId;
        
        // Join the call
        if (uvSession) {
            console.log("Joining call with URL:", callDetails.joinUrl);
            await uvSession.joinCall(callDetails.joinUrl);
            callActive = true;
            
            // Update UI states
            startCallButton.classList.add('hidden');
            endCallButton.classList.remove('hidden');
            transcriptContent.textContent = '';
            console.log("Successfully joined call");
        } else {
            throw new Error('Ultravox session not initialized');
        }
    } catch (error) {
        console.error('Error starting call:', error);
        showErrorMessage(error.message || 'Failed to start call', 'error');
        updateCallStatus('Error');
    } finally {
        // Hide loading state
        loadingSpinner.classList.add('hidden');
        startCallButton.disabled = false;
    }
}

/**
 * End the current call
 */
async function endCall() {
    if (!callActive) return;
    
    try {
        // Update UI states
        endCallButton.disabled = true;
        loadingSpinner.classList.remove('hidden');
        
        // Leave the call
        if (uvSession) {
            await uvSession.leaveCall();
        }
    } catch (error) {
        console.error('Error ending call:', error);
    } finally {
        // Reset the UI
        callActive = false;
        updateCallStatus('Disconnected');
        endCallButton.classList.add('hidden');
        startCallButton.classList.remove('hidden');
        startCallButton.disabled = false;
        loadingSpinner.classList.add('hidden');
    }
}

/**
 * Update the call status display
 * @param {string} status - The current call status
 */
function updateCallStatus(status) {
    callStatusValue.textContent = status;
    
    // Reset classes
    callStatusValue.className = 'status-value';
    
    // Add specific status class
    switch (status.toLowerCase()) {
        case 'connecting':
        case 'initializing':
            callStatusValue.classList.add('status-connecting');
            break;
        case 'connected':
        case 'active':
            callStatusValue.classList.add('status-connected');
            break;
        case 'disconnected':
        case 'error':
            callStatusValue.classList.add('status-disconnected');
            break;
        default:
            callStatusValue.classList.add('status-waiting');
    }
}

/**
 * Update the transcript display
 * @param {Array} transcripts - Array of transcript objects
 */
function updateTranscript(transcripts) {
    if (!transcripts || !Array.isArray(transcripts)) return;
    
    // Filter out user messages and empty transcripts
    const assistantTranscripts = transcripts
        .filter(t => t && t.speaker !== "user")
        .map(t => t ? t.text : "")
        .join("\n");
    
    transcriptContent.textContent = assistantTranscripts;
    
    // Auto-scroll to bottom of transcript container
    const container = document.querySelector('.transcript-container');
    container.scrollTop = container.scrollHeight;
}
