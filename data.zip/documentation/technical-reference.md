# Technical Reference

## Architecture Overview
AeroOptima.ai follows a modular architecture organized around functional domains of airline operations. The platform is built using the Flask framework with a SQLite database (configurable to PostgreSQL for production).

```
AeroOptima.ai
├── Flask Application
│   ├── Routes (by module)
│   ├── Services
│   └── Models
├── Database
│   └── SQLite/PostgreSQL
├── Frontend
│   ├── Templates
│   ├── Static Assets
│   └── JavaScript
└── External Services
    └── Gemini API
```

## Technology Stack

### Backend
- **Python 3.10+**: Core programming language
- **Flask**: Web application framework
- **SQLAlchemy**: ORM for database interaction
- **Flask-SQLAlchemy**: Flask integration for SQLAlchemy
- **Pandas**: Data manipulation and analysis
- **PuLP**: Linear programming solver for optimization
- **rule-engine**: Rule evaluation for alerts
- **requests**: HTTP client for API calls
- **gunicorn**: WSGI HTTP server

### Frontend
- **HTML/CSS/JavaScript**: Core web technologies
- **Bootstrap 5**: UI framework for responsive design
- **Chart.js**: Data visualization library
- **Mermaid.js**: Diagram and flowchart rendering
- **FontAwesome**: Icon library

### Database
- **SQLite**: Default lightweight database
- **PostgreSQL**: Optional for production deployment

### External Services
- **Gemini API**: AI capabilities for natural language processing

## Code Organization

### Directory Structure
```
/
├── app.py                  # Application initialization
├── main.py                 # Entry point
├── models.py               # Database models
├── config.py               # Configuration settings
├── populate_sample_data.py # Sample data creation
├── routes/                 # Route handlers by module
│   ├── __init__.py
│   ├── chat.py             # AI assistant endpoints
│   ├── data_hub.py         # Data management endpoints
│   ├── debrief.py          # Incident analysis endpoints
│   ├── live_watch.py       # Monitoring endpoints
│   ├── optimizer.py        # Optimization endpoints
│   └── whatif.py           # What-if analysis (deprecated)
├── services/               # Business logic services
│   ├── __init__.py
│   ├── data_service.py     # Data processing functions
│   ├── gemini_service.py   # AI interaction functions
│   ├── optimization_service.py  # Optimization algorithms
│   └── rule_service.py     # Rule evaluation functions
├── static/                 # Static assets
│   ├── css/
│   │   └── main.css        # Custom styles
│   ├── js/
│   │   ├── main.js         # Common JavaScript
│   │   ├── data_hub.js     # Data hub functionality
│   │   ├── debrief.js      # Debrief functionality
│   │   ├── gemini_chat.js  # AI assistant functionality
│   │   ├── live_watch.js   # Monitoring functionality
│   │   ├── mermaid_charts.js # Chart generation
│   │   └── optimizer.js    # Optimizer functionality
│   └── images/             # Image assets
├── templates/              # HTML templates
│   ├── base.html           # Base template with common elements
│   ├── data_hub.html       # Data hub page
│   ├── debrief.html        # Debrief page
│   ├── live_watch.html     # Monitoring page
│   └── optimizer.html      # Optimizer page
└── documentation/          # Comprehensive documentation
```

## Database Models

### Core Models
- **DataSource**: Records of imported data sources
- **Alert**: Active and historical system alerts
- **Rule**: Alert generation rules
- **OptimizationPlan**: Saved optimization scenarios
- **Incident**: Recorded operational disruptions

### Operational Models
- **Flight**: Flight schedule and status data
- **Aircraft**: Aircraft fleet information
- **Crew**: Crew roster and qualification data

## Key Functions and Methods

### Data Processing
- `analyze_data_quality()`: Assess data quality metrics
- `save_data_to_db()`: Store imported data in appropriate tables
- `reset_database()`: Restore database to sample data state

### Rule Engine
- `evaluate_rule()`: Test a rule against provided data
- `convert_natural_language()`: Transform questions into rule syntax
- `process_alerts()`: Generate alerts from rule evaluations

### Optimization Engine
- `create_optimization_model()`: Build mathematical model for scenario
- `solve_optimization()`: Find optimal solution for constraints
- `score_solution()`: Calculate effectiveness score for solutions
- `generate_flowchart()`: Create visual representation of process

### AI Integration
- `get_gemini_response()`: Call Gemini API with prompt
- `chat_with_gemini()`: Maintain conversation with context
- `create_enhanced_prompt()`: Build context-aware prompts
- `clean_text()`: Format AI responses for display

## API Endpoints Reference
Complete list of API endpoints by module with request/response formats.

### Chat API
- **POST /api/chat**
  - Request: `{message: string, history: array, context: object}`
  - Response: `{response: string}`

### Data Hub API
- **GET /api/data-sources**
  - Response: `[{id, name, category, last_updated, row_count, quality_metrics}]`
- **POST /api/upload-data**
  - Request: `FormData with file, category, name`
  - Response: `{success: boolean, message: string, data_source: object}`
- **POST /api/generate-schema**
  - Request: `{description: string}`
  - Response: `{schema: string}`

### Monitoring API
- **GET /api/alerts**
  - Response: `[{id, title, severity, category, timestamp, is_active, ...}]`
- **POST /api/rules**
  - Request: `{name, description, rule_text, category, severity}`
  - Response: `{id, name, ...}`
- **POST /api/evaluate-rule/<id>**
  - Request: `{data: object}`
  - Response: `{result: boolean, matched: boolean, details: string}`

### Optimizer API
- **GET /api/plans**
  - Response: `[{id, name, scenario, status, score, ...}]`
- **POST /api/plans**
  - Request: `{name, description, scenario, constraints, objective_weights}`
  - Response: `{id, name, ...}`
- **POST /api/plans/<id>/run**
  - Response: `{results: object, score: number, execution_time: number}`

### Debrief API
- **GET /api/incidents**
  - Response: `[{id, title, start_time, end_time, category, severity, ...}]`
- **POST /api/incidents**
  - Request: `{title, description, start_time, end_time, category, severity}`
  - Response: `{id, title, ...}`
- **POST /api/incidents/<id>/root-cause**
  - Response: `{root_cause: string}`

## Environment Variables
- `DATABASE_URL`: Database connection string
- `FLASK_SECRET_KEY`: Secret key for sessions
- `GEMINI_API_KEY`: API key for Gemini AI service
- `DEBUG`: Enable debug mode (development only)

## Performance Considerations
- Database query optimization with appropriate indexes
- Caching for frequently accessed data
- Asynchronous processing for time-consuming operations
- Pagination for large data sets

## Security Measures
- Input validation for all form submissions
- CSRF protection on all forms
- Parametrized queries to prevent SQL injection
- API rate limiting to prevent abuse
- Content security policy implementation

## Development Guidelines
- Use virtual environments for dependency isolation
- Follow PEP 8 style guidelines for Python code
- Write unit tests for new functionality
- Document all functions and classes with docstrings
- Use semantic versioning for releases