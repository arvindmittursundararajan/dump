from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy.dialects.postgresql import TEXT

db = SQLAlchemy()

class DocumentVersion(db.Model):
    __tablename__ = 'document_versions'
    id = db.Column(db.Integer, primary_key=True)
    confluence_page_id = db.Column(db.String(50), nullable=False, index=True)
    version_number = db.Column(db.Integer, nullable=False, default=0)
    title = db.Column(db.String(500), nullable=False)
    content = db.Column(TEXT, nullable=False)
    space_key = db.Column(db.String(50), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_current = db.Column(db.Boolean, default=False)
    tone_used = db.Column(db.String(50))
    length_used = db.Column(db.String(50))
    rewriting_options = db.Column(TEXT)  # JSON string of options used
    custom_instructions = db.Column(TEXT)
    __table_args__ = (
        db.UniqueConstraint('confluence_page_id', 'version_number', name='unique_page_version'),
        db.Index('idx_page_current', 'confluence_page_id', 'is_current'),
    )
    def __repr__(self):
        return f'<DocumentVersion {self.confluence_page_id} v{self.version_number}>'
    @classmethod
    def get_current_version(cls, page_id):
        return cls.query.filter_by(
            confluence_page_id=page_id, 
            is_current=True
        ).first()
    @classmethod
    def get_all_versions(cls, page_id):
        return cls.query.filter_by(
            confluence_page_id=page_id
        ).order_by(cls.version_number.asc()).all()
    @classmethod
    def create_new_version(cls, page_id, title, content, space_key, 
                          tone=None, length=None, options=None, instructions=None):
        latest_version = cls.query.filter_by(
            confluence_page_id=page_id
        ).order_by(cls.version_number.desc()).first()
        new_version_number = (latest_version.version_number + 1) if latest_version else 0
        cls.query.filter_by(
            confluence_page_id=page_id,
            is_current=True
        ).update({'is_current': False})
        new_version = cls(
            confluence_page_id=page_id,
            version_number=new_version_number,
            title=title,
            content=content,
            space_key=space_key,
            is_current=True,
            tone_used=tone,
            length_used=length,
            rewriting_options=options,
            custom_instructions=instructions
        )
        db.session.add(new_version)
        db.session.commit()
        return new_version
    @classmethod
    def set_current_version(cls, page_id, version_number):
        cls.query.filter_by(
            confluence_page_id=page_id,
            is_current=True
        ).update({'is_current': False})
        version = cls.query.filter_by(
            confluence_page_id=page_id,
            version_number=version_number
        ).first()
        if version:
            version.is_current = True
            db.session.commit()
            return version
        return None 