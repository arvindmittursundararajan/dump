from flask import Flask, render_template, request, jsonify
import api
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    content = request.json.get('content', '')
    try:
        ideas = api.get_recommendations_and_rewrite(content)
        return jsonify({'success': True, 'recommendations': ideas})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/rewrite', methods=['POST'])
def rewrite():
    content = request.json.get('content', '')
    selected = request.json.get('selected', [])
    additional = request.json.get('additional', '')
    try:
        html = api.get_recommendations_and_rewrite(content, additional_points=additional, selected_recommendations=selected)
        return jsonify({'success': True, 'html': html})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True) 