import os

# Confluence Configuration
CONFLUENCE_BASE_URL = os.getenv("CONFLUENCE_BASE_URL", "https://jaiswalarthi03.atlassian.net/wiki/rest/api")
CONFLUENCE_EMAIL = os.getenv("CONFLUENCE_EMAIL", "jaiswalarthi03@gmail.com")
CONFLUENCE_API_TOKEN = os.getenv("CONFLUENCE_API_TOKEN", "ATATT3xFfGF06PP-F-A9enU8SvWA9it8cfddJfraTKQ1_e8QAJAaPYq8NzozRraQxFFsWQcXurTGb4CT8-N4kuIHwsTD4C1pHWvn5B6zQiy5gJc8HTXFkXPDI1D6cM1AbVwkz66CD0uyEWg_YEpkVa2lZVYL-TZOHEUQ5bl4p7XJv2rFjNyJ3G0=8F35B020")

# Gemini AI Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyC0jryJMwYhI1a1eVZAK6nLjPrDFV5VFhY")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Style Guide Prompts for Documentation Analysis
STYLE_GUIDE_PROMPTS = {
    "clarity": "Analyze the clarity of explanations and identify sections that are unclear or confusing",
    "completeness": "Check for missing information, incomplete examples, or gaps in the documentation",
    "code_examples": "Evaluate the quality and completeness of code examples",
    "structure": "Assess the organization and flow of the documentation",
    "terminology": "Check for consistent use of technical terms and proper definitions",
    "accessibility": "Evaluate if the documentation is accessible to different skill levels"
}

# Rewriting Options
REWRITING_OPTIONS = [
    {
        "id": "showcase_code",
        "label": "Showcase how to run code examples",
        "description": "Add comprehensive, runnable code examples with setup instructions"
    },
    {
        "id": "explain_features",
        "label": "Explain features in detail",
        "description": "Provide detailed explanations of features and their use cases"
    },
    {
        "id": "add_troubleshooting",
        "label": "Add troubleshooting section",
        "description": "Include common issues and their solutions"
    },
    {
        "id": "improve_structure",
        "label": "Improve document structure",
        "description": "Reorganize content with better headings and flow"
    },
    {
        "id": "add_prerequisites",
        "label": "Add prerequisites and setup",
        "description": "Include required dependencies and setup instructions"
    },
    {
        "id": "enhance_examples",
        "label": "Enhance examples",
        "description": "Improve existing examples with better context and explanations"
    }
]

# Language and Tone Options
TONE_OPTIONS = [
    {"id": "professional", "label": "Professional", "description": "Formal, business-appropriate tone"},
    {"id": "casual", "label": "Casual", "description": "Friendly, conversational tone"},
    {"id": "technical", "label": "Technical", "description": "Precise, technical language for experts"},
    {"id": "beginner", "label": "Beginner-friendly", "description": "Simple, accessible language for newcomers"},
    {"id": "concise", "label": "Concise", "description": "Brief, to-the-point communication"},
    {"id": "detailed", "label": "Detailed", "description": "Comprehensive, thorough explanations"}
]

# Length Options
LENGTH_OPTIONS = [
    {"id": "short", "label": "Short", "description": "Brief overview (200-500 words)", "words": "200-500"},
    {"id": "medium", "label": "Medium", "description": "Comprehensive guide (500-1500 words)", "words": "500-1500"},
    {"id": "long", "label": "Long", "description": "Detailed documentation (1500+ words)", "words": "1500+"}
]

# Sample Developer Documentation Templates
SAMPLE_DOCS = [
    {
        "title": "API Authentication Guide",
        "content": """
<h1>API Authentication Guide</h1>

<p>This guide covers authentication methods for our REST API.</p>

<h2>Authentication Methods</h2>
<p>We support multiple authentication methods including API keys and OAuth 2.0.</p>

<h3>API Key Authentication</h3>
<p>Include your API key in the Authorization header.</p>

<pre><code>curl -H "Authorization: Bearer YOUR_API_KEY" https://api.example.com/v1/data</code></pre>

<h3>OAuth 2.0</h3>
<p>For more secure applications, use OAuth 2.0 flow.</p>

<h2>Rate Limiting</h2>
<p>API calls are rate limited to 1000 requests per hour.</p>
        """.strip()
    },
    {
        "title": "SDK Installation and Setup",
        "content": """
<h1>SDK Installation and Setup</h1>

<p>Get started with our SDK in minutes.</p>

<h2>Installation</h2>
<p>Install via package manager:</p>

<pre><code>npm install our-sdk</code></pre>

<h2>Basic Usage</h2>
<p>Import and initialize the SDK:</p>

<pre><code>import SDK from 'our-sdk';
const client = new SDK({ apiKey: 'your-key' });</code></pre>

<h2>Configuration</h2>
<p>Configure the SDK with your credentials and preferences.</p>
        """.strip()
    },
    {
        "title": "Webhook Integration Tutorial",
        "content": """
<h1>Webhook Integration Tutorial</h1>

<p>Learn how to set up webhooks for real-time event notifications.</p>

<h2>What are Webhooks?</h2>
<p>Webhooks are HTTP callbacks that notify your application of events.</p>

<h2>Setting Up Webhooks</h2>
<p>Configure webhook endpoints in your dashboard.</p>

<h3>Endpoint Requirements</h3>
<p>Your endpoint must respond with 200 status code.</p>

<h2>Event Types</h2>
<p>We support various event types including user.created and payment.completed.</p>

<h2>Security</h2>
<p>Verify webhook signatures to ensure authenticity.</p>
        """.strip()
    },
    {
        "title": "Error Handling Best Practices",
        "content": """
<h1>Error Handling Best Practices</h1>

<p>Implement robust error handling in your applications.</p>

<h2>Common Error Codes</h2>
<p>Understand our standard HTTP error codes and their meanings.</p>

<h3>400 Bad Request</h3>
<p>Invalid request parameters or malformed JSON.</p>

<h3>401 Unauthorized</h3>
<p>Missing or invalid authentication credentials.</p>

<h3>429 Too Many Requests</h3>
<p>Rate limit exceeded, implement exponential backoff.</p>

<h2>Error Response Format</h2>
<p>All errors return JSON with error code and message.</p>

<h2>Retry Logic</h2>
<p>Implement proper retry logic for transient failures.</p>
        """.strip()
    }
]
