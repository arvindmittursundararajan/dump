# Monitoring

## Overview
The Monitoring module (previously called "Live Watch") provides real-time surveillance of airline operations, detecting disruptions and issues through a rule-based alerting system. It enables operations staff to quickly identify and respond to emerging situations before they escalate.

## URL Route
- Main URL: `/monitoring` (accessible through the top navigation bar)

## Key Features

### 1. Real-time Alert Dashboard
- **Active Alerts Display**: Visual representation of current operational issues
- **Severity Classification**: Critical, Major, and Informational alert levels
- **Filtering Capabilities**: Sort and filter alerts by type, severity, and status
- **Resolution Tracking**: Mark alerts as resolved with resolution notes

### 2. Rule Engine
- **Custom Rule Creation**: Define operational rules using a simplified syntax
- **Rule Categories**: Categorize rules by operational area (crew, aircraft, passenger, etc.)
- **Rule Testing**: Validate rules against current data before activation
- **Rule Management**: Enable/disable rules as needed

### 3. Natural Language Querying
- **AI-Powered Queries**: Convert natural language questions into rule expressions
- **Query History**: Access previously asked questions
- **Suggested Queries**: Common questions for quick access

### 4. Alert Analysis
- **Trend Visualization**: Charts showing alert frequency over time
- **Impact Assessment**: Overview of operational areas affected
- **Correlation Detection**: Identify related issues across the operation

## User Interface Components

### Alert Panel
- Color-coded alert cards by severity
- Expand/collapse functionality for details
- Quick action buttons for resolution
- Timestamp and affected entity information

### Rule Management Interface
- List of active and inactive rules
- Rule editor with syntax highlighting
- Category and severity selection
- Test button with immediate feedback

### Natural Language Query Tool
- Text input for natural language questions
- AI processing indicator
- Results display with highlighting
- Option to convert query to permanent rule

## Specialized Alert Types

### 1. Unaccompanied Minor Alerts
- **Transit Monitoring**: Tracking connections for unaccompanied minors
- **Staff Availability**: Ensuring sufficient staff for minor assistance
- **Overnight Detection**: Flagging potential overnight stays for minors

### 2. Crew Duty Time Alerts
- **Duty Limit Approach**: Warning when crew approaching maximum duty hours
- **Rest Violation Risk**: Identifying potential minimum rest violations
- **Qualification Expiry**: Tracking approaching qualification expirations

### 3. Aircraft Maintenance Alerts
- **Maintenance Due**: Notification of approaching maintenance deadlines
- **Unscheduled Maintenance**: Alerts when aircraft requires unexpected service
- **Part Availability**: Warnings for maintenance requiring scarce parts

### 4. Operational Disruption Alerts
- **Delay Propagation**: Identifying cascading delays through the network
- **Cancellation Impact**: Assessing passenger and crew impact from cancellations
- **Airport Capacity**: Monitoring for ground or airspace capacity constraints

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/alerts` | GET | Retrieve all active alerts |
| `/api/alerts/<id>` | GET | Get specific alert details |
| `/api/alerts/<id>/resolve` | POST | Mark alert as resolved |
| `/api/rules` | GET | Get all defined rules |
| `/api/rules` | POST | Create a new rule |
| `/api/rules/<id>` | PUT | Update an existing rule |
| `/api/evaluate-rule/<id>` | POST | Test a rule against provided data |
| `/api/natural-language-query` | POST | Convert natural language to rule syntax |

## Database Models
The Monitoring module uses two primary models:

### Alert Model
- `id`: Unique identifier
- `title`: Alert headline
- `description`: Detailed alert information
- `severity`: Critical, Major, or Info classification
- `category`: Operational category
- `source`: System component that generated the alert
- `timestamp`: When the alert was created
- `is_active`: Whether alert is still active
- `resolved_at`: When the alert was resolved (if applicable)
- `resolution_notes`: Comments on how the alert was addressed
- `affected_entities`: JSON data of impacted flights, crew, etc.
- `additional_data`: Extra context information

### Rule Model
- `id`: Unique identifier
- `name`: Rule name
- `description`: Explanation of what the rule detects
- `rule_text`: The rule expression syntax
- `category`: Operational category
- `severity`: Severity level assigned to triggered alerts
- `is_active`: Whether rule is currently enforced
- `created_at`: Creation timestamp
- `updated_at`: Last modification timestamp
- `rule_config`: Additional configuration options

## Technical Implementation
- Uses Flask routes in `routes/live_watch.py`
- Leverages the `rule_engine` library for rule evaluation
- Implements a custom alert priority algorithm
- Uses WebSockets for real-time updates (when configured)

## Best Practices
1. Set appropriate severity levels to avoid alert fatigue
2. Create specific rules targeting known operational weak points
3. Review and refine rules based on false positive/negative rates
4. Establish clear escalation protocols for critical alerts
5. Document resolution steps for common alert types