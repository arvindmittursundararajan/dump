import os
import json
import requests
from config import GEMINI_API_KEY

# API Configuration
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

def create_analysis_prompt(schema_metadata, analysis_type, sql_query=None):
    """
    Creates a prompt for the Together AI model based on schema metadata and analysis type.
    
    Args:
        schema_metadata (dict): Dictionary containing schema information
        analysis_type (str): Type of analysis to perform
        sql_query (str): Optional SQL query to include in the analysis
    
    Returns:
        str: Formatted prompt for the AI model
    """
    # Format schema information for the prompt
    schema_info = json.dumps(schema_metadata, indent=2)
    
    base_prompt = f"""
You are a database schema expert analyzing schema information from a Databricks database. Provide a detailed {analysis_type} analysis of the following database objects:

## Schema Information:
```json
{schema_info}
```

"""
    
    if sql_query:
        base_prompt += f"""
## SQL Query for Analysis:
```sql
{sql_query}
```
"""
    
    # Add specific instructions based on analysis type
    if analysis_type == "general":
        base_prompt += """
Please provide a comprehensive schema analysis that includes:
1. Overview of the schema structure
2. Assessment of entity relationships
3. Primary and foreign key analysis
4. Data type assessments
5. Recommendations for schema improvements
"""
    elif analysis_type == "performance":
        base_prompt += """
Please provide a performance-focused analysis that includes:
1. Identification of potential performance bottlenecks
2. Query optimization opportunities
3. Indexing recommendations
4. Partitioning and clustering suggestions
5. Materialized view recommendations
"""
    elif analysis_type == "normalization":
        base_prompt += """
Please provide a normalization analysis that includes:
1. Current normalization level assessment (1NF, 2NF, 3NF, etc.)
2. Data redundancy identification
3. Functional dependency analysis
4. Denormalization considerations
5. Recommendations for improving normalization
"""
    elif analysis_type == "relationships":
        base_prompt += """
Please provide a relationships-focused analysis that includes:
1. Entity relationship mapping
2. Identifying missing relationships
3. Assessment of referential integrity
4. Cardinality analysis
5. Recommendations for relationship improvements
"""
    elif analysis_type == "naming":
        base_prompt += """
Please provide a naming convention analysis that includes:
1. Consistency assessment of naming patterns
2. Table naming convention evaluation
3. Column naming convention evaluation
4. Identifier clarity and meaning
5. Recommendations for naming improvements
"""
    elif analysis_type == "standards":
        base_prompt += """
Please provide a standards compliance analysis that includes:
1. Adherence to industry best practices
2. SQL standard compliance
3. Databricks-specific conventions evaluation
4. Documentation and comment quality
5. Recommendations for improved standards compliance
"""
    
    # General formatting instructions
    base_prompt += """
Format your response as HTML with these elements:
- Use <h1>, <h2>, <h3> for headings
- Use <ul>, <ol>, <li> for lists
- Use <table>, <tr>, <th>, <td> for tabular data
- Use <code> and <pre> for SQL examples
- Add emojis for visual appeal (e.g., 📊, 🔍, ✅, ⚠️, 💡)

Make your response informative, specific, and actionable.
"""
    
    return base_prompt

def generate_analysis(prompt):
    """
    Generate an analysis by sending a prompt to the Google Gemini API.
    
    Args:
        prompt (str): The formatted prompt to send to the API
        
    Returns:
        str: HTML-formatted analysis result
    """
    try:
        print("\n--- GEMINI PROMPT SENT ---\n")
        print(prompt)
        print("\n--- END GEMINI PROMPT ---\n")
        # Configuration for the API request
        params = {
            'key': GEMINI_API_KEY,
        }
        
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 32,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        
        # For demo purposes, return a sample analysis if no API key
        if not GEMINI_API_KEY:
            return get_sample_analysis()
        
        # Send request to Gemini API
        response = requests.post(
            GEMINI_API_URL, 
            params=params, 
            json=request_body,
            headers={"Content-Type": "application/json"}
        )
        
        # Check if request was successful
        if response.status_code == 200:
            response_json = response.json()
            if 'candidates' in response_json and len(response_json['candidates']) > 0:
                # Gemini 2.0 API response format
                parts = response_json['candidates'][0].get('content', {}).get('parts', [])
                if parts and 'text' in parts[0]:
                    analysis_text = parts[0]['text']
                else:
                    analysis_text = str(parts)
                
                # Clean up the response if needed
                if not analysis_text.strip():
                    return get_sample_analysis()
                
                return analysis_text
            else:
                print(f"No valid response from Gemini API: {response_json}")
                return f"""
                <h1>⚠️ API Error</h1>
                <p>There was an error with the Gemini API response format.</p>
                <p>Using sample analysis instead.</p>
                {get_sample_analysis()}
                """
        else:
            print(f"API Error: {response.status_code} - {response.text}")
            return f"""
            <h1>⚠️ API Error</h1>
            <p>There was an error connecting to the Gemini API:</p>
            <pre>{response.status_code} - {response.text}</pre>
            <p>Using sample analysis instead.</p>
            {get_sample_analysis()}
            """
    
    except Exception as e:
        print(f"Error generating analysis: {str(e)}")
        return f"""
        <h1>⚠️ Error</h1>
        <p>There was an error generating the analysis:</p>
        <pre>{str(e)}</pre>
        <p>Using sample analysis instead.</p>
        {get_sample_analysis()}
        """

def get_sample_analysis():
    """Return a sample analysis for demonstration purposes."""
    return """
    <h1>📊 Database Schema Analysis</h1>
    
    <p>This is a sample analysis of the database schema. In a real implementation, this would be generated by the AI model based on your specific schema.</p>
    
    <h2>🔑 Schema Overview</h2>
    
    <p>The analyzed schema appears to be an e-commerce database with the following key tables:</p>
    
    <ul>
        <li><strong>customer_data</strong>: Stores customer information</li>
        <li><strong>product_catalog</strong>: Contains product details</li>
        <li><strong>sales_transactions</strong>: Records individual sales</li>
        <li><strong>sales_summary_mv</strong>: A materialized view for aggregated sales data</li>
    </ul>
    
    <h2>✅ Strengths</h2>
    
    <ul>
        <li>Clear separation of concerns between tables</li>
        <li>Good use of descriptive column names</li>
        <li>Appropriate data types for most columns</li>
        <li>Use of materialized view for performance optimization</li>
    </ul>
    
    <h2>⚠️ Potential Issues</h2>
    
    <ul>
        <li>Missing foreign key constraints between sales and customer/product tables</li>
        <li>Some tables may benefit from additional indexing</li>
        <li>Large file count in sales table (256 files) indicates potential compaction opportunity</li>
        <li>VARCHAR sizes may be unnecessarily large for some fields</li>
    </ul>
    
    <h2>💡 Recommendations</h2>
    
    <ol>
        <li>Add explicit foreign key constraints to enforce referential integrity</li>
        <li>Consider compacting the sales_transactions table to improve query performance</li>
        <li>Add appropriate indexes on frequently queried columns</li>
        <li>Review and adjust VARCHAR sizes to optimize storage</li>
        <li>Consider partitioning large tables by date for improved query performance</li>
    </ol>
    
    <h2>📈 Performance Considerations</h2>
    
    <p>Based on the query history, the following performance optimizations are recommended:</p>
    
    <table border="1" cellpadding="5">
        <tr>
            <th>Table</th>
            <th>Current Size</th>
            <th>Avg Query Time</th>
            <th>Optimization</th>
        </tr>
        <tr>
            <td>sales_transactions</td>
            <td>3 GB</td>
            <td>5.07s</td>
            <td>Partition by transaction_date</td>
        </tr>
        <tr>
            <td>customer_data</td>
            <td>750 MB</td>
            <td>2.32s</td>
            <td>Add index on email column</td>
        </tr>
        <tr>
            <td>product_catalog</td>
            <td>250 MB</td>
            <td>1.20s</td>
            <td>Add index on category column</td>
        </tr>
    </table>
    
    <h2>🔄 Example Query Optimizations</h2>
    
    <p>Consider replacing this query:</p>
    
    <pre><code>SELECT * FROM sales_transactions 
WHERE transaction_date > '2025-04-01'</code></pre>
    
    <p>With this optimized version:</p>
    
    <pre><code>SELECT transaction_id, customer_id, product_id, quantity, price
FROM sales_transactions
WHERE transaction_date > '2025-04-01'</code></pre>
    
    <p>This reduces the amount of data scanned and improves performance.</p>
    """