from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from .db import db_manager

class JobService:
    """Service for managing scheduled jobs."""
    
    def create_job(self, job_data: Dict[str, Any]) -> int:
        """Create a new scheduled job."""
        try:
            # Validate job data
            if not job_data.get('name'):
                raise ValueError("Job name is required")
            
            if not job_data.get('catalog') or not job_data.get('schema'):
                raise ValueError("Catalog and schema are required")
            
            if not job_data.get('tables'):
                raise ValueError("At least one table is required")
            
            if not job_data.get('analysis_types'):
                raise ValueError("At least one analysis type is required")
            
            # Calculate next run time
            schedule_type = job_data.get('schedule_type')
            schedule_time = job_data.get('schedule_time')
            if not schedule_type or not schedule_time:
                raise ValueError("Schedule type and time are required")
            next_run = self._calculate_next_run(schedule_type, schedule_time)
            
            # Add next_run to job data
            job_data['next_run'] = next_run
            
            # Create job in database
            job_id = db_manager.create_scheduled_job(job_data)
            
            return job_id
            
        except Exception as e:
            raise Exception(f"Failed to create job: {str(e)}")
    
    def get_jobs(self) -> List[Dict[str, Any]]:
        """Get all scheduled jobs."""
        try:
            jobs = db_manager.get_scheduled_jobs()
            
            # Format jobs for frontend
            formatted_jobs = []
            for job in jobs:
                formatted_jobs.append({
                    'id': job['id'],
                    'name': job['name'],
                    'schedule': f"{job['schedule_type']} at {job['schedule_time']}",
                    'active': job['active'],
                    'lastRun': job['last_run'],
                    'nextRun': job['next_run']
                })
            
            return formatted_jobs
            
        except Exception as e:
            raise Exception(f"Failed to get jobs: {str(e)}")
    
    def update_job(self, job_id: int, job_data: Dict[str, Any]) -> bool:
        """Update an existing job."""
        try:
            # Validate job data
            if not job_data.get('name'):
                raise ValueError("Job name is required")
            
            if not job_data.get('catalog') or not job_data.get('schema'):
                raise ValueError("Catalog and schema are required")
            
            if not job_data.get('tables'):
                raise ValueError("At least one table is required")
            
            if not job_data.get('analysis_types'):
                raise ValueError("At least one analysis type is required")
            
            # Calculate next run time
            schedule_type = job_data.get('schedule_type')
            schedule_time = job_data.get('schedule_time')
            if not schedule_type or not schedule_time:
                raise ValueError("Schedule type and time are required")
            next_run = self._calculate_next_run(schedule_type, schedule_time)
            
            # Add next_run to job data
            job_data['next_run'] = next_run
            
            # Update job in database
            success = db_manager.update_scheduled_job(job_id, job_data)
            
            return success
            
        except Exception as e:
            raise Exception(f"Failed to update job: {str(e)}")
    
    def delete_job(self, job_id: int) -> bool:
        """Delete a job."""
        try:
            success = db_manager.delete_scheduled_job(job_id)
            return success
        except Exception as e:
            raise Exception(f"Failed to delete job: {str(e)}")
    
    def _calculate_next_run(self, schedule_type: str, schedule_time: str) -> datetime:
        """Calculate the next run time for a job."""
        now = datetime.now()
        
        # Parse time (assuming format like "14:30")
        try:
            hour, minute = map(int, schedule_time.split(':'))
        except ValueError:
            raise ValueError("Invalid time format. Use HH:MM")
        
        if schedule_type == 'daily':
            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=1)
        
        elif schedule_type == 'weekly':
            # For weekly, we'd need to specify which day of the week
            # For now, just add 7 days
            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=7)
        
        elif schedule_type == 'monthly':
            # For monthly, we'd need to specify which day of the month
            # For now, just add 30 days
            next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_run <= now:
                next_run += timedelta(days=30)
        
        else:
            raise ValueError(f"Unsupported schedule type: {schedule_type}")
        
        return next_run

class RuleService:
    """Service for managing custom rules."""
    
    def create_rule(self, rule_data: Dict[str, Any]) -> int:
        """Create a new custom rule."""
        try:
            # Validate rule data
            if not rule_data.get('name'):
                raise ValueError("Rule name is required")
            
            if not rule_data.get('type'):
                raise ValueError("Rule type is required")
            
            if not rule_data.get('category'):
                raise ValueError("Rule category is required")
            
            if not rule_data.get('severity'):
                raise ValueError("Rule severity is required")
            
            if not rule_data.get('query'):
                raise ValueError("Rule query is required")
            
            # Validate SQL query
            query = rule_data.get('query')
            if query is None or not self.validate_rule_query(query):
                raise ValueError("Invalid SQL query")
            
            # Create rule in database
            rule_id = db_manager.create_custom_rule(rule_data)
            
            return rule_id
            
        except Exception as e:
            raise Exception(f"Failed to create rule: {str(e)}")
    
    def get_rules(self) -> List[Dict[str, Any]]:
        """Get all custom rules."""
        try:
            rules = db_manager.get_custom_rules()
            
            # Format rules for frontend
            formatted_rules = []
            for rule in rules:
                formatted_rules.append({
                    'id': rule['id'],
                    'name': rule['name'],
                    'type': rule['type'],
                    'category': rule['category'],
                    'severity': rule['severity'],
                    'active': rule['active']
                })
            
            return formatted_rules
            
        except Exception as e:
            raise Exception(f"Failed to get rules: {str(e)}")
    
    def update_rule(self, rule_id: int, rule_data: Dict[str, Any]) -> bool:
        """Update an existing rule."""
        try:
            # Validate rule data
            if not rule_data.get('name'):
                raise ValueError("Rule name is required")
            
            if not rule_data.get('type'):
                raise ValueError("Rule type is required")
            
            if not rule_data.get('category'):
                raise ValueError("Rule category is required")
            
            if not rule_data.get('severity'):
                raise ValueError("Rule severity is required")
            
            if not rule_data.get('query'):
                raise ValueError("Rule query is required")
            
            # Validate SQL query
            query = rule_data.get('query')
            if query is None or not self.validate_rule_query(query):
                raise ValueError("Invalid SQL query")
            
            # Update rule in database
            success = db_manager.update_custom_rule(rule_id, rule_data)
            
            return success
            
        except Exception as e:
            raise Exception(f"Failed to update rule: {str(e)}")
    
    def delete_rule(self, rule_id: int) -> bool:
        """Delete a rule."""
        try:
            success = db_manager.delete_custom_rule(rule_id)
            return success
        except Exception as e:
            raise Exception(f"Failed to delete rule: {str(e)}")
    
    def validate_rule_query(self, query: str) -> bool:
        """Validate a rule SQL query."""
        try:
            # Basic SQL validation - in production, you'd want more sophisticated validation
            if not query.strip():
                return False
            
            # Check for basic SQL keywords
            required_keywords = ['SELECT', 'FROM']
            query_upper = query.upper()
            
            for keyword in required_keywords:
                if keyword not in query_upper:
                    return False
            
            return True
            
        except Exception:
            return False

# Global service instances
job_service = JobService()
rule_service = RuleService() 