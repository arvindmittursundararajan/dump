import os
import logging
import requests
from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from config import ULTRAVOX_API_KEY, ULTRAVOX_API_URL, SYSTEM_PROMPT, EXAMPLE_TOOL, DEFAULT_VOICE, ERROR_MESSAGES

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "ultravox-voice-chat-secret")

def ultravox_request(method, path, **kwargs):
    """
    Helper function to make requests to the Ultravox API
    """
    url = ULTRAVOX_API_URL + path
    headers = {"X-API-Key": ULTRAVOX_API_KEY}
    
    if 'headers' in kwargs:
        kwargs['headers'].update(headers)
    else:
        kwargs['headers'] = headers
    
    try:
        logger.debug(f"Making {method} request to {url}")
        response = requests.request(method, url, **kwargs)
        
        # Log the response status
        logger.debug(f"Response status: {response.status_code}")
        
        if response.status_code >= 400:
            logger.error(f"API error response: {response.text}")
        
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        logger.error(f"API request error: {e}")
        return None

@app.route('/')
def index():
    """
    Main page of the application
    """
    return render_template('index.html')

@app.route('/test_ultravox', methods=['GET'])
def test_ultravox():
    """
    Test connection to Ultravox API by creating a test call
    """
    try:
        # Try to create a test call to check API connection
        test_data = {
            "systemPrompt": "This is a test call to check API connectivity.",
            "voice": DEFAULT_VOICE,
        }
        
        response = ultravox_request("POST", "/calls", json=test_data)
        
        if response and response.status_code == 201:
            # Successfully created a call
            call_details = response.json()
            
            # Delete the test call immediately
            call_id = call_details.get('callId')
            if call_id:
                delete_response = ultravox_request("DELETE", f"/calls/{call_id}")
                delete_status = "Test call was deleted successfully." if delete_response and delete_response.status_code == 204 else "Failed to delete test call."
            else:
                delete_status = "No call ID was returned."
            
            return jsonify({
                "success": True,
                "message": f"Successfully connected to Ultravox API. {delete_status}",
                "call_id": call_id
            })
        else:
            if response:
                error_message = f"Failed to connect to Ultravox API. Status code: {response.status_code}, Response: {response.text if hasattr(response, 'text') else 'No response text'}"
            else:
                error_message = "Failed to connect to Ultravox API"
            
            logger.error(error_message)
            return jsonify({
                "success": False,
                "message": error_message
            }), 500
    
    except Exception as e:
        error_message = f"Error testing Ultravox API: {str(e)}"
        logger.exception(error_message)
        return jsonify({
            "success": False, 
            "message": error_message
        }), 500

@app.route('/check_api_key', methods=['GET'])
def check_api_key():
    """
    Check if the current API key is valid and has enough credits
    """
    # Just return the currently used API key (last 4 chars)
    masked_key = "****" + ULTRAVOX_API_KEY[-4:] if ULTRAVOX_API_KEY else "Not configured"
    return jsonify({
        "api_key_configured": bool(ULTRAVOX_API_KEY),
        "masked_key": masked_key
    })

@app.route('/start_call', methods=['POST'])
def start_call():
    """
    Start a new voice call with Ultravox API
    """
    try:
        # Check if API key is configured
        if not ULTRAVOX_API_KEY:
            return jsonify({
                "error": "Ultravox API key is not configured. Please set the ULTRAVOX_API_KEY environment variable."
            }), 401
        
        data = {
            "systemPrompt": SYSTEM_PROMPT,
            "voice": DEFAULT_VOICE,
            "selectedTools": EXAMPLE_TOOL,
        }
        
        logger.debug(f"Starting call with data: {data}")
        response = ultravox_request("POST", "/calls", json=data)
        
        if response and response.status_code == 201:
            call_details = response.json()
            logger.debug(f"Call created successfully: {call_details}")
            return jsonify(call_details)
        else:
            if response:
                # Get a friendly error message based on status code
                status_code = response.status_code
                friendly_error = ERROR_MESSAGES.get(status_code, f"Unknown error (status code: {status_code})") 
                
                # Parse response text if available
                try:
                    response_json = response.json()
                    api_detail = response_json.get('detail', '')
                except:
                    api_detail = response.text if hasattr(response, 'text') else ''
                
                error_message = f"API Error: {friendly_error}"
                if api_detail:
                    error_message += f" - {api_detail}"
                
                logger.error(f"API error: {status_code} - {error_message}")
                
                # Special handling for payment required error
                if status_code == 402:
                    return jsonify({
                        "error": "Payment required. This API key has reached its usage limit or requires a subscription.",
                        "detail": api_detail,
                        "status": "payment_required"
                    }), 402
                
                return jsonify({"error": error_message}), status_code
            else:
                error_message = "Failed to connect to Ultravox API. Please check your internet connection."
                logger.error(error_message)
                return jsonify({"error": error_message}), 500
    
    except Exception as e:
        logger.exception("Error starting call")
        return jsonify({"error": str(e)}), 500

@app.route('/api_key', methods=['GET'])
def api_key_page():
    """
    API key configuration page
    """
    # Just mask the API key for display
    masked_key = "****" + ULTRAVOX_API_KEY[-4:] if ULTRAVOX_API_KEY and len(ULTRAVOX_API_KEY) > 4 else ""
    return render_template('api_key.html', current_key=masked_key, message=request.args.get('message'))

@app.route('/update_api_key', methods=['POST'])
def update_api_key():
    """
    Update the Ultravox API key
    """
    try:
        api_key = request.form.get('api_key', '').strip()
        
        if not api_key:
            return redirect(url_for('api_key_page', message="API key cannot be empty"))
        
        # Set the environment variable
        os.environ['ULTRAVOX_API_KEY'] = api_key
        
        # Update the module variable (will be reset on app restart)
        global ULTRAVOX_API_KEY
        ULTRAVOX_API_KEY = api_key
        
        # Test the new API key
        test_data = {
            "systemPrompt": "This is a test call to check API connectivity.",
            "voice": DEFAULT_VOICE,
        }
        
        headers = {"X-API-Key": api_key}
        test_response = requests.post(
            ULTRAVOX_API_URL + "/calls", 
            json=test_data,
            headers=headers
        )
        
        if test_response.status_code == 201:
            # API key works
            return redirect(url_for('api_key_page', message="API key updated successfully!"))
        else:
            # API key doesn't work
            error_message = f"API key validation failed (Status: {test_response.status_code})"
            if test_response.status_code == 402:
                error_message = "This API key requires a subscription or has reached its usage limit"
            elif test_response.status_code == 403:
                error_message = "Invalid API key"
            
            return redirect(url_for('api_key_page', message=f"Warning: {error_message}. The key has been saved anyway."))
            
    except Exception as e:
        logger.exception("Error updating API key")
        return redirect(url_for('api_key_page', message=f"Error: {str(e)}"))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
