/**
 * AeroOptima.ai - Main JavaScript
 * Contains shared functionality used across the application
 */

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });

    // Initialize popovers
    const popovers = document.querySelectorAll('[data-bs-toggle="popover"]');
    popovers.forEach(popover => {
        new bootstrap.Popover(popover);
    });

    // Initialize toast notifications
    const toastElList = document.querySelectorAll('.toast');
    toastElList.forEach(toastEl => {
        new bootstrap.Toast(toastEl);
    });

    // Toggle chat panel visibility
    const chatToggleBtn = document.getElementById('chat-toggle');
    const chatPanel = document.getElementById('chat-panel');
    
    if (chatToggleBtn && chatPanel) {
        // Make sure chat panel is initially hidden with d-none
        if (!chatPanel.classList.contains('d-none')) {
            chatPanel.classList.add('d-none');
        }
        
        chatToggleBtn.addEventListener('click', function() {
            chatPanel.classList.toggle('d-none');
            
            // Update button text based on visibility
            if (chatPanel.classList.contains('d-none')) {
                chatToggleBtn.innerHTML = '<i class="fas fa-comment"></i> Show Gemini';
            } else {
                chatToggleBtn.innerHTML = '<i class="fas fa-times"></i> Hide Gemini';
                // Focus the input when opening
                document.getElementById('chat-input')?.focus();
            }
        });
    }
    
    // Initialize close chat button (fix for close button)
    const closeChat = document.getElementById('close-chat');
    if (closeChat && chatPanel) {
        closeChat.addEventListener('click', function() {
            chatPanel.classList.add('d-none');
            if (chatToggleBtn) {
                chatToggleBtn.innerHTML = '<i class="fas fa-comment"></i> Show Gemini';
            }
        });
    }
});

/**
 * Format a date string into a human readable format
 * @param {string} dateString - ISO date string
 * @param {boolean} includeTime - Whether to include time
 * @returns {string} Formatted date
 */
function formatDate(dateString, includeTime = true) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) {
        return 'Invalid Date';
    }
    
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    };
    
    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
    }
    
    return date.toLocaleDateString('en-US', options);
}

/**
 * Format a number as a percentage
 * @param {number} value - Value to format (0-1)
 * @param {number} decimals - Number of decimal places
 * @returns {string} Formatted percentage
 */
function formatPercent(value, decimals = 1) {
    if (value === undefined || value === null) return 'N/A';
    return (value * 100).toFixed(decimals) + '%';
}

/**
 * Create and display a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of toast (success, danger, warning, info)
 */
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + new Date().getTime();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    // Create toast content
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show the toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 5000
    });
    bsToast.show();
    
    // Remove the toast from DOM after it's hidden
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}

/**
 * Make API call with error handling
 * @param {string} url - API endpoint
 * @param {Object} options - Fetch options
 * @returns {Promise} API response
 */
async function apiCall(url, options = {}) {
    try {
        const response = await fetch(url, options);
        
        // Parse response based on content type
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            data = await response.text();
        }
        
        // Check if response is OK
        if (!response.ok) {
            const errorMessage = data.error || data.message || `API error: ${response.status}`;
            throw new Error(errorMessage);
        }
        
        return data;
    } catch (error) {
        console.error('API call failed:', error);
        showToast(error.message, 'danger');
        throw error;
    }
}

/**
 * Show a loading spinner
 * @param {string} elementId - ID of element to show spinner in
 * @param {string} text - Optional loading text
 */
function showLoading(elementId, text = 'Loading...') {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = `
            <div class="text-center my-4">
                <div class="spinner"></div>
                <p class="mt-2">${text}</p>
            </div>
        `;
    }
}

/**
 * Create a color-coded data quality indicator
 * @param {number} value - Quality score (0-1)
 * @param {string} label - Label for the quality metric
 * @returns {string} HTML for quality indicator
 */
function createQualityIndicator(value, label) {
    if (value === undefined || value === null) {
        return '';
    }
    
    let colorClass;
    if (value >= 0.9) {
        colorClass = 'bg-success';
    } else if (value >= 0.7) {
        colorClass = 'bg-info';
    } else if (value >= 0.5) {
        colorClass = 'bg-warning';
    } else {
        colorClass = 'bg-danger';
    }
    
    return `
        <div class="mb-2">
            <div class="small">${label}: ${formatPercent(value)}</div>
            <div class="data-quality-meter">
                <div class="data-quality-value ${colorClass}" style="width: ${value * 100}%"></div>
            </div>
        </div>
    `;
}

/**
 * Initialize Mermaid diagrams
 */
function initMermaid() {
    if (typeof mermaid !== 'undefined') {
        mermaid.initialize({
            startOnLoad: true,
            theme: 'neutral',
            flowchart: {
                useMaxWidth: true,
                htmlLabels: true,
                curve: 'basis'
            },
            securityLevel: 'loose'
        });
    }
}

/**
 * Export data to CSV file
 * @param {Array} data - Array of objects to export
 * @param {string} filename - Filename to save as
 */
function exportToCSV(data, filename) {
    if (!data || !data.length) {
        showToast('No data to export', 'warning');
        return;
    }
    
    // Get headers from first row
    const headers = Object.keys(data[0]);
    
    // Convert data to CSV format
    let csvContent = headers.join(',') + '\n';
    
    data.forEach(item => {
        const row = headers.map(header => {
            let cell = item[header];
            
            // Handle nested objects or arrays
            if (typeof cell === 'object') {
                cell = JSON.stringify(cell);
            }
            
            // Escape quotes and wrap in quotes
            if (cell !== null && cell !== undefined) {
                cell = String(cell).replace(/"/g, '""');
                if (cell.includes(',') || cell.includes('"') || cell.includes('\n')) {
                    cell = `"${cell}"`;
                }
            } else {
                cell = '';
            }
            
            return cell;
        });
        
        csvContent += row.join(',') + '\n';
    });
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename || 'export.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
