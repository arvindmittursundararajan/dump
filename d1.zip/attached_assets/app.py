import os
import sqlite3
import uuid
from flask import Flask, render_template, request, redirect, url_for, session, g, flash, jsonify
from werkzeug.middleware.proxy_fix import ProxyFix
import databricks_api as db_api
import gemini_client

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "adwworkbenchsecretkey")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Ensure the database is initialized
with app.app_context():
    db_api.init_db()

@app.before_request
def before_request():
    # Create a session ID if it doesn't exist
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())

# Routes
@app.route('/')
def index():
    """Home page with schema selection."""
    catalogs = db_api.get_catalogs()
    # Get any flash messages
    return render_template('index.html', 
                          catalogs=catalogs, 
                          analysis_types=get_analysis_types())

@app.route('/schemas/<catalog_name>')
def get_schemas(catalog_name):
    """AJAX endpoint to get schemas for a catalog."""
    schemas = db_api.get_schemas(catalog_name)
    return jsonify(schemas)

@app.route('/tables/<catalog_name>/<schema_name>')
def get_tables(catalog_name, schema_name):
    """AJAX endpoint to get tables for a schema."""
    tables = db_api.get_tables(catalog_name, schema_name)
    return jsonify(tables)

@app.route('/columns/<catalog_name>/<schema_name>/<table_name>')
def get_columns(catalog_name, schema_name, table_name):
    """AJAX endpoint to get columns for a table."""
    columns = db_api.get_columns(catalog_name, schema_name, table_name)
    return jsonify(columns)

@app.route('/select_table', methods=['POST'])
def select_table():
    """AJAX endpoint to select a table for analysis."""
    try:
        data = request.json
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
            
        catalog_name = data.get('catalog')
        schema_name = data.get('schema')
        table_name = data.get('table')
        
        if not all([catalog_name, schema_name, table_name]):
            return jsonify({'success': False, 'message': 'Missing required fields: catalog, schema, or table'}), 400
        
        # Save the catalog if it doesn't exist
        catalog_id = db_api.save_catalog_to_db({'name': catalog_name})
        
        # Save the schema if it doesn't exist
        schema_id = db_api.save_schema_to_db({'name': schema_name}, catalog_id)
        
        # Save the table if it doesn't exist
        table_info = {
            'name': table_name,
            'type': data.get('type', ''),
            'data_source_format': data.get('data_source_format', '')
        }
        table_id = db_api.save_table_to_db(table_info, schema_id)
        
        # Get and save the columns
        columns = db_api.get_columns(catalog_name, schema_name, table_name)
        for column in columns:
            db_api.save_column_to_db(column, table_id)
        
        # Save the selected table for this session
        db_api.save_selected_table(table_id, session['session_id'])
        
        # Return success
        return jsonify({'success': True, 'message': f'Table {table_name} selected for analysis'})
    except Exception as e:
        app.logger.error(f"Error in select_table: {str(e)}")
        return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/clear_selection', methods=['POST'])
def clear_selection():
    """Clear the currently selected tables."""
    db_api.clear_selected_tables(session['session_id'])
    return jsonify({'success': True, 'message': 'Selection cleared'})

@app.route('/analysis', methods=['GET', 'POST'])
def analysis():
    """Perform analysis on selected tables."""
    if request.method == 'POST':
        try:
            # Get the analysis type
            analysis_type = request.form.get('analysis_type', 'general')
            
            # Get the selected tables
            if 'session_id' not in session:
                session['session_id'] = str(uuid.uuid4())
                flash('Session initialized. Please select tables for analysis.', 'info')
                return redirect(url_for('index'))
            
            # Enable debug logging
            import logging
            app.logger.setLevel(logging.DEBUG)
            
            # Log what's happening
            app.logger.debug(f"Starting analysis with session_id: {session['session_id']}")
                
            selected_tables = db_api.get_selected_tables(session['session_id'])
            app.logger.debug(f"Retrieved selected tables: {selected_tables}")
            
            if not selected_tables:
                flash('Please select at least one table for analysis.', 'error')
                return redirect(url_for('index'))
            
            # Build the schema info
            database_name = selected_tables[0]['catalog_name']
            table_names = []
            schema_info = {}
            
            # Debug logging
            app.logger.debug(f"Selected tables: {selected_tables}")
            
            # Collect schema info for all selected tables
            for table in selected_tables:
                # Debug each table
                app.logger.debug(f"Processing table: {table}")
                
                # The table object should already be a dictionary from db_api.get_selected_tables
                catalog_name = table.get('catalog_name', 'unknown_catalog')
                schema_name = table.get('schema_name', 'unknown_schema')
                table_name = table.get('table_name', table.get('name', 'unknown_table'))
                
                full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
                table_names.append(full_table_name)
                
                columns_data = []
                try:
                    columns = db_api.get_columns(
                        catalog_name, 
                        schema_name, 
                        table_name
                    )
                    
                    app.logger.debug(f"Retrieved {len(columns)} columns for {full_table_name}")
                    
                    for column in columns:
                        columns_data.append({
                            'name': column.get('name', 'unknown'),
                            'type': column.get('full_data_type', 'unknown'),
                            'nullable': column.get('is_nullable') == 'YES',
                            'comment': column.get('comment', '')
                        })
                        
                except Exception as e:
                    app.logger.error(f"Error fetching columns for {full_table_name}: {str(e)}")
                    # Continue with empty columns rather than failing
                    
                # Add the table schema info
                schema_info[full_table_name] = {
                    'columns': columns_data,
                    'type': table.get('table_type', 'UNKNOWN'),
                    'format': table.get('data_source_format', 'UNKNOWN')
                }
            
            # Perform the analysis with HTML output format
            tables_string = ', '.join(table_names)
            analysis_result = gemini_client.analyze_schema(
                database_name, 
                tables_string, 
                schema_info, 
                analysis_type=analysis_type,
                output_format='html'  # Request HTML format with emojis
            )
            
            # Save to history
            history_id = db_api.save_analysis_to_history(
                analysis_type, 
                tables_string, 
                analysis_result
            )
            
            # Collect performance metrics for display
            metrics = {}
            for table in selected_tables:
                # Use get() method on dictionary
                catalog_name = table.get('catalog_name', 'unknown_catalog')
                schema_name = table.get('schema_name', 'unknown_schema') 
                table_name = table.get('table_name', 'unknown_table')
                
                full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
                app.logger.debug(f"Collecting metrics for table: {full_table_name}")
                
                try:
                    # Get table details
                    table_details = db_api.get_table_details(
                        catalog_name,
                        schema_name,
                        table_name
                    )
                    
                    # Get query history (with shorter table name for history)
                    queries = db_api.get_query_history(table_name, limit=5)
                    
                    # Calculate average query duration if available
                    query_duration = None
                    if queries:
                        durations = [q.get('duration_ms', 0) for q in queries if 'duration_ms' in q]
                        query_duration = sum(durations) / len(durations) if durations else None
                    
                    # Store metrics - focus on size and query duration
                    metrics[full_table_name] = {
                        'table_size_bytes': table_details.get('sizeInBytes', 'Unknown'),
                        'file_count': table_details.get('numFiles', 'Unknown'),
                        'query_duration_ms': query_duration,
                        'queries': queries
                    }
                    
                    # Save to performance metrics table
                    db_api.save_performance_metrics(full_table_name, metrics[full_table_name])
                except Exception as e:
                    app.logger.error(f"Error collecting metrics for {full_table_name}: {str(e)}")
                    metrics[full_table_name] = {
                        'table_size_bytes': 'Unknown',
                        'file_count': 'Unknown',
                        'query_duration_ms': 'Unknown',
                        'queries': []
                    }
            
            return render_template(
                'analysis.html',
                analysis_type=analysis_type,
                tables_analyzed=table_names,
                analysis_result=analysis_result,
                metrics=metrics,
                from_history=False
            )
        except Exception as e:
            app.logger.error(f"Error in analysis: {str(e)}")
            flash(f"An error occurred during analysis: {str(e)}", 'error')
            return redirect(url_for('index'))
    
    # For GET requests, show the most recent analysis if available
    history = db_api.get_analysis_history()
    if history:
        latest = history[0]
        return render_template(
            'analysis.html',
            analysis_type=latest['analysis_type'],
            tables_analyzed=latest['tables_analyzed'],
            analysis_result=latest['analysis_result'],
            metrics={}  # No metrics for historical view
        )
    
    # If no history, redirect to the index
    return redirect(url_for('index'))

@app.route('/history')
def history():
    """Show analysis history."""
    history_items = db_api.get_analysis_history()
    return render_template('history.html', history=history_items)

@app.route('/history/<int:analysis_id>')
def view_analysis(analysis_id):
    """View a specific analysis from history."""
    analysis = db_api.get_analysis_by_id(analysis_id)
    if not analysis:
        flash('Analysis not found.', 'error')
        return redirect(url_for('history'))
    
    return render_template(
        'analysis.html',
        analysis_type=analysis['analysis_type'],
        tables_analyzed=analysis['tables_analyzed'],
        analysis_result=analysis['analysis_result'],
        metrics={},  # No metrics for historical view
        from_history=True
    )

@app.route('/history/delete/<int:analysis_id>', methods=['POST'])
def delete_analysis(analysis_id):
    """Delete a specific analysis from history."""
    try:
        db_api.delete_analysis(analysis_id)
        return jsonify({'success': True})
    except Exception as e:
        app.logger.error(f"Error deleting analysis {analysis_id}: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

def get_analysis_types():
    """Get the list of available analysis types."""
    return [
        {"value": "general", "name": "General Schema Analysis", "description": "Overall assessment of schema design, normalization, and relationships"},
        {"value": "performance", "name": "Performance Analysis", "description": "Evaluation of schema for performance optimization opportunities"},
        {"value": "normalization", "name": "Normalization Analysis", "description": "Assessment of normalization levels and potential data redundancy"},
        {"value": "relationships", "name": "Relationships Analysis", "description": "Focus on entity relationships, foreign keys, and referential integrity"},
        {"value": "naming", "name": "Naming Convention Analysis", "description": "Review of naming patterns for tables, columns, and constraints"},
        {"value": "standards", "name": "Standards Compliance", "description": "Evaluation against industry standard practices and patterns"},
        {"value": "mapping_sheet", "name": "Data Mapping Sheet", "description": "Detailed metadata for tables and columns"},
        {"value": "compliance", "name": "CASTLE Compliance Assessment", "description": "Assessment of Compliance, Auditability, Security, Traceability, Lineage, Ethics"},
        {"value": "domain", "name": "Domain Analysis", "description": "Brief overview of what the database represents"},
        {"value": "diagram_conceptual", "name": "Conceptual ERD", "description": "High-level diagram of entities and relationships"},
        {"value": "diagram_logical", "name": "Logical ERD", "description": "Detailed diagram of entities, attributes, and relationships"},
        {"value": "diagram_physical", "name": "Physical ERD", "description": "Complete diagram of tables, columns, and constraints"},
        {"value": "diagram_dependency", "name": "Dependency Diagram", "description": "Diagram showing table dependencies"},
        {"value": "diagram_hierarchical", "name": "Hierarchical Diagram", "description": "Diagram showing parent/child relationships"}
    ]

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
