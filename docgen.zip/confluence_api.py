import requests
import json
from requests.auth import HTTPBasicAuth
from datetime import datetime
import config

class ConfluenceAPI:
    def __init__(self):
        self.base_url = config.CONFLUENCE_BASE_URL
        self.auth = HTTPBasicAuth(config.CONFLUENCE_EMAIL, config.CONFLUENCE_API_TOKEN)
        self.headers = {"Content-Type": "application/json", "Accept": "application/json"}
    
    def get_all_spaces(self):
        """Get all spaces accessible to the user"""
        url = f"{self.base_url}/space"
        try:
            response = requests.get(url, auth=self.auth, headers=self.headers, verify=False)
            if response.status_code == 200:
                return response.json()["results"]
            else:
                print(f"Error getting spaces: {response.status_code}")
                return []
        except Exception as e:
            print(f"Exception getting spaces: {e}")
            return []
    
    def get_all_pages(self, space_key, limit=100):
        """Get all pages in a space with pagination"""
        start = 0
        all_pages = []
        
        while True:
            url = f"{self.base_url}/content?spaceKey={space_key}&limit={limit}&start={start}&expand=version"
            try:
                response = requests.get(url, auth=self.auth, headers=self.headers, verify=False)
                
                if response.status_code == 200:
                    data = response.json()
                    pages = data.get("results", [])
                    all_pages.extend(pages)
                    
                    # Check if there are more pages
                    if len(pages) < limit or not data.get("_links", {}).get("next"):
                        break
                    start += limit
                else:
                    print(f"Error getting pages: {response.status_code}")
                    break
            except Exception as e:
                print(f"Exception getting pages: {e}")
                break
        
        return all_pages
    
    def get_page_content(self, page_id):
        """Get full page content with body"""
        url = f"{self.base_url}/content/{page_id}?expand=body.storage,version"
        try:
            response = requests.get(url, auth=self.auth, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error getting page content: {response.status_code}")
                return None
        except Exception as e:
            print(f"Exception getting page content: {e}")
            return None
    
    def create_page(self, space_key, title, content, parent_id=None):
        """Create a new page"""
        url = f"{self.base_url}/content"
        
        payload = {
            "type": "page",
            "title": title,
            "space": {"key": space_key},
            "body": {
                "storage": {
                    "value": content,
                    "representation": "storage"
                }
            }
        }
        
        if parent_id:
            payload["ancestors"] = [{"id": parent_id}]
        
        try:
            response = requests.post(url, json=payload, auth=self.auth, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error creating page: {response.status_code}")
                print(f"Response: {response.text}")
                return None
        except Exception as e:
            print(f"Exception creating page: {e}")
            return None
    
    def update_page(self, page_id, title, content):
        """Update an existing page"""
        # First get current page to get version number
        current_page = self.get_page_content(page_id)
        if not current_page:
            return None
        
        url = f"{self.base_url}/content/{page_id}"
        new_version = current_page["version"]["number"] + 1
        
        payload = {
            "id": page_id,
            "type": "page",
            "title": title,
            "version": {"number": new_version},
            "body": {
                "storage": {
                    "value": content,
                    "representation": "storage"
                }
            }
        }
        
        try:
            response = requests.put(url, json=payload, auth=self.auth, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error updating page: {response.status_code}")
                print(f"Response: {response.text}")
                return None
        except Exception as e:
            print(f"Exception updating page: {e}")
            return None
    
    def delete_page(self, page_id):
        """Delete a page"""
        url = f"{self.base_url}/content/{page_id}"
        try:
            response = requests.delete(url, auth=self.auth, headers=self.headers, verify=False)
            
            if response.status_code == 204:
                return True
            else:
                print(f"Error deleting page: {response.status_code}")
                return False
        except Exception as e:
            print(f"Exception deleting page: {e}")
            return False
