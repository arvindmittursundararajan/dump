/**
 * AeroOptima.ai - What-If Analysis Module
 * Handles generation and visualization of what-if scenarios
 */

// Global variables
let currentIncident = null;
let currentScenarios = [];
let scenarioCharts = {};
let selectedScenarioId = null;

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Setup event listeners
    setupEventListeners();
    
    // Initialize UI components
    updateSliderLabels();
});

/**
 * Setup event listeners for UI components
 */
function setupEventListeners() {
    // Incident selection
    const incidentSelect = document.getElementById('incident-select');
    if (incidentSelect) {
        incidentSelect.addEventListener('change', function() {
            const incidentId = this.value;
            if (incidentId) {
                loadIncidentDetails(incidentId);
                document.getElementById('generate-scenarios').disabled = false;
            } else {
                hideIncidentDetails();
                document.getElementById('generate-scenarios').disabled = true;
            }
        });
    }
    
    // Parameter sliders
    const sliders = [
        { id: 'delay-minutes', valueId: 'delay-value', suffix: '' },
        { id: 'um-count', valueId: 'um-value', suffix: '' },
        { id: 'aircraft-availability', valueId: 'aircraft-value', suffix: '%' },
        { id: 'crew-availability', valueId: 'crew-value', suffix: '%' },
        { id: 'weather-severity', valueId: 'weather-value', transform: weatherValueToText }
    ];
    
    sliders.forEach(slider => {
        const element = document.getElementById(slider.id);
        if (element) {
            element.addEventListener('input', function() {
                updateSliderValue(slider.id, slider.valueId, slider.suffix, slider.transform);
            });
        }
    });
    
    // Generate scenarios button
    const generateButton = document.getElementById('generate-scenarios');
    if (generateButton) {
        generateButton.addEventListener('click', generateScenarios);
    }
    
    // Reset button
    const resetButton = document.getElementById('reset-whatif');
    if (resetButton) {
        resetButton.addEventListener('click', resetWhatIf);
    }
}

/**
 * Update the displayed value for a slider
 * @param {string} sliderId - ID of the slider element
 * @param {string} valueId - ID of the element to display the value
 * @param {string} suffix - Optional suffix to add to the value
 * @param {Function} transform - Optional function to transform the value
 */
function updateSliderValue(sliderId, valueId, suffix = '', transform = null) {
    const slider = document.getElementById(sliderId);
    const valueElement = document.getElementById(valueId);
    
    if (slider && valueElement) {
        let value = slider.value;
        if (transform) {
            value = transform(value);
        } else {
            value = value + suffix;
        }
        valueElement.textContent = value;
    }
}

/**
 * Convert weather severity value to text
 * @param {number} value - Weather severity value (0-5)
 * @returns {string} Weather severity text
 */
function weatherValueToText(value) {
    const weatherTexts = ['Clear', 'Light', 'Moderate', 'Heavy', 'Severe', 'Extreme'];
    return weatherTexts[value] || 'Unknown';
}

/**
 * Update all slider labels
 */
function updateSliderLabels() {
    updateSliderValue('delay-minutes', 'delay-value');
    updateSliderValue('um-count', 'um-value');
    updateSliderValue('aircraft-availability', 'aircraft-value', '%');
    updateSliderValue('crew-availability', 'crew-value', '%');
    updateSliderValue('weather-severity', 'weather-value', '', weatherValueToText);
}

/**
 * Load incident details
 * @param {number} incidentId - ID of the incident
 */
function loadIncidentDetails(incidentId) {
    // Show loading
    document.getElementById('incident-details').classList.add('d-none');
    
    // Load incident details via AJAX
    fetch(`/api/incidents/${incidentId}`)
        .then(response => response.json())
        .then(data => {
            // Store current incident
            currentIncident = data;
            
            // Update UI
            document.getElementById('incident-category').textContent = data.category;
            document.getElementById('incident-start-time').textContent = new Date(data.start_time).toLocaleString();
            document.getElementById('incident-root-cause').textContent = data.root_cause || 'Not available';
            
            // Show incident details
            document.getElementById('incident-details').classList.remove('d-none');
        })
        .catch(error => {
            console.error('Error loading incident details:', error);
            showToast('Failed to load incident details', 'danger');
        });
}

/**
 * Hide incident details
 */
function hideIncidentDetails() {
    document.getElementById('incident-details').classList.add('d-none');
    currentIncident = null;
}

/**
 * Generate what-if scenarios
 */
function generateScenarios() {
    if (!currentIncident) {
        showToast('Please select an incident first', 'warning');
        return;
    }
    
    // Get parameters
    const params = {
        incident_id: currentIncident.id,
        delay_minutes: parseInt(document.getElementById('delay-minutes').value),
        um_count: parseInt(document.getElementById('um-count').value),
        aircraft_availability: parseInt(document.getElementById('aircraft-availability').value),
        crew_availability: parseInt(document.getElementById('crew-availability').value),
        weather_severity: parseInt(document.getElementById('weather-severity').value)
    };
    
    // Show loading
    const generateButton = document.getElementById('generate-scenarios');
    const originalBtnText = generateButton.innerHTML;
    generateButton.disabled = true;
    generateButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
    
    // Generate scenarios via AJAX
    fetch('/api/whatif/scenarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    })
        .then(response => response.json())
        .then(data => {
            // Reset button
            generateButton.disabled = false;
            generateButton.innerHTML = originalBtnText;
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Store scenarios
            currentScenarios = data.scenarios;
            
            // Display scenarios
            displayScenarios(currentScenarios);
        })
        .catch(error => {
            // Reset button
            generateButton.disabled = false;
            generateButton.innerHTML = originalBtnText;
            
            console.error('Error generating scenarios:', error);
            showToast('Failed to generate scenarios: ' + error.message, 'danger');
        });
}

/**
 * Display scenarios
 * @param {Array} scenarios - Array of scenario objects
 */
function displayScenarios(scenarios) {
    if (!scenarios || !scenarios.length) {
        showToast('No scenarios generated', 'warning');
        return;
    }
    
    // Get containers
    const tabsContainer = document.getElementById('scenarios-tabs');
    const contentContainer = document.getElementById('scenarios-content');
    
    // Clear containers
    tabsContainer.innerHTML = '';
    contentContainer.innerHTML = '';
    
    // Create tabs and content for each scenario
    scenarios.forEach((scenario, index) => {
        const scenarioId = `scenario-${index}`;
        const isActive = index === 0;
        
        // Create tab
        const tab = document.createElement('li');
        tab.className = 'nav-item';
        tab.innerHTML = `
            <a class="nav-link ${isActive ? 'active' : ''}" id="${scenarioId}-tab" data-bs-toggle="tab" href="#${scenarioId}" role="tab">
                ${scenario.name || `Scenario ${index + 1}`}
            </a>
        `;
        tabsContainer.appendChild(tab);
        
        // Create content
        const content = document.createElement('div');
        content.className = `tab-pane fade ${isActive ? 'show active' : ''}`;
        content.id = scenarioId;
        content.setAttribute('role', 'tabpanel');
        
        // Build content HTML
        content.innerHTML = `
            <div class="mb-3">
                <h5>${scenario.name || `Scenario ${index + 1}`}</h5>
                <p>${scenario.description || 'No description available'}</p>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-tasks me-2"></i> Actions
                        </div>
                        <div class="card-body">
                            <ol class="mb-0">
                                ${scenario.actions ? scenario.actions.map(action => `<li>${action}</li>`).join('') : '<li>No actions specified</li>'}
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-chart-line me-2"></i> Expected Outcomes
                        </div>
                        <div class="card-body">
                            <ul class="mb-0">
                                ${scenario.expected_outcomes ? scenario.expected_outcomes.map(outcome => `<li>${outcome}</li>`).join('') : '<li>No outcomes specified</li>'}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-sliders-h me-2"></i> Constraints
                </div>
                <div class="card-body">
                    <div class="row">
                        ${renderConstraints(scenario.constraints)}
                    </div>
                </div>
            </div>
            
            <div class="d-flex">
                <button class="btn btn-primary me-2" onclick="visualizeScenario(${index})">
                    <i class="fas fa-project-diagram me-2"></i> Visualize
                </button>
                <button class="btn btn-outline-primary me-2" onclick="simulateScenario(${index})">
                    <i class="fas fa-play me-2"></i> Simulate
                </button>
            </div>
        `;
        
        contentContainer.appendChild(content);
    });
    
    // Show scenarios container, hide placeholder
    document.getElementById('scenarios-container').classList.remove('d-none');
    document.getElementById('scenarios-placeholder').classList.add('d-none');
    
    // Select first scenario
    if (scenarios.length > 0) {
        selectedScenarioId = 0;
        visualizeScenario(0);
    }
}

/**
 * Render constraints HTML
 * @param {Object} constraints - Constraints object
 * @returns {string} HTML string
 */
function renderConstraints(constraints) {
    if (!constraints) {
        return '<div class="col-12">No constraints specified</div>';
    }
    
    const constraintItems = [
        { key: 'delay_tolerance', label: 'Delay Tolerance', format: value => `${value} minutes` },
        { key: 'crew_requirements', label: 'Additional Crew', format: value => value ? 'Required' : 'Not required' },
        { key: 'aircraft_changes', label: 'Aircraft Swaps', format: value => value ? 'Required' : 'Not required' },
        { key: 'passenger_impact', label: 'Affected Passengers', format: value => value },
        { key: 'um_handling', label: 'UM Special Handling', format: value => value ? 'Required' : 'Not required' }
    ];
    
    return constraintItems.map(item => {
        const value = constraints[item.key];
        if (value === undefined) return '';
        
        return `
            <div class="col-md-4 mb-2">
                <div class="d-flex justify-content-between">
                    <span>${item.label}:</span>
                    <span class="fw-bold">${item.format(value)}</span>
                </div>
            </div>
        `;
    }).join('');
}

/**
 * Visualize a scenario
 * @param {number} index - Index of the scenario in currentScenarios array
 */
function visualizeScenario(index) {
    const scenario = currentScenarios[index];
    if (!scenario) return;
    
    selectedScenarioId = index;
    
    // Show loading
    const container = document.getElementById('visualization-container');
    container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-3">Generating visualization...</p></div>';
    container.classList.remove('d-none');
    document.getElementById('visualization-placeholder').classList.add('d-none');
    
    // Generate visualization via AJAX
    fetch('/api/whatif/visualize', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ scenario: scenario })
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Render diagram
            container.innerHTML = `<div class="mermaid-container"><div class="mermaid">${data.diagram}</div></div>`;
            
            // Initialize mermaid
            if (window.mermaid) {
                try {
                    // Reset mermaid to clear any previous configurations
                    if (window.mermaid.mermaidAPI && window.mermaid.mermaidAPI.reset) {
                        window.mermaid.mermaidAPI.reset();
                    }
                    
                    // Configure mermaid with version 9.4.3 compatible settings
                    window.mermaid.initialize({
                        startOnLoad: false,
                        theme: 'neutral',
                        securityLevel: 'loose',
                        logLevel: 'error',
                        flowchart: {
                            htmlLabels: true,
                            curve: 'linear',
                            useMaxWidth: true,
                            nodeSpacing: 50,
                            rankSpacing: 50
                        }
                    });
                    
                    // Render the diagram
                    window.mermaid.init(undefined, container.querySelector('.mermaid'));
                } catch (error) {
                    console.error('Mermaid visualization error:', error);
                    container.innerHTML = `
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i> Error rendering diagram: ${error.message}
                        </div>
                    `;
                }
            } else {
                console.warn('Mermaid library not loaded');
                container.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i> Mermaid library not loaded. Cannot render diagram.
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error visualizing scenario:', error);
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i> Failed to generate visualization: ${error.message}
                </div>
            `;
        });
}

/**
 * Simulate a scenario and display metrics
 * @param {number} index - Index of the scenario in currentScenarios array
 */
function simulateScenario(index) {
    const scenario = currentScenarios[index];
    if (!scenario) return;
    
    selectedScenarioId = index;
    
    // Show loading for metrics
    const container = document.getElementById('metrics-container');
    container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><p class="mt-3">Simulating scenario...</p></div>';
    container.classList.remove('d-none');
    document.getElementById('metrics-placeholder').classList.add('d-none');
    
    // Simulate scenario via AJAX
    fetch('/api/whatif/simulate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ scenario: scenario })
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Display metrics
            displayMetrics(data, scenario.name || `Scenario ${index + 1}`);
        })
        .catch(error => {
            console.error('Error simulating scenario:', error);
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i> Failed to simulate scenario: ${error.message}
                </div>
            `;
        });
}

/**
 * Display metrics for a scenario
 * @param {Object} data - Metrics data
 * @param {string} scenarioName - Name of the scenario
 */
function displayMetrics(data, scenarioName) {
    const container = document.getElementById('metrics-container');
    
    // Create metrics containers
    container.innerHTML = `
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Passenger Impact</div>
                    <div class="card-body">
                        <canvas id="passenger-impact-chart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Operational Impact</div>
                    <div class="card-body">
                        <canvas id="operational-impact-chart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Cost Impact</div>
                    <div class="card-body">
                        <canvas id="cost-impact-chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-header">
                <i class="fas fa-check-circle me-2"></i> Optimization Score
            </div>
            <div class="card-body">
                <div class="progress">
                    <div class="progress-bar ${getScoreColorClass(data.score)}" role="progressbar" style="width: ${data.score * 100}%">
                        ${Math.round(data.score * 100)}%
                    </div>
                </div>
                <div class="text-center mt-2">
                    <small class="text-muted">Execution time: ${data.execution_time.toFixed(2)} seconds</small>
                </div>
            </div>
        </div>
    `;
    
    // Create charts
    createPassengerImpactChart(data.metrics.passenger_impact, scenarioName);
    createOperationalImpactChart(data.metrics.operational_impact, scenarioName);
    createCostImpactChart(data.metrics.cost_impact, scenarioName);
}

/**
 * Create passenger impact chart
 * @param {Object} data - Passenger impact data
 * @param {string} scenarioName - Name of the scenario
 */
function createPassengerImpactChart(data, scenarioName) {
    const ctx = document.getElementById('passenger-impact-chart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (scenarioCharts.passengerImpact) {
        scenarioCharts.passengerImpact.destroy();
    }
    
    // Create new chart
    scenarioCharts.passengerImpact = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Stranded Passengers', 'UM Impact', 'Missed Connections'],
            datasets: [{
                label: scenarioName,
                data: [data.stranded_passengers, data.um_impact, data.missed_connections],
                backgroundColor: 'rgba(77, 208, 225, 0.7)',
                borderColor: 'rgba(77, 208, 225, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * Create operational impact chart
 * @param {Object} data - Operational impact data
 * @param {string} scenarioName - Name of the scenario
 */
function createOperationalImpactChart(data, scenarioName) {
    const ctx = document.getElementById('operational-impact-chart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (scenarioCharts.operationalImpact) {
        scenarioCharts.operationalImpact.destroy();
    }
    
    // Create new chart
    scenarioCharts.operationalImpact = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Delay (mins)', 'Cancellations', 'Aircraft Swaps'],
            datasets: [{
                label: scenarioName,
                data: [data.total_delay_minutes, data.cancellations, data.aircraft_swaps],
                backgroundColor: 'rgba(255, 159, 64, 0.7)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * Create cost impact chart
 * @param {Object} data - Cost impact data
 * @param {string} scenarioName - Name of the scenario
 */
function createCostImpactChart(data, scenarioName) {
    const ctx = document.getElementById('cost-impact-chart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (scenarioCharts.costImpact) {
        scenarioCharts.costImpact.destroy();
    }
    
    // Create new chart
    scenarioCharts.costImpact = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Delay Cost', 'Compensation', 'Crew Overtime'],
            datasets: [{
                label: scenarioName,
                data: [data.delay_cost, data.passenger_compensation, data.crew_overtime],
                backgroundColor: 'rgba(153, 102, 255, 0.7)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * Get Bootstrap color class based on score
 * @param {number} score - Score value (0-1)
 * @returns {string} Bootstrap color class
 */
function getScoreColorClass(score) {
    if (score >= 0.8) return 'bg-success';
    if (score >= 0.6) return 'bg-info';
    if (score >= 0.4) return 'bg-warning';
    return 'bg-danger';
}

/**
 * Reset the What-If analysis
 */
function resetWhatIf() {
    // Reset incident selection
    document.getElementById('incident-select').value = '';
    hideIncidentDetails();
    
    // Reset parameters
    document.getElementById('delay-minutes').value = 30;
    document.getElementById('um-count').value = 0;
    document.getElementById('aircraft-availability').value = 100;
    document.getElementById('crew-availability').value = 100;
    document.getElementById('weather-severity').value = 0;
    updateSliderLabels();
    
    // Reset scenarios
    document.getElementById('scenarios-container').classList.add('d-none');
    document.getElementById('scenarios-placeholder').classList.remove('d-none');
    
    // Reset visualization
    document.getElementById('visualization-container').classList.add('d-none');
    document.getElementById('visualization-placeholder').classList.remove('d-none');
    
    // Reset metrics
    document.getElementById('metrics-container').classList.add('d-none');
    document.getElementById('metrics-placeholder').classList.remove('d-none');
    
    // Reset state
    currentIncident = null;
    currentScenarios = [];
    selectedScenarioId = null;
    
    // Destroy charts
    Object.values(scenarioCharts).forEach(chart => {
        if (chart) chart.destroy();
    });
    scenarioCharts = {};
    
    // Disable generate button
    document.getElementById('generate-scenarios').disabled = true;
}

/**
 * Show a toast message
 * @param {string} message - Message to display
 * @param {string} type - Type of message (success, danger, warning, info)
 */
function showToast(message, type = 'info') {
    // Check if toast container exists, create if not
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'position-fixed top-0 end-0 p-3';
        toastContainer.style.zIndex = '1050';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.id = toastId;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toast);
    
    // Initialize and show toast
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: 5000
    });
    bsToast.show();
}