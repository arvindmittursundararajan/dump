// Ingest page JavaScript

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize file upload functionality
    initializeFileUpload();
    
    // Load machines for the selection dropdown
    loadMachines();
    
    // Set up machine selection change event
    setupMachineChangeEvent();
});

// Initialize file upload functionality
function initializeFileUpload() {
    const fileInput = document.getElementById('csv-file');
    const uploadForm = document.getElementById('upload-form');
    const fileNameDisplay = document.getElementById('selected-file');

    // Show file name when selected via file input
    if (fileInput && fileNameDisplay) {
        fileInput.addEventListener('change', function() {
            if (fileInput.files && fileInput.files.length > 0) {
                fileNameDisplay.textContent = 'Selected file: ' + fileInput.files[0].name;
            } else {
                fileNameDisplay.textContent = 'Selected file: No file selected';
            }
        });
    }

    // Handle form submission
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            // Check if file input exists
            if (!fileInput) {
                showMessage('File input not found. Please reload the page.', 'error');
                return;
            }
            // Check if a file is selected
            if (!fileInput.files || fileInput.files.length === 0) {
                showMessage('Please select a file to upload.', 'error');
                return;
            }
            // Check if machine is selected
            const machineId = document.getElementById('machine-select').value;
            if (!machineId) {
                showMessage('Please select a device or machine.', 'error');
                return;
            }
            // Create form data
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            formData.append('machine_id', machineId);
            // Add part ID if selected
            const partId = document.getElementById('part-select').value;
            if (partId) {
                formData.append('part_id', partId);
            }
            // Show loading state
            showLoadingState();
            // Upload the file
            fetch('/api/upload-sensor-data', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                hideLoadingState();
                if (data.success) {
                    showMessage(`Successfully processed ${data.count} records.`, 'success');
                    // Reset only the file input and file name display
                    fileInput.value = '';
                    fileNameDisplay.textContent = 'Selected file: No file selected';
                    // Optionally reset the part select
                    const partSelect = document.getElementById('part-select');
                    if (partSelect) {
                        partSelect.value = '';
                    }
                    // Refresh the page to update all UI and state
                    setTimeout(() => { window.location.reload(); }, 1000);
                } else {
                    showMessage(`Error: ${data.message}`, 'error');
                }
            })
            .catch(error => {
                hideLoadingState();
                console.error('Error uploading file:', error);
                showMessage('An error occurred while uploading the file.', 'error');
            });
        });
    }
}

// Load machines for dropdown
function loadMachines() {
    const machineSelect = document.getElementById('machine-select');
    
    if (!machineSelect) return;
    
    // Show loading state
    machineSelect.innerHTML = '<option value="">Loading machines...</option>';
    
    // Fetch machines from API
    fetch('/api/machines')
        .then(response => response.json())
        .then(data => {
            machineSelect.innerHTML = '<option value="">Select a machine</option>';
            
            data.forEach(machine => {
                const option = document.createElement('option');
                option.value = machine.id;
                option.textContent = machine.name;
                machineSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading machines:', error);
            machineSelect.innerHTML = '<option value="">Failed to load machines</option>';
        });
}

// Setup machine change event to load parts
function setupMachineChangeEvent() {
    const machineSelect = document.getElementById('machine-select');
    const partSelect = document.getElementById('part-select');
    
    if (!machineSelect || !partSelect) return;
    
    machineSelect.addEventListener('change', function() {
        const machineId = this.value;
        
        // Clear and disable part select if no machine is selected
        if (!machineId) {
            partSelect.innerHTML = '<option value="">Select a machine first</option>';
            partSelect.disabled = true;
            return;
        }
        
        // Show loading state
        partSelect.innerHTML = '<option value="">Loading parts...</option>';
        partSelect.disabled = true;
        
        // Fetch parts for the selected machine
        fetch(`/api/machine/${machineId}/parts`)
            .then(response => response.json())
            .then(data => {
                partSelect.innerHTML = '<option value="">All parts (machine level)</option>';
                
                data.forEach(part => {
                    const option = document.createElement('option');
                    option.value = part.id;
                    option.textContent = part.name;
                    partSelect.appendChild(option);
                });
                
                partSelect.disabled = false;
            })
            .catch(error => {
                console.error('Error loading parts:', error);
                partSelect.innerHTML = '<option value="">Failed to load parts</option>';
                partSelect.disabled = true;
            });
    });
}

// Show a message to the user
function showMessage(message, type) {
    const messageElement = document.getElementById('message-container');
    
    if (!messageElement) return;
    
    // Create alert element
    const alertElement = document.createElement('div');
    alertElement.className = `alert alert-${type === 'error' ? 'danger' : 'success'} alert-dismissible fade show`;
    alertElement.role = 'alert';
    
    // Add message text
    alertElement.textContent = message;
    
    // Add dismiss button
    const dismissButton = document.createElement('button');
    dismissButton.type = 'button';
    dismissButton.className = 'close';
    dismissButton.setAttribute('data-dismiss', 'alert');
    dismissButton.setAttribute('aria-label', 'Close');
    dismissButton.innerHTML = '<span aria-hidden="true">&times;</span>';
    
    alertElement.appendChild(dismissButton);
    
    // Clear existing messages
    messageElement.innerHTML = '';
    
    // Add the new message
    messageElement.appendChild(alertElement);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertElement.classList.remove('show');
        setTimeout(() => alertElement.remove(), 500);
    }, 5000);
}

// Show loading state during file upload
function showLoadingState() {
    const submitButton = document.querySelector('#upload-form button[type="submit"]');
    const loadingIndicator = document.getElementById('loading-indicator');
    
    if (submitButton) {
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
    }
    
    if (loadingIndicator) {
        loadingIndicator.style.display = 'block';
    }
}

// Hide loading state after file upload
function hideLoadingState() {
    const submitButton = document.querySelector('#upload-form button[type="submit"]');
    const loadingIndicator = document.getElementById('loading-indicator');
    
    if (submitButton) {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Upload Data';
    }
    
    if (loadingIndicator) {
        loadingIndicator.style.display = 'none';
    }
}

// Display the sample CSV structure
function showSampleCsv() {
    const sampleData = [
        ['timestamp', 'sensor_type', 'value', 'unit'],
        ['2023-07-01 08:00:00', 'temperature', '72.5', '°C'],
        ['2023-07-01 08:15:00', 'temperature', '73.2', '°C'],
        ['2023-07-01 08:30:00', 'pressure', '95.7', 'PSI'],
        ['2023-07-01 08:45:00', 'vibration', '3.2', 'mm/s']
    ];
    
    let sampleHtml = '<table class="table table-sm table-bordered">';
    sampleData.forEach((row, index) => {
        sampleHtml += '<tr>';
        row.forEach(cell => {
            if (index === 0) {
                sampleHtml += `<th>${cell}</th>`;
            } else {
                sampleHtml += `<td>${cell}</td>`;
            }
        });
        sampleHtml += '</tr>';
    });
    sampleHtml += '</table>';
    
    document.getElementById('sample-csv-container').innerHTML = sampleHtml;
}
