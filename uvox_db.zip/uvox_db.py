import sqlite3
import logging
from config import DATABASE_PATH

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Core database functions
def get_connection():
    """Create a connection to the SQLite database"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        logger.error(f"Database connection error: {e}")
        return None

def execute_query(query, params=()):
    """Execute a simple SELECT query and return results"""
    try:
        conn = get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchall()
    except sqlite3.Error as e:
        logger.error(f"Database query error: {e}")
        return None
    finally:
        if conn:
            conn.close()

# Simple table queries
def get_products():
    """Get all products"""
    return execute_query("SELECT * FROM product")

def get_categories():
    """Get all categories"""
    return execute_query("SELECT * FROM category")

def get_customers():
    """Get all customers"""
    return execute_query("SELECT * FROM customer")

def get_suppliers():
    """Get all suppliers"""
    return execute_query("SELECT * FROM supplier")

def get_stores():
    """Get all stores"""
    return execute_query("SELECT * FROM store")

def get_table_info():
    """Get detailed information about all tables"""
    info = {}
    tables = {
        'product': get_products(),
        'category': get_categories(),
        'customer': get_customers(),
        'supplier': get_suppliers(),
        'store': get_stores()
    }
    
    conn = get_connection()
    if not conn:
        return None
        
    try:
        cursor = conn.cursor()
        
        for table_name, data in tables.items():
            # Get column names
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = [column[1] for column in cursor.fetchall()]
            
            # Get sample data
            rows = []
            if data:
                for row in data:
                    rows.append(dict(row))
            
            info[table_name] = {
                'columns': columns,
                'sample_data': rows
            }
            
        return info
    except sqlite3.Error as e:
        logger.error(f"Error getting table info: {e}")
        return None
    finally:
        conn.close()

def process_inventory_query(query_text):
    """Process inventory queries using basic SELECT * queries without filters"""
    query_lower = query_text.lower()
    result = {"query": query_text, "found": False, "data": None, "message": ""}
    
    try:
        # Map keywords to table queries using direct SELECT *
        if "product" in query_lower:
            data = get_products()  # Using direct SELECT *
            table = "products"
        elif "category" in query_lower:
            data = get_categories()  # Using direct SELECT *
            table = "categories"
        elif "customer" in query_lower:
            data = get_customers()  # Using direct SELECT *
            table = "customers"
        elif "supplier" in query_lower:
            data = get_suppliers()  # Using direct SELECT *
            table = "suppliers"
        elif "store" in query_lower:
            data = get_stores()  # Using direct SELECT *
            table = "stores"
        else:
            # Default to products if no specific table mentioned
            data = get_products()  # Using direct SELECT *
            table = "products"

        if data:
            # Convert all rows to dictionaries with complete raw data
            data_dicts = [dict(row) for row in data]
            result["found"] = True
            result["data"] = data_dicts
            result["data_type"] = table
            
            # Include count in message
            result["message"] = f"Found {len(data_dicts)} records in {table} table"
            
            # If looking for specific item, include all its raw data
            if table == "products":
                search_words = query_lower.split()
                for product in data_dicts:
                    name = product.get('name', '').lower()
                    for word in search_words:
                        if len(word) > 3 and word in name:
                            fields = []
                            for key, value in product.items():
                                fields.append(f"{key}: {value}")
                            result["message"] = "Found product with raw data: " + " | ".join(fields)
                            break
                    
        return result
            
    except Exception as e:
        logger.exception(f"Error processing query: {e}")
        return {
            "query": query_text,
            "found": False,
            "error": str(e),
            "message": "Sorry, there was an error processing your query."
        }
