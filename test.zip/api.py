import requests
import re
from prompts import recommendation_prompt, rewrite_prompt

API_KEY = "AIzaSyDk2FHPTQq67n0IDELgqxI798hdWxff9k4"
ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

def get_recommendations_and_rewrite(content, additional_points=None, selected_recommendations=None):
    headers = {
        "Content-Type": "application/json",
        "X-goog-api-key": API_KEY
    }
    if selected_recommendations is None:
        prompt = recommendation_prompt(content)
        data = {
            "contents": [
                {"parts": [{"text": prompt}]}
            ]
        }
        resp = requests.post(ENDPOINT, headers=headers, json=data)
        resp.raise_for_status()
        ideas = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
        items = re.findall(r"\d+\.\s+(.*?)(?=\n\d+\.|$)", ideas, re.DOTALL)
        if not items:
            items = [line.strip() for line in ideas.split("\n") if re.match(r"^\d+\. ", line.strip())]
            items = [re.sub(r"^\d+\.\s*", "", item) for item in items]
        return items
    else:
        prompt = rewrite_prompt(content, selected_recommendations, additional_points)
        data = {
            "contents": [
                {"parts": [{"text": prompt}]}
            ]
        }
        resp = requests.post(ENDPOINT, headers=headers, json=data)
        resp.raise_for_status()
        html = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
        match = re.search(r"(<html[\s\S]*?</html>)", html, re.IGNORECASE)
        if match:
            html = match.group(1)
        else:
            match = re.search(r"(<body[\s\S]*?</body>)", html, re.IGNORECASE)
            if match:
                html = f"<html>{match.group(1)}</html>"
            else:
                html = html.strip()
        return html 