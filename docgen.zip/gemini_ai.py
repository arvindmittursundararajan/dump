import requests
import json
import config

class GeminiAI:
    def __init__(self):
        self.api_key = config.GEMINI_API_KEY
        self.url = config.GEMINI_URL
    
    def analyze_documentation(self, content, style_guides):
        """Analyze documentation against style guides"""
        headers = {
            'Content-Type': 'application/json',
            'X-goog-api-key': self.api_key
        }
        
        style_guide_text = "\n".join([f"- {guide}: {desc}" for guide, desc in style_guides.items()])
        
        prompt = f"""
Analyze the following developer documentation against these style guide criteria:

{style_guide_text}

Documentation content:
{content}

Please identify specific gaps and issues in the documentation. For each issue found, provide:
1. The issue type (clarity, completeness, code_examples, structure, terminology, or accessibility)
2. A brief description of the problem (plain text, no markdown)
3. The specific text or section that has the issue
4. A suggested improvement with proper HTML formatting for display

Format your response as a JSON array with objects containing:
- type: string (one of: clarity, completeness, code_examples, structure, terminology, accessibility)
- title: string (short descriptive title for the issue)
- description: string (brief description of the problem)
- problematic_text: string (the problematic text found)
- suggestion: string (HTML-formatted suggested improvement with proper tags like <p>, <code>, <pre>, <a>, etc.)
- severity: string (one of: high, medium, low)

Return only the JSON array with no markdown formatting, code blocks, or additional text.
The suggestions should include proper HTML tags for better display.
"""
        
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt
                        }
                    ]
                }
            ]
        }
        
        try:
            response = requests.post(self.url, headers=headers, json=payload, verify=False)
            if response.status_code == 200:
                result = response.json()
                if 'candidates' in result and len(result['candidates']) > 0:
                    analysis_text = result['candidates'][0]['content']['parts'][0]['text']
                    # Try to parse as JSON
                    try:
                        # Clean the response text to extract JSON
                        analysis_text = analysis_text.strip()
                        
                        # Remove common markdown artifacts
                        if analysis_text.startswith('```json'):
                            analysis_text = analysis_text[7:]
                        elif analysis_text.startswith('```'):
                            analysis_text = analysis_text[3:]
                            
                        if analysis_text.endswith('```'):
                            analysis_text = analysis_text[:-3]
                            
                        analysis_text = analysis_text.strip()
                        
                        # Parse JSON
                        result = json.loads(analysis_text)
                        
                        # Validate structure
                        if isinstance(result, list):
                            return result
                        else:
                            print("Analysis result is not a list, wrapping in array")
                            return [result] if isinstance(result, dict) else []
                            
                    except json.JSONDecodeError as e:
                        print(f"JSON parsing failed: {e}")
                        print(f"Raw text: {analysis_text[:200]}...")
                        # Return empty array if JSON parsing fails
                        return []
                else:
                    return []
            else:
                print(f"Error calling Gemini API for analysis: {response.status_code}")
                return []
        except Exception as e:
            print(f"Exception calling Gemini API for analysis: {e}")
            return []
    
    def generate_rewriting_options(self, content):
        """Generate LLM-powered rewriting options based on content"""
        headers = {
            'Content-Type': 'application/json',
            'X-goog-api-key': self.api_key
        }
        
        prompt = f"""
Analyze the following developer documentation and suggest specific improvement options:

{content}

Based on the content, generate 4-6 specific rewriting options that would improve this documentation. 
Each option should be actionable and relevant to the content.

Format your response as a JSON array with objects containing: id, label, description

Examples of good options:
- Add missing error handling examples
- Include API response examples  
- Add step-by-step installation guide
- Explain configuration options in detail
- Add troubleshooting section for common issues
- Include performance considerations

Return only the JSON array, no additional text.
"""
        
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt
                        }
                    ]
                }
            ]
        }
        
        try:
            response = requests.post(self.url, headers=headers, json=payload, verify=False)
            if response.status_code == 200:
                result = response.json()
                if 'candidates' in result and len(result['candidates']) > 0:
                    options_text = result['candidates'][0]['content']['parts'][0]['text']
                    try:
                        # Clean the response text to extract JSON
                        options_text = options_text.strip()
                        if options_text.startswith('```json'):
                            options_text = options_text[7:]
                        if options_text.endswith('```'):
                            options_text = options_text[:-3]
                        options_text = options_text.strip()
                        
                        return json.loads(options_text)
                    except json.JSONDecodeError:
                        # Return default options if parsing fails
                        return config.REWRITING_OPTIONS
                else:
                    return config.REWRITING_OPTIONS
            else:
                print(f"Error generating rewriting options: {response.status_code}")
                return config.REWRITING_OPTIONS
        except Exception as e:
            print(f"Exception generating rewriting options: {e}")
            return config.REWRITING_OPTIONS
    
    def rewrite_content(self, content, selected_options, tone, length_option, custom_instruction=""):
        """Rewrite content based on user selections"""
        headers = {
            'Content-Type': 'application/json',
            'X-goog-api-key': self.api_key
        }
        
        options_text = "\n".join([f"- {opt}" for opt in selected_options])
        tone_instruction = f"Use a {tone} tone throughout the documentation."
        length_instruction = f"Target length: {length_option['description']} ({length_option['words']} words)."
        
        prompt = f"""
Rewrite the following developer documentation with these specific improvements:

{options_text}

Style requirements:
- {tone_instruction}
- {length_instruction}
- Maintain technical accuracy
- Use clear, actionable language
- Include proper HTML formatting for web display
- Ensure the content is well-structured with appropriate headings

{custom_instruction}

Original content:
{content}

Please rewrite the content incorporating all the requested improvements. 
Return ONLY clean HTML content without any markdown code blocks, backticks, or additional explanations.
Do not include ```html or ``` or any other formatting markers.
Start directly with the HTML content.
"""
        
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt
                        }
                    ]
                }
            ]
        }
        
        try:
            response = requests.post(self.url, headers=headers, json=payload, verify=False)
            response.raise_for_status()  # Raise exception for bad status codes
            
            if response.status_code == 200:
                result = response.json()
                if 'candidates' in result and len(result['candidates']) > 0:
                    candidate = result['candidates'][0]
                    if 'content' in candidate and 'parts' in candidate['content']:
                        rewritten_text = candidate['content']['parts'][0]['text']
                        if rewritten_text and rewritten_text.strip():
                            return rewritten_text.strip()
                
                print("No valid content generated by Gemini")
                return f"<p>Unable to rewrite content. Original content:</p>{content}"
            else:
                print(f"Error calling Gemini API for rewriting: {response.status_code}")
                print(f"Response: {response.text}")
                return f"<p>API Error (Status {response.status_code}). Original content:</p>{content}"
                
        except requests.exceptions.RequestException as e:
            print(f"Request exception calling Gemini API: {e}")
            return f"<p>Network error occurred. Original content:</p>{content}"
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}")
            return f"<p>Invalid response format. Original content:</p>{content}"
        except Exception as e:
            print(f"Unexpected exception calling Gemini API for rewriting: {e}")
            return f"<p>Unexpected error: {str(e)}. Original content:</p>{content}"
