import requests
import re
import os
import json
import logging
from flask import current_app

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def clean_text(text, is_mermaid=False):
    """
    Clean text from formatting, markdown, or other unwanted characters
    
    Args:
        text (str): The text to clean
        is_mermaid (bool): If True, preserve newlines and structure for Mermaid diagrams
        
    Returns:
        str: Cleaned text
    """
    # Check if this is a Mermaid diagram request
    if is_mermaid or 'graph ' in text or 'flowchart ' in text or 'gantt ' in text or 'sequenceDiagram' in text:
        # Special cleaning for Mermaid diagrams
        # First, extract the diagram if it's inside a code block
        mermaid_match = re.search(r'```(?:mermaid)?\s*([\s\S]*?)```', text)
        if mermaid_match:
            text = mermaid_match.group(1).strip()
        
        # Remove any remaining markdown formatting but preserve structure
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Bold
        text = re.sub(r'\*(.*?)\*', r'\1', text)      # Italic
        text = re.sub(r'`([^`]*)`', r'\1', text)      # Inline code
        
        # Handle graph/flowchart directive issues
        if not re.search(r'^(?:graph|flowchart)\s+(?:TD|TB|BT|RL|LR)', text, re.MULTILINE):
            graph_match = re.search(r'(?:graph|flowchart)\s+(?:TD|TB|BT|RL|LR)', text)
            if graph_match:
                # Extract from the graph declaration
                start_pos = graph_match.start()
                text = text[start_pos:]
            else:
                # No valid graph directive found, add one
                text = "graph TD\n" + text
        
        return text.strip()
    else:
        # Standard text cleaning
        # Remove markdown formatting
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Bold
        text = re.sub(r'\*(.*?)\*', r'\1', text)      # Italic
        text = re.sub(r'```.*?\n', '', text)          # Code block start
        text = re.sub(r'```', '', text)               # Code block end
        # Clean extra spaces
        return re.sub(r'\s+', ' ', text.strip())

def get_gemini_response(prompt):
    """Get a response from the Gemini API"""
    try:
        # Get API key - use the one provided
        api_key = "AIzaSyBPjMxcjqCa59PgX9vl8UehpP0nmIsR9Zo"
        
        # More stable endpoint - use gemini-1.5-flash for better compatibility
        api_url = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent"
        
        # Add API key to URL 
        url = f"{api_url}?key={api_key}"
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        # Simple data structure
        data = {
            "contents": [
                {
                    "parts": [{"text": prompt}]
                }
            ],
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 2048
            }
        }
        
        # Log the API call
        logger.info(f"Calling Gemini API with prompt: {prompt[:100]}...")
        
        # Make the request with a timeout
        response = requests.post(url, headers=headers, json=data, timeout=15)
        
        # Log the raw response for debugging
        logger.info(f"Gemini API response status: {response.status_code}")
        logger.info(f"Gemini API response first 100 chars: {response.text[:100]}...")
        
        # Check for success
        if response.status_code == 200:
            try:
                # Parse the JSON response
                response_json = response.json()
                
                # Extract the content
                if 'candidates' in response_json and response_json['candidates']:
                    content = response_json['candidates'][0]['content']['parts'][0]['text']
                    return clean_text(content)
                else:
                    # Handle blocked content or error
                    logger.warning("No candidates in Gemini response")
                    if 'promptFeedback' in response_json:
                        reason = response_json['promptFeedback'].get('blockReason', 'Unknown')
                        return f"The request was blocked. Reason: {reason}"
                    return "No response generated. Please try a different prompt."
                    
            except (json.JSONDecodeError, KeyError) as err:
                # Handle JSON errors
                logger.error(f"Error parsing Gemini response: {str(err)}")
                return "Error: Unable to parse the Gemini API response. Please try again."
        else:
            # Handle API error responses
            logger.error(f"Gemini API error: {response.status_code} - {response.text}")
            return f"Gemini API Error: {response.status_code}. Please try again later."
    
    except Exception as e:
        # Handle all other exceptions
        logger.exception(f"Error calling Gemini API: {str(e)}")
        return "Sorry, there was an error connecting to the Gemini API. Please try again later."

def chat_with_gemini(conversation_history, user_input):
    """Chat with Gemini API maintaining conversation history"""
    try:
        # Get API key - use the one provided
        api_key = "AIzaSyBPjMxcjqCa59PgX9vl8UehpP0nmIsR9Zo"
        
        # More stable endpoint - use gemini-1.5-flash for better compatibility
        api_url = "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent"
        
        # Add API key to URL 
        url = f"{api_url}?key={api_key}"
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        # Format the history in the right structure
        formatted_history = []
        for entry in conversation_history:
            role = entry.get("role", "user")
            content = entry.get("content", "")
            formatted_history.append({
                "role": role,
                "parts": [{"text": content}]
            })
        
        # Add the current user message
        formatted_history.append({
            "role": "user",
            "parts": [{"text": user_input}]
        })
        
        # Prepare the request
        data = {
            "contents": formatted_history,
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 2048
            }
        }
        
        # Log the request
        logger.info(f"Calling Gemini Chat API with {len(formatted_history)} messages")
        
        # Make the request
        response = requests.post(url, headers=headers, json=data, timeout=15)
        
        # Log the raw response for debugging
        logger.info(f"Gemini Chat API response status: {response.status_code}")
        logger.info(f"Gemini Chat API response first 100 chars: {response.text[:100]}...")
        
        # Check for success
        if response.status_code == 200:
            try:
                # Parse the JSON response
                response_json = response.json()
                
                # Extract the content
                if 'candidates' in response_json and response_json['candidates']:
                    content = response_json['candidates'][0]['content']['parts'][0]['text']
                    return clean_text(content)
                else:
                    # Handle blocked content
                    logger.warning("No candidates in Gemini chat response")
                    if 'promptFeedback' in response_json:
                        reason = response_json['promptFeedback'].get('blockReason', 'Unknown')
                        return f"The chat request was blocked. Reason: {reason}"
                    return "No response generated. Please try a different question."
                    
            except (json.JSONDecodeError, KeyError) as err:
                # Handle JSON errors
                logger.error(f"Error parsing Gemini chat response: {str(err)}")
                return "Error: Unable to parse the Gemini API response for chat. Please try again."
        else:
            # Handle API error responses
            logger.error(f"Gemini Chat API error: {response.status_code} - {response.text}")
            return f"Gemini API Error: {response.status_code}. Please try again later."
    
    except Exception as e:
        # Handle all other exceptions
        logger.exception(f"Error calling Gemini Chat API: {str(e)}")
        return "Sorry, there was an error connecting to the Gemini API for chat. Please try again later."
