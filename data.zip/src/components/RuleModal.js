import React, { useState } from 'react';
import Modal from './Modal';
import { Box, Button, TextField, Select, MenuItem, FormControl, InputLabel, Checkbox, FormControlLabel, Grid, Typography, CircularProgress } from '@mui/material';
import apiService from '../api';

const RuleModal = ({ isOpen, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    ruleName: '',
    ruleDescription: '',
    ruleType: '',
    ruleCategory: '',
    ruleSeverity: '',
    ruleQuery: '',
    ruleActive: true
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await apiService.createRule({
        name: formData.ruleName,
        description: formData.ruleDescription,
        type: formData.ruleType,
        category: formData.ruleCategory,
        severity: formData.ruleSeverity,
        query: formData.ruleQuery,
        active: formData.ruleActive
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err) {
      setError('Failed to create rule.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create Custom Rule" size="modal-lg">
      <Box component="form" onSubmit={handleSubmit} sx={{ p: 2 }}>
        {/* Basic Information */}
        <Typography variant="h6" sx={{ mb: 2 }}>Basic Information</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Rule Name *"
              name="ruleName"
              value={formData.ruleName}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Description"
              name="ruleDescription"
              value={formData.ruleDescription}
              onChange={handleInputChange}
              fullWidth
            />
          </Grid>
        </Grid>
        {/* Rule Configuration */}
        <Typography variant="h6" sx={{ mb: 2 }}>Rule Configuration</Typography>
        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Rule Type *</InputLabel>
              <Select
                label="Rule Type *"
                name="ruleType"
                value={formData.ruleType}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select rule type</MenuItem>
                <MenuItem value="validation">Data Validation</MenuItem>
                <MenuItem value="completeness">Completeness Check</MenuItem>
                <MenuItem value="consistency">Consistency Check</MenuItem>
                <MenuItem value="accuracy">Accuracy Check</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Category *</InputLabel>
              <Select
                label="Category *"
                name="ruleCategory"
                value={formData.ruleCategory}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select category</MenuItem>
                <MenuItem value="data_quality">Data Quality</MenuItem>
                <MenuItem value="compliance">Compliance</MenuItem>
                <MenuItem value="business">Business Rules</MenuItem>
                <MenuItem value="technical">Technical</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth required sx={{ minWidth: 480 }}>
              <InputLabel>Severity *</InputLabel>
              <Select
                label="Severity *"
                name="ruleSeverity"
                value={formData.ruleSeverity}
                onChange={handleInputChange}
              >
                <MenuItem value="">Select severity</MenuItem>
                <MenuItem value="low">Low</MenuItem>
                <MenuItem value="medium">Medium</MenuItem>
                <MenuItem value="high">High</MenuItem>
                <MenuItem value="critical">Critical</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        {/* SQL Query */}
        <Typography variant="h6" sx={{ mb: 2 }}>SQL Query</Typography>
        <TextField
          label="SQL Query *"
          name="ruleQuery"
          value={formData.ruleQuery}
          onChange={handleInputChange}
          required
          fullWidth
          multiline
          rows={6}
          placeholder="Enter your SQL query here..."
          sx={{ mb: 1 }}
        />
        <Typography variant="caption" color="text.secondary" sx={{ mb: 2, display: 'block' }}>
          Write a SQL query that returns rows when the rule is violated
        </Typography>
        {/* Status */}
        <FormControlLabel
          control={
            <Checkbox
              name="ruleActive"
              checked={formData.ruleActive}
              onChange={handleInputChange}
            />
          }
          label="Active"
          sx={{ mb: 2 }}
        />
        {error && <Typography color="error" sx={{ mb: 2 }}>{error}</Typography>}
        {/* Form Actions */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button variant="outlined" color="secondary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button variant="contained" color="primary" type="submit" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Create Rule'}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default RuleModal; 