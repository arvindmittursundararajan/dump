import os

# Gemini API Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyBPjMxcjqCa59PgX9vl8UehpP0nmIsR9Zo")
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Application Configuration
APP_NAME = "AeroOptima.ai"
APP_VERSION = "1.0.0"

# UI Configuration
UI_COLORS = {
    "primary": "#0f1a2b",    # Midnight blue
    "secondary": "#33475b",   # Steel gray
    "accent": "#4dd0e1",      # Sky cyan
    "alert_red": "#FF6B6B",   # Alert red
    "success_green": "#4CAF50", # Success green
    "text": "#FFFFFF",        # White text
    "background": "#F8F9FA",  # Cloud white
}

# Data Quality Thresholds
DATA_QUALITY_THRESHOLDS = {
    "accuracy": 0.95,
    "completeness": 0.90,
    "consistency": 0.95,
    "uniqueness": 0.99,
    "validity": 0.95,
    "timeliness": 0.90,
}

# Alert Severity Levels
ALERT_LEVELS = {
    "critical": {"color": "danger", "threshold": 0.8},
    "warning": {"color": "warning", "threshold": 0.5},
    "info": {"color": "info", "threshold": 0.2},
}

# Data Categories and Sources
DATA_CATEGORIES = [
    {
        "name": "Crew Schedules",
        "sources": [
            "Crew Rosters",
            "Crew Qualifications",
            "Crew Duty and Rest Rules",
            "Crew Bidding and Scheduling",
            "Crew Training Records",
            "Crew Seniority and Preferences",
            "Crew Productivity Metrics",
            "Crew Disruption History"
        ]
    },
    {
        "name": "Aircraft Operations",
        "sources": [
            "Fleet Information",
            "Maintenance Records",
            "Aircraft Utilization",
            "Aircraft Availability",
            "Modification Plans",
            "Fuel Consumption Data",
            "Performance Metrics",
            "Leasing Records"
        ]
    },
    {
        "name": "Flight Schedules",
        "sources": [
            "Flight Schedules",
            "Codeshare Agreements",
            "Fare and Pricing Data",
            "Passenger Demand Forecasts",
            "Revenue Management",
            "Market Competition Data",
            "Regulatory Information",
            "Seasonal Demand Patterns"
        ]
    },
    {
        "name": "Station Operations",
        "sources": [
            "Airport Capacity",
            "Ground Handling Resources",
            "Airport Slot Allocations",
            "Passenger Flows",
            "Facility Maintenance",
            "Ground Transportation",
            "Performance Metrics",
            "Weather Impacts"
        ]
    },
    {
        "name": "Passenger Data",
        "sources": [
            "Passenger Bookings",
            "Passenger Profiles",
            "Disruption History",
            "Satisfaction Data",
            "Loyalty Data",
            "Ancillary Revenue",
            "Demographic Data",
            "Digital Engagement"
        ]
    },
    {
        "name": "Maintenance",
        "sources": [
            "Maintenance Schedules",
            "Facility Capacity",
            "Parts Inventory",
            "Regulatory Requirements",
            "Vendor Data",
            "Cost Optimization",
            "Condition Monitoring",
            "Disruption Data"
        ]
    },
    {
        "name": "OCC Monitoring",
        "sources": [
            "Flight Tracking",
            "IROP Alerts",
            "Decision Records",
            "Incident Reports",
            "Response Times",
            "Recovery Cost Data",
            "Reassignment Strategies",
            "Rebooking Workflows"
        ]
    },
    {
        "name": "Weather Data",
        "sources": [
            "Weather Forecasts",
            "Historical Patterns",
            "Operational Impact",
            "Disruption Data",
            "Risk Modeling",
            "Meteorological Data",
            "Environmental Factors",
            "Impact Assessment"
        ]
    },
    {
        "name": "Regulatory Compliance",
        "sources": [
            "Safety Regulations",
            "Crew Duty Regulations",
            "Slot Regulations",
            "Environmental Regulations",
            "Passenger Rights",
            "Interline Agreements",
            "Emissions Standards",
            "Airworthiness Requirements"
        ]
    }
]

# Optimization Parameters
OPTIMIZATION_WEIGHTS = {
    "cost": 0.25,
    "on_time_performance": 0.25,
    "crew_legality": 0.2,
    "passenger_impact": 0.15,
    "maintenance_compliance": 0.15,
}

# Rule Engine Configuration
RULE_ENGINE_CONFIG = {
    "max_rules": 100,
    "evaluation_interval": 5,  # minutes
    "default_threshold": 0.7,
}
