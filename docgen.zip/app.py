import os
import logging
from flask import Flask
from models import db, DocumentVersion

# Configure logging
logging.basicConfig(level=logging.DEBUG)

def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///docgen.db")
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    db.init_app(app)
    with app.app_context():
        db.create_all()
    return app

app = create_app()

from routes import *

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
