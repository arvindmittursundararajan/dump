import React, { useState, useEffect } from 'react';
import apiService from '../api';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import CircularProgress from '@mui/material/CircularProgress';
import Fade from '@mui/material/Fade';
import Slide from '@mui/material/Slide';

// Solid red spinner CSS (Standard & Poor red)
const solidRedSpinnerStyle = {
  width: 64,
  height: 64,
  border: '8px solid #d32f2f',
  borderTop: '8px solid #fff',
  borderRadius: '50%',
  animation: 'solid-spin 0.8s linear infinite',
  margin: '0 auto',
  boxShadow: '0 0 16px 4px #d32f2f',
};

const solidSpinnerKeyframes = `
@keyframes solid-spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
@keyframes slide-in {
  0% { opacity: 0; transform: translateX(100%); }
  100% { opacity: 1; transform: translateX(0); }
}
@keyframes slide-out {
  0% { opacity: 1; transform: translateX(0); }
  100% { opacity: 0; transform: translateX(-100%); }
}
`;

// Animated progress story component
function ProgressStory({ messages }) {
  const [index, setIndex] = React.useState(0);
  const [slideOut, setSlideOut] = React.useState(false);
  React.useEffect(() => {
    if (!messages || messages.length === 0) return;
    setSlideOut(false);
    const timer = setTimeout(() => setSlideOut(true), 1800);
    const next = setTimeout(() => {
      setIndex((i) => (i + 1) % messages.length);
      setSlideOut(false);
    }, 2000);
    return () => { clearTimeout(timer); clearTimeout(next); };
  }, [index, messages]);
  if (!messages || messages.length === 0) return null;
  return (
    <div style={{ minHeight: 32, position: 'relative', width: '100%', overflow: 'hidden' }}>
      <div
        key={index}
        style={{
          position: 'absolute',
          width: '100%',
          color: '#d32f2f',
          fontWeight: 600,
          fontSize: '1.1rem',
          letterSpacing: 1,
          whiteSpace: 'nowrap',
          animation: slideOut
            ? 'slide-out 0.3s forwards'
            : 'slide-in 0.4s',
        }}
      >
        {messages[index]}
      </div>
    </div>
  );
}

function isLikelyHtml(str) {
  if (!str || typeof str !== 'string') return false;
  return str.trim().startsWith('<') || str.includes('<html') || str.includes('<body');
}

// Translate backend log messages to simple English
function translateLog(msg) {
  if (msg.includes('Loading Table Data')) return 'Loading table data...';
  if (msg.includes('Loading') && msg.includes('as DataFrame')) return 'Loading table: ' + msg.split('Loading ')[1].replace(' as DataFrame...', '');
  if (msg.includes('Building ToT Tree')) return 'Building the analysis tree...';
  if (msg.startsWith('Built tree for table')) return 'Prepared table: ' + msg.split(': ')[1];
  if (msg.startsWith('Analyzed chunk:')) return 'Analyzed a chunk of data.';
  if (msg.startsWith('Aggregated table:')) return 'Summarized table: ' + msg.split(': ')[1];
  if (msg.startsWith('Aggregated database root')) return 'Summarized all tables.';
  if (msg.includes('Compiling ToT Results')) return 'Compiling final results...';
  return msg;
}

// Icon for each progress message type
function getProgressIcon(msg) {
  if (msg.includes('Loading Table Data')) return '📋';
  if (msg.includes('Loading') && msg.includes('as DataFrame')) return '📊';
  if (msg.includes('Building ToT Tree')) return '🌳';
  if (msg.startsWith('Built tree for table')) return '🌲';
  if (msg.startsWith('Analyzed chunk:')) return '🧩';
  if (msg.startsWith('Aggregated table:')) return '📦';
  if (msg.startsWith('Aggregated database root')) return '🗃️';
  if (msg.includes('Compiling ToT Results')) return '📊';
  return '🔄';
}

// Fun animated placeholder messages for loader (short, punchy, professional)
const funPlaceholders = [
  "Powering clarity, every day.",
  "Insights that move markets.",
  "Decisions, driven by data.",
  "Transparency fuels progress.",
  "Opportunity in every trend.",
  "Precision. Perspective. Progress.",
  "Analysis in action.",
  "Clarity for every challenge.",
  "Transforming data to insight.",
  "Preparing analysis...",
  // Humorous and light-hearted
  "It will take more time for longer tables.",
  "Get a coffee whilst we do the analysis.",
  "Crunching numbers, please wait...",
  "Big data, big patience!",
  "Optimizing insights, stay tuned.",
  "Your data is in good hands.",
  "Almost there, don't blink!",
  "Analyzing like a pro...",
  "Good things take time!",
  "We love long tables!",
];

function AnimatedPlaceholder() {
  const [index, setIndex] = React.useState(0);
  const [slideOut, setSlideOut] = React.useState(false);
  React.useEffect(() => {
    setSlideOut(false);
    const timer = setTimeout(() => setSlideOut(true), 1700);
    const next = setTimeout(() => {
      setIndex((i) => (i + 1) % funPlaceholders.length);
      setSlideOut(false);
    }, 2000);
    return () => { clearTimeout(timer); clearTimeout(next); };
  }, [index]);
  return (
    <div style={{ minHeight: 28, position: 'relative', width: '100%', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <img src="/img/evaluation_16678222.gif" alt="insight" style={{ height: 32, marginRight: 10, verticalAlign: 'middle' }} />
      <div
        key={index}
        style={{
          display: 'inline-block',
          color: '#d32f2f',
          fontWeight: 500,
          fontSize: '0.98rem',
          letterSpacing: 0.5,
          whiteSpace: 'normal',
          wordBreak: 'break-word',
          animation: slideOut
            ? 'slide-out 0.3s forwards'
            : 'slide-in 0.4s',
          background: '#fff',
          borderRadius: 6,
          padding: '2px 10px',
        }}
      >
        {funPlaceholders[index]}
      </div>
    </div>
  );
}

// Add a CountdownTimer component
function CountdownTimer({ seconds }) {
  // Show only in minutes: 5m+, 3m+, 2m+, 1m+, then stay at 1m+
  const [timeLeft, setTimeLeft] = useState(seconds);
  useEffect(() => {
    if (timeLeft <= 60) return; // Stop at 1 minute for hazy effect
    const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft]);
  if (seconds <= 0) return null;
  let display = '';
  if (timeLeft > 240) {
    display = 'Estimated time left: 5m+';
  } else if (timeLeft > 120) {
    display = 'Estimated time left: 3m+';
  } else if (timeLeft > 60) {
    display = 'Estimated time left: 2m+';
  } else {
    display = 'Estimated time left: 1m+';
  }
  return (
    <div style={{ fontSize: '1.1rem', color: '#d32f2f', fontWeight: 600, marginBottom: 8, textAlign: 'center' }}>
      {display}
    </div>
  );
}

// Add a helper to check if a string is HTML
function isHtml(str) {
  return /<[a-z][\s\S]*>/i.test(str);
}

// Add a helper to clean table name lines from HTML string
function cleanHtmlString(htmlString) {
  // Remove lines that are just table names (e.g., samples.tpch.supplier)
  return htmlString.replace(/^[a-zA-Z0-9_.]+\s*$/gm, '');
}

const Analysis = ({
  tierCounts,
  dummyDatasets,
  handleTierClick,
  TableIcon,
  DataTable,
  showJobModal,
  setShowJobModal,
  showRuleModal,
  setShowRuleModal,
  isLoading,
  error
}) => {
  // State for catalogs, schemas, tables, selection, analysis
  const [catalogs, setCatalogs] = useState([]);
  const [schemas, setSchemas] = useState([]);
  const [tables, setTables] = useState([]);
  const [selectedCatalog, setSelectedCatalog] = useState('');
  const [selectedSchema, setSelectedSchema] = useState('');
  const [selectedTable, setSelectedTable] = useState('');
  const [selectedTables, setSelectedTables] = useState([]);
  const [analysisType, setAnalysisType] = useState('');
  const [customRules, setCustomRules] = useState([]);
  const [sqlQuery, setSqlQuery] = useState('');
  const [analysisResult, setAnalysisResult] = useState('');
  const [loadingCatalogs, setLoadingCatalogs] = useState(false);
  const [loadingSchemas, setLoadingSchemas] = useState(false);
  const [loadingTables, setLoadingTables] = useState(false);
  const [runningAnalysis, setRunningAnalysis] = useState(false);
  const [formError, setFormError] = useState(null);
  const [progressLog, setProgressLog] = useState([]);

  // Animation control for section reveal
  const [showSchema, setShowSchema] = useState(false);
  const [showTable, setShowTable] = useState(false);
  useEffect(() => {
    if (selectedCatalog) {
      setTimeout(() => setShowSchema(true), 350);
    } else {
      setShowSchema(false);
      setShowTable(false);
    }
  }, [selectedCatalog]);
  useEffect(() => {
    if (selectedSchema) {
      setTimeout(() => setShowTable(true), 350);
    } else {
      setShowTable(false);
    }
  }, [selectedSchema]);

  // Fetch catalogs on mount
  useEffect(() => {
    fetchCatalogs();
  }, []);

  const fetchCatalogs = async () => {
    setLoadingCatalogs(true);
    try {
      const data = await apiService.getCatalogs();
      setCatalogs(data.catalogs || data || []);
    } catch (err) {
      setFormError('Failed to load catalogs.');
    } finally {
      setLoadingCatalogs(false);
    }
  };

  const fetchSchemas = async (catalog) => {
    setLoadingSchemas(true);
    try {
      const data = await apiService.getSchemas(catalog);
      setSchemas(data.schemas || data || []);
    } catch (err) {
      setFormError('Failed to load schemas.');
    } finally {
      setLoadingSchemas(false);
    }
  };

  const fetchTables = async (catalog, schema) => {
    setLoadingTables(true);
    try {
      const data = await apiService.getTables(catalog, schema);
      setTables(data.tables || data || []);
    } catch (err) {
      setFormError('Failed to load tables.');
    } finally {
      setLoadingTables(false);
    }
  };

  // Handlers for dropdowns
  const handleCatalogChange = (e) => {
    const value = e.target.value;
    setSelectedCatalog(value);
    setSelectedSchema('');
    setSelectedTable('');
    setSchemas([]);
    setTables([]);
    if (value) fetchSchemas(value);
  };
  const handleSchemaChange = (e) => {
    const value = e.target.value;
    setSelectedSchema(value);
    setSelectedTable('');
    setTables([]);
    if (selectedCatalog && value) fetchTables(selectedCatalog, value);
  };
  const handleTableChange = (e) => {
    setSelectedTable(e.target.value);
  };

  // Add table to selection
  const handleAddTable = () => {
    if (selectedCatalog && selectedSchema && selectedTable) {
      const fullName = `${selectedCatalog}.${selectedSchema}.${selectedTable}`;
      if (!selectedTables.some(t => t.fullName === fullName)) {
        setSelectedTables([...selectedTables, {
          catalog: selectedCatalog,
          schema: selectedSchema,
          name: selectedTable,
          fullName
        }]);
      }
    }
  };
  // Remove table from selection
  const handleRemoveTable = (fullName) => {
    setSelectedTables(selectedTables.filter(t => t.fullName !== fullName));
  };
  // Clear selection
  const handleClearSelection = () => {
    setSelectedTables([]);
  };

  // Run analysis
  const handleRunAnalysis = async () => {
    setRunningAnalysis(true);
    setFormError(null);
    setAnalysisResult('');
    setProgressLog([]);
    try {
      // Debug print
      console.log('Selected tables:', selectedTables);
      const requestData = {
        selected_tables: selectedTables.map(table => ({
          catalog: table.catalog,
          schema_name: table.schema || table.schema_name, // always send schema_name
          name: table.name,
          full_name: table.fullName || table.full_name
        })),
        analysis_type: analysisType,
        sql_query: sqlQuery
      };
      console.log('Request data sent to backend:', requestData);
      const result = await apiService.runAnalysis(selectedTables, analysisType, sqlQuery);
      setAnalysisResult(result);
      // If backend returns progress_log, show it
      if (result && result.results && result.results.progress_log) {
        setProgressLog(result.results.progress_log);
      }
    } catch (err) {
      setFormError('Failed to run analysis.');
    } finally {
      setRunningAnalysis(false);
    }
  };

  // 1. Update compactControlSx for left panel to use fontSize: '0.90rem'
  const compactControlSx = { fontSize: '0.90rem', minHeight: 32, padding: '4px 10px', fontWeight: 500, borderRadius: 2 };

  let estTime = 0;
  if (analysisResult && analysisResult.results && analysisResult.results.dataset_summary) {
    const match = analysisResult.results.dataset_summary.match(/Estimated analysis time: (\d+) seconds/);
    if (match) estTime = parseInt(match[1], 10);
  }

  // Calculate a 'bloated' estimated time (in seconds) based on tables/columns
  let bloatedEstTime = 0;
  if (analysisResult && analysisResult.results && analysisResult.results.dataset_summary) {
    // Use the same logic as backend, but bloat it for UI
    const match = analysisResult.results.dataset_summary.match(/Dataset contains (\d+) tables, (\d+) columns/);
    if (match) {
      const numTables = parseInt(match[1], 10);
      const numColumns = parseInt(match[2], 10);
      // Bloat: 5m+ for >20 cols, 4m+ for >15, 3m+ for >10, 2m+ for >5, 1m+ for <=5
      if (numColumns > 20) bloatedEstTime = 300;
      else if (numColumns > 15) bloatedEstTime = 240;
      else if (numColumns > 10) bloatedEstTime = 180;
      else if (numColumns > 5) bloatedEstTime = 120;
      else bloatedEstTime = 60;
    }
  }
  // If runningAnalysis is false, show 'Done!'
  const loaderTimeDisplay = !runningAnalysis ? 'Done!' : (
    bloatedEstTime > 240 ? 'Estimated time left: 5m+' :
    bloatedEstTime > 180 ? 'Estimated time left: 4m+' :
    bloatedEstTime > 120 ? 'Estimated time left: 3m+' :
    bloatedEstTime > 60 ? 'Estimated time left: 2m+' :
    bloatedEstTime > 0 ? 'Estimated time left: 1m+' : ''
  );

  return (
    <Box sx={{ px: { xs: 1, md: 4 }, py: 4 }}>
      {/* Solid spinner keyframes */}
      <style>{solidSpinnerKeyframes}</style>
      {runningAnalysis && (
        <Box sx={{
          position: 'fixed',
          top: 0, left: 0, width: '100vw', height: '100vh',
          bgcolor: 'rgba(0,0,0,0.6)',
          zIndex: 2000,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={solidRedSpinnerStyle}></div>
          <Typography variant="h5" sx={{ color: '#fff', mt: 3, mb: 2, fontWeight: 'bold', letterSpacing: 1 }}>
            Analyzing your data...
          </Typography>
          {/* Loader overlay: only show the image once with the animated placeholder */}
          <Box sx={{ bgcolor: '#fff', borderRadius: 2, p: 3, minWidth: 420, maxWidth: 700, boxShadow: 4, maxHeight: 320, overflowY: 'auto', mt: 2 }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: '100%' }}>
              {/* Show bloated estimated time or Done! */}
              <Typography sx={{ fontSize: '1.1rem', color: '#d32f2f', fontWeight: 600, mb: 1, textAlign: 'center' }}>{loaderTimeDisplay}</Typography>
                <AnimatedPlaceholder />
            </Box>
            {progressLog.length > 0 ? (
              progressLog.map((msg, idx) => (
                <Box key={idx} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <span style={{ fontSize: 22, marginRight: 10 }}>{getProgressIcon(msg)}</span>
                  <Typography sx={{ color: '#d32f2f', fontWeight: 500, fontSize: '0.95rem', letterSpacing: 0.3, whiteSpace: 'normal', wordBreak: 'break-word', width: '100%' }}>
                    {translateLog(msg)}
                  </Typography>
                </Box>
              ))
            ) : null}
          </Box>
        </Box>
      )}
      {/* Custom flex layout for side panel and main area */}
      <Box sx={{ display: 'flex', flexDirection: 'row', width: '100%', gap: 4, alignItems: 'flex-start', flexWrap: 'nowrap' }}>
        {/* Schema Selection Panel (left, 18%) */}
        <Box sx={{ width: '28%', minWidth: 180, maxWidth: 340, flexShrink: 0 }}>
          <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
            <svg className="icon" viewBox="0 0 24 24" fill="currentColor" style={{ marginRight: 8, verticalAlign: 'middle' }}><path d="M12 2C6.48 2 2 4.02 2 6.5v11C2 19.98 6.48 22 12 22s10-2.02 10-4.5v-11C22 4.02 17.52 2 12 2zM12 20c-4.42 0-8-1.79-8-4v-1.07c2.05 1.87 5.16 3.07 8 3.07s5.95-1.2 8-3.07V16c0 2.21-3.58 4-8 4zm0-6c-4.42 0-8-1.79-8-4v-1.07c2.05 1.87 5.16 3.07 8 3.07s5.95-1.2 8-3.07V10c0 2.21-3.58 4-8 4z" /></svg>
            Table Select
          </Typography>
          {(error || formError) && (
            <Box sx={{ mb: 2 }}>
              <Typography color="error" variant="body2">{error || formError}</Typography>
            </Box>
          )}
          {isLoading || loadingCatalogs ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 120 }}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              {/* Catalog Dropdown */}
              <Card sx={{ mb: 2, border: selectedCatalog ? '2px solid #d32f2f' : '2px solid #eee', transition: 'border 0.3s' }}>
                <CardHeader title={<span style={{ display: 'flex', alignItems: 'center', fontSize: '0.92rem', fontWeight: 500 }}>Catalog {loadingCatalogs && <CircularProgress size={16} sx={{ ml: 1 }} />}</span>} sx={{ pb: 0 }} />
                <CardContent>
                  <FormControl fullWidth sx={{ mb: 2 }}>
                    <InputLabel sx={{ fontSize: '0.90rem' }}>Catalog</InputLabel>
                    <Select label="Catalog" value={selectedCatalog} onChange={handleCatalogChange} sx={compactControlSx}>
                      <MenuItem value="" sx={compactControlSx}>Select a catalog</MenuItem>
                      {catalogs.map((c) => (
                        <MenuItem key={c} value={c} sx={compactControlSx}>{c}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </CardContent>
              </Card>
              {/* Schema Dropdown (animated) */}
              <Fade in={showSchema} timeout={600} unmountOnExit>
                <div>
                  <Card sx={{ mb: 2, border: selectedSchema ? '2px solid #d32f2f' : '2px solid #eee', transition: 'border 0.3s' }}>
                    <CardHeader title={<span style={{ display: 'flex', alignItems: 'center', fontSize: '0.92rem', fontWeight: 500 }}>Schema {loadingSchemas && <CircularProgress size={16} sx={{ ml: 1 }} />}</span>} sx={{ pb: 0 }} />
                    <CardContent>
                      <FormControl fullWidth sx={{ mb: 2 }} disabled={!selectedCatalog || loadingSchemas}>
                        <InputLabel sx={{ fontSize: '0.90rem' }}>Schema</InputLabel>
                        <Select label="Schema" value={selectedSchema} onChange={handleSchemaChange} sx={compactControlSx}>
                          <MenuItem value="" sx={compactControlSx}>Select a schema</MenuItem>
                          {schemas.map((s) => (
                            <MenuItem key={s} value={s} sx={compactControlSx}>{s}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </CardContent>
                  </Card>
                </div>
              </Fade>
              {/* Table Dropdown (animated) */}
              <Fade in={showTable} timeout={600} unmountOnExit>
                <div>
                  <Card sx={{ mb: 2, border: selectedTable ? '2px solid #d32f2f' : '2px solid #eee', transition: 'border 0.3s' }}>
                    <CardHeader title={<span style={{ display: 'flex', alignItems: 'center', fontSize: '0.92rem', fontWeight: 500 }}>Table {loadingTables && <CircularProgress size={16} sx={{ ml: 1 }} />}</span>} sx={{ pb: 0 }} />
                    <CardContent>
                      <FormControl fullWidth sx={{ mb: 2 }} disabled={!selectedSchema || loadingTables}>
                        <InputLabel sx={{ fontSize: '0.90rem' }}>Table</InputLabel>
                        <Select label="Table" value={selectedTable} onChange={handleTableChange} sx={compactControlSx}>
                          <MenuItem value="" sx={compactControlSx}>Select a table</MenuItem>
                          {tables.map((t) => (
                            <MenuItem key={t} value={t} sx={compactControlSx}>{t}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                      <Button variant="contained" fullWidth onClick={handleAddTable} disabled={!selectedTable} sx={{ ...compactControlSx, '&:hover': { backgroundColor: '#d32f2f', color: '#fff' } }}>Add Table to Selection</Button>
                    </CardContent>
                  </Card>
                </div>
              </Fade>
              {/* Selected Tables Card */}
              <Card sx={{ mb: 2 }}>
                <CardHeader title={<span style={{ color: '#d32f2f', fontSize: '0.90rem', fontWeight: 600 }}>Selected Tables</span>} sx={{ pb: 0 }} />
                <CardContent>
                  {selectedTables.length === 0 ? (
                    <Box sx={{ textAlign: 'center', mb: 2 }}>
                      {TableIcon && <TableIcon />}
                      <img src="/img/data-collection_19002128.gif" alt="No tables selected" style={{ width: 120, margin: '0 auto' }} />
                      <Typography variant="body2" color="text.secondary">No tables selected. Use the form above to select tables for analysis.</Typography>
                    </Box>
                  ) : (
                    <Box sx={{ overflowY: 'auto', maxHeight: 180, maxWidth: '100%' }}>
                      {selectedTables.map((t) => (
                        <Box key={t.fullName} sx={{ display: 'flex', alignItems: 'center', mb: 1, minWidth: 0 }}>
                          <Typography sx={{ flex: 1, minWidth: 0, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '0.90rem' }}>{t.fullName}</Typography>
                          <Button size="small" color="error" onClick={() => handleRemoveTable(t.fullName)} sx={{ ...compactControlSx, '&:hover': { backgroundColor: '#d32f2f', color: '#fff' } }}>Remove</Button>
                        </Box>
                      ))}
                    </Box>
                  )}
                  <Button variant="outlined" color="secondary" fullWidth onClick={handleClearSelection} disabled={selectedTables.length === 0} sx={{ ...compactControlSx, '&:hover': { backgroundColor: '#d32f2f', color: '#fff' } }}>Clear Selection</Button>
                </CardContent>
              </Card>
              {/* Analysis Options Card */}
              <Card sx={{ ...compactControlSx, mb: 2, border: selectedTables.length === 0 || !analysisType ? '2px solid #eee' : '2px solid #d32f2f', transition: 'border 0.3s' }}>
                <CardHeader title={<span style={{ color: '#d32f2f', fontSize: '0.90rem', fontWeight: 600 }}>Analysis Options</span>} sx={{ pb: 0 }} />
                <CardContent>
                  <FormControl fullWidth sx={{ mb: 2 }}>
                    <InputLabel sx={{ fontSize: '0.90rem' }}>Analysis Type</InputLabel>
                    <Select label="Analysis Type" value={analysisType} onChange={e => setAnalysisType(e.target.value)} sx={compactControlSx}>
                      <MenuItem value="" sx={compactControlSx}>Select analysis type</MenuItem>
                      <MenuItem value="general" sx={compactControlSx}>General Analysis</MenuItem>
                      <MenuItem value="performance" sx={compactControlSx}>Performance Analysis</MenuItem>
                      <MenuItem value="normalization" sx={compactControlSx}>Normalization</MenuItem>
                      <MenuItem value="relationships" sx={compactControlSx}>Relationships</MenuItem>
                      <MenuItem value="naming" sx={compactControlSx}>Naming Conventions</MenuItem>
                      <MenuItem value="standards" sx={compactControlSx}>Standards Compliance</MenuItem>
                      <MenuItem value="denormalization" sx={compactControlSx}>Denormalization</MenuItem>
                      <MenuItem value="data_quality" sx={compactControlSx}>Data Quality</MenuItem>
                      <MenuItem value="security" sx={compactControlSx}>Security & Privacy</MenuItem>
                      <MenuItem value="data_types" sx={compactControlSx}>Data Types</MenuItem>
                      <MenuItem value="partitioning" sx={compactControlSx}>Partitioning</MenuItem>
                      <MenuItem value="constraints" sx={compactControlSx}>Constraints</MenuItem>
                      <MenuItem value="documentation" sx={compactControlSx}>Documentation</MenuItem>
                      <MenuItem value="governance" sx={compactControlSx}>Governance</MenuItem>
                      <MenuItem value="pii_detection" sx={compactControlSx}>PII Detection</MenuItem>
                      <MenuItem value="pci_compliance" sx={compactControlSx}>PCI Compliance</MenuItem>
                      <MenuItem value="gdpr_compliance" sx={compactControlSx}>GDPR Compliance</MenuItem>
                      <MenuItem value="ml_readiness" sx={compactControlSx}>ML Readiness</MenuItem>
                      <MenuItem value="data_lineage" sx={compactControlSx}>Data Lineage</MenuItem>
                      <MenuItem value="cost_optimization" sx={compactControlSx}>Cost Optimization</MenuItem>
                      <MenuItem value="data_catalog" sx={compactControlSx}>Data Catalog</MenuItem>
                      <MenuItem value="etl_pipeline" sx={compactControlSx}>ETL Pipeline</MenuItem>
                      <MenuItem value="audit_trail" sx={compactControlSx}>Audit Trail</MenuItem>
                      <MenuItem value="data_retention" sx={compactControlSx}>Data Retention</MenuItem>
                      <MenuItem value="disaster_recovery" sx={compactControlSx}>Disaster Recovery</MenuItem>
                      <MenuItem value="data_migration" sx={compactControlSx}>Data Migration</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl fullWidth sx={{ mb: 2 }}>
                    <InputLabel sx={{ fontSize: '0.90rem' }}>Custom Rules (Optional)</InputLabel>
                    <Select label="Custom Rules (Optional)" value={customRules} onChange={e => setCustomRules(e.target.value)} multiple sx={compactControlSx}>
                      <MenuItem value="" sx={compactControlSx}>No custom rules available</MenuItem>
                    </Select>
                    <FormHelperText sx={{ fontSize: '0.90rem' }}>Select custom rules to apply during analysis</FormHelperText>
                  </FormControl>
                  <TextField
                    label="SQL Query (Optional)"
                    placeholder="Paste your SQL query here for analysis (optional)"
                    multiline
                    rows={3}
                    fullWidth
                    sx={{ mb: 2, fontSize: '0.92rem' }}
                    value={sqlQuery}
                    onChange={e => setSqlQuery(e.target.value)}
                  />
                  <Box sx={{ display: 'flex', gap: 2 }}>
                    <Button variant="contained" color="primary" fullWidth onClick={handleRunAnalysis} disabled={selectedTables.length === 0 || !analysisType || runningAnalysis} sx={{ ...compactControlSx, '&:hover': { backgroundColor: '#d32f2f', color: '#fff' } }}>
                      {runningAnalysis ? <CircularProgress size={20} /> : 'Run Analysis'}
                    </Button>
                    <Button variant="outlined" color="error" fullWidth disabled sx={{ ...compactControlSx, '&:hover': { backgroundColor: '#d32f2f', color: '#fff' } }}>Add to Batch Job</Button>
                  </Box>
                </CardContent>
              </Card>
            </>
          )}
        </Box>
        {/* Analysis Results Panel (main, 80%) */}
        <Box sx={{ width: '70%', minWidth: 320, flexShrink: 0, overflowX: 'auto', display: 'flex', flexDirection: 'column' }}>
          <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', fontWeight: 'bold' }}>
            <svg className="icon" viewBox="0 0 24 24" fill="currentColor" style={{ marginRight: 8, verticalAlign: 'middle' }}><path d="M3 17.25V21h3.75l11.06-11.06-3.75-3.75L3 17.25zm14.71-9.04c.39-.39.39-1.02 0-1.41l-2.54-2.54a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" /></svg>
            Analysis Results
          </Typography>
          <Box sx={{ width: '100%' }}>
            {analysisResult && analysisResult.results && (
              analysisResult.results.analysis ? (
                <Box>
                  {/* Render the AI's HTML analysis beautifully */}
                  <div
                    style={{ background: '#fff', borderRadius: 8, padding: 24, fontSize: '1.05rem', color: '#222', boxShadow: '0 2px 12px #eee', marginBottom: 24 }}
                    dangerouslySetInnerHTML={{ __html: cleanHtmlString(analysisResult.results.analysis) }}
                  />
                  {/* If view_code is present, show it in a styled code block */}
                  {analysisResult.results.view_code && (
                    <Box sx={{ mb: 2 }}>
                      <Typography variant="subtitle1" sx={{ mb: 1, fontWeight: 600, color: '#d32f2f' }}>Materialized View Definition</Typography>
                      <Box sx={{ bgcolor: '#f5f5f5', color: '#222', p: 2, borderRadius: 2, fontFamily: 'monospace', fontSize: '0.95rem', overflowX: 'auto', boxShadow: '0 1px 6px #ccc' }}>
                        <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{analysisResult.results.view_code}</pre>
                      </Box>
                    </Box>
                  )}
                  {/* Show metadata */}
                  <Box sx={{ color: '#888', fontSize: '0.95rem', mt: 2 }}>
                    <div><b>Object:</b> {analysisResult.results.object_name}</div>
                    <div><b>Type:</b> {analysisResult.results.object_type}</div>
                    <div><b>Timestamp:</b> {analysisResult.results.timestamp}</div>
                  </Box>
                </Box>
              ) : analysisResult.results.tot_tree_summary ? (
                <Box>
                  {analysisResult.results.dataset_summary && (
                    <div
                      style={{ background: '#fff', borderRadius: 8, padding: 24, fontSize: '1.05rem', color: '#222', boxShadow: '0 2px 12px #eee', marginBottom: 24 }}
                      dangerouslySetInnerHTML={{ __html: cleanHtmlString(analysisResult.results.dataset_summary) }}
                    />
                  )}
                  <Card sx={{ ...compactControlSx, mb: 2, border: '2px solid #d32f2f', transition: 'border 0.3s' }}>
              <CardContent>
                  <Box sx={{ bgcolor: '#f5f5f5', borderRadius: 2, p: 2, fontFamily: 'Inter, sans-serif', fontSize: '0.80rem', lineHeight: 1.35, overflowX: 'auto', minHeight: 320 }}>
                    {analysisResult.results.tot_tree_summary.table_summaries?.map((table, tIdx) => (
                      <Box key={table.table || tIdx} sx={{ mb: 3 }}>
                        <Typography variant="h6" sx={{ mb: 1, fontSize: '0.93rem', fontWeight: 600 }}>{table.table}</Typography>
                        {table.chunk_summaries?.map((chunk, cIdx) => (
                          <div key={cIdx} dangerouslySetInnerHTML={{ __html: cleanHtmlString(chunk) }} style={{ marginBottom: 18, fontSize: '0.95rem', background: '#fff', borderRadius: 8, padding: 16, boxShadow: '0 2px 12px #eee' }} />
                        ))}
                      </Box>
                    ))}
                  </Box>
                    </CardContent>
                  </Card>
                  </Box>
                ) : (
                  <Box sx={{ textAlign: 'center', color: 'text.secondary', width: '95%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', margin: '0 auto' }}>
                    <img src="/img/chart.gif" alt="No analysis results" style={{ width: 140, marginBottom: 24 }} />
                    <Typography variant="body1">Analysis results will appear here...</Typography>
                  </Box>
              )
                )}
          </Box>
        </Box>
        {/* Spacer for remaining width (if any) */}
        <Box sx={{ flexGrow: 1 }} />
      </Box>
    </Box>
  );
};

export default Analysis; 