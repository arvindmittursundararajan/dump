from app import app, db
from models import Machine, Part, SensorData, MaintenanceRecord, Alert, FileMetadata, AiInteraction, PredictiveModel, User, Device, DeviceType
import datetime
import random
from datetime import timedelta
import os
from werkzeug.security import generate_password_hash

TECHNICIANS = ['John Smith', 'Maria Garcia', 'David Johnson', 'Sarah Wilson', 'Robert Brown']
ALERT_TYPES = ['High Temperature', 'Low Pressure', 'Excessive Vibration', 'Abnormal Noise', 'Overload Condition']
MAINTENANCE_TYPES = ['Toyota ProActive PMaaS', 'Corrective', 'Inspection', 'Replacement', 'Lubrication']

def random_date(start_date, end_date):
    time_between = end_date - start_date
    days_between = time_between.days
    random_days = random.randrange(days_between)
    return start_date + timedelta(days=random_days)

MANUFACTURERS = ['Toyota']
DEALERS = [
    'Toyota Dealer Warsaw',
    'Toyota Dealer Krakow',
    'Toyota Dealer Gdansk',
    'Toyota Dealer Poznan',
    'Toyota Dealer Wroclaw'
]
SENSOR_TYPES = ['temperature', 'pressure', 'vibration', 'rpm', 'current']
CONNECTED_CAR_PARTS = [
    'Hybrid Battery',
    'ECU',
    'Turbocharger',
    'Brake System',
    'ADAS Module',
    'Inverter',
    'Transmission',
    'High-Voltage Cable',
    'Radar Sensor',
    'Camera Module'
]
PART_TYPES = [
    # Core Components
    'MCU', 'Microcontroller',
    # Sensors
    'Current Sensor', 'Temperature Sensor', 'Pressure Sensor', 'Flow Sensor', 'Proximity Sensor', 'Gas Sensor', 'Humidity Sensor', 'Light Sensor', 'IR Sensor', 'Ultrasonic Sensor', 'Magnetic Sensor',
    # Power Management
    'PSU', 'PMIC', 'Voltage Regulator', 'Battery', 'Solar Panel', 'Energy Harvester',
    # Connectivity
    'Comm Module', 'WiFi Module', 'Bluetooth Module', 'Zigbee Module', 'LoRa Module', 'Ethernet Module', 'USB Interface', 'Serial Bus', 'CAN Bus', 'Cloud Module',
    # Control Systems
    'PLC', 'HMI', 'IPC', 'FPGA', 'Edge Device', 'AI Accelerator',
    # Peripherals & Interfaces
    'DAQ Module', 'Signal Conditioner', 'ADC', 'DAC',
    # I/O
    'Relay', 'Switch', 'Connector', 'Keypad', 'Touchscreen',
    # Identification
    'RFID', 'NFC', 'Barcode Scanner',
    # Environmental
    'Enclosure', 'Cooling Fan', 'Heat Sink',
    # Support Components
    'Clock Module', 'RTC',
    'Capacitor', 'Resistor', 'Inductor', 'Diode', 'Transistor',
    # Monitoring
    'Power Meter', 'Smoke Detector', 'Water Level Sensor',
    # Existing/General
    'Stator', 'Rotor', 'Bearing', 'Shaft', 'Gearbox', 'Fan Blade', 'Compressor', 'Filter', 'PCB', 'Sensor', 'Controller', 'Belt', 'Spindle', 'Heater Coil', 'Switch', 'LED Module'
]

def seed_database():
    print("Clearing existing data...")
    db.session.query(AiInteraction).delete()
    db.session.query(Alert).delete()
    db.session.query(SensorData).delete()
    db.session.query(MaintenanceRecord).delete()
    db.session.query(FileMetadata).delete()
    db.session.query(Part).delete()
    db.session.query(Machine).delete()
    db.session.query(Device).delete()
    db.session.query(DeviceType).delete()
    db.session.query(User).delete()
    db.session.commit()

    print("Creating device types...")
    device_types = ['IoT', 'SCADA', 'non-SCADA', 'Sensor', 'Controller', 'PLC', 'Legacy', 'Other']
    device_type_objs = []
    for dtype in device_types:
        obj = DeviceType(name=dtype)
        db.session.add(obj)
        device_type_objs.append(obj)
    db.session.commit()

    print("Creating sample devices...")
    for i, dtype in enumerate(device_type_objs):
        device = Device(
            name=f"Sample {dtype.name} Device {i+1}",
            device_type_id=dtype.id,
            description=f"A {dtype.name} device for testing.",
            location=f"Test Location {i+1}",
            manufacturer="Universal Inc.",
            model_number=f"Model-{i+1}",
            serial_number=f"SN-{i+1:04d}",
            installation_date=datetime.datetime.now().date(),
            status='operational'
        )
        db.session.add(device)
    db.session.commit()

    # Create only the demo user
    demo_user = User(username='demo', password_hash=generate_password_hash('demo'))
    db.session.add(demo_user)
    db.session.commit()

    print("Creating sample connected car parts for Toyota ProActive PMaaS...")
    machines = []
    for dealer in DEALERS:
        for i in range(random.randint(3, 5)):
            part_type = random.choice(CONNECTED_CAR_PARTS)
            machine = Machine(
                name=f"{part_type} #{i+1} ({dealer})",
                description=f"{part_type} at {dealer}",
                asset_type=part_type,
                location=dealer,
                manufacturer='Toyota',
                model_number=f"TY-{random.randint(1000, 9999)}",
                serial_number=f"TY-SN-{random.randint(10000, 99999)}",
                installation_date=random_date(
                    datetime.datetime.now() - timedelta(days=1095),
                    datetime.datetime.now() - timedelta(days=365)
                ).date(),
                status=random.choice(['operational', 'operational', 'warning', 'maintenance'])
            )
            db.session.add(machine)
            machines.append(machine)
    db.session.commit()

    print("Creating sample parts for Toyota machines...")
    parts = []
    for machine in machines:
        for j in range(random.randint(4, 7)):
            part_type = random.choice(PART_TYPES)
            part = Part(
                machine_id=machine.id,
                parent_part_id=None,
                name=f"{part_type} {j+1}",
                description=f"{part_type} for {machine.name}",
                part_type=part_type,
                manufacturer='Toyota',
                part_number=f"TY-PART-{random.randint(1000, 9999)}",
                installation_date=random_date(
                    datetime.datetime.now() - timedelta(days=1095),
                    datetime.datetime.now() - timedelta(days=365)
                ).date(),
                expected_lifetime_hours=random.randint(5000, 20000),
                status=random.choice(['operational', 'operational', 'warning', 'maintenance'])
            )
            db.session.add(part)
            parts.append(part)
    db.session.commit()

    print("Creating sample sensor data...")
    for part in parts:
        # Add 20-50 sensor data points for each part
        for k in range(random.randint(20, 50)):
            sensor_type = random.choice(SENSOR_TYPES)
            timestamp = datetime.datetime.now() - timedelta(days=random.randint(0, 30), hours=random.randint(0, 24))
            is_anomaly = random.random() < 0.1  # 10% chance of anomaly
            
            if sensor_type == 'temperature':
                value = random.uniform(50, 90) if is_anomaly else random.uniform(60, 80)
                unit = '°C'
            elif sensor_type == 'pressure':
                value = random.uniform(80, 120) if is_anomaly else random.uniform(90, 110)
                unit = 'PSI'
            elif sensor_type == 'vibration':
                value = random.uniform(8, 15) if is_anomaly else random.uniform(1, 7)
                unit = 'mm/s'
            elif sensor_type == 'rpm':
                value = random.uniform(2800, 3500) if is_anomaly else random.uniform(1800, 2700)
                unit = 'RPM'
            else:  # current
                value = random.uniform(40, 60) if is_anomaly else random.uniform(20, 35)
                unit = 'A'
            
            sensor_data = SensorData(
                machine_id=part.machine_id,
                part_id=part.id,
                sensor_type=sensor_type,
                timestamp=timestamp,
                value=value,
                unit=unit,
                is_anomaly=is_anomaly
            )
            db.session.add(sensor_data)
            
            # Create alerts for anomalies
            if is_anomaly:
                alert = Alert(
                    machine_id=part.machine_id,
                    part_id=part.id,
                    alert_type=f"Anomaly: {sensor_type}",
                    severity=random.choice(['low', 'medium', 'high']),
                    message=f"Anomalous {sensor_type} reading detected: {value:.2f} {unit}",
                    timestamp=timestamp,
                    is_acknowledged=random.random() < 0.7
                )
                if alert.is_acknowledged:
                    alert.acknowledged_by = random.choice(TECHNICIANS)
                    alert.acknowledged_at = timestamp + timedelta(hours=random.randint(1, 8))
                db.session.add(alert)
    
    # Create additional alerts
    print("Creating additional alerts...")
    for machine in machines:
        # 50% chance for each machine to have an alert
        if random.random() < 0.5:
            alert_type = random.choice(ALERT_TYPES)
            alert = Alert(
                machine_id=machine.id,
                alert_type=alert_type,
                severity=random.choice(['low', 'medium', 'high', 'critical']),
                message=f"{alert_type} detected on {machine.name}",
                timestamp=datetime.datetime.now() - timedelta(days=random.randint(0, 10)),
                is_acknowledged=random.random() < 0.5
            )
            db.session.add(alert)
    
    print("Creating maintenance records...")
    for machine in machines:
        # Add 2-4 maintenance records for each machine
        for m in range(random.randint(2, 4)):
            maintenance_type = random.choice(MAINTENANCE_TYPES)
            
            # Random start date in the past year
            start_date = random_date(
                datetime.datetime.now() - timedelta(days=365),
                datetime.datetime.now() - timedelta(days=10)
            )
            
            # 80% chance the maintenance is completed
            is_completed = random.random() < 0.8
            
            if is_completed:
                end_date = start_date + timedelta(days=random.randint(1, 5))
                status = 'completed'
                cost = round(random.uniform(100, 5000), 2)
            else:
                end_date = None
                status = 'in_progress' if start_date < datetime.datetime.now() else 'scheduled'
                cost = None
            
            record = MaintenanceRecord(
                machine_id=machine.id,
                maintenance_type=maintenance_type,
                start_date=start_date,
                end_date=end_date,
                technician=random.choice(TECHNICIANS),
                status=status,
                cost=cost,
                description=f"{maintenance_type} maintenance for {machine.name}",
                notes="Regular scheduled maintenance" if random.random() < 0.7 else "Urgent maintenance required due to unexpected issue"
            )
            db.session.add(record)
    
    print("Creating AI interactions...")
    # Sample queries and responses
    sample_queries = [
        "What is the expected lifetime of the motor bearings?",
        "Why is the pump temperature increasing?",
        "When should we schedule the next maintenance?",
        "What could cause excessive vibration in the gearbox?",
        "How can we reduce failure rates in our equipment?"
    ]
    
    sample_responses = [
        "Based on the data, the motor bearings have an expected lifetime of approximately 15,000 operating hours under normal conditions. Recent vibration readings suggest scheduling an inspection within the next 30 days.",
        "The temperature increase in the pump could be due to: 1) Insufficient cooling fluid, 2) Bearing wear, 3) Prolonged operation at high loads, or 4) Environmental factors. I recommend checking the cooling system and bearings.",
        "Based on performance metrics, I recommend scheduling maintenance in approximately 45 days. The slight increase in motor current suggests tension adjustment will be needed during the next service.",
        "The excessive vibration likely stems from: 1) Misaligned gears, 2) Worn bearings, 3) Insufficient lubrication, or 4) Loose mounting bolts. Bearing wear is the most probable cause based on frequency analysis.",
        "To reduce failure rates: 1) Establish regular inspections every 500 hours, 2) Ensure proper warm-up procedures, 3) Monitor vibration levels continuously, and 4) Replace components at 80% of rated lifespan rather than waiting for failure indications."
    ]
    
    for machine in machines:
        # 70% chance for each machine to have an AI interaction
        if random.random() < 0.7:
            index = random.randint(0, len(sample_queries) - 1)
            interaction = AiInteraction(
                query=sample_queries[index],
                response=sample_responses[index],
                machine_id=machine.id,
                timestamp=datetime.datetime.now() - timedelta(days=random.randint(0, 14))
            )
            db.session.add(interaction)
    
    for part in parts[:5]:  # Just add a few part-specific interactions
        if random.random() < 0.4:
            index = random.randint(0, len(sample_queries) - 1)
            interaction = AiInteraction(
                query=f"About the {part.name}: {sample_queries[index]}",
                response=sample_responses[index],
                part_id=part.id,
                timestamp=datetime.datetime.now() - timedelta(days=random.randint(0, 14))
            )
            db.session.add(interaction)
    
    # Create sample metadata files
    print("Creating sample metadata...")
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
        
    # Create a dummy file for metadata
    with open('uploads/equipment_manual.pdf', 'w') as f:
        f.write("This is a sample equipment manual")
        
    # Add metadata records
    for part in parts[:8]:  # Just add metadata for some parts
        metadata = FileMetadata(
            part_id=part.id,
            metadata_type=random.choice(['manual', 'photo', 'specifications']),
            file_path='equipment_manual.pdf',
            title=f"{part.name} Documentation",
            description=f"Technical documentation for {part.name}",
            upload_date=datetime.datetime.now() - timedelta(days=random.randint(0, 60))
        )
        db.session.add(metadata)
    
    # Final commit
    db.session.commit()
    print("Sample data seeding completed!")

if __name__ == "__main__":
    with app.app_context():
        seed_database()
