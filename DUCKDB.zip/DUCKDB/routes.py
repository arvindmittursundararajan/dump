import duckdb
import sys

# --- Generate a sample Parquet file for demo purposes ---
try:
    import pandas as pd
    import pyarrow as pa
    import pyarrow.parquet as pq
    df = pd.DataFrame(
        data={
            "Name": ["Tenacious D", "Backstreet Boys", "Wu Tang Clan", "Nirvana", "Queen"],
            "Albums": [4, 10, 7, 3, 15]
        },
        columns=pd.Index(["Name", "Albums"])
    )
    table = pa.Table.from_pandas(df)
    pq.write_table(table, "example.parquet")
    print("Sample Parquet file 'example.parquet' generated.")
except Exception as e:
    print("Error generating sample Parquet file:", e, file=sys.stderr)

try:
    # Connect to DuckDB (in-memory)
    con = duckdb.connect()

    # Install and load the DuckLake extension
    con.execute("INSTALL ducklake;")
    con.execute("LOAD ducklake;")

    # Attach a DuckLake catalog and switch to it
    con.execute("ATTACH 'ducklake:my_ducklake.ducklake' AS my_ducklake;")
    con.execute("USE my_ducklake;")

    # Drop the table if it exists to avoid conflicts
    con.execute("DROP TABLE IF EXISTS demo;")
    # Create a table, insert data, and query it
    con.execute("CREATE TABLE demo (i INTEGER);")
    con.execute("INSERT INTO demo VALUES (42), (43);")
    result = con.execute("SELECT * FROM demo;").fetchall()

    print("Query result:", result)
except Exception as e:
    print("An error occurred:", e, file=sys.stderr)
    raise

# --- ADBC with DuckDB and PyArrow Example ---
try:
    import pyarrow as pa
    import adbc_driver_duckdb.dbapi

    # Connect to DuckDB via ADBC (creates or opens 'test.duckdb' file)
    with adbc_driver_duckdb.dbapi.connect("test.duckdb") as conn:
        with conn.cursor() as cur:
            # Create a PyArrow table with sample data
            table = pa.table({
                "Name": ["Tenacious D", "Backstreet Boys", "Wu Tang Clan"],
                "Albums": [4, 10, 7]
            })

            # Ingest the PyArrow table into DuckDB, creating a new table 'Bands'
            cur.adbc_ingest("Bands", table)

            # Execute a query on the ingested data
            cur.execute("SELECT * FROM Bands")

            # Fetch the result as a PyArrow Table
            result_table = cur.fetch_arrow_table()

            # Print the result
            print("ADBC Query result as Arrow Table:")
            print(result_table)
except Exception as e:
    print("An error occurred in the ADBC example:", e, file=sys.stderr)
    raise

# --- ADBC with DuckDB and PyArrow via adbc_driver_manager Example ---
try:
    import pyarrow as pa
    from adbc_driver_manager import dbapi

    DUCKDB_DLL_PATH = "duckdb.dll"  # Local DLL in project directory

    with dbapi.connect(
        driver=DUCKDB_DLL_PATH,
        entrypoint="duckdb_adbc_init",
        db_kwargs={"path": "test.duckdb"}
    ) as conn:
        with conn.cursor() as cur:
            # Create a PyArrow table with sample data
            table = pa.table({
                "Name": ["Tenacious D", "Backstreet Boys", "Wu Tang Clan"],
                "Albums": [4, 10, 7]
            })

            # Ingest the PyArrow table into DuckDB, creating a new table 'Bands'
            cur.adbc_ingest("Bands", table)

            # Execute a query on the ingested data
            cur.execute("SELECT * FROM Bands")

            # Fetch the result as a PyArrow Table
            result_table = cur.fetch_arrow_table()

            # Print the result
            print("ADBC Query result as Arrow Table:")
            print(result_table)
except Exception as e:
    print("An error occurred in the ADBC example:", e, file=sys.stderr)
    raise

# --- Example 1: Ingest Parquet file using DuckDB SQL ---
try:
    # This will create a DuckDB table from a Parquet file
    con = duckdb.connect()
    con.execute("DROP TABLE IF EXISTS parquet_table;")
    con.execute("CREATE TABLE parquet_table AS SELECT * FROM 'example.parquet';")
    result = con.execute("SELECT * FROM parquet_table LIMIT 5;").fetchall()
    print("DuckDB SQL Parquet Ingest result (first 5 rows):", result)
except Exception as e:
    print("Error in DuckDB SQL Parquet ingest:", e, file=sys.stderr)

# --- Example 2: Ingest Parquet file as Arrow Table via ADBC ---
try:
    import pyarrow.parquet as pq
    from adbc_driver_manager import dbapi
    arrow_table = pq.read_table("example.parquet")
    with dbapi.connect(driver="duckdb.dll", entrypoint="duckdb_adbc_init", db_kwargs={"path": "test.duckdb"}) as conn:
        with conn.cursor() as cur:
            cur.adbc_ingest("arrow_parquet_table", arrow_table)
            cur.execute("SELECT * FROM arrow_parquet_table LIMIT 5;")
            result_table = cur.fetch_arrow_table()
            print("ADBC Arrow Parquet Ingest result (first 5 rows):")
            print(result_table)
except Exception as e:
    print("Error in ADBC Arrow Parquet ingest:", e, file=sys.stderr)

# --- Example 3: Ingest Delta Lake table using DuckDB's delta extension ---
try:
    con = duckdb.connect()
    con.execute("INSTALL delta;")
    con.execute("LOAD delta;")
    con.execute("DROP TABLE IF EXISTS delta_table;")
    con.execute("CREATE TABLE delta_table AS SELECT * FROM 'path/to/delta/table';")
    result = con.execute("SELECT * FROM delta_table LIMIT 5;").fetchall()
    print("DuckDB Delta Table Ingest result (first 5 rows):", result)
except Exception as e:
    print("Error in DuckDB Delta Table ingest:", e, file=sys.stderr)

# --- Simulate Multiple Concurrent DuckLake Queries with ADBC ---
try:
    import threading
    from adbc_driver_manager import dbapi

    DUCKDB_DLL_PATH = "duckdb.dll"
    DUCKLAKE_CATALOG = "my_ducklake.ducklake"

    def run_concurrent_query(thread_id):
        with dbapi.connect(
            driver=DUCKDB_DLL_PATH,
            entrypoint="duckdb_adbc_init",
            db_kwargs={"path": DUCKLAKE_CATALOG}
        ) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM demo;")
                result = cur.fetch_arrow_table()
                print(f"[Thread {thread_id}] Query result:\n{result}")

    num_threads = 4  # Simulate 4 concurrent clients
    threads = []
    print("\n--- Simulating concurrent DuckLake queries with ADBC ---")
    for i in range(num_threads):
        t = threading.Thread(target=run_concurrent_query, args=(i,))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    print("--- All concurrent queries completed ---\n")
except Exception as e:
    print("Error during concurrent DuckLake ADBC queries:", e, file=sys.stderr)

# --- Ensure 'demo' table exists in my_ducklake.ducklake for parallelism demo ---
try:
    con = duckdb.connect('my_ducklake.ducklake')
    con.execute("DROP TABLE IF EXISTS demo;")
    con.execute("CREATE TABLE demo (i INTEGER);")
    con.execute("INSERT INTO demo VALUES (42), (43);")
    con.close()
    print("'demo' table ensured in my_ducklake.ducklake.")
except Exception as e:
    print("Error ensuring 'demo' table in my_ducklake.ducklake:", e, file=sys.stderr)

# --- Demonstrate DuckDB Internal Parallelism with Profiling ---
try:
    print("\n--- Demonstrating DuckDB Internal Parallelism with Profiling ---")
    con = duckdb.connect('my_ducklake.ducklake')
    con.execute("PRAGMA threads=4;")  # Use 4 threads
    con.execute("PRAGMA enable_profiling='json';")
    result = con.execute("SELECT COUNT(*), AVG(i) FROM demo, range(1000000) t(x);").fetchall()
    print("Parallel query result:", result)
    profile = con.execute("PRAGMA show_profile;").fetchall()
    print("Query profile:", profile)
    print("--- End of parallelism demo ---\n")
    con.close()
except Exception as e:
    print("Error during DuckDB parallelism demo:", e, file=sys.stderr)
