import json
import datetime
import time
from typing import List, Dict, Any, Optional
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db
import ai
from analyzer import TreeOfTablesAnalyzer
from .db import db_manager

class AnalysisService:
    def __init__(self):
        self.tree_analyzer = TreeOfTablesAnalyzer()
    
    def run_analysis(self, selected_tables: List[Dict], analysis_type: str, 
                    sql_query: Optional[str] = None) -> Dict[str, Any]:
        """
        Run comprehensive analysis on selected tables using ToT chunked tree-based AI analysis.
        - For each table, load as DataFrame
        - Build ToT tree (chunks of 10 columns)
        - Send each chunk's metadata to real AI (ai_engine.ai_analyze_chunk_metadata)
        - Aggregate results up the tree (chunk -> table -> database)
        - Return cumulative answer and tree structure
        """
        try:
            print("🚀 Starting ToT Tree-of-Table Analysis...")
            def safe_json(obj):
                try:
                    return json.dumps(obj, indent=2)
                except TypeError:
                    if hasattr(obj, 'dict'):
                        return json.dumps(obj.dict(), indent=2)
                    elif isinstance(obj, list):
                        return json.dumps([o.dict() if hasattr(o, 'dict') else o for o in obj], indent=2)
                    else:
                        return str(obj)
            print(f"Selected tables received: {safe_json(selected_tables)}")
            selected_tables = [t.dict() if not isinstance(t, dict) and hasattr(t, 'dict') else t for t in selected_tables]

            # Detect if the selected object is a view/materialized view
            # Assume only one table/view is selected for this special analysis
            if len(selected_tables) == 1:
                table_info = selected_tables[0]
                catalog_name = table_info['catalog']
                schema_name = table_info['schema_name']
                table_name = table_info['name']
                # Query Databricks for table type
                query = f"SELECT table_type FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}' AND table_name = '{table_name}'"
                response = db.execute_sql_statement(query, use_cache=False)
                table_type = None
                if response and 'result' in response and 'data_array' in response['result'] and len(response['result']['data_array']) > 0:
                    table_type = response['result']['data_array'][0][0]
                print(f"Detected table_type for {catalog_name}.{schema_name}.{table_name}: {table_type}")
                # Fallback: treat as materialized view if name matches pattern
                is_mv = (table_type in ('VIEW', 'MATERIALIZED VIEW') or table_name.startswith('__materialization_mat_'))
                if is_mv:
                    # Fetch the view definition
                    show_create = f"SHOW CREATE TABLE {catalog_name}.{schema_name}.{table_name}"
                    code_response = db.execute_sql_statement(show_create, use_cache=False)
                    view_code = None
                    if code_response and 'result' in code_response and 'data_array' in code_response['result']:
                        view_code = code_response['result']['data_array'][0][0]
                    from client import get_spark_assist_analysis
                    # If the view_code is very long, chunk it and analyze each chunk
                    def chunk_text(text, word_limit=200):
                        words = text.split()
                        return [' '.join(words[i:i+word_limit]) for i in range(0, len(words), word_limit)]
                    chunks = chunk_text(view_code, 200) if view_code else []
                    chunk_analyses = []
                    if len(chunks) > 1:
                        all_chunk_insights = []
                        for idx, chunk in enumerate(chunks):
                            prompt = (
                                f"Analyze the following materialized view definition chunk. "
                                "Highlight any issues or improvements. "
                                "Respond ONLY in well-structured HTML (with <h2>, <ul>, <li>, <b>, <span style='color: #222;'>, <span style='color: #333;'>, <span style='color: #d32f2f;'>, etc). "
                                "Do NOT use markdown or plain text formatting. "
                                "Use only dark or high-contrast colors for all text (never white or light shades). "
                                "Make the report visually appealing and easy to read. "
                                "If you mention code, wrap it in <pre><code> blocks. "
                                "If you mention issues, use <span style='color: #d32f2f;'> for problems and <span style='color: #388e3c;'> for good practices. "
                                "Use clear section headings and bullet points. "
                                f"Here is the materialized view definition chunk:\n\n{chunk}"
                            )
                            time.sleep(5)
                            chunk_analysis = get_spark_assist_analysis(prompt)
                            all_chunk_insights.append(chunk_analysis)
                        # Summarize all chunk insights into a single, unified report
                        summary_prompt = (
                            "You are a database expert. Given the following chunk analyses of a materialized view definition, write a single, cohesive summary and actionable recommendations. "
                            "Do NOT mention chunk numbers or chunking. Only present a unified, insightful report. "
                            "Respond ONLY in well-structured HTML (with <h2>, <ul>, <li>, <b>, <span style='color: #222;'>, <span style='color: #333;'>, <span style='color: #d32f2f;'>, etc). "
                            "Do NOT use markdown or plain text formatting. "
                            "Make the report visually appealing and easy to read. "
                            "Here are the chunk analyses:\n\n" + '\n\n'.join(all_chunk_insights)
                        )
                        time.sleep(5)
                        analysis_text = get_spark_assist_analysis(summary_prompt)
                    else:
                        prompt = (
                            "Analyze the following materialized view definition for performance, correctness, and best practices. "
                            "Highlight any issues or improvements. "
                            "Respond ONLY in well-structured HTML (with <h2>, <ul>, <li>, <table>, <tr>, <th>, <td>, <b>, <i>, <span style='color: #222;'>, <span style='color: #333;'>, <span style='color: #d32f2f;'>, etc). "
                            "Do NOT use markdown or plain text formatting. "
                            "Use only dark or high-contrast colors for all text (never white or light shades). "
                            "Make the report visually appealing and easy to read. "
                            "If you mention code, wrap it in <pre><code> blocks. "
                            "If you mention issues, use <span style='color: #d32f2f;'> for problems and <span style='color: #388e3c;'> for good practices. "
                            "Use clear section headings and bullet points. "
                            "Here is the materialized view definition:\n\n" + view_code
                        )
                        time.sleep(5)
                        analysis_text = get_spark_assist_analysis(prompt)
                    analysis_result = {
                        'analysis_type': analysis_type,
                        'object_type': table_type or 'MATERIALIZED VIEW',
                        'object_name': f"{catalog_name}.{schema_name}.{table_name}",
                        'view_code': view_code,
                        'analysis': analysis_text,
                        'timestamp': datetime.datetime.now().isoformat()
                    }
                    analysis_id = db_manager.store_analysis_result(
                        analysis_type, [f"{catalog_name}.{schema_name}.{table_name}"], sql_query, analysis_result, None
                    )
                    return {
                        "success": True,
                        "analysis_id": analysis_id,
                        "results": analysis_result,
                        "metrics": None
                    }

            # Step 1: Connection & Discovery from Databricks
            print("📡 Connecting to Databricks...")
            if not db.test_connection():
                return {
                    "success": False, 
                    "error": "Failed to connect to Databricks"
                }

            # Step 2: Table Data Loading
            print("📋 Loading Table Data for ToT Analysis...")
            dataframes = {}
            tables_for_tot = []
            table_metadatas = {}
            for table_info in selected_tables:
                if isinstance(table_info, dict):
                    if 'catalog' in table_info and 'schema_name' in table_info and 'name' in table_info:
                        catalog_name = table_info['catalog']
                        schema_name = table_info['schema_name']
                        table_name = table_info['name']
                        full_name = f"{catalog_name}.{schema_name}.{table_name}"
                        tables_for_tot.append({'catalog': catalog_name, 'schema': schema_name, 'name': table_name})
                        print(f"  📊 Loading {full_name} as DataFrame...")
                        try:
                            df = self.tree_analyzer.load_table_from_databricks(catalog_name, schema_name, table_name, limit=1000)
                            dataframes[full_name] = df
                            # Gather extra metadata for richer ToT analysis
                            schema_info = db.execute_sql_statement(f"DESCRIBE TABLE {catalog_name}.{schema_name}.{table_name}")
                            tbl_properties = db.execute_sql_statement(f"SHOW TBLPROPERTIES {catalog_name}.{schema_name}.{table_name}")
                            detail_info = db.execute_sql_statement(f"DESCRIBE DETAIL {catalog_name}.{schema_name}.{table_name}")
                            table_metadatas[full_name] = {
                                'schema': schema_info,
                                'properties': tbl_properties,
                                'detail': detail_info
                            }
                        except Exception as e:
                            print(f"❌ Failed to load {full_name}: {e}")
                            return {"success": False, "error": f"Failed to load {full_name}: {e}"}
                    else:
                        continue
                else:
                    continue
            # Pass table_metadatas into ToT chunking and Gemini prompt as needed

            # Dataset summary (business intro + technical)
            num_tables = len(dataframes)
            total_columns = sum(len(df.columns) for df in dataframes.values())
            table_names = list(dataframes.keys())
            tech_summary = f"Dataset contains {num_tables} tables, {total_columns} columns. Example tables: {', '.join(table_names[:3])}{'...' if num_tables > 3 else ''}."
            # Estimate analysis time (simple heuristic)
            est_time_sec = int(num_tables * 2 + total_columns * 0.1)
            time_summary = f"Estimated analysis time: {est_time_sec} seconds."
            # Use Gemini to generate a business intro
            from client import get_spark_assist_analysis
            business_intro_prompt = (
                "You are a data analyst. Write a visually appealing, executive-style summary for a data analysis report. "
                "Use emojis for key points (e.g., 📊, 💡, ⚠️, ✅). "
                "Respond ONLY in well-structured HTML (with <h2>, <ul>, <li>, <b>, <span style='color: #d32f2f;'>, <span style='color: #388e3c;'>, etc). "
                "Do NOT use markdown or plain text formatting. "
                "Make the summary visually appealing and easy to read. "
                "Use clear section headings and bullet points. "
                "Base your summary and recommendations ONLY on the actual data and chunk analyses provided. Do not guess or invent facts. If you are not sure, say so. "
                f"<h2>💡 Dataset Context</h2> <p>In 3-4 lines, describe what domain this dataset is from, what problem it is solving, and what kind of data is inside. Be specific and insightful, not generic. Only use information you can infer from the actual data and chunk analyses below. If you mention table/column counts or example tables, do so subtly in the middle or end of your summary, not at the beginning.</p> "
                f"<h2>⚠️ Key Insights & Recommendations</h2> <ul><li>After reading the chunk analyses below, summarize the 3-4 most important issues, recommendations, or fixes for this dataset. Be specific and actionable, and only mention issues you can see in the data.</li></ul> "
            )
            time.sleep(5)
            business_intro = get_spark_assist_analysis(business_intro_prompt)
            dataset_summary = f"{business_intro.strip()} {tech_summary} {time_summary}"

            # Benchmark analysis time
            import time as _time
            real_start_time = _time.time()
            # Step 3: Build ToT Tree and Run Chunked AI Analysis
            print("🌳 Building ToT Tree and Running Chunked AI Analysis...")
            progress_log = []
            def progress_callback(msg):
                print(msg)
                progress_log.append(msg)
            # Patch: pass table_metadatas to tot_full_analysis
            tot_result = self.tree_analyzer.tot_full_analysis(
                tables_for_tot, dataframes, ai.ai_analyze_chunk_metadata, analysis_type, progress_callback, table_metadatas=table_metadatas
            )
            real_end_time = _time.time()
            real_elapsed_sec = real_end_time - real_start_time
            real_elapsed_str = f"Actual analysis time: {real_elapsed_sec:.1f} seconds."
            # Step 4: Results & Reporting
            print("📊 Compiling ToT Results...")
            # Add real benchmark time to the summary
            dataset_summary = f"{business_intro.strip()} {tech_summary} {time_summary} <br/><b>⏱️ {real_elapsed_str}</b>"
            analysis_result = {
                'analysis_type': analysis_type,
                'tables_analyzed': list(dataframes.keys()),
                'dataset_summary': dataset_summary,
                'tot_tree_summary': tot_result['summary'],
                'tot_tree': tot_result['tree'],
                'progress_log': progress_log,
                'timestamp': datetime.datetime.now().isoformat()
            }

            # Store result in database
            analysis_id = db_manager.store_analysis_result(
                analysis_type, list(dataframes.keys()), sql_query, analysis_result, None
            )

            return {
                "success": True,
                "analysis_id": analysis_id,
                "results": analysis_result,
                "metrics": None
            }

        except Exception as e:
            print(f"❌ ToT Analysis failed: {str(e)}")
            return {
                "success": False,
                "error": f"ToT Analysis failed: {str(e)}"
            }

    def get_analysis_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get analysis history from database."""
        return db_manager.get_analysis_history(limit)
    
    def get_analysis_by_id(self, analysis_id: int) -> Optional[Dict[str, Any]]:
        """Get specific analysis result by ID."""
        return db_manager.get_analysis_by_id(analysis_id)
    
    def delete_analysis(self, analysis_id: int) -> bool:
        """Delete analysis result by ID."""
        return db_manager.delete_analysis(analysis_id)

# Global analysis service instance
analysis_service = AnalysisService() 