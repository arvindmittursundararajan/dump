# DuckLake Browser UI

A modern, full-featured web UI for DuckDB and DuckLake, built with Python Flask.

## Vision

DuckLake Browser is a beautiful, powerful analytics platform for the lakehouse era. It supports SQL, Parquet, Delta, Arrow, cloud storage, and all the power of DuckDB and DuckLake—accessible through an intuitive web interface.

## Features

- Home / Dashboard: Quick stats, recent queries, system health
- SQL Editor: Syntax highlighting, autocomplete, query history, result visualization
- Data Catalog / Explorer: Browse catalogs, schemas, tables, view metadata
- Ingestion & Upload: Upload CSV/Parquet/Arrow, ingest from cloud storage
- Table Management: Create/drop/rename/edit tables, view/edit schemas
- Query History & Saved Queries: List, save, and share queries
- Visualization: Bar, line, pie, scatter, and custom charts
- Lakehouse Management: Attach/detach catalogs, configure endpoints
- User Management (optional): Roles, audit logs
- Settings: Configure DuckDB/DuckLake, integrations, notifications

## Screen Map

```mermaid
graph TD
    A[Home / Dashboard]
    B[SQL Editor]
    C[Data Catalog / Explorer]
    D[Ingestion & Upload]
    E[Table Management]
    F[Query History & Saved Queries]
    G[Visualization]
    H[Lakehouse Management]
    I[User Management]
    J[Settings]

    A --> B
    A --> C
    B --> F
    B --> G
    C --> E
    D --> E
    H --> C
    I --> A
    J --> A
```

## Tech Stack
- Backend: Flask (Python), DuckDB Python API, DuckLake extension
- Frontend: React (recommended) or Flask+Jinja2 templates
- Visualization: Plotly, Chart.js, or ECharts
- Auth: Flask-Login or Authlib (optional)

## Getting Started

1. Install dependencies (to be added)
2. Run the Flask app
3. Open in your browser and explore the lakehouse!

---

*This README is the blueprint for building the DuckLake Browser UI. Next steps: scaffold the Flask app and implement the first screens.* 