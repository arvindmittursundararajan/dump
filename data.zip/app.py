import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
# Set specific loggers
logger = logging.getLogger(__name__)
requests_logger = logging.getLogger('urllib3')
requests_logger.setLevel(logging.DEBUG)  # Enable to see details of HTTP requests
gemini_logger = logging.getLogger('services.gemini_service')
gemini_logger.setLevel(logging.DEBUG)

class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")  # Default for development

# Database configuration - using SQLite
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///aerooptima.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the database with the app
db.init_app(app)

# Import configuration values
import config
# Apply config values
for key in dir(config):
    if key.isupper():
        app.config[key] = getattr(config, key)

# Import and register blueprints
with app.app_context():
    from routes.data_hub import data_hub_bp
    from routes.live_watch import live_watch_bp
    from routes.optimizer import optimizer_bp
    from routes.debrief import debrief_bp
    from routes.chat import chat_bp
    from routes.whatif import whatif_bp
    from routes.help import help_bp
    
    app.register_blueprint(data_hub_bp)
    app.register_blueprint(live_watch_bp)
    app.register_blueprint(optimizer_bp)
    app.register_blueprint(debrief_bp)
    app.register_blueprint(whatif_bp)
    app.register_blueprint(help_bp)
    app.register_blueprint(chat_bp)
    
    # Import models and create tables
    import models  # noqa: F401
    db.create_all()
    
    logger.info("AeroOptima.ai application initialized")
