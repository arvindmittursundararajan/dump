import datetime
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import JSONResponse
from .models import AnalysisRequest, AnalysisResponse
from .analysis import analysis_service

router = APIRouter()

@router.post("/analysis", response_model=AnalysisResponse)
async def analyze(request: AnalysisRequest):
    """Run comprehensive analysis on selected tables."""
    if not request.selected_tables:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Please select at least one table for analysis."
        )
    result = analysis_service.run_analysis(
        request.selected_tables,
        request.analysis_type,
        request.sql_query
    )
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result["error"]
        )
    return AnalysisResponse(
        success=True,
        analysis_id=result["analysis_id"],
        results=result["results"],
        metrics=result["metrics"]
    )

@router.post("/tree_analysis")
async def tree_analysis(request: AnalysisRequest):
    """Run tree-of-tables analysis."""
    if not request.selected_tables:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Please select at least one table for analysis."
        )
    try:
        table_names = [f"{t.catalog}.{t.schema_name}.{t.name}" for t in request.selected_tables]
        tree_structure = analysis_service.tree_analyzer.analyze_tables(table_names)
        return {
            "success": True,
            "tree_structure": tree_structure
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/history")
async def history():
    """Get analysis history."""
    try:
        history_data = analysis_service.get_analysis_history()
        return {"history": history_data}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/history/{analysis_id}")
async def view_analysis(analysis_id: int):
    """View specific analysis result."""
    try:
        analysis_data = analysis_service.get_analysis_by_id(analysis_id)
        if not analysis_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Analysis not found"
            )
        return analysis_data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.post("/history/delete/{analysis_id}")
async def delete_analysis(analysis_id: int):
    """Delete analysis result."""
    try:
        success = analysis_service.delete_analysis(analysis_id)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Analysis not found"
            )
        return {"success": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/export/{analysis_id}")
async def export_analysis(analysis_id: int):
    """Export analysis result."""
    try:
        analysis_data = analysis_service.get_analysis_by_id(analysis_id)
        if not analysis_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Analysis not found"
            )
        export_data = {
            "analysis_id": analysis_data["id"],
            "analysis_type": analysis_data["analysis_type"],
            "tables_analyzed": analysis_data["table_names"],
            "created_at": analysis_data["created_at"],
            "results": analysis_data["analysis_result"],
            "metrics": analysis_data["metrics"]
        }
        return JSONResponse(
            content=export_data,
            headers={"Content-Disposition": f"attachment; filename=analysis_{analysis_id}.json"}
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        ) 