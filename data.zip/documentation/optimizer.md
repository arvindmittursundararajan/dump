# Optimizer

## Overview
The Optimizer module is the decision support engine of AeroOptima.ai, offering scenario-based modeling capabilities for complex operational challenges. It enables operations controllers to explore multiple solutions, compare outcomes, and implement the most effective strategies during both normal operations and disruption events.

## URL Route
- Main URL: `/optimizer` (accessible through the top navigation bar)

## Key Features

### 1. Scenario-Based Optimization
- **Pre-built Scenarios**: Templates for common operational challenges
- **Custom Scenario Creation**: Define unique optimization scenarios
- **Constraint Configuration**: Set boundaries for acceptable solutions
- **Objective Weighting**: Balance competing priorities (cost, passenger satisfaction, etc.)

### 2. Solution Comparison
- **Multi-Solution Generation**: Create multiple potential solutions
- **Comparative Analysis**: Side-by-side evaluation of different approaches
- **KPI Visualization**: See impact across key performance indicators
- **Version Control**: Track iterations of optimization plans

### 3. Decision Support
- **Recommendation Engine**: AI-generated suggestions for optimal actions
- **Implementation Roadmap**: Step-by-step execution plan
- **Expected Outcomes**: Forecasted results of implementing solutions
- **Risk Assessment**: Identification of potential implementation challenges

### 4. Specialized Optimization Scenarios

#### Unaccompanied Minor Optimization
- **Safety-First Routing**: Prioritize secure connections for minors
- **Staff Availability**: Ensure sufficient staff at connection points
- **No Overnight Transits**: Prevent overnight stays for unaccompanied minors
- **Limited Connections**: Restrict to single-connection itineraries when possible

#### Crew Recovery Optimization
- **Duty Time Compliance**: Maintain legal duty time limitations
- **Qualification Matching**: Ensure crews have required qualifications
- **Crew Base Optimization**: Minimize out-of-base assignments
- **Rest Requirement Adherence**: Preserve minimum rest periods

#### Aircraft Utilization Optimization
- **Maintenance Compliance**: Schedule around maintenance requirements
- **Equipment Matching**: Assign appropriate aircraft types to routes
- **Fuel Efficiency**: Optimize for reduced fuel consumption
- **Utilization Balancing**: Even distribution of flight hours across fleet

## User Interface Components

### Plan Builder Interface
- Scenario selection dropdown
- Constraint configuration sliders and toggles
- Objective priority weight controls
- Save and manage plan versions

### Solution Comparison View
- Side-by-side plan cards
- Key metric summary for each solution
- Visual indicators of comparative performance
- Clone, edit, and execute controls

### Execution Dashboard
- Implementation timeline
- Action item checklist
- Resource allocation overview
- Expected vs. actual outcome tracking

### Flowchart Visualization
- Mermaid.js-powered decision flowcharts
- Visual representation of optimization logic
- Interactive node exploration
- Exportable diagrams for communication

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/plans` | GET | Retrieve all optimization plans |
| `/api/plans` | POST | Create a new optimization plan |
| `/api/plans/<id>` | GET | Get specific plan details |
| `/api/plans/<id>/run` | POST | Execute an optimization plan |
| `/api/plans/<id>/clone` | POST | Create a new version of an existing plan |
| `/api/plans/<id>/summary` | GET | Get an AI-generated plan summary |
| `/api/generate-flowchart` | POST | Generate a visualization for a plan |

## Database Models
The Optimizer uses the `OptimizationPlan` model with the following key fields:
- `id`: Unique identifier
- `name`: Plan name
- `description`: Detailed plan description
- `scenario`: The optimization scenario type
- `constraints`: JSON object of constraint parameters
- `objective_weights`: JSON object with weighted priorities
- `created_at`: Creation timestamp
- `status`: Current state (draft, running, completed, failed)
- `results`: JSON data with optimization outcomes
- `score`: Overall effectiveness score
- `execution_time`: Time taken to run optimization
- `version`: Iteration number

## Solution Types and Algorithms
The Optimizer uses different algorithms depending on the scenario:

### 1. Network Flow Optimization
For passenger and aircraft routing problems, using:
- PuLP linear programming solver
- Network flow models with capacity constraints
- Multi-objective optimization techniques

### 2. Constraint Satisfaction Problems
For crew scheduling and regulatory compliance:
- Rule-based constraint engines
- Backtracking algorithms with heuristics
- Penalty-based optimization for soft constraints

### 3. Simulation-Based Optimization
For complex operational scenarios:
- Monte Carlo simulation
- Discrete event simulation
- What-if scenario modeling

## Technical Implementation
- Uses Flask routes in `routes/optimizer.py`
- Implementation in `services/optimization_service.py`
- Leverages PuLP for mathematical optimization
- Uses Mermaid.js for flowchart generation
- Gemini API for natural language summaries

## Best Practices
1. Start with realistic constraints to avoid infeasible solutions
2. Balance competing objectives based on business priorities
3. Compare multiple solutions before implementation
4. Document successful optimization strategies for future reference
5. Validate optimization results against operational realities
6. Update scenario templates based on effectiveness in real situations