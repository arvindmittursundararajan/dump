import os
import requests
import sqlite3
import json
import time
from config import DATABRICKS_SERVER, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN, DATABASE_PATH

# Define your Databricks workspace URL and API key from config
workspace_url = f'https://{DATABRICKS_SERVER}'
access_token = DATABRICKS_TOKEN
http_path = DATABRICKS_HTTP_PATH

# Set the headers for authentication
headers = {
    'Authorization': f'Bearer {access_token}',
    'Content-Type': 'application/json',
}

def connect_db():
    """Connect to the SQLite database."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with the schema."""
    try:
        with open('schema.sql', 'r') as f:
            schema = f.read()
        conn = connect_db()
        conn.executescript(schema)
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error initializing database: {str(e)}")
        raise

def execute_sql_statement(statement, use_cache=True, cache_ttl=3600):
    """Execute a SQL statement in Databricks and return the response.
    
    Args:
        statement: The SQL statement to execute
        use_cache: Whether to use the local SQLite cache
        cache_ttl: Cache time-to-live in seconds (default: 1 hour)
    """
    conn = None
    cursor = None
    
    # Check if we have a cached result
    if use_cache:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT result, timestamp FROM query_cache WHERE query = ?",
            (statement,)
        )
        cached = cursor.fetchone()
        
        if cached:
            now = time.time()
            cache_time = cached['timestamp']
            
            # If cache is still valid, return it
            if now - cache_time < cache_ttl:
                conn.close()
                return json.loads(cached['result'])
    
    # No valid cache, execute the query
    try:
        response = requests.post(
            f'{workspace_url}/api/2.0/sql/statements',
            headers=headers,
            json={"statement": statement, "warehouse_id": http_path.split('/')[-1]}
        )
        
        # Check if the request was successful
        if response.status_code == 200:
            result = response.json()
            
            # Cache the result if caching is enabled
            if use_cache and conn and cursor:
                cursor.execute(
                    """INSERT OR REPLACE INTO query_cache (query, result, timestamp) 
                    VALUES (?, ?, ?)""",
                    (statement, json.dumps(result), time.time())
                )
                conn.commit()
            
            if conn:
                conn.close()
                
            return result
        else:
            if conn:
                conn.close()
            print(f"Error executing SQL: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        if conn:
            conn.close()
        print(f"Exception executing SQL: {str(e)}")
        return None

def get_catalogs():
    """Fetch all catalogs from Databricks."""
    response = execute_sql_statement("SHOW CATALOGS;")
    if response and 'result' in response and 'data_array' in response['result']:
        catalogs = [{"name": catalog[0]} for catalog in response['result']['data_array']]
        return catalogs
    return []

def get_schemas(catalog_name):
    """Fetch all schemas for a given catalog from Databricks."""
    query = f"SELECT schema_name FROM {catalog_name}.information_schema.schemata;"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        schemas = [{"name": schema[0], "catalog": catalog_name} for schema in response['result']['data_array']]
        return schemas
    return []

def get_tables(catalog_name, schema_name):
    """Fetch all tables for a given schema from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}';"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        tables = []
        for table in response['result']['data_array']:
            table_info = {
                "catalog": table[0],
                "schema": table[1],
                "name": table[2],
                "type": table[3],
                "data_source_format": table[13] if len(table) > 13 else ""
            }
            tables.append(table_info)
        return tables
    return []

def get_columns(catalog_name, schema_name, table_name):
    """Fetch all columns for a given table from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.columns WHERE table_schema = '{schema_name}' AND table_name = '{table_name}';"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        columns = []
        for column in response['result']['data_array']:
            column_info = {
                "catalog": column[0],
                "schema": column[1],
                "table": column[2],
                "name": column[3],
                "data_type": column[8] if len(column) > 8 else "",
                "is_nullable": column[6] if len(column) > 6 else "",
                "full_data_type": column[7] if len(column) > 7 else "",
                "numeric_precision": column[10] if len(column) > 10 else "",
                "character_maximum_length": column[9] if len(column) > 9 else "",
                "comment": column[18] if len(column) > 18 else ""
            }
            columns.append(column_info)
        return columns
    return []

def get_table_details(catalog_name, schema_name, table_name):
    """Get detailed information about a table using DESCRIBE DETAIL."""
    query = f"DESCRIBE DETAIL {catalog_name}.{schema_name}.{table_name};"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        detail_rows = response['result']['data_array']
        if detail_rows and len(detail_rows) > 0:
            try:
                column_names = [col['name'] for col in response['result']['column_meta']]
                detail_dict = dict(zip(column_names, detail_rows[0]))
                return {
                    "size_bytes": int(detail_dict.get('sizeInBytes', 0)),
                    "file_count": int(detail_dict.get('numFiles', 0)),
                    "format": detail_dict.get('format', '')
                }
            except (KeyError, IndexError, ValueError):
                pass
    # Default values if anything goes wrong
    return {
        "size_bytes": 0,
        "file_count": 0,
        "format": ""
    }

def get_query_history(table_name=None, limit=10):
    """Get recent query history from Databricks, optionally filtered by table."""
    # This function previously returned sample/demo data. To ensure only real data is used,
    # either implement a real Databricks query here, or return an empty list / raise error.
    # For now, return an empty list to avoid any fake/sample data.
    return []

def save_catalog_to_db(catalog):
    """Save a catalog to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO catalogs (name) VALUES (?)",
        (catalog['name'],)
    )
    conn.commit()
    # Get the ID of the inserted catalog
    cursor.execute("SELECT id FROM catalogs WHERE name = ?", (catalog['name'],))
    catalog_id = cursor.fetchone()['id']
    conn.close()
    return catalog_id

def save_schema_to_db(schema, catalog_id):
    """Save a schema to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO schemas (catalog_id, name) VALUES (?, ?)",
        (catalog_id, schema['name'])
    )
    conn.commit()
    # Get the ID of the inserted schema
    cursor.execute("SELECT id FROM schemas WHERE catalog_id = ? AND name = ?", 
                 (catalog_id, schema['name']))
    schema_id = cursor.fetchone()['id']
    conn.close()
    return schema_id

def save_table_to_db(table, schema_id):
    """Save a table to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT OR IGNORE INTO tables 
        (schema_id, name, type, data_source_format) 
        VALUES (?, ?, ?, ?)""",
        (schema_id, table['name'], table['type'], table.get('data_source_format', ''))
    )
    conn.commit()
    # Get the ID of the inserted table
    cursor.execute("SELECT id FROM tables WHERE schema_id = ? AND name = ?", 
                 (schema_id, table['name']))
    table_id = cursor.fetchone()['id']
    conn.close()
    return table_id

def save_column_to_db(column, table_id):
    """Save a column to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT OR IGNORE INTO columns 
        (table_id, name, data_type, is_nullable, full_data_type, 
         numeric_precision, max_length, comment) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            table_id, 
            column['name'], 
            column.get('data_type', ''), 
            column.get('is_nullable', ''), 
            column.get('full_data_type', ''),
            column.get('numeric_precision', ''), 
            column.get('character_maximum_length', ''), 
            column.get('comment', '')
        )
    )
    conn.commit()
    conn.close()

def save_selected_table(table_id, session_id):
    """Save a selected table for analysis."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO selected_tables (table_id, session_id) VALUES (?, ?)",
        (table_id, session_id)
    )
    conn.commit()
    conn.close()

def get_selected_tables(session_id):
    """Get all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """SELECT t.id, t.name, s.name as schema_name, c.name as catalog_name
        FROM selected_tables st
        JOIN tables t ON st.table_id = t.id
        JOIN schemas s ON t.schema_id = s.id
        JOIN catalogs c ON s.catalog_id = c.id
        WHERE st.session_id = ?""",
        (session_id,)
    )
    tables = cursor.fetchall()
    conn.close()
    return tables

def save_analysis_to_history(analysis_type, tables_analyzed, analysis_result):
    """Save an analysis to the history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO analysis_history 
        (analysis_type, tables_analyzed, analysis_result, created_at) 
        VALUES (?, ?, ?, datetime('now'))""",
        (analysis_type, tables_analyzed, analysis_result)
    )
    conn.commit()
    conn.close()

def get_analysis_history():
    """Get all analysis history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history ORDER BY created_at DESC")
    history = cursor.fetchall()
    conn.close()
    return history

def get_analysis_by_id(analysis_id):
    """Get a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history WHERE id = ?", (analysis_id,))
    analysis = cursor.fetchone()
    conn.close()
    return analysis

def delete_analysis(analysis_id):
    """Delete a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analysis_history WHERE id = ?", (analysis_id,))
    conn.commit()
    conn.close()

def save_performance_metrics(table_name, metrics):
    """Save performance metrics for a table."""
    conn = connect_db()
    cursor = conn.cursor()
    # Convert metrics to JSON string
    metrics_json = json.dumps(metrics)
    cursor.execute(
        """INSERT OR REPLACE INTO performance_metrics 
        (table_name, metrics, collected_at) 
        VALUES (?, ?, datetime('now'))""",
        (table_name, metrics_json)
    )
    conn.commit()
    conn.close()

def clear_selected_tables(session_id):
    """Clear all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM selected_tables WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()