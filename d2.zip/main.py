import os
import logging
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import json
import time

import databricks_api
import gemini_client
from config import ANALYSIS_TYPES

# Configure basic logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "ADWWorkbenchSecretKey")

# Ensure session_id is set for each user
@app.before_request
def ensure_session():
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())

# Routes
@app.route('/')
def index():
    """Home page - show schema selection UI."""
    catalogs = databricks_api.get_catalogs()
    return render_template(
        'index.html',
        title="ADW Workbench",
        catalogs=catalogs,
        analysis_types=[ANALYSIS_TYPES[key] for key in ANALYSIS_TYPES]
    )

@app.route('/get_schemas/<catalog_name>')
def get_schemas(catalog_name):
    """API endpoint to get schemas for a selected catalog."""
    schemas = databricks_api.get_schemas(catalog_name)
    return jsonify(schemas)

@app.route('/get_tables/<catalog_name>/<schema_name>')
def get_tables(catalog_name, schema_name):
    """API endpoint to get tables for a selected schema."""
    tables = databricks_api.get_tables(catalog_name, schema_name)
    # Add IDs for frontend reference
    for i, table in enumerate(tables):
        table['id'] = i + 1
    return jsonify(tables)

@app.route('/get_columns/<catalog_name>/<schema_name>/<table_name>')
def get_columns(catalog_name, schema_name, table_name):
    """API endpoint to get columns for a selected table."""
    columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
    return jsonify(columns)

@app.route('/select_table', methods=['POST'])
def select_table():
    """AJAX endpoint to select a table for analysis."""
    data = request.json
    if 'table_id' not in data:
        return jsonify({'error': 'No table_id provided'}), 400
    
    session_id = session.get('session_id')
    databricks_api.save_selected_table(data['table_id'], session_id)
    return jsonify({'success': True})

@app.route('/select_table', methods=['DELETE'])
def remove_table():
    """AJAX endpoint to remove a table from selection."""
    data = request.json
    if 'table_id' not in data:
        return jsonify({'error': 'No table_id provided'}), 400
    
    # Remove table logic would go here
    # For now, just return success
    return jsonify({'success': True})

@app.route('/get_selected_tables')
def get_selected_tables():
    """AJAX endpoint to get all selected tables."""
    session_id = session.get('session_id')
    tables = databricks_api.get_selected_tables(session_id)
    return jsonify(tables)

@app.route('/clear_selection', methods=['POST'])
def clear_selection():
    """AJAX endpoint to clear the currently selected tables."""
    session_id = session.get('session_id')
    databricks_api.clear_selected_tables(session_id)
    return jsonify({'success': True})

@app.route('/analysis', methods=['POST'])
def analysis():
    """Perform analysis on selected tables."""
    try:
        data = request.get_json(force=True)
        analysis_type = data.get('analysis_type', 'general')
        sql_query = data.get('sql_query', '')
        selected_tables = data.get('selected_tables', [])
        if not selected_tables:
            return jsonify({'error': 'Please select at least one table for analysis.'}), 400
        # Collect schema information for selected tables
        schema_data = {}
        metrics = {}
        tables_analyzed = []
        for table in selected_tables:
            full_name = table.get('fullName') or table.get('full_name')
            if not full_name:
                continue
            parts = full_name.split('.')
            if len(parts) >= 3:
                catalog_name, schema_name, table_name = parts
                columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
                table_details = databricks_api.get_table_details(catalog_name, schema_name, table_name)
                if catalog_name not in schema_data:
                    schema_data[catalog_name] = {}
                if schema_name not in schema_data[catalog_name]:
                    schema_data[catalog_name][schema_name] = {}
                schema_data[catalog_name][schema_name][table_name] = {
                    'columns': columns,
                    'details': table_details
                }
                metrics[full_name] = {
                    'table_size_bytes': table_details.get('size_bytes', 0),
                    'file_count': table_details.get('file_count', 0),
                    'format': table_details.get('format', 'unknown'),
                }
                tables_analyzed.append(full_name)
        # Generate analysis with Gemini API
        analysis_prompt = gemini_client.create_analysis_prompt(schema_data, analysis_type, sql_query)
        analysis_result = gemini_client.generate_analysis(analysis_prompt)
        # Save the analysis to history
        analysis_id = databricks_api.save_analysis_to_history(analysis_type, ', '.join(tables_analyzed), analysis_result)
        return jsonify({
            'analysis_result': analysis_result,
            'analysis_id': analysis_id,
            'metrics': metrics
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/history')
def history():
    """Show analysis history."""
    history_items = databricks_api.get_analysis_history()
    return render_template(
        'history.html',
        title="Analysis History",
        history=history_items
    )

@app.route('/history/<int:analysis_id>', methods=['GET', 'POST'])
def view_analysis(analysis_id):
    """View a specific analysis from history or run a new analysis type on the same tables."""
    if request.method == 'POST':
        # Run a new analysis on the same tables but with a different analysis type
        new_analysis_type = request.form.get('analysis_type')
        
        if not new_analysis_type:
            flash('Please select an analysis type.', 'error')
            return redirect(url_for('view_analysis', analysis_id=analysis_id))
        
        # Get the original analysis to extract table information
        original_analysis = databricks_api.get_analysis_by_id(analysis_id)
        
        if not original_analysis:
            flash('Analysis not found.', 'error')
            return redirect(url_for('history'))
        
        # Collect schema information for tables in the original analysis
        tables_analyzed = original_analysis['tables_analyzed']
        table_list = [t.strip() for t in tables_analyzed.split(',')]
        
        # Build schema data for analysis
        schema_data = {}
        metrics = {}
        
        for full_table_name in table_list:
            parts = full_table_name.split('.')
            if len(parts) >= 3:
                catalog_name, schema_name, table_name = parts
                
                # Get columns for this table
                columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
                
                # Get table details
                table_details = databricks_api.get_table_details(catalog_name, schema_name, table_name)
                
                # Add to schema data
                if catalog_name not in schema_data:
                    schema_data[catalog_name] = {}
                
                if schema_name not in schema_data[catalog_name]:
                    schema_data[catalog_name][schema_name] = {}
                
                schema_data[catalog_name][schema_name][table_name] = {
                    'columns': columns,
                    'details': table_details
                }
                
                # Add metrics
                metrics[full_table_name] = {
                    'table_size_bytes': table_details.get('size_bytes', 0),
                    'file_count': table_details.get('file_count', 0),
                    'format': table_details.get('format', 'unknown'),
                    'query_duration_ms': 2500,  # Example value
                    'queries': []  # Would come from query history
                }
        
        # Generate new analysis with Gemini API
        analysis_prompt = gemini_client.create_analysis_prompt(schema_data, new_analysis_type)
        analysis_result = gemini_client.generate_analysis(analysis_prompt)
        
        # Save the new analysis to history
        new_analysis_id = databricks_api.save_analysis_to_history(new_analysis_type, tables_analyzed, analysis_result)
        
        return render_template(
            'analysis.html',
            title=f"{new_analysis_type.title()} Analysis",
            analysis_type=new_analysis_type,
            tables_analyzed=tables_analyzed,
            analysis_result=analysis_result,
            metrics=metrics,
            analysis_id=new_analysis_id,
            from_history=True,
            analysis_types=ANALYSIS_TYPES
        )
    else:
        # View existing analysis
        analysis = databricks_api.get_analysis_by_id(analysis_id)
        
        if not analysis:
            flash('Analysis not found.', 'error')
            return redirect(url_for('history'))
        
        # Get metrics for tables in this analysis
        tables_analyzed = analysis['tables_analyzed']
        table_list = [t.strip() for t in tables_analyzed.split(',')]
        
        metrics = {}
        for table_name in table_list:
            # In a real implementation, we would fetch metrics from the database
            # Here we'll create some example metrics
            parts = table_name.split('.')
            if len(parts) >= 3:
                catalog_name, schema_name, table_name = parts
                table_details = databricks_api.get_table_details(catalog_name, schema_name, table_name)
                
                metrics[table_name] = {
                    'table_size_bytes': table_details.get('size_bytes', 0),
                    'file_count': table_details.get('file_count', 0),
                    'format': table_details.get('format', 'unknown'),
                    'query_duration_ms': 2500,  # Example value
                    'queries': []  # Would come from query history
                }
        
        return render_template(
            'analysis.html',
            title=f"{analysis['analysis_type'].title()} Analysis",
            analysis_type=analysis['analysis_type'],
            tables_analyzed=analysis['tables_analyzed'],
            analysis_result=analysis['analysis_result'],
            metrics=metrics,
            analysis_id=analysis_id,
            from_history=True,
            analysis_date=analysis['created_at'],
            analysis_types=ANALYSIS_TYPES
        )

@app.route('/history/delete/<int:analysis_id>', methods=['POST'])
def delete_analysis(analysis_id):
    """Delete a specific analysis from history."""
    result = databricks_api.delete_analysis(analysis_id)
    
    if result:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Failed to delete analysis'})

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    # Initialize database on first run
    databricks_api.init_db()
    # Run app with debugging enabled
    app.run(debug=True, host='0.0.0.0')