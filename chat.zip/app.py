from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'whatsapp-style-app'
DB = 'instance/inventory_new.db'

# ----- Utility Functions -----
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def get_or_create_customer(phone, name=None, email=None, address=None):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM customer WHERE phone=?", (phone,))
    customer = cur.fetchone()
    if not customer and name:
        cur.execute("INSERT INTO customer (name, phone, email, address) VALUES (?, ?, ?, ?)", (name, phone, email, address))
        conn.commit()
        customer = cur.execute("SELECT * FROM customer WHERE phone=?", (phone,)).fetchone()
    conn.close()
    return customer

def get_or_create_supplier(phone, name=None, email=None, contact=None, address=None):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM supplier WHERE phone=?", (phone,))
    supplier = cur.fetchone()
    if not supplier and name:
        cur.execute("INSERT INTO supplier (name, phone, email, contact, address) VALUES (?, ?, ?, ?, ?)", (name, phone, email, contact, address))
        conn.commit()
        supplier = cur.execute("SELECT * FROM supplier WHERE phone=?", (phone,)).fetchone()
    conn.close()
    return supplier

# ----- Routes -----
@app.route('/')
def home():
    return redirect('/customers')

# -------- CUSTOMER FLOW --------
@app.route('/customers')
def customers():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM customer")
    users = cur.fetchall()
    conn.close()
    return render_template("overview.html", users=users, user_type='customer')

@app.route('/customer/<int:id>', methods=['GET', 'POST'])
def customer_chat(id):
    session_key = f'customer_{id}_messages'
    if session_key not in session:
        session[session_key] = []

    conn = get_db()
    cur = conn.cursor()
    customer = cur.execute("SELECT * FROM customer WHERE id=?", (id,)).fetchone()

    if not customer:
        return "Customer not found", 404

    if request.method == 'POST':
        msg = request.form['message']
        session[session_key].append({'from': 'user', 'text': msg})

        if 'c_stage' not in session:
            session['c_stage'] = 'select_products'
            products = conn.execute("SELECT * FROM product WHERE quantity > 0").fetchall()
            session['c_products'] = [dict(p) for p in products]
            session['c_cart'] = []
            session['c_current_index'] = 0
            session.modified = True

            # Create product menu
            product_menu = "Available products:\n"
            for index, product in enumerate(products):
                product_menu += f"{index + 1}. {product['name']} (Available: {product['quantity']}, Price: ₹{product['price']})\n"
            product_menu += "Please select the product numbers you want (e.g., 1,3):"
            session[session_key].append({'from': 'bot', 'text': product_menu})
        else:
            stage = session['c_stage']
            if stage == 'select_products':
                # Get valid indices, handle empty input
                selected_indices = [int(i.strip()) - 1 for i in msg.split(',') if i.strip().isdigit()]
                
                if not selected_indices:
                    session[session_key].append({'from': 'bot', 'text': "Please enter at least one valid product number."})
                    return render_template("chat.html", messages=session[session_key], user_type='customer')
                    
                # Validate indices are in range
                if any(i < 0 or i >= len(session['c_products']) for i in selected_indices):
                    session[session_key].append({'from': 'bot', 'text': "Invalid selection. Please enter valid product numbers."})
                    return render_template("chat.html", messages=session[session_key], user_type='customer')

                session['c_selected_products'] = selected_indices
                session['c_cart'] = []
                session['c_current_index'] = 0
                session['c_stage'] = 'ask_quantities'
                session.modified = True

                # Ask for quantities only if we have valid products
                first_product = session['c_products'][selected_indices[0]]
                session[session_key].append({'from': 'bot', 'text': f"How many units of {first_product['name']}?"})
            elif stage == 'ask_quantities':
                quantity = int(msg)
                product_index = session['c_selected_products'][session['c_current_index']]
                product = session['c_products'][product_index]

                if quantity > product['quantity']:
                    session[session_key].append({'from': 'bot', 'text': f"Only {product['quantity']} units available for {product['name']}. How many?"})
                else:
                    session['c_cart'].append({
                        'product_id': product['id'],
                        'name': product['name'],
                        'price': product['price'],
                        'quantity': quantity
                    })
                    session['c_current_index'] += 1
                    if session['c_current_index'] >= len(session['c_selected_products']):
                        total = sum([p['price'] * p['quantity'] for p in session['c_cart']])
                        cur.execute("INSERT INTO customer_order (total_amount) VALUES (?)",
                                    (total,))
                        order_id = cur.lastrowid
                        for item in session['c_cart']:
                            cur.execute("INSERT INTO order_item (product_id, quantity, price, customer_order_id) VALUES (?, ?, ?, ?)",
                                        (item['product_id'], item['quantity'], item['price'], order_id))
                            cur.execute("UPDATE product SET quantity = quantity - ? WHERE id = ?", (item['quantity'], item['product_id']))
                        conn.commit()
                        session[session_key].append({'from': 'bot', 'text': f"Order placed for {len(session['c_cart'])} products totaling ₹{total}."})
                        session.pop('c_stage')
                        session.pop('c_products')
                        session.pop('c_cart')
                        session.pop('c_selected_products')
                        session.pop('c_current_index')
                    else:
                        next_product = session['c_products'][session['c_selected_products'][session['c_current_index']]]['name']
                        session[session_key].append({'from': 'bot', 'text': f"How many units of {next_product}?"})
                session.modified = True

    return render_template("chat.html", messages=session[session_key], user_type='customer')

# -------- SUPPLIER FLOW --------
@app.route('/suppliers')
def suppliers():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM supplier")
    users = cur.fetchall()
    conn.close()
    return render_template("overview.html", users=users, user_type='supplier')

@app.route('/supplier/<int:id>', methods=['GET', 'POST'])
def supplier_chat(id):
    session_key = f'supplier_{id}_messages'
    if session_key not in session:
        session[session_key] = []

    conn = get_db()
    cur = conn.cursor()
    supplier = cur.execute("SELECT * FROM supplier WHERE id=?", (id,)).fetchone()

    if not supplier:
        return "Supplier not found", 404

    if request.method == 'POST':
        msg = request.form['message']
        session[session_key].append({'from': 'user', 'text': msg})

        if 's_stage' not in session:
            session['s_stage'] = 'select_products'
            products = conn.execute("SELECT * FROM product").fetchall()
            session['s_products'] = [dict(p) for p in products]
            session['s_cart'] = []
            session['s_current_index'] = 0
            session.modified = True

            # Create product menu
            product_menu = "Available products:\n"
            for index, product in enumerate(products):
                product_menu += f"{index + 1}. {product['name']} (Current Stock: {product['quantity']}, Price: ₹{product['price']})\n"
            product_menu += "Please select the product numbers to add (e.g., 1,3):"
            session[session_key].append({'from': 'bot', 'text': product_menu})
        else:
            stage = session['s_stage']
            if stage == 'select_products':
                selected_indices = msg.split(',')
                selected_indices = [int(i.strip()) - 1 for i in selected_indices if i.strip().isdigit()]

                # Validate selection
                if any(i < 0 or i >= len(session['s_products']) for i in selected_indices):
                    session[session_key].append({'from': 'bot', 'text': "Invalid selection. Please try again."})
                else:
                    session['s_selected_products'] = selected_indices
                    session['s_cart'] = []
                    session['s_current_index'] = 0
                    session['s_stage'] = 'ask_quantities'
                    session.modified = True

                    # Ask for quantities
                    first_product = session['s_products'][selected_indices[0]]
                    session[session_key].append({'from': 'bot', 'text': f"How many units to add for {first_product['name']}?"})
            elif stage == 'ask_quantities':
                quantity = int(msg)
                product_index = session['s_selected_products'][session['s_current_index']]
                product = session['s_products'][product_index]

                session['s_cart'].append({
                    'product_id': product['id'],
                    'name': product['name'],
                    'price': product['price'],
                    'quantity': quantity
                })
                session['s_current_index'] += 1
                if session['s_current_index'] >= len(session['s_selected_products']):
                    total = sum([p['price'] * p['quantity'] for p in session['s_cart']])
                    cur.execute("INSERT INTO supplier_order (total_amount) VALUES (?)",
                                (total,))
                    order_id = cur.lastrowid
                    for item in session['s_cart']:
                        cur.execute("INSERT INTO order_item (product_id, quantity, price, supplier_order_id) VALUES (?, ?, ?, ?)",
                                    (item['product_id'], item['quantity'], item['price'], order_id))
                        cur.execute("UPDATE product SET quantity = quantity + ? WHERE id = ?", (item['quantity'], item['product_id']))
                    conn.commit()
                    session[session_key].append({'from': 'bot', 'text': f"Stock added for {len(session['s_cart'])} products totaling ₹{total}."})
                    session.pop('s_stage')
                    session.pop('s_products')
                    session.pop('s_cart')
                    session.pop('s_selected_products')
                    session.pop('s_current_index')
                else:
                    next_product = session['s_products'][session['s_selected_products'][session['s_current_index']]]['name']
                    session[session_key].append({'from': 'bot', 'text': f"How many units to add for {next_product}?"})
                session.modified = True

    return render_template("chat.html", messages=session[session_key], user_type='supplier')

if __name__ == '__main__':
    app.run(debug=True)
