from flask import Blueprint, render_template, request, jsonify, current_app
from models import OptimizationPlan, Flight, Aircraft, Crew
from app import db
from datetime import datetime
import json
from services.optimization_service import run_optimization, get_optimization_summary
from services.gemini_service import get_gemini_response

optimizer_bp = Blueprint('optimizer', __name__)

@optimizer_bp.route('/optimizer')
def optimizer():
    """Render the optimizer page"""
    plans = OptimizationPlan.query.order_by(OptimizationPlan.created_at.desc()).limit(10).all()
    # Get counts for displaying in the UI
    flights_count = Flight.query.count()
    aircraft_count = Aircraft.query.count()
    crew_count = Crew.query.count()
    
    return render_template('optimizer.html', 
                          plans=plans,
                          flights_count=flights_count,
                          aircraft_count=aircraft_count,
                          crew_count=crew_count,
                          active_page='optimizer')

@optimizer_bp.route('/api/plans', methods=['GET'])
def get_plans():
    """API endpoint to get all optimization plans"""
    plans = OptimizationPlan.query.order_by(OptimizationPlan.created_at.desc()).all()
    result = []
    for plan in plans:
        result.append({
            'id': plan.id,
            'name': plan.name,
            'description': plan.description,
            'scenario': plan.scenario,
            'created_at': plan.created_at.isoformat(),
            'status': plan.status,
            'score': plan.score,
            'version': plan.version
        })
    return jsonify(result)

@optimizer_bp.route('/api/plans/<int:plan_id>', methods=['GET'])
def get_plan(plan_id):
    """API endpoint to get a specific optimization plan"""
    plan = OptimizationPlan.query.get_or_404(plan_id)
    return jsonify({
        'id': plan.id,
        'name': plan.name,
        'description': plan.description,
        'scenario': plan.scenario,
        'constraints': plan.constraints,
        'objective_weights': plan.objective_weights,
        'created_at': plan.created_at.isoformat(),
        'status': plan.status,
        'results': plan.results,
        'score': plan.score,
        'execution_time': plan.execution_time,
        'version': plan.version
    })

@optimizer_bp.route('/api/plans', methods=['POST'])
def create_plan():
    """API endpoint to create a new optimization plan"""
    data = request.json
    
    if not data or 'name' not in data or 'scenario' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Set default weights if not provided
    weights = data.get('objective_weights', None)
    if not weights:
        weights = current_app.config['OPTIMIZATION_WEIGHTS']
    
    # Create the plan
    plan = OptimizationPlan(
        name=data['name'],
        description=data.get('description', ''),
        scenario=data['scenario'],
        constraints=data.get('constraints', {}),
        objective_weights=weights,
        status="draft"
    )
    
    db.session.add(plan)
    db.session.commit()
    
    return jsonify({
        'id': plan.id,
        'name': plan.name,
        'description': plan.description,
        'scenario': plan.scenario,
        'constraints': plan.constraints,
        'objective_weights': plan.objective_weights,
        'created_at': plan.created_at.isoformat(),
        'status': plan.status,
        'version': plan.version
    })

@optimizer_bp.route('/api/plans/<int:plan_id>/run', methods=['POST'])
def run_plan(plan_id):
    """API endpoint to run an optimization plan"""
    plan = OptimizationPlan.query.get_or_404(plan_id)
    
    if plan.status == "running":
        return jsonify({'error': 'Plan is already running'}), 400
    
    # Update plan status
    plan.status = "running"
    db.session.commit()
    
    try:
        # Run the optimization
        results, score, execution_time = run_optimization(plan)
        
        # Update the plan with results
        plan.status = "completed"
        plan.results = results
        plan.score = score
        plan.execution_time = execution_time
        db.session.commit()
        
        return jsonify({
            'id': plan.id,
            'status': plan.status,
            'results': plan.results,
            'score': plan.score,
            'execution_time': plan.execution_time
        })
    
    except Exception as e:
        current_app.logger.error(f"Error running optimization: {str(e)}")
        plan.status = "failed"
        db.session.commit()
        return jsonify({'error': str(e)}), 500

@optimizer_bp.route('/api/plans/<int:plan_id>/clone', methods=['POST'])
def clone_plan(plan_id):
    """API endpoint to clone an optimization plan with a new version"""
    original_plan = OptimizationPlan.query.get_or_404(plan_id)
    
    # Create a new plan as a clone of the original
    new_plan = OptimizationPlan(
        name=original_plan.name,
        description=original_plan.description,
        scenario=original_plan.scenario,
        constraints=original_plan.constraints,
        objective_weights=original_plan.objective_weights,
        status="draft",
        version=original_plan.version + 1
    )
    
    db.session.add(new_plan)
    db.session.commit()
    
    return jsonify({
        'id': new_plan.id,
        'name': new_plan.name,
        'description': new_plan.description,
        'scenario': new_plan.scenario,
        'constraints': new_plan.constraints,
        'objective_weights': new_plan.objective_weights,
        'created_at': new_plan.created_at.isoformat(),
        'status': new_plan.status,
        'version': new_plan.version
    })

@optimizer_bp.route('/api/plans/<int:plan_id>/summary', methods=['GET'])
def get_plan_summary(plan_id):
    """API endpoint to get a natural language summary of an optimization plan"""
    plan = OptimizationPlan.query.get_or_404(plan_id)
    
    if plan.status != "completed" or not plan.results:
        return jsonify({'error': 'Plan has not been completed yet'}), 400
    
    try:
        summary = get_optimization_summary(plan)
        return jsonify({'summary': summary})
    except Exception as e:
        current_app.logger.error(f"Error generating plan summary: {str(e)}")
        return jsonify({'error': str(e)}), 500

@optimizer_bp.route('/api/generate-flowchart', methods=['POST'])
def generate_flowchart():
    """API endpoint to generate a mermaid.js flowchart for an optimization scenario"""
    data = request.json
    
    if not data or 'scenario' not in data:
        return jsonify({'error': 'No scenario provided'}), 400
    
    scenario = data['scenario']
    
    with open('prompts/optimizer_flow.txt', 'r') as f:
        prompt = f.read()
    
    full_prompt = prompt + "\n\nScenario: " + scenario
    
    try:
        # Use the Gemini service to get the response
        # First get the raw response
        from services.gemini_service import get_gemini_response, clean_text
        
        raw_response = get_gemini_response(full_prompt)
        
        # Apply special Mermaid-specific cleaning
        cleaned_flowchart = clean_text(raw_response, is_mermaid=True)
        
        # Log the generated flowchart for debugging
        current_app.logger.info(f"Generated flowchart (first 100 chars): {cleaned_flowchart[:100]}...")
        
        return jsonify({'flowchart': cleaned_flowchart})
    except Exception as e:
        current_app.logger.error(f"Error generating flowchart: {str(e)}")
        return jsonify({'error': str(e)}), 500
