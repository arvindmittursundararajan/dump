import pytest
from ducklake_browser.app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        yield client

def login(client, username, password):
    return client.post('/login', data={'username': username, 'password': password}, follow_redirects=True)

def test_login_logout(client):
    rv = login(client, 'admin', 'ducklake')
    assert b'Welcome to DuckLake Browser' in rv.data
    rv = client.get('/logout', follow_redirects=True)
    assert b'Login' in rv.data

def test_home_dashboard(client):
    login(client, 'admin', 'ducklake')
    rv = client.get('/')
    assert b'Catalogs' in rv.data
    assert b'Tables' in rv.data

def test_sql_editor(client):
    login(client, 'admin', 'ducklake')
    rv = client.post('/sql', data={'sql': 'SELECT 1 as test_col;'}, follow_redirects=True)
    assert b'test_col' in rv.data
    assert b'1' in rv.data

def test_catalog(client):
    login(client, 'admin', 'ducklake')
    rv = client.get('/catalog')
    assert b'Data Catalog' in rv.data

def test_api_sql(client):
    login(client, 'admin', 'ducklake')
    rv = client.post('/api/sql', json={'sql': 'SELECT 1 as test_col;'}, follow_redirects=True)
    assert rv.is_json
    assert rv.json['success']
    assert rv.json['data']['columns'] == ['test_col']
    assert rv.json['data']['rows'][0][0] == 1 