# Debrief

## Overview
The Debrief module provides comprehensive incident analysis and documentation capabilities, enabling airlines to learn from operational challenges and improve future responses. It captures the timeline, root causes, and lessons learned from disruption events, creating an institutional knowledge base for continuous improvement.

## URL Route
- Main URL: `/debrief` (accessible through the top navigation bar)

## Key Features

### 1. Incident Management
- **Incident Recording**: Create and maintain records of operational disruptions
- **Severity Classification**: Categorize incidents by impact level
- **Timeline Tracking**: Chronological record of events during incidents
- **Status Monitoring**: Track open, in-progress, and resolved incidents

### 2. Root Cause Analysis
- **AI-Assisted Analysis**: Gemini-powered identification of underlying causes
- **Contributing Factor Mapping**: Visualize relationships between causes
- **Systematic Issue Identification**: Recognize patterns across incidents
- **Preventability Assessment**: Determine if the incident could have been avoided

### 3. Timeline Visualization
- **Event Sequencing**: Visual representation of the incident timeline
- **Critical Path Identification**: Highlight key decision points
- **Time-based Correlation**: Connect related events across operational areas
- **Interactive Timeline**: Explore details of specific events

### 4. Lessons Learned Documentation
- **Action Item Creation**: Document required follow-up steps
- **Process Improvement Suggestions**: AI-generated improvement recommendations
- **Knowledge Management**: Organize and preserve institutional knowledge
- **Cross-Referencing**: Link related incidents and common themes

## User Interface Components

### Incident List View
- Categorized list of recorded incidents
- Severity indicators with color-coding
- Quick filters for incident types and status
- Search functionality for specific incidents

### Timeline Panel (Left Side, 20% width)
- Chronological display of events
- Color-coded event categories
- Expand/collapse functionality for details
- Add new event capability

### Incident Summary Panel (Center, 30% width)
- Incident overview cards
- Start/end time information
- Severity and category indicators
- Selection mechanism for detailed view

### Detail Panel (Right Side, 50% width)
- Comprehensive incident information
- Timeline visualization using Mermaid.js
- Affected entities summary
- Root cause and lessons learned sections
- Action buttons for analysis generation

## Specialized Analysis Areas

### 1. Unaccompanied Minor Incidents
- **Protection Measure Effectiveness**: Assess safety protocols for minors
- **Communication Analysis**: Review information flow to guardians
- **Staff Response Evaluation**: Measure effectiveness of employee actions
- **Policy Compliance**: Verify adherence to airline policies

### 2. Irregular Operations (IROPS)
- **Delay Propagation Analysis**: Trace cascading effects through network
- **Resource Allocation Review**: Evaluate distribution of resources during disruption
- **Recovery Timeline Analysis**: Measure time to return to normal operations
- **Passenger Impact Assessment**: Quantify effect on customer experience

### 3. Crew-Related Incidents
- **Duty Time Compliance**: Verify adherence to regulatory limits
- **Crew Communication Analysis**: Assess information flow to crew members
- **Reserve Utilization Evaluation**: Review use of reserve crews
- **Crew Recovery Effectiveness**: Measure efficiency of crew recovery efforts

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/incidents` | GET | Retrieve all incidents |
| `/api/incidents` | POST | Create a new incident |
| `/api/incidents/<id>` | GET | Get specific incident details |
| `/api/incidents/<id>/timeline` | POST | Add event to incident timeline |
| `/api/incidents/<id>/root-cause` | POST | Generate root cause analysis |
| `/api/incidents/<id>/postmortem` | POST | Generate postmortem report |
| `/api/generate-timeline-chart` | POST | Create a Mermaid timeline visualization |

## Database Models
The Debrief module uses the `Incident` model with the following key fields:
- `id`: Unique identifier
- `title`: Incident title
- `description`: Detailed incident description
- `start_time`: When the incident began
- `end_time`: When the incident was resolved
- `category`: Type classification
- `severity`: Impact level assessment
- `timeline`: JSON array of chronological events
- `affected_entities`: JSON data of impacted flights, crew, etc.
- `root_cause`: Analysis of underlying causes
- `resolution`: How the incident was resolved
- `lessons_learned`: Knowledge gained for future incidents
- `optimization_plan_id`: Link to any related optimization plans

## Technical Implementation
- Uses Flask routes in `routes/debrief.py`
- Implements timeline visualization with Mermaid.js
- Leverages Gemini API for analysis generation
- Uses the `services/gemini_service.py` for AI interactions

## Incident Creation Workflow
1. User clicks "New Incident" button
2. Form appears to collect basic information:
   - Title
   - Description
   - Start time
   - End time (optional)
   - Category
   - Severity
3. On submission, incident record is created
4. Timeline is initialized with the first event
5. User is directed to the detail view for further documentation

## Analysis Generation Process
1. User selects an incident to analyze
2. Options for "Generate Root Cause" or "Generate Lessons Learned"
3. System gathers incident details and timeline
4. Request is sent to Gemini API with appropriate prompt
5. AI-generated analysis is displayed for review
6. User can accept or regenerate the analysis
7. Accepted analysis is saved to the incident record

## Best Practices
1. Create incident records as soon as disruptions occur
2. Document timeline events in real-time when possible
3. Be specific about affected entities and impact
4. Focus on systemic issues rather than individual blame
5. Create actionable lessons learned with clear ownership
6. Review past incidents when planning new processes
7. Use standardized categorization for better trend analysis