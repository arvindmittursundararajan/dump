import json
import time
from config import ARCHITECTURAL_STANDARDS, DIAGRAM_TEMPLATES
from client import get_spark_assist_analysis
from utils import get_sample_analysis

# API Configuration - Use config.py for URL

# Add a global prompt suffix for strict HTML enforcement
LLM_HTML_SUFFIX = """
Respond ONLY in valid, well-structured HTML.
- Do NOT use markdown, plain text, or code blocks.
- Do NOT include <html>, <head>, or <body> tags—only the content inside the body.
- Do NOT escape HTML (no &lt; or &gt;).
- Do NOT wrap your response in triple backticks or language tags.
- Start your response with a <div> or <section>.
- Use <h2>, <ul>, <li>, <b>, <span style='color: #222;'>, <span style='color: #333;'>, <span style='color: #d32f2f;'>, <span style='color: #388e3c;'>, etc.
- Make the report visually appealing and easy to read.
- If you must include code, use <pre><code> blocks (not markdown).
- If you cannot answer, say so in HTML.
- Use only dark or high-contrast colors for all text (never white or light shades).
"""

def create_analysis_prompt(schema_metadata, analysis_type, sql_query=None, tree_structure=None):
    """
    Creates a prompt for the Spark Assist AI model based on schema metadata, analysis type, and Tree-of-Table structure.
    Returns a prompt with HTML formatting only (no markdown).
    
    Args:
        schema_metadata (dict): Dictionary containing schema information
        analysis_type (str): Type of analysis to perform
        sql_query (str): Optional SQL query to include in the analysis
        tree_structure (dict): Optional Tree-of-Table hierarchical structure
    
    Returns:
        str: Formatted prompt for the AI model
    """
    schema_info = json.dumps(schema_metadata, indent=2)
    base_prompt = f'''
You are a database schema expert analyzing schema information from a Databricks database. Provide a detailed {analysis_type} analysis of the following database objects:

<h2>Schema Information:</h2>
<pre><code class="language-json">{schema_info}</code></pre>
'''
    if sql_query:
        base_prompt += f'''
<h2>SQL Query for Analysis:</h2>
<pre><code class="language-sql">{sql_query}</code></pre>
'''
    if tree_structure:
        tree_info = json.dumps(tree_structure, indent=2)
        base_prompt += f'''
<h2>Tree-of-Table Hierarchical Structure:</h2>
<pre><code class="language-json">{tree_info}</code></pre>
<p>This hierarchical structure represents the decomposition of large tables into manageable chunks for analysis.</p>
'''
    
    # Add specific instructions based on analysis type
    if analysis_type == "general":
        base_prompt += """
<h2>Please provide a comprehensive schema analysis that includes:</h2>
<ul>
    <li><b>1.</b> Overview of the schema structure</li>
    <li><b>2.</b> Assessment of entity relationships</li>
    <li><b>3.</b> Primary and foreign key analysis</li>
    <li><b>4.</b> Data type assessments</li>
    <li><b>5.</b> Recommendations for schema improvements</li>
</ul>
"""
    elif analysis_type == "performance":
        base_prompt += """
<h2>Please provide a performance-focused analysis that includes:</h2>
<ul>
    <li><b>1.</b> Identification of potential performance bottlenecks</li>
    <li><b>2.</b> Query optimization opportunities</li>
    <li><b>3.</b> Indexing recommendations</li>
    <li><b>4.</b> Partitioning and clustering suggestions</li>
    <li><b>5.</b> Materialized view recommendations</li>
</ul>
"""
    elif analysis_type == "normalization":
        base_prompt += """
<h2>Please provide a normalization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Current normalization level assessment (1NF, 2NF, 3NF, etc.)</li>
    <li><b>2.</b> Data redundancy identification</li>
    <li><b>3.</b> Functional dependency analysis</li>
    <li><b>4.</b> Denormalization considerations</li>
    <li><b>5.</b> Recommendations for improving normalization</li>
</ul>
"""
    elif analysis_type == "relationships":
        base_prompt += """
<h2>Please provide a relationships-focused analysis that includes:</h2>
<ul>
    <li><b>1.</b> Entity relationship mapping</li>
    <li><b>2.</b> Identifying missing relationships</li>
    <li><b>3.</b> Assessment of referential integrity</li>
    <li><b>4.</b> Cardinality analysis</li>
    <li><b>5.</b> Recommendations for relationship improvements</li>
</ul>
"""
    elif analysis_type == "naming":
        base_prompt += """
<h2>Please provide a naming convention analysis that includes:</h2>
<ul>
    <li><b>1.</b> Consistency assessment of naming patterns</li>
    <li><b>2.</b> Table naming convention evaluation</li>
    <li><b>3.</b> Column naming convention evaluation</li>
    <li><b>4.</b> Identifier clarity and meaning</li>
    <li><b>5.</b> Recommendations for naming improvements</li>
</ul>
"""
    elif analysis_type == "standards":
        base_prompt += """
<h2>Please provide a standards compliance analysis that includes:</h2>
<ul>
    <li><b>1.</b> Adherence to industry best practices</li>
    <li><b>2.</b> SQL standard compliance</li>
    <li><b>3.</b> Databricks-specific conventions evaluation</li>
    <li><b>4.</b> Documentation and comment quality</li>
    <li><b>5.</b> Recommendations for improved standards compliance</li>
</ul>
"""
    elif analysis_type == "denormalization":
        base_prompt += """
<h2>Please provide a denormalization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Current normalization level assessment</li>
    <li><b>2.</b> Denormalization opportunities identification</li>
    <li><b>3.</b> Performance vs. storage trade-offs analysis</li>
    <li><b>4.</b> Query pattern analysis for denormalization benefits</li>
    <li><b>5.</b> Recommendations for strategic denormalization</li>
    <li><b>6.</b> Impact on data consistency and maintenance</li>
</ul>
"""
    elif analysis_type == "data_quality":
        base_prompt += create_data_quality_prompt()
    elif analysis_type == "security":
        base_prompt += create_security_prompt()
    elif analysis_type == "data_types":
        base_prompt += create_data_types_prompt()
    elif analysis_type == "partitioning":
        base_prompt += create_partitioning_prompt()
    elif analysis_type == "constraints":
        base_prompt += create_constraints_prompt()
    elif analysis_type == "documentation":
        base_prompt += create_documentation_prompt()
    elif analysis_type == "governance":
        base_prompt += create_governance_prompt()
    elif analysis_type == "pii_detection":
        base_prompt += create_pii_detection_prompt()
    elif analysis_type == "pci_compliance":
        base_prompt += create_pci_compliance_prompt()
    elif analysis_type == "gdpr_compliance":
        base_prompt += create_gdpr_compliance_prompt()
    elif analysis_type == "ml_readiness":
        base_prompt += create_ml_readiness_prompt()
    elif analysis_type == "data_lineage":
        base_prompt += create_data_lineage_prompt()
    elif analysis_type == "cost_optimization":
        base_prompt += create_cost_optimization_prompt()
    elif analysis_type == "data_catalog":
        base_prompt += create_data_catalog_prompt()
    elif analysis_type == "etl_pipeline":
        base_prompt += create_etl_pipeline_prompt()
    elif analysis_type == "data_governance":
        base_prompt += create_data_governance_prompt()
    elif analysis_type == "audit_trail":
        base_prompt += create_audit_trail_prompt()
    elif analysis_type == "data_retention":
        base_prompt += create_data_retention_prompt()
    elif analysis_type == "disaster_recovery":
        base_prompt += create_disaster_recovery_prompt()
    elif analysis_type == "data_migration":
        base_prompt += create_data_migration_prompt()
    
    # Add diagram template if available for this analysis type
    if analysis_type in DIAGRAM_TEMPLATES:
        diagram_info = DIAGRAM_TEMPLATES[analysis_type]
        base_prompt += """

<h2>DIAGRAM REQUIREMENT:</h2>
You MUST include a Mermaid.js diagram in your response to visualize the analysis results.

<h3>Diagram Type:</h3> """ + diagram_info['description'] + """

<h3>Diagram Template (use as starting point, adapt to actual schema):</h3>
<pre><code class="language-mermaid">""" + diagram_info['template'] + """</code></pre>

<h3>CRITICAL DIAGRAM RULES:</h3>
<ul>
    <li>Use EXACT Mermaid.js syntax - no special characters or formatting</li>
    <li>Replace placeholder table names with actual tables from the schema</li>
    <li>Use proper relationship syntax: ||--o{ for one-to-many, ||--|| for one-to-one, }o--o{ for many-to-many</li>
    <li>Include actual column names from the schema</li>
    <li>Show relationships, dependencies, or processes as appropriate for the analysis type</li>
    <li>Place the diagram in a <div class="mermaid-diagram"> block in your HTML response</li>
    <li>DO NOT add any special characters, quotes, or formatting that could break Mermaid rendering</li>
    <li>If multiple diagrams are needed, create them separately</li>
    <li>IMPORTANT: The diagram MUST be rendered as an actual visual diagram, not just text</li>
    <li>Use <br/> for line breaks in node labels to make them more readable</li>
    <li>FORBIDDEN: In ER diagrams, DO NOT use any 'classDef', 'class', 'PRIMARY KEY', or 'FOREIGN KEY' lines. Only use the format: TABLE_NAME { datatype column_name PK/FK ... }</li>
    <li>If you include any line with 'classDef', 'class', 'PRIMARY KEY', or 'FOREIGN KEY' in an ER diagram, your answer will be rejected.</li>
    <li>For flowcharts and other diagrams, use classDef syntax: classDef tableStyle fill:#f9f,stroke:#333,stroke-width:2px</li>
    <li>Use subgraphs to group related processes or data sources</li>
</ul>

<h3>WARNING:</h3>
If you include any forbidden lines in an ER diagram, your answer will be rejected and not used.

<h3>EXAMPLE OF CORRECT DIAGRAM PLACEMENT:</h3>
<pre><code class="language-html">&lt;h2&gt;Visual Diagram&lt;/h2&gt;
&lt;div class="mermaid-diagram"&gt;
erDiagram
    CUSTOMER {
        string id PK
        string name
        string email
    }
    
    ORDER {
        string id PK
        string customer_id FK
        string order_date
    }
    
    CUSTOMER ||--o{ ORDER : "places"
&lt;/div&gt;</code></pre>

<h3>CRITICAL: DO NOT create empty <div class="mermaid-diagram"></div> - it must contain diagram code!</h3>

<h3>MANDATORY: Include at least ONE diagram in your response. The diagram should:</h3>
<ul>
    <li>Be placed in a dedicated section with a clear heading like "## Visual Diagram"</li>
    <li>Use actual table names from the provided schema</li>
    <li>Include proper styling and colors</li>
    <li>Be comprehensive enough to show the key relationships or processes</li>
    <li>Be wrapped in <div class="mermaid-diagram"> tags</li>
    <li>CRITICAL: The <div class="mermaid-diagram"> MUST contain the actual diagram code, not be empty</li>
</ul>

<h3>EXAMPLE OF CORRECT DIAGRAM PLACEMENT:</h3>
<pre><code class="language-html">&lt;h2&gt;Visual Diagram&lt;/h2&gt;
&lt;div class="mermaid-diagram"&gt;
erDiagram
    CUSTOMER {
        string id PK
        string name
        string email
    }
    ORDER {
        string id PK
        string customer_id FK
        string status
    }
    CUSTOMER ||--o{ ORDER : places
    
    classDef tableStyle fill:#f9f,stroke:#333,stroke-width:2px
    class CUSTOMER,ORDER tableStyle
&lt;/div&gt;</code></pre>

<h3>CRITICAL: DO NOT create empty <div class="mermaid-diagram"></div> - it must contain diagram code!</h3>
"""

    # General formatting instructions
    base_prompt += """
<h2>Format your response as HTML with these elements:</h2>
<ul>
    <li>Use <h1>, <h2>, <h3> for headings</li>
    <li>Use <ul>, <ol>, <li> for lists</li>
    <li>Use <table>, <tr>, <th>, <td> for tabular data</li>
    <li>Use <code> and <pre> for SQL examples</li>
    <li>Add emojis for visual appeal (e.g., 📊, 🔍, ✅, ⚠️, 💡)</li>
    <li>Use color coding: <span style="color: red;"> for issues, <span style="color: green;"> for good practices</li>
    <li>Include Mermaid.js diagrams in <div class="mermaid"> blocks as specified above</li>
</ul>

<h2>Make your response informative, specific, and actionable.</h2>
"""
    base_prompt += LLM_HTML_SUFFIX
    return base_prompt

def create_data_quality_prompt():
    """Create data quality assessment prompt"""
    return """
<h2>Please provide a comprehensive data quality assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Data Completeness Analysis** 📊</li>
    <li><b>2.</b> **Data Accuracy Assessment** ✅</li>
    <li><b>3.</b> **Data Consistency Review** 🔄</li>
    <li><b>4.</b> **Data Timeliness Evaluation** ⏰</li>
    <li><b>5.</b> **Data Lineage Tracking** 🛤️</li>
    <li><b>6.</b> **Data Quality Metrics** 📈</li>
</ul>
<p>Focus on actionable insights and specific recommendations for improving data quality.</p>
"""

def create_security_prompt():
    """Create security and privacy analysis prompt"""
    return """
<h2>Please provide a comprehensive security and privacy analysis that includes:</h2>
<ul>
    <li><b>1.</b> **Data Encryption Assessment** 🔐</li>
    <li><b>2.</b> **Access Control Analysis** 🚪</li>
    <li><b>3.</b> **Audit Trail Evaluation** 📝</li>
    <li><b>4.</b> **Data Masking Assessment** 🎭</li>
    <li><b>5.</b> **Privacy Compliance Review** 🛡️</li>
    <li><b>6.</b> **Security Risk Assessment** ⚠️</li>
</ul>
<p>Focus on security best practices and compliance requirements.</p>
"""

def create_scalability_prompt():
    """Create scalability assessment prompt"""
    return """
<h2>Please provide a comprehensive scalability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Horizontal Scaling Analysis** ↔️</li>
    <li><b>2.</b> **Vertical Scaling Assessment** ↕️</li>
    <li><b>3.</b> **Data Distribution Strategy** 📊</li>
    <li><b>4.</b> **Performance Scaling** ⚡</li>
    <li><b>5.</b> **Capacity Planning** 📈</li>
    <li><b>6.</b> **Scalability Recommendations** 💡</li>
</ul>
<p>Focus on scalable architecture patterns and growth strategies.</p>
"""

def create_maintainability_prompt():
    """Create maintainability review prompt"""
    return """
<h2>Please provide a comprehensive maintainability review that includes:</h2>
<ul>
    <li><b>1.</b> **Code Quality Assessment** 🧹</li>
    <li><b>2.</b> **Documentation Quality** 📚</li>
    <li><b>3.</b> **Change Management** 🔄</li>
    <li><b>4.</b> **Modularity Analysis** 🧩</li>
    <li><b>5.</b> **Testing Coverage** 🧪</li>
    <li><b>6.</b> **Maintenance Recommendations** 🔧</li>
</ul>
<p>Focus on long-term maintainability and operational efficiency.</p>
"""

def create_reliability_prompt():
    """Create reliability and availability prompt"""
    return """
<h2>Please provide a comprehensive reliability and availability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Backup and Recovery** 💾</li>
    <li><b>2.</b> **Disaster Recovery Planning** 🚨</li>
    <li><b>3.</b> **High Availability Configuration** ⚡</li>
    <li><b>4.</b> **Error Handling Mechanisms** 🛠️</li>
    <li><b>5.</b> **Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Reliability Recommendations** 🎯</li>
</ul>
<p>Focus on system resilience and business continuity.</p>
"""

def create_regulatory_compliance_prompt():
    """Create regulatory compliance prompt"""
    return """
<h2>Please provide a comprehensive regulatory compliance assessment that includes:</h2>
<ul>
    <li><b>1.</b> **SOX Compliance** 💼</li>
    <li><b>2.</b> **HIPAA Compliance** 🏥</li>
    <li><b>3.</b> **PCI DSS Compliance** 💳</li>
    <li><b>4.</b> **GDPR Compliance** 🌍</li>
    <li><b>5.</b> **Industry-Specific Regulations** 🏭</li>
    <li><b>6.</b> **Compliance Recommendations** 📋</li>
</ul>
<p>Focus on regulatory requirements and compliance frameworks.</p>
"""

def create_data_governance_framework_prompt():
    """Create data governance framework prompt"""
    return """
<h2>Please provide a comprehensive data governance framework assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Data Ownership and Stewardship** 👥</li>
    <li><b>2.</b> **Data Classification Policies** 🏷️</li>
    <li><b>3.</b> **Data Lifecycle Management** 🔄</li>
    <li><b>4.</b> **Governance Framework** 🏛️</li>
    <li><b>5.</b> **Data Catalog Implementation** 📚</li>
    <li><b>6.</b> **Governance Recommendations** 🎯</li>
</ul>
<p>Focus on governance maturity and framework effectiveness.</p>
"""

def create_integration_prompt():
    """Create integration standards prompt"""
    return """
<h2>Please provide a comprehensive integration standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **API Design and Documentation** 🔌</li>
    <li><b>2.</b> **Data Format Standardization** 📋</li>
    <li><b>3.</b> **Integration Testing** 🧪</li>
    <li><b>4.</b> **Error Handling** ⚠️</li>
    <li><b>5.</b> **Integration Health Monitoring** 📊</li>
    <li><b>6.</b> **Integration Recommendations** 🔧</li>
</ul>
<p>Focus on integration reliability and maintainability.</p>
"""

def create_monitoring_prompt():
    """Create monitoring and observability prompt"""
    return """
<h2>Please provide a comprehensive monitoring and observability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Performance Metrics Collection** 📈</li>
    <li><b>2.</b> **Error Rate Monitoring** ❌</li>
    <li><b>3.</b> **Resource Utilization Tracking** 💻</li>
    <li><b>4.</b> **Business Metrics Monitoring** 📊</li>
    <li><b>5.</b> **Alert and Notification Systems** 🔔</li>
    <li><b>6.</b> **Monitoring Recommendations** 🎯</li>
</ul>
<p>Focus on comprehensive observability and proactive monitoring.</p>
"""

def create_testing_prompt():
    """Create testing standards prompt"""
    return """
<h2>Please provide a comprehensive testing standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Unit Testing** 🧪</li>
    <li><b>2.</b> **Integration Testing** 🔗</li>
    <li><b>3.</b> **Data Quality Testing** ✅</li>
    <li><b>4.</b> **Regression Testing** 🔄</li>
    <li><b>5.</b> **Test Data Management** 📊</li>
    <li><b>6.</b> **Testing Recommendations** 🎯</li>
</ul>
<p>Focus on comprehensive testing coverage and quality assurance.</p>
"""

def create_documentation_prompt():
    """Creates a prompt for documentation quality analysis."""
    return """
<h2>Please provide a documentation quality analysis that includes:</h2>
<ul>
    <li><b>1.</b> Table comment completeness assessment</li>
    <li><b>2.</b> Column comment quality evaluation</li>
    <li><b>3.</b> Business rule documentation gaps</li>
    <li><b>4.</b> Metadata completeness analysis</li>
    <li><b>5.</b> Documentation standards compliance</li>
    <li><b>6.</b> Recommendations for improving documentation</li>
</ul>
"""

def create_versioning_prompt():
    """Create versioning and change management prompt"""
    return """
<h2>Please provide a comprehensive versioning and change management assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Schema Versioning** 🔄</li>
    <li><b>2.</b> **API Versioning** 🔌</li>
    <li><b>3.</b> **Data Migration** 📦</li>
    <li><b>4.</b> **Rollback Capabilities** ↩️</li>
    <li><b>5.</b> **Change Tracking and Audit** 📊</li>
    <li><b>6.</b> **Versioning Recommendations** 🎯</li>
</ul>
<p>Focus on change management and version control best practices.</p>
"""

def create_cost_optimization_assessment_prompt():
    """Create cost optimization assessment prompt"""
    return """
<h2>Please provide a comprehensive cost optimization assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Storage Optimization** 💾</li>
    <li><b>2.</b> **Compute Resource Optimization** 💻</li>
    <li><b>3.</b> **Query Cost Analysis** 💰</li>
    <li><b>4.</b> **Resource Scheduling** ⏰</li>
    <li><b>5.</b> **Cost Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Cost Optimization Recommendations** 🎯</li>
</ul>
<p>Focus on cost efficiency and resource optimization.</p>
"""

def create_data_modeling_prompt():
    """Create data modeling standards prompt"""
    return """
<h2>Please provide a comprehensive data modeling standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Normalization Level Assessment** 📊</li>
    <li><b>2.</b> **Entity Relationship Modeling** 🔗</li>
    <li><b>3.</b> **Dimensional Modeling Practices** 📐</li>
    <li><b>4.</b> **Data Warehouse Design Principles** 🏗️</li>
    <li><b>5.</b> **Model Documentation Quality** 📝</li>
    <li><b>6.</b> **Modeling Recommendations** 🎯</li>
</ul>
<p>Focus on data modeling best practices and consistency.</p>
"""

def create_data_engineering_prompt():
    """Create data engineering standards prompt"""
    return """
<h2>Please provide a comprehensive data engineering standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **ETL/ELT Process Design** 🔄</li>
    <li><b>2.</b> **Data Pipeline Orchestration** ⚙️</li>
    <li><b>3.</b> **Error Handling and Recovery** ⚠️</li>
    <li><b>4.</b> **Data Transformation Logic** 🔧</li>
    <li><b>5.</b> **Pipeline Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Engineering Recommendations** 🎯</li>
</ul>
<p>Focus on robust data engineering practices.</p>
"""

def create_machine_learning_prompt():
    """Create machine learning standards prompt"""
    return """
<h2>Please provide a comprehensive machine learning standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Feature Engineering Practices** 🔧</li>
    <li><b>2.</b> **Model Versioning and Tracking** 📊</li>
    <li><b>3.</b> **Model Performance Monitoring** 📈</li>
    <li><b>4.</b> **A/B Testing Capabilities** 🧪</li>
    <li><b>5.</b> **Model Explainability and Interpretability** 🔍</li>
    <li><b>6.</b> **ML Recommendations** 🎯</li>
</ul>
<p>Focus on ML governance and best practices.</p>
"""

def create_data_ops_prompt():
    """Create DataOps standards prompt"""
    return """
<h2>Please provide a comprehensive DataOps standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Automated Testing and Deployment** 🤖</li>
    <li><b>2.</b> **Continuous Integration/Continuous Deployment** 🔄</li>
    <li><b>3.</b> **Environment Management** 🌍</li>
    <li><b>4.</b> **Release Management Processes** 📦</li>
    <li><b>5.</b> **Collaboration and Communication Tools** 💬</li>
    <li><b>6.</b> **DataOps Recommendations** 🎯</li>
</ul>
<p>Focus on DataOps maturity and automation.</p>
"""

def create_governance_prompt():
    """Create comprehensive governance analysis prompt using architectural standards"""
    standards_info = ""
    for standard_key, standard_data in ARCHITECTURAL_STANDARDS.items():
        standards_info += f"<h2>{standard_data['name']}</h2>\n"
        standards_info += f"{standard_data['description']}\n"
        standards_info += "<b>Checks:</b>\n"
        for check in standard_data['checks']:
            standards_info += f"- {check}\n"
    
    return f"""
<h2>Please provide a comprehensive data governance and compliance analysis covering all 20+ architectural standards:</h2>

<h3>Architectural Standards to Evaluate:</h3>
{standards_info}

<h3>Analysis Requirements:</h3>

Please provide a comprehensive governance and compliance analysis that includes:

<ul>
    <li><b>1.</b> **Data Quality Assessment** 🔍</li>
    <li><b>2.</b> **Security & Privacy Analysis** 🔒</li>
    <li><b>3.</b> **Performance & Scalability Review** ⚡</li>
    <li><b>4.</b> **Compliance Evaluation** 📋</li>
    <li><b>5.</b> **Data Governance Assessment** 🏛️</li>
    <li><b>6.</b> **Technical Architecture Review** 🏗️</li>
    <li><b>7.</b> **Risk Assessment** ⚠️</li>
    <li><b>8.</b> **Cost Optimization Analysis** 💰</li>
    <li><b>9.</b> **Data Lineage & Catalog Assessment** 📚</li>
    <li><b>10.</b> **Machine Learning & DataOps Standards** 🤖</li>
</ul>

<p>Make your response comprehensive, actionable, and focused on governance and compliance standards.</p>
"""

def create_tree_of_tables_prompt():
    """Create Tree-of-Table specific analysis prompt"""
    return """
<h2>Please provide a Tree-of-Table hierarchical analysis that includes:</h2>

<ul>
    <li><b>1.</b> **Hierarchical Structure Analysis** 🌳</li>
    <li><b>2.</b> **Chunking Strategy Assessment** 📦</li>
    <li><b>3.</b> **Similarity Search Analysis** 🔍</li>
    <li><b>4.</b> **Context Preservation** 🧠</li>
    <li><b>5.</b> **Scalability Analysis** 📈</li>
    <li><b>6.</b> **Integration Assessment** 🔗</li>
    <li><b>7.</b> **Governance Compliance** 📋</li>
</ul>

<p>Focus on the unique aspects of Tree-of-Table methodology and its application to large-scale data analysis.</p>
"""

def generate_analysis(prompt):
    """
    Generate an analysis by sending a prompt to the Spark Assist API client (Spark Assist, OpenAI, Bedrock, etc.).
    Args:
        prompt (str): The formatted prompt to send to the API
    Returns:
        str: HTML-formatted analysis result
    """
    try:
        print("\U0001F4E4 Sending to AI...")
        time.sleep(5)
        return get_spark_assist_analysis(prompt)
    except Exception as e:
        print(f"Error generating analysis: {str(e)}")
        return f"""
        <h1>⚠️ Error</h1>
        <p>There was an error generating the analysis:</p>
        <pre>{str(e)}</pre>
        <p>Using sample analysis instead.</p>
        {get_sample_analysis()}
        """

def clean_mermaid_code(mermaid_code):
    """
    Removes forbidden lines from Mermaid ER diagrams: classDef, class, PRIMARY KEY, FOREIGN KEY.
    """
    cleaned_lines = []
    for line in mermaid_code.splitlines():
        if any(forbidden in line for forbidden in ['classDef', 'class ', 'PRIMARY KEY', 'FOREIGN KEY']):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def chunk_text_token_safe(text, word_limit=3000, overlap=100):
    """
    Split text into chunks of word_limit, with overlap (in words) between consecutive chunks.
    """
    words = text.split()
    chunks = []
    i = 0
    n = len(words)
    while i < n:
        chunk = words[i:i+word_limit]
        chunks.append(' '.join(chunk))
        if i + word_limit >= n:
            break
        i += word_limit - overlap  # move forward with overlap
    return chunks

# Universal chunk-and-analyze function for LLM calls
# llm_func: function that takes a prompt and returns LLM output
# prompt_prefix: instructions and context (string)
# data: the large text to chunk and analyze
# label: label for the data (e.g., 'Materialized View Definition')
# llm_suffix: any strict HTML enforcement, etc.
def chunk_and_analyze(data, llm_func, prompt_prefix, label, llm_suffix=LLM_HTML_SUFFIX, word_limit=3000, overlap=100):
    """
    Chunks data with overlap, analyzes each chunk, and aggregates results into a unified summary.
    Returns the final aggregated LLM output.
    """
    if not isinstance(data, str):
        data = json.dumps(data, indent=2)
    if len(data.split()) <= word_limit:
        # No need to chunk
        prompt = f"{prompt_prefix}\n<h3>{label}:</h3><pre><code>{data}</code></pre>\n" + llm_suffix
        return llm_func(prompt)
    # Chunk with overlap
    chunks = chunk_text_token_safe(data, word_limit, overlap)
    chunk_analyses = []
    for idx, chunk in enumerate(chunks):
        chunk_prompt = (
            f"{prompt_prefix}\nAnalyze the following {label} chunk for issues, structure, and recommendations. "
            f"Respond ONLY in well-structured HTML. Here is the chunk (part {idx+1}/{len(chunks)}):\n<pre><code>{chunk}</code></pre>" + llm_suffix
        )
        time.sleep(5)
        chunk_analysis = llm_func(chunk_prompt)
        chunk_analyses.append(chunk_analysis)
    # Aggregate all chunk insights into a single, unified report
    summary_prompt = (
        f"You are a database expert. Given the following chunk analyses of {label}, write a single, cohesive summary and actionable recommendations. "
        "Do NOT mention chunk numbers or chunking. Only present a unified, insightful report. "
        "Respond ONLY in well-structured HTML. Here are the chunk analyses:\n\n" + '\n\n'.join(chunk_analyses) + llm_suffix
    )
    time.sleep(5)
    summary = llm_func(summary_prompt)
    return summary

# Update ai_analyze_chunk_metadata to use chunk_and_analyze for all large metadata fields

def ai_analyze_chunk_metadata(chunk_metadata, analysis_type="data_quality", table_metadata=None):
    """
    Analyze a chunk's metadata (list of column dicts) using the AI model, with a type-specific prompt.
    Returns a summary dict or string.
    """
    prompt = f"You are a database schema expert. Analyze the following table chunk metadata for {analysis_type.replace('_', ' ')}.\n"
    prompt += "Return your answer as a beautiful, well-structured HTML report suitable for direct rendering in a web UI.\n"
    prompt += "CRITICAL: For any tabular data, ALWAYS use a proper HTML <table> with <thead>, <tbody>, <tr>, <th>, and <td> tags. Spread the table so that each column is a separate <th> and each row is a separate <tr>. Do NOT cram all data into a single row or column. Use clear column headers and ensure the table is easy to read, with proper cell spacing.\n"
    prompt += "Use <h2>, <h3>, <ul>, <ol>, <li>, <table>, <tr>, <th>, <td> for structure. Highlight issues and recommendations with <span style='color: #d32f2f;'> for problems and <span style='color: #388e3c;'> for good practices. Use emojis for key points. Include a summary section, a column-by-column analysis, and a clear, actionable recommendations section. Do NOT use markdown, only HTML. Format all code or SQL examples in <pre><code> blocks. If you mention data types or column names, use <code> tags. Make the report visually appealing and easy to read.\n"
    # If table_metadata is provided, include it in the prompt
    if table_metadata:
        prompt += "\nHere is additional metadata for the table. Use this information in your analysis if it is relevant to the topic. If not useful, you can ignore it.\n"
        from client import get_spark_assist_analysis
        for key, label in [("schema", "DESCRIBE TABLE Output"), ("properties", "SHOW TBLPROPERTIES Output"), ("detail", "DESCRIBE DETAIL Output")]:
            if key in table_metadata and table_metadata[key]:
                value = table_metadata[key]
                # Use chunk_and_analyze for large values
                summary = chunk_and_analyze(
                    value,
                    get_spark_assist_analysis,
                    prompt_prefix="",
                    label=label,
                    llm_suffix=LLM_HTML_SUFFIX,
                    word_limit=3000,
                    overlap=100
                )
                prompt += f"<h3>{label} (summarized):</h3>" + summary + "\n"
    # Add chunk metadata
    for col in chunk_metadata:
        prompt += f"- <code>{col['name']}</code> (type: <code>{col['dtype']}</code>, nulls: {col['null_count']}, unique: {col['unique_count']}, sample: {col['sample_values']})\n"
    prompt += LLM_HTML_SUFFIX
    from client import get_spark_assist_analysis
    time.sleep(5)
    result = get_spark_assist_analysis(prompt)
    return result

def create_data_types_prompt():
    return "<h2>Data Types Analysis</h2><ul><li>Placeholder for data types analysis prompt.</li></ul>"
def create_partitioning_prompt():
    return "<h2>Partitioning Analysis</h2><ul><li>Placeholder for partitioning analysis prompt.</li></ul>"
def create_constraints_prompt():
    return "<h2>Constraints Analysis</h2><ul><li>Placeholder for constraints analysis prompt.</li></ul>"
def create_pii_detection_prompt():
    return "<h2>PII Detection Analysis</h2><ul><li>Placeholder for PII detection analysis prompt.</li></ul>"
def create_pci_compliance_prompt():
    return "<h2>PCI Compliance Analysis</h2><ul><li>Placeholder for PCI compliance analysis prompt.</li></ul>"
def create_gdpr_compliance_prompt():
    return "<h2>GDPR Compliance Analysis</h2><ul><li>Placeholder for GDPR compliance analysis prompt.</li></ul>"
def create_ml_readiness_prompt():
    return "<h2>ML Readiness Analysis</h2><ul><li>Placeholder for ML readiness analysis prompt.</li></ul>"
def create_data_lineage_prompt():
    return "<h2>Data Lineage Analysis</h2><ul><li>Placeholder for data lineage analysis prompt.</li></ul>"
def create_cost_optimization_prompt():
    return "<h2>Cost Optimization Analysis</h2><ul><li>Placeholder for cost optimization analysis prompt.</li></ul>"
def create_data_catalog_prompt():
    return "<h2>Data Catalog Analysis</h2><ul><li>Placeholder for data catalog analysis prompt.</li></ul>"
def create_etl_pipeline_prompt():
    return "<h2>ETL Pipeline Analysis</h2><ul><li>Placeholder for ETL pipeline analysis prompt.</li></ul>"
def create_data_governance_prompt():
    return "<h2>Data Governance Analysis</h2><ul><li>Placeholder for data governance analysis prompt.</li></ul>"
def create_audit_trail_prompt():
    return "<h2>Audit Trail Analysis</h2><ul><li>Placeholder for audit trail analysis prompt.</li></ul>"
def create_data_retention_prompt():
    return "<h2>Data Retention Analysis</h2><ul><li>Placeholder for data retention analysis prompt.</li></ul>"
def create_disaster_recovery_prompt():
    return "<h2>Disaster Recovery Analysis</h2><ul><li>Placeholder for disaster recovery analysis prompt.</li></ul>"
def create_data_migration_prompt():
    return "<h2>Data Migration Analysis</h2><ul><li>Placeholder for data migration analysis prompt.</li></ul>"

# Test the diagram generation
if __name__ == "__main__":
    print("AI Engine module loaded successfully")
    print("Available functions:")
    print("- create_analysis_prompt")
    print("- generate_analysis")
    print("- clean_mermaid_code")