"""
Optimization Service for AeroOptima.ai
Handles running optimization models for different airline scenarios
"""

import json
import logging
import random
import time
from datetime import datetime, timedelta

from app import db
from models import Flight, Aircraft, Crew, Alert

logger = logging.getLogger(__name__)

def run_optimization(plan):
    """
    Run an optimization plan
    
    Args:
        plan: OptimizationPlan object
        
    Returns:
        Tuple of (results, score, execution_time)
    """
    # Start timer
    start_time = time.time()
    
    # Parse the scenario
    try:
        if isinstance(plan.scenario, str):
            scenario = json.loads(plan.scenario)
        else:
            scenario = plan.scenario
    except Exception as e:
        logger.error(f"Error parsing scenario: {str(e)}")
        scenario = {"type": "unknown"}
    
    # Get the appropriate optimization function based on scenario type or name
    if isinstance(scenario, str):
        scenario_type = scenario  # Scenario might be directly stored as a string
    else:
        scenario_type = scenario.get('type', '')
    
    # Check if this is a UM scenario
    if (isinstance(plan.scenario, str) and 
        ("unaccompanied minor" in plan.scenario.lower() or 
         "um " in plan.scenario.lower() or 
         "um protection" in plan.scenario.lower())):
        logger.info(f"Detected Unaccompanied Minor scenario from plan name: {plan.scenario}")
        results = optimize_unaccompanied_minor_scenario(plan, scenario)
    elif "crew" in scenario_type.lower():
        results = optimize_crew_scenario(plan, scenario)
    elif "aircraft" in scenario_type.lower():
        results = optimize_aircraft_scenario(plan, scenario)
    elif "passenger" in scenario_type.lower() or "pax" in scenario_type.lower():
        results = optimize_passenger_scenario(plan, scenario)
    elif "network" in scenario_type.lower():
        results = optimize_network_scenario(plan, scenario)
    elif "um" in scenario_type.lower() or "minor" in scenario_type.lower() or "unaccompanied" in scenario_type.lower():
        results = optimize_unaccompanied_minor_scenario(plan, scenario)
    else:
        # Default generic optimization
        logger.info(f"Using generic optimization for scenario: {scenario_type}")
        results = optimize_generic_scenario(plan, scenario)
    
    # Calculate score
    score = calculate_optimization_score(results, plan.objective_weights)
    
    # End timer
    execution_time = time.time() - start_time
    
    return results, score, execution_time

def optimize_crew_scenario(plan, scenario):
    """Optimize a crew-related scenario"""
    # This would contain specific crew optimization logic
    # For now, simulate with some realistic results
    results = {
        "solution_type": "crew_recovery",
        "affected_crews": random.randint(3, 15),
        "crew_swaps": random.randint(2, 10),
        "duty_time_violations_fixed": random.randint(1, 5),
        "deadhead_segments": random.randint(0, 3),
        "reserve_crews_used": random.randint(0, 5),
        "hotel_costs": random.randint(500, 5000),
        "deadhead_costs": random.randint(1000, 10000),
        "overtime_hours": random.uniform(0, 24),
        "total_delay_minutes": random.randint(30, 240),
        "affected_passengers": random.randint(0, 500),
        "affected_um": random.randint(0, 5),
        "missed_connections": random.randint(0, 50),
        "cancellations": random.randint(0, 3),
        "aircraft_swaps": random.randint(0, 2),
        "delay_cost": random.randint(5000, 50000),
        "passenger_compensation": random.randint(0, 20000),
        "crew_overtime": random.randint(0, 15000)
    }
    return results

def optimize_aircraft_scenario(plan, scenario):
    """Optimize an aircraft-related scenario"""
    # This would contain specific aircraft optimization logic
    # For now, simulate with some realistic results
    results = {
        "solution_type": "aircraft_recovery",
        "affected_aircraft": random.randint(1, 5),
        "aircraft_swaps": random.randint(1, 5),
        "maintenance_slots_adjusted": random.randint(0, 2),
        "ferry_flights": random.randint(0, 2),
        "total_delay_minutes": random.randint(60, 480),
        "affected_passengers": random.randint(100, 1000),
        "affected_um": random.randint(0, 10),
        "missed_connections": random.randint(10, 100),
        "cancellations": random.randint(1, 8),
        "delay_cost": random.randint(10000, 100000),
        "passenger_compensation": random.randint(5000, 50000),
        "crew_overtime": random.randint(0, 20000)
    }
    return results

def optimize_passenger_scenario(plan, scenario):
    """Optimize a passenger-related scenario"""
    # This would contain specific passenger optimization logic
    # For now, simulate with some realistic results
    results = {
        "solution_type": "passenger_recovery",
        "affected_passengers": random.randint(50, 500),
        "rebooked_passengers": random.randint(25, 450),
        "hotel_vouchers": random.randint(5, 100),
        "meal_vouchers": random.randint(20, 200),
        "transport_vouchers": random.randint(10, 150),
        "special_handling_cases": random.randint(1, 20),
        "total_delay_minutes": random.randint(30, 360),
        "affected_um": random.randint(0, 15),
        "missed_connections": random.randint(5, 80),
        "cancellations": random.randint(0, 5),
        "aircraft_swaps": random.randint(0, 3),
        "delay_cost": random.randint(2000, 30000),
        "passenger_compensation": random.randint(5000, 80000),
        "crew_overtime": random.randint(0, 10000)
    }
    return results

def optimize_network_scenario(plan, scenario):
    """Optimize a network-related scenario"""
    # This would contain specific network optimization logic
    # For now, simulate with some realistic results
    results = {
        "solution_type": "network_recovery",
        "affected_flights": random.randint(5, 50),
        "delayed_flights": random.randint(3, 30),
        "cancelled_flights": random.randint(0, 10),
        "diverted_flights": random.randint(0, 5),
        "total_delay_minutes": random.randint(120, 1200),
        "affected_passengers": random.randint(200, 2000),
        "affected_um": random.randint(0, 20),
        "missed_connections": random.randint(20, 200),
        "aircraft_swaps": random.randint(2, 15),
        "delay_cost": random.randint(20000, 200000),
        "passenger_compensation": random.randint(10000, 100000),
        "crew_overtime": random.randint(5000, 50000)
    }
    return results

def optimize_unaccompanied_minor_scenario(plan, scenario):
    """Optimize an unaccompanied minor scenario"""
    # Factors to consider for UM scenarios:
    # 1. UMs must be prioritized for rebooking
    # 2. UMs cannot be left at a connecting station overnight
    # 3. Staff must be available for UM handling
    # 4. Minimize connections for UMs
    
    # Extract any specific UM constraints from the plan
    constraints = plan.constraints or {}
    
    # Default values
    no_overnight_transit = constraints.get('no_overnight_transit_um', True)
    max_connections = constraints.get('max_connections_um', 1)
    min_staff_at_transit = constraints.get('min_staff_at_transit', 2)
    
    logger.info(f"Running UM optimization with constraints: no_overnight_transit={no_overnight_transit}, "
               f"max_connections={max_connections}, min_staff_at_transit={min_staff_at_transit}")
    
    # Simulate results based on the constraints
    um_count = random.randint(1, 10)
    
    # Apply constraints to simulation
    # Stricter constraints mean better UM handling but possibly higher costs
    if no_overnight_transit:
        um_overnight_stays = 0
        delay_cost_factor = 1.2  # More cost due to timing constraints
    else:
        um_overnight_stays = random.randint(0, min(2, um_count))
        delay_cost_factor = 1.0
    
    if max_connections <= 0:
        connections = 0
        delay_cost_factor *= 1.3  # Even more cost for direct flights only
    elif max_connections == 1:
        connections = random.randint(0, 1)
        delay_cost_factor *= 1.1
    else:
        connections = random.randint(0, max_connections)
    
    # Staff constraints affect both safety and cost
    staff_assigned = max(min_staff_at_transit, random.randint(1, max(1, um_count // 2)))
    
    # Query active alerts related to UMs to incorporate into solution
    um_alerts = Alert.query.filter(
        Alert.is_active == True,
        Alert.category.in_(['passenger', 'service', 'schedule']),
        Alert.description.ilike('%unaccompanied%')
    ).all()
    
    # Adjust affected_um count based on actual alerts
    if um_alerts:
        um_count = max(um_count, len(um_alerts))
        logger.info(f"Found {len(um_alerts)} active UM-related alerts")
    
    results = {
        "solution_type": "um_recovery",
        "affected_um": um_count,
        "um_rebooking_priority": "high",
        "um_staff_assigned": staff_assigned,
        "um_overnight_stays": um_overnight_stays,
        "um_max_connections": max_connections,
        "um_actual_connections": connections,
        "um_alternative_routing": random.randint(0, um_count),
        "delayed_flights_for_um": random.randint(0, 3),
        "total_delay_minutes": random.randint(15, 120),
        "affected_passengers": random.randint(10, 200),
        "missed_connections": random.randint(0, 30),
        "cancellations": random.randint(0, 2),
        "aircraft_swaps": random.randint(0, 1),
        "delay_cost": int(random.randint(1000, 15000) * delay_cost_factor),
        "passenger_compensation": random.randint(500, 10000),
        "crew_overtime": random.randint(0, 5000),
        "um_protection_score": random.uniform(0.7, 0.95)  # UMs are well protected
    }
    
    # Add example routing solutions for UMs
    um_routings = []
    for i in range(min(3, um_count)):
        origin = random.choice(["LAX", "ORD", "ATL", "DFW", "JFK"])
        destination = random.choice(["MIA", "SEA", "BOS", "DEN", "IAD"])
        
        # Ensure origin and destination are different
        while destination == origin:
            destination = random.choice(["MIA", "SEA", "BOS", "DEN", "IAD"])
        
        connection = None
        if connections > 0 and random.random() > 0.3:  # 70% chance of connection if allowed
            connection = random.choice(["CLT", "PHX", "DTW", "IAH", "SLC"])
            
            # Ensure connection is not origin or destination
            while connection == origin or connection == destination:
                connection = random.choice(["CLT", "PHX", "DTW", "IAH", "SLC"])
        
        routing = {
            "um_id": f"UM{i+1}",
            "origin": origin,
            "destination": destination,
            "connection": connection,
            "staff_assigned": random.randint(1, min_staff_at_transit),
            "original_flight": f"AO{random.randint(100, 999)}",
            "new_flight": f"AO{random.randint(100, 999)}",
            "overnight_stay": False
        }
        um_routings.append(routing)
    
    results["um_routings"] = um_routings
    return results

def optimize_generic_scenario(plan, scenario):
    """Optimize a generic scenario when no specific type is matched"""
    # This would contain general optimization logic
    # For now, simulate with some realistic results
    results = {
        "solution_type": "general_recovery",
        "affected_flights": random.randint(1, 20),
        "delayed_flights": random.randint(1, 15),
        "cancelled_flights": random.randint(0, 5),
        "total_delay_minutes": random.randint(30, 600),
        "affected_passengers": random.randint(50, 1000),
        "affected_um": random.randint(0, 10),
        "missed_connections": random.randint(5, 100),
        "aircraft_swaps": random.randint(0, 5),
        "delay_cost": random.randint(5000, 80000),
        "passenger_compensation": random.randint(1000, 50000),
        "crew_overtime": random.randint(0, 20000)
    }
    return results

def calculate_optimization_score(results, weights=None):
    """
    Calculate an optimization score based on results and weights
    
    Args:
        results: Dictionary of optimization results
        weights: Dictionary of weights for different factors
        
    Returns:
        score: Optimization score between 0 and 1
    """
    if not weights:
        weights = {
            "safety": 0.3,
            "passenger_satisfaction": 0.2,
            "delay_cost": 0.2,
            "passenger_impact": 0.1,
            "operational_feasibility": 0.1,
            "crew_impact": 0.05,
            "aircraft_utilization": 0.05
        }
    
    # Initialize score components
    score_components = {}
    
    # Calculate delay cost score (lower is better)
    if "delay_cost" in results:
        # Normalize with a reasonable maximum ($200,000)
        delay_cost_score = max(0, 1 - (results["delay_cost"] / 200000))
        score_components["delay_cost"] = delay_cost_score
    else:
        score_components["delay_cost"] = 0.5  # Default
    
    # Calculate passenger impact score (lower is better)
    passenger_impact = 0
    if "affected_passengers" in results:
        # Normalize with a reasonable maximum (2000 passengers)
        passenger_impact += results["affected_passengers"] / 2000
    
    if "missed_connections" in results:
        # Normalize with a reasonable maximum (200 connections)
        passenger_impact += results["missed_connections"] / 200
    
    if "affected_um" in results:
        # Unaccompanied minors have higher weight
        # Normalize with a reasonable maximum (20 UMs)
        passenger_impact += (results["affected_um"] / 20) * 3
    
    # Combine and invert (lower impact is better)
    passenger_impact_score = max(0, 1 - min(1, passenger_impact / 3))
    score_components["passenger_impact"] = passenger_impact_score
    
    # Calculate operational feasibility score
    operational_score = 0
    if "cancellations" in results:
        # Normalize with a reasonable maximum (10 cancellations)
        operational_score += (1 - min(1, results["cancellations"] / 10)) * 0.5
    
    if "total_delay_minutes" in results:
        # Normalize with a reasonable maximum (1200 minutes)
        operational_score += (1 - min(1, results["total_delay_minutes"] / 1200)) * 0.5
    
    score_components["operational_feasibility"] = operational_score or 0.5  # Default
    
    # Calculate crew impact score (lower is better)
    if "crew_overtime" in results:
        # Normalize with a reasonable maximum ($50,000)
        crew_impact_score = max(0, 1 - (results["crew_overtime"] / 50000))
        score_components["crew_impact"] = crew_impact_score
    else:
        score_components["crew_impact"] = 0.5  # Default
    
    # Calculate aircraft utilization score
    if "aircraft_swaps" in results:
        # Normalize with a reasonable maximum (15 swaps)
        # More swaps is worse for utilization
        aircraft_score = max(0, 1 - (results["aircraft_swaps"] / 15))
        score_components["aircraft_utilization"] = aircraft_score
    else:
        score_components["aircraft_utilization"] = 0.5  # Default
        
    # Calculate safety score - a crucial metric for UM scenarios
    safety_score = 0.5  # Default
    
    # For UM scenarios, use um_protection_score if available
    if "um_protection_score" in results:
        safety_score = results["um_protection_score"]
    # Otherwise calculate based on various factors
    else:
        safety_factors = []
        
        # Staff assigned for UMs increases safety
        if "um_staff_assigned" in results and "affected_um" in results and results["affected_um"] > 0:
            staff_per_um = results["um_staff_assigned"] / results["affected_um"]
            staff_factor = min(1, staff_per_um / 0.5)  # Ideal is at least 0.5 staff per UM
            safety_factors.append(staff_factor)
        
        # Overnight stays for UMs reduces safety
        if "um_overnight_stays" in results and "affected_um" in results and results["affected_um"] > 0:
            overnight_ratio = results["um_overnight_stays"] / results["affected_um"]
            overnight_factor = 1 - min(1, overnight_ratio * 2)  # Penalize heavily for overnight stays
            safety_factors.append(overnight_factor)
        
        # If we have factors, calculate average safety score
        if safety_factors:
            safety_score = sum(safety_factors) / len(safety_factors)
    
    score_components["safety"] = safety_score
    
    # Calculate passenger satisfaction score
    satisfaction_score = 0.5  # Default
    
    if "solution_type" in results and "um" in results["solution_type"]:
        # For UM scenarios, prioritize minimal connections and delays
        satisfaction_factors = []
        
        # Fewer connections mean higher satisfaction
        if "um_actual_connections" in results and "affected_um" in results and results["affected_um"] > 0:
            if results["um_actual_connections"] == 0:
                connection_factor = 1.0  # Direct flights are ideal
            else:
                avg_connections = min(2, results["um_actual_connections"])
                connection_factor = 1 - (avg_connections / 2)
            satisfaction_factors.append(connection_factor)
        
        # Shorter delays mean higher satisfaction
        if "total_delay_minutes" in results:
            delay_factor = max(0, 1 - (results["total_delay_minutes"] / 180))  # 3 hours is the threshold
            satisfaction_factors.append(delay_factor)
            
        # Staff availability increases satisfaction
        if "um_staff_assigned" in results and "affected_um" in results and results["affected_um"] > 0:
            staff_ratio = min(1, results["um_staff_assigned"] / results["affected_um"])
            satisfaction_factors.append(staff_ratio)
            
        # Calculate average satisfaction score
        if satisfaction_factors:
            satisfaction_score = sum(satisfaction_factors) / len(satisfaction_factors)
    else:
        # For non-UM scenarios, use regular passenger impact metrics
        if "affected_passengers" in results and "missed_connections" in results:
            # Invert the passenger_impact score we calculated earlier
            satisfaction_score = passenger_impact_score
    
    score_components["passenger_satisfaction"] = satisfaction_score
    
    # Calculate final weighted score
    final_score = 0
    for component, score in score_components.items():
        if component in weights:
            final_score += score * weights[component]
    
    # Add a small random variation for realism
    final_score = min(1, max(0, final_score + random.uniform(-0.05, 0.05)))
    
    return final_score

def get_optimization_summary(plan):
    """
    Generate a natural language summary of an optimization plan and its results
    
    Args:
        plan: OptimizationPlan object
        
    Returns:
        summary: String with natural language summary
    """
    summary_parts = []
    
    # Basic plan info
    summary_parts.append(f"Optimization Plan: {plan.name}")
    if plan.description:
        summary_parts.append(f"Description: {plan.description}")
    
    # Status and score
    summary_parts.append(f"Status: {plan.status.capitalize()}")
    if plan.score:
        score_percent = int(plan.score * 100)
        if score_percent >= 80:
            quality = "excellent"
        elif score_percent >= 60:
            quality = "good"
        elif score_percent >= 40:
            quality = "fair"
        else:
            quality = "poor"
        summary_parts.append(f"Score: {score_percent}% ({quality})")
    
    # Execution info
    if plan.execution_time:
        summary_parts.append(f"Execution time: {plan.execution_time:.2f} seconds")
    
    # Results summary
    if plan.results:
        try:
            results = plan.results if isinstance(plan.results, dict) else json.loads(plan.results)
            
            # Add solution type
            if "solution_type" in results:
                solution_type = results["solution_type"].replace("_", " ").capitalize()
                summary_parts.append(f"Solution type: {solution_type}")
            
            # Add key metrics based on solution type
            metrics = []
            if "affected_passengers" in results:
                metrics.append(f"{results['affected_passengers']} affected passengers")
            
            # Handle UM-specific metrics
            if "affected_um" in results and results["affected_um"] > 0:
                metrics.append(f"{results['affected_um']} unaccompanied minors")
                
                # Add UM-specific summary if it's a UM scenario
                if "solution_type" in results and "um" in results["solution_type"]:
                    um_details = []
                    
                    # Add staff assigned metric
                    if "um_staff_assigned" in results:
                        um_details.append(f"{results['um_staff_assigned']} staff assigned to UMs")
                    
                    # Add overnight stays metric (emphasize if zero)
                    if "um_overnight_stays" in results:
                        if results["um_overnight_stays"] == 0:
                            um_details.append("No overnight stays for UMs")
                        else:
                            um_details.append(f"{results['um_overnight_stays']} overnight stays")
                    
                    # Add connection metric
                    if "um_actual_connections" in results:
                        if results["um_actual_connections"] == 0:
                            um_details.append("Direct flights for all UMs")
                        else:
                            um_details.append(f"Max {results['um_actual_connections']} connection(s) per UM")
                            
                    # Add protection score if available
                    if "um_protection_score" in results:
                        protection_percent = int(results["um_protection_score"] * 100)
                        um_details.append(f"UM protection level: {protection_percent}%")
                        
                    if um_details:
                        summary_parts.append("UM protection: " + ", ".join(um_details))
                        
                    # Add specific UM routing examples if available
                    if "um_routings" in results and results["um_routings"]:
                        routing_examples = []
                        for i, routing in enumerate(results["um_routings"][:2]):  # Show max 2 examples
                            if routing["connection"]:
                                route = f"{routing['origin']}-{routing['connection']}-{routing['destination']}"
                            else:
                                route = f"{routing['origin']}-{routing['destination']} (direct)"
                            routing_examples.append(f"{routing['um_id']}: {route}")
                        
                        if routing_examples:
                            summary_parts.append("Example UM routings: " + ", ".join(routing_examples))
            
            if "total_delay_minutes" in results:
                hours = results["total_delay_minutes"] // 60
                minutes = results["total_delay_minutes"] % 60
                if hours > 0:
                    metrics.append(f"{hours}h {minutes}m total delay")
                else:
                    metrics.append(f"{minutes}m total delay")
            
            if "cancellations" in results and results["cancellations"] > 0:
                metrics.append(f"{results['cancellations']} cancellations")
            
            if "aircraft_swaps" in results and results["aircraft_swaps"] > 0:
                metrics.append(f"{results['aircraft_swaps']} aircraft swaps")
            
            if metrics:
                summary_parts.append("Key metrics: " + ", ".join(metrics))
            
            # Add cost summary
            costs = []
            if "delay_cost" in results:
                costs.append(f"${results['delay_cost']:,} delay cost")
            
            if "passenger_compensation" in results:
                costs.append(f"${results['passenger_compensation']:,} passenger compensation")
            
            if "crew_overtime" in results:
                costs.append(f"${results['crew_overtime']:,} crew overtime")
            
            if costs:
                summary_parts.append("Cost impact: " + ", ".join(costs))
                
        except Exception as e:
            logger.error(f"Error parsing optimization results: {str(e)}")
            summary_parts.append("Results available but could not be parsed.")
    
    return "\n".join(summary_parts)