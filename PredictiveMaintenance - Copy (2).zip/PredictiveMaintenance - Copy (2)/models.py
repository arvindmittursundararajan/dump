from datetime import datetime
from app import db
from werkzeug.security import generate_password_hash, check_password_hash

class Machine(db.Model):
    """Model for industrial machines or equipment (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    asset_type = db.Column(db.String(64))  # e.g., conveyor, CNC, pump
    location = db.Column(db.String(128))
    manufacturer = db.Column(db.String(128))
    model_number = db.Column(db.String(64))
    serial_number = db.Column(db.String(64))
    installation_date = db.Column(db.Date)
    status = db.Column(db.String(32), default='operational')  # operational, warning, maintenance, error
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    parts = db.relationship('Part', backref='machine', cascade='all, delete-orphan')
    sensor_data = db.relationship('SensorData', backref='machine', cascade='all, delete-orphan')
    maintenance_records = db.relationship('MaintenanceRecord', backref='machine', cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='machine', cascade='all, delete-orphan')

class Part(db.Model):
    """Model for individual parts within machines."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'), nullable=False)
    parent_part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    name = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text)
    part_type = db.Column(db.String(64))  # e.g., motor, belt, gearbox
    manufacturer = db.Column(db.String(128))
    part_number = db.Column(db.String(64))
    installation_date = db.Column(db.Date)
    expected_lifetime_hours = db.Column(db.Integer)  # Expected operational lifetime in hours
    status = db.Column(db.String(32), default='operational')  # operational, warning, maintenance, error
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    child_parts = db.relationship('Part', backref=db.backref('parent_part', remote_side=[id]))
    sensor_data = db.relationship('SensorData', backref='part', cascade='all, delete-orphan')
    alerts = db.relationship('Alert', backref='part', cascade='all, delete-orphan')
    file_metadata = db.relationship('FileMetadata', backref='part', cascade='all, delete-orphan')

class SensorData(db.Model):
    """Model for time-series sensor data from machines and parts (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    sensor_type = db.Column(db.String(64), nullable=False)  # e.g., temperature, pressure, vibration
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    value = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(32))  # e.g., °C, PSI, mm/s
    is_anomaly = db.Column(db.Boolean, default=False)  # Flag for anomalous readings

class MaintenanceRecord(db.Model):
    """Model for maintenance activities performed on machines (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'), nullable=False)
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    maintenance_type = db.Column(db.String(64))  # e.g., preventive, corrective, inspection
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime)
    technician = db.Column(db.String(128))
    status = db.Column(db.String(32))  # scheduled, in_progress, completed, cancelled
    cost = db.Column(db.Float)
    description = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    part = db.relationship('Part', backref='maintenance_records', foreign_keys=[part_id])

class Alert(db.Model):
    """Model for system-generated alerts based on sensor data or maintenance schedules (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    alert_type = db.Column(db.String(64), nullable=False)  # e.g., anomaly, maintenance_due, failure_prediction
    severity = db.Column(db.String(32))  # low, medium, high, critical
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_acknowledged = db.Column(db.Boolean, default=False)
    acknowledged_by = db.Column(db.String(128))
    acknowledged_at = db.Column(db.DateTime)
    resolution = db.Column(db.Text)

class FileMetadata(db.Model):
    """Model for files associated with machines or parts (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    metadata_type = db.Column(db.String(64))  # e.g., manual, photo, specifications
    file_path = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(128))
    description = db.Column(db.Text)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)

class AiInteraction(db.Model):
    """Model for storing interactions with the AI assistant (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    query = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class PredictiveModel(db.Model):
    """Model for storing trained predictive models (Praventive)."""
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey('machine.id'))
    part_id = db.Column(db.Integer, db.ForeignKey('part.id'))
    model_type = db.Column(db.String(64))  # e.g., regression, classification, time-series
    training_date = db.Column(db.DateTime, default=datetime.utcnow)
    performance_metrics = db.Column(db.Text)  # JSON-serialized metrics
    parameters = db.Column(db.Text)  # JSON-serialized model parameters
    is_active = db.Column(db.Boolean, default=True)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class DeviceType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)  # e.g., IoT, SCADA, etc.

class Device(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    device_type_id = db.Column(db.Integer, db.ForeignKey('device_type.id'))
    device_type = db.relationship('DeviceType', backref='devices')
    description = db.Column(db.Text)
    location = db.Column(db.String(128))
    manufacturer = db.Column(db.String(128))
    model_number = db.Column(db.String(64))
    serial_number = db.Column(db.String(64))
    installation_date = db.Column(db.Date)
    status = db.Column(db.String(32), default='operational')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
