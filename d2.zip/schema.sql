-- Drop tables if they exist
DROP TABLE IF EXISTS query_cache;
DROP TABLE IF EXISTS analysis_history;
DROP TABLE IF EXISTS columns;
DROP TABLE IF EXISTS tables;
DROP TABLE IF EXISTS schemas;
DROP TABLE IF EXISTS catalogs;
DROP TABLE IF EXISTS selected_tables;
DROP TABLE IF EXISTS performance_metrics;

-- Create tables
CREATE TABLE IF NOT EXISTS query_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT UNIQUE NOT NULL,
    result TEXT NOT NULL,
    timestamp REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS catalogs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS schemas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    catalog_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    FOREIGN KEY (catalog_id) REFERENCES catalogs (id),
    UNIQUE (catalog_id, name)
);

CREATE TABLE IF NOT EXISTS tables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    schema_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    data_source_format TEXT,
    FOREIGN KEY (schema_id) REFERENCES schemas (id),
    UNIQUE (schema_id, name)
);

CREATE TABLE IF NOT EXISTS columns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    data_type TEXT NOT NULL,
    is_nullable TEXT,
    full_data_type TEXT,
    numeric_precision TEXT,
    max_length TEXT,
    comment TEXT,
    FOREIGN KEY (table_id) REFERENCES tables (id),
    UNIQUE (table_id, name)
);

CREATE TABLE IF NOT EXISTS selected_tables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    session_id TEXT NOT NULL,
    FOREIGN KEY (table_id) REFERENCES tables (id),
    UNIQUE (table_id, session_id)
);

CREATE TABLE IF NOT EXISTS analysis_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_type TEXT NOT NULL,
    tables_analyzed TEXT NOT NULL,
    sql_query TEXT,
    analysis_result TEXT NOT NULL,
    metrics TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS performance_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    metrics TEXT NOT NULL,
    collected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (table_name)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_query_cache_query ON query_cache(query);
CREATE INDEX IF NOT EXISTS idx_catalogs_name ON catalogs(name);
CREATE INDEX IF NOT EXISTS idx_schemas_catalog_id ON schemas(catalog_id);
CREATE INDEX IF NOT EXISTS idx_tables_schema_id ON tables(schema_id);
CREATE INDEX IF NOT EXISTS idx_columns_table_id ON columns(table_id);
CREATE INDEX IF NOT EXISTS idx_selected_tables_session_id ON selected_tables(session_id);
CREATE INDEX IF NOT EXISTS idx_analysis_history_created_at ON analysis_history(created_at);
CREATE INDEX IF NOT EXISTS idx_performance_metrics_table_name ON performance_metrics(table_name);