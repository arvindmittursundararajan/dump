import os
from flask import Blueprint, render_template, current_app, abort
import markdown

help_bp = Blueprint('help', __name__, url_prefix='/help')

@help_bp.route('/')
def help_index():
    docs_dir = os.path.join(current_app.root_path, 'documentation')
    try:
        md_files = sorted(f for f in os.listdir(docs_dir) if f.endswith('.md'))
    except FileNotFoundError:
        md_files = []
    docs = []
    for filename in md_files:
        title = filename[:-3].replace('-', ' ').replace('_', ' ').title()
        docs.append({'name': filename, 'title': title})
    return render_template('help/index.html', docs=docs, active_page='help')

@help_bp.route('/<path:doc_name>')
def help_detail(doc_name):
    docs_dir = os.path.join(current_app.root_path, 'documentation')
    safe_path = os.path.normpath(os.path.join(docs_dir, doc_name))
    if not safe_path.startswith(docs_dir) or not os.path.isfile(safe_path):
        abort(404)
    with open(safe_path, 'r', encoding='utf-8') as f:
        md_content = f.read()
    html_content = markdown.markdown(md_content, extensions=['fenced_code', 'tables'])
    title = doc_name[:-3].replace('-', ' ').replace('_', ' ').title()
    return render_template('help/detail.html', title=title, content=html_content, active_page='help') 