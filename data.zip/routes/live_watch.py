from flask import Blueprint, render_template, request, jsonify, current_app
from models import Alert, Rule
from app import db
from datetime import datetime
from services.rule_service import evaluate_rule, get_all_rules
from services.gemini_service import get_gemini_response
import markdown
import re

live_watch_bp = Blueprint('live_watch', __name__)

@live_watch_bp.route('/live-watch')
def live_watch():
    """Render the live watch page"""
    alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(50).all()
    rules = Rule.query.filter_by(is_active=True).all()
    return render_template('live_watch.html', 
                          alerts=alerts,
                          rules=rules,
                          active_page='live_watch')

@live_watch_bp.route('/api/alerts', methods=['GET'])
def get_alerts():
    """API endpoint to get all alerts"""
    # Get query parameters
    severity = request.args.get('severity')
    category = request.args.get('category')
    is_active = request.args.get('is_active')
    limit = request.args.get('limit', 50, type=int)
    
    # Build the query
    query = Alert.query
    
    if severity:
        query = query.filter(Alert.severity == severity)
    if category:
        query = query.filter(Alert.category == category)
    if is_active is not None:
        is_active_bool = is_active.lower() == 'true'
        query = query.filter(Alert.is_active == is_active_bool)
    
    # Get results
    alerts = query.order_by(Alert.timestamp.desc()).limit(limit).all()
    
    # Format the results
    result = []
    for alert in alerts:
        result.append({
            'id': alert.id,
            'title': alert.title,
            'description': alert.description,
            'severity': alert.severity,
            'category': alert.category,
            'source': alert.source,
            'timestamp': alert.timestamp.isoformat(),
            'is_active': alert.is_active,
            'affected_entities': alert.affected_entities
        })
    
    return jsonify(result)

@live_watch_bp.route('/api/alerts/<int:alert_id>', methods=['GET'])
def get_alert(alert_id):
    """API endpoint to get a specific alert"""
    alert = Alert.query.get_or_404(alert_id)
    return jsonify({
        'id': alert.id,
        'title': alert.title,
        'description': alert.description,
        'severity': alert.severity,
        'category': alert.category,
        'source': alert.source,
        'timestamp': alert.timestamp.isoformat(),
        'is_active': alert.is_active,
        'resolved_at': alert.resolved_at.isoformat() if alert.resolved_at else None,
        'resolution_notes': alert.resolution_notes,
        'affected_entities': alert.affected_entities,
        'additional_data': alert.additional_data
    })

@live_watch_bp.route('/api/alerts/<int:alert_id>/resolve', methods=['POST'])
def resolve_alert(alert_id):
    """API endpoint to resolve an alert"""
    alert = Alert.query.get_or_404(alert_id)
    data = request.json or {}
    
    alert.is_active = False
    alert.resolved_at = datetime.utcnow()
    alert.resolution_notes = data.get('resolution_notes', '')
    
    db.session.commit()
    
    return jsonify({'success': True})

@live_watch_bp.route('/api/rules', methods=['GET'])
def get_rules():
    """API endpoint to get all rules"""
    rules = get_all_rules()
    return jsonify(rules)

@live_watch_bp.route('/api/rules', methods=['POST'])
def create_rule():
    """API endpoint to create a new rule"""
    data = request.json
    
    if not data or 'name' not in data or 'rule_text' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    rule = Rule(
        name=data['name'],
        description=data.get('description', ''),
        rule_text=data['rule_text'],
        category=data.get('category', 'General'),
        severity=data.get('severity', 'warning'),
        is_active=data.get('is_active', True),
        rule_config=data.get('metadata', {})
    )
    
    db.session.add(rule)
    db.session.commit()
    
    return jsonify({
        'id': rule.id,
        'name': rule.name,
        'description': rule.description,
        'rule_text': rule.rule_text,
        'category': rule.category,
        'severity': rule.severity,
        'is_active': rule.is_active,
        'created_at': rule.created_at.isoformat(),
        'updated_at': rule.updated_at.isoformat(),
        'metadata': rule.rule_config
    })

@live_watch_bp.route('/api/rules/<int:rule_id>', methods=['PUT'])
def update_rule(rule_id):
    """API endpoint to update a rule"""
    rule = Rule.query.get_or_404(rule_id)
    data = request.json
    
    if 'name' in data:
        rule.name = data['name']
    if 'description' in data:
        rule.description = data['description']
    if 'rule_text' in data:
        rule.rule_text = data['rule_text']
    if 'category' in data:
        rule.category = data['category']
    if 'severity' in data:
        rule.severity = data['severity']
    if 'is_active' in data:
        rule.is_active = data['is_active']
    if 'metadata' in data:
        rule.rule_config = data['metadata']
    
    rule.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'id': rule.id,
        'name': rule.name,
        'description': rule.description,
        'rule_text': rule.rule_text,
        'category': rule.category,
        'severity': rule.severity,
        'is_active': rule.is_active,
        'created_at': rule.created_at.isoformat(),
        'updated_at': rule.updated_at.isoformat(),
        'metadata': rule.rule_config
    })

@live_watch_bp.route('/api/rules/<int:rule_id>/evaluate', methods=['POST'])
def evaluate_rule_endpoint(rule_id):
    """API endpoint to evaluate a rule with given data"""
    rule = Rule.query.get_or_404(rule_id)
    data = request.json
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    try:
        result = evaluate_rule(rule.rule_text, data)
        return jsonify({'result': result})
    except Exception as e:
        current_app.logger.error(f"Error evaluating rule: {str(e)}")
        return jsonify({'error': str(e)}), 500

@live_watch_bp.route('/api/nl-query', methods=['POST'])
def natural_language_query():
    """API endpoint to convert natural language to SQL/rule query using Gemini"""
    data = request.json
    
    if not data or 'query' not in data:
        return jsonify({'error': 'No query provided'}), 400
    
    nl_query = data['query']
    run_query = data.get('execute', True)  # Default to executing the query
    
    with open('prompts/nl_to_sql_alert_query.txt', 'r') as f:
        prompt = f.read()
    
    full_prompt = prompt + "\n\nNatural Language Query: " + nl_query
    
    try:
        # Get the SQL or rule from Gemini
        generated_query = get_gemini_response(full_prompt)
        current_app.logger.info(f"Generated query: {generated_query}")
        
        # Clean up the response (remove markdown code blocks if present)
        if "```" in generated_query:
            # Handle multi-line code blocks
            lines = generated_query.split('\n')
            query_lines = []
            in_code_block = False
            language_line = False
            
            for line in lines:
                if line.startswith("```") and not in_code_block:
                    in_code_block = True
                    language_line = True  # Next line will be processed
                    continue
                elif line.startswith("```") and in_code_block:
                    in_code_block = False
                    continue
                elif language_line:
                    # Skip the language identifier line (sql, python, etc.)
                    if line.strip().lower() in ['sql', 'python', 'rule']:
                        language_line = False
                        continue
                    else:
                        language_line = False
                
                if in_code_block:
                    query_lines.append(line)
            
            if query_lines:
                generated_query = '\n'.join(query_lines).strip()
            
        # Further cleanup - remove any other markdown formatting
        generated_query = generated_query.strip()
        # Convert NOW() to SQLite datetime('now'), JSON operators to JSON_EXTRACT, and INTERVAL arithmetic
        generated_query = re.sub(r"\bNOW\(\)", "datetime('now')", generated_query, flags=re.IGNORECASE)
        generated_query = re.sub(r"(\w+)\s*->>\s*'(\w+)'", r"JSON_EXTRACT(\1, '$.\2')", generated_query, flags=re.IGNORECASE)
        generated_query = re.sub(r"::\s*\w+", "", generated_query, flags=re.IGNORECASE)
        generated_query = re.sub(
            r"\(?\s*datetime\('now'\)\s*([+-])\s*INTERVAL\s*'(\d+)\s*(hours?|minutes?)'\s*\)?",
            lambda m: f"datetime('now','{m.group(1)}{m.group(2)} {m.group(3)}')",
            generated_query,
            flags=re.IGNORECASE
        )
        
        result = {
            'generated_query': generated_query,
            'query_type': 'unknown',
            'original_query': nl_query
        }
        
        # Determine if it's SQL or a rule expression
        query_text = generated_query.lower().strip()
        if query_text.startswith("select") or query_text.startswith("with"):
            result['query_type'] = 'sql'
            
            # If we should execute the query
            if run_query:
                try:
                    # Execute the SQL query against our database
                    with db.engine.connect() as connection:
                        raw_results = connection.execute(db.text(generated_query))
                        if raw_results.returns_rows:
                            columns = raw_results.keys()
                            query_results = [dict(zip(columns, row)) for row in raw_results]
                            
                            # Convert any non-JSON serializable objects to strings
                            for row in query_results:
                                for key, value in row.items():
                                    if hasattr(value, 'isoformat'):  # Handle datetime objects
                                        row[key] = value.isoformat()
                                    elif not isinstance(value, (str, int, float, bool, type(None))):
                                        row[key] = str(value)
                            
                            result['data'] = query_results
                        else:
                            result['data'] = []
                except Exception as sql_error:
                    current_app.logger.error(f"Error executing SQL: {str(sql_error)}")
                    result['error'] = f"Error executing query: {str(sql_error)}"
        else:
            result['query_type'] = 'rule'
            
            # If we should evaluate the rule
            if run_query:
                try:
                    # Get some sample data to evaluate the rule against
                    # For now, we'll just check if the rule is syntactically valid
                    from services.rule_service import parse_rule_text
                    parsed_rule = parse_rule_text(generated_query)
                    result['valid'] = True
                    result['parsed_rule'] = parsed_rule
                except Exception as rule_error:
                    current_app.logger.error(f"Error parsing rule: {str(rule_error)}")
                    result['error'] = f"Invalid rule syntax: {str(rule_error)}"
                    result['valid'] = False
        
        return jsonify(result)
    except Exception as e:
        current_app.logger.error(f"Error processing natural language query: {str(e)}")
        return jsonify({'error': str(e)}), 500