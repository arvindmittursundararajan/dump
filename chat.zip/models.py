from datetime import datetime
from app import db

class Store(db.Model):
    """Store represents country-specific configuration for the inventory system"""
    id = db.Column(db.Integer, primary_key=True)
    country_code = db.Column(db.String(2), unique=True, nullable=False)
    country_name = db.Column(db.String(50), nullable=False)
    store_name = db.Column(db.String(50), nullable=False)
    currency_symbol = db.Column(db.String(5), nullable=False)
    is_active = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f"<Store {self.country_code}: {self.store_name}>"
    
    @property
    def country_code_lower(self):
        """Return country code in lowercase for flag icons"""
        return self.country_code.lower()

class Product(db.Model):
    """Product represents items in the inventory"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    sku = db.Column(db.String(20), unique=True, nullable=False)
    category = db.Column(db.String(50))
    quantity = db.Column(db.Integer, default=0)
    price = db.Column(db.Float, nullable=False)
    cost_price = db.Column(db.Float, nullable=False)
    supplier_id = db.Column(db.Integer)
    reorder_level = db.Column(db.Integer, default=10)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Product {self.sku}: {self.name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "sku": self.sku,
            "category": self.category,
            "quantity": self.quantity,
            "price": self.price,
            "cost_price": self.cost_price,
            "supplier_id": self.supplier_id,
            "reorder_level": self.reorder_level,
            "last_updated": self.last_updated.isoformat()
        }

class CustomerOrder(db.Model):
    """CustomerOrder represents orders placed by customers"""
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(100))
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Pending")  # Pending, Completed, Cancelled
    total_amount = db.Column(db.Float, default=0.0)
    
    # Relationship with OrderItem
    items = db.relationship('OrderItem', backref='customer_order', lazy=True,
                           foreign_keys='OrderItem.customer_order_id')
    
    def __repr__(self):
        return f"<CustomerOrder {self.id}: {self.customer_name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "customer_name": self.customer_name,
            "order_date": self.order_date.isoformat(),
            "status": self.status,
            "total_amount": self.total_amount,
            "items": [item.to_dict() for item in self.items]
        }

class SupplierOrder(db.Model):
    """SupplierOrder represents orders placed to suppliers"""
    id = db.Column(db.Integer, primary_key=True)
    supplier_name = db.Column(db.String(100))
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="Pending")  # Pending, Completed, Cancelled
    total_amount = db.Column(db.Float, default=0.0)
    
    # Relationship with OrderItem
    items = db.relationship('OrderItem', backref='supplier_order', lazy=True,
                           foreign_keys='OrderItem.supplier_order_id')
    
    def __repr__(self):
        return f"<SupplierOrder {self.id}: {self.supplier_name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "supplier_name": self.supplier_name,
            "order_date": self.order_date.isoformat(),
            "status": self.status,
            "total_amount": self.total_amount,
            "items": [item.to_dict() for item in self.items]
        }

class OrderItem(db.Model):
    """OrderItem represents items in customer or supplier orders"""
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    
    # Relationships - an item belongs to either a customer or supplier order
    customer_order_id = db.Column(db.Integer, db.ForeignKey('customer_order.id'), nullable=True)
    supplier_order_id = db.Column(db.Integer, db.ForeignKey('supplier_order.id'), nullable=True)
    
    # Relationship with Product
    product = db.relationship('Product', backref='order_items')
    
    def __repr__(self):
        return f"<OrderItem {self.id}: {self.quantity} x Product {self.product_id}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "product_id": self.product_id,
            "product_name": self.product.name if self.product else "Unknown",
            "quantity": self.quantity,
            "price": self.price,
            "total": self.quantity * self.price
        }

class CurrencyConversion(db.Model):
    """CurrencyConversion represents exchange rates between different currencies"""
    id = db.Column(db.Integer, primary_key=True)
    from_currency = db.Column(db.String(3), nullable=False)
    to_currency = db.Column(db.String(3), nullable=False)
    rate = db.Column(db.Float, nullable=False)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<CurrencyConversion {self.from_currency}->{self.to_currency}: {self.rate}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "from_currency": self.from_currency,
            "to_currency": self.to_currency,
            "rate": self.rate,
            "last_updated": self.last_updated.isoformat()
        }

class Competitor(db.Model):
    """Competitor represents other businesses in the market"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    website = db.Column(db.String(200))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with CompetitorPrice
    prices = db.relationship('CompetitorPrice', backref='competitor', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<Competitor {self.name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "website": self.website,
            "notes": self.notes,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }

class CompetitorPrice(db.Model):
    """CompetitorPrice represents price information for products from competitors"""
    id = db.Column(db.Integer, primary_key=True)
    competitor_id = db.Column(db.Integer, db.ForeignKey('competitor.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    price = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), nullable=False)
    last_checked = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    
    # Relationship with Product
    product = db.relationship('Product', backref='competitor_prices')
    
    def __repr__(self):
        return f"<CompetitorPrice {self.competitor.name} - {self.product.name}: {self.price} {self.currency}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "competitor_id": self.competitor_id,
            "competitor_name": self.competitor.name,
            "product_id": self.product_id,
            "product_name": self.product.name,
            "price": self.price,
            "currency": self.currency,
            "last_checked": self.last_checked.isoformat(),
            "notes": self.notes
        }

class Supplier(db.Model):
    """Supplier represents vendors who supply products"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    contact_person = db.Column(db.String(100))
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    messages = db.relationship('Message', backref='supplier', lazy=True,
                             primaryjoin="Message.supplier_id == Supplier.id")
    
    def __repr__(self):
        return f"<Supplier {self.name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "contact_person": self.contact_person,
            "email": self.email,
            "phone": self.phone,
            "address": self.address,
            "is_active": self.is_active
        }

class Customer(db.Model):
    """Customer represents buyers of products"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    messages = db.relationship('Message', backref='customer', lazy=True,
                             primaryjoin="Message.customer_id == Customer.id")
    
    def __repr__(self):
        return f"<Customer {self.name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "address": self.address,
            "is_active": self.is_active
        }

class Category(db.Model):
    """Category represents product categories"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False, unique=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Category {self.name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description
        }

class Unit(db.Model):
    """Unit represents measurement units for products"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False, unique=True)
    symbol = db.Column(db.String(5), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Unit {self.name} ({self.symbol})>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "symbol": self.symbol
        }

class Message(db.Model):
    """Chat message model"""
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'))
    supplier_id = db.Column(db.Integer, db.ForeignKey('supplier.id'))
    is_sent_by_admin = db.Column(db.Boolean, default=False)
    is_from_system = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'customer_id': self.customer_id,
            'supplier_id': self.supplier_id,
            'is_sent_by_admin': self.is_sent_by_admin,
            'is_from_system': self.is_from_system,
            'timestamp': self.timestamp.isoformat()
        }
