-- Drop tables if they already exist
DROP TABLE IF EXISTS analysis_history;
DROP TABLE IF EXISTS performance_metrics;
DROP TABLE IF EXISTS selected_tables;
DROP TABLE IF EXISTS columns;
DROP TABLE IF EXISTS tables;
DROP TABLE IF EXISTS schemas;
DROP TABLE IF EXISTS catalogs;
DROP TABLE IF EXISTS query_cache;

-- Create table for query cache
CREATE TABLE IF NOT EXISTS query_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT UNIQUE,
    result TEXT,
    timestamp REAL
);

-- Create table for database catalogs
CREATE TABLE catalogs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create table for database schemas
CREATE TABLE schemas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    catalog_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (catalog_id) REFERENCES catalogs (id),
    UNIQUE (catalog_id, name)
);

-- Create table for database tables
CREATE TABLE tables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    schema_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    type TEXT,
    data_source_format TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (schema_id) REFERENCES schemas (id),
    UNIQUE (schema_id, name)
);

-- Create table for table columns
CREATE TABLE columns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    data_type TEXT,
    is_nullable TEXT,
    full_data_type TEXT,
    numeric_precision TEXT,
    max_length TEXT,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (table_id) REFERENCES tables (id),
    UNIQUE (table_id, name)
);

-- Create table for selected tables (for analysis)
CREATE TABLE selected_tables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_id INTEGER NOT NULL,
    session_id TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (table_id) REFERENCES tables (id)
);

-- Create table for performance metrics
CREATE TABLE performance_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    query_duration REAL,
    scanned_bytes INTEGER,
    file_count INTEGER,
    table_size_bytes INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create table for analysis history
CREATE TABLE analysis_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_type TEXT NOT NULL,
    tables_analyzed TEXT NOT NULL,
    analysis_result TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
