import os
import requests
import sqlite3
import json
import time
import datetime
import warnings
from config import DATABRICKS_SERVER, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN, DATABASE_PATH

# Suppress urllib3 InsecureRequestWarning
from urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore', InsecureRequestWarning)

# Define your Databricks workspace URL and API key from config
workspace_url = f'https://{DATABRICKS_SERVER}'
access_token = DATABRICKS_TOKEN
http_path = DATABRICKS_HTTP_PATH

# Set the headers for authentication
headers = {
    'Authorization': f'Bearer {access_token}',
    'Content-Type': 'application/json',
}

def connect_db():
    """Connect to the SQLite database."""
    conn = sqlite3.connect(DATABASE_PATH)
    # Fix for Python 3.12 datetime adapter deprecation warning
    sqlite3.register_adapter(datetime.datetime, lambda dt: dt.isoformat())
    conn.row_factory = sqlite3.Row
    return conn

def get_warehouse_status():
    """Check the status of the Databricks SQL warehouse (cluster)."""
    warehouse_id = http_path.split('/')[-1]
    url = f"{workspace_url}/api/2.0/sql/warehouses/{warehouse_id}"
    try:
        resp = requests.get(url, headers=headers, verify=False)
        if resp.status_code == 200:
            return resp.json().get('state', 'UNKNOWN')
        else:
            print(f"Error checking warehouse status: {resp.status_code} - {resp.text}")
            return 'ERROR'
    except Exception as e:
        print(f"Exception checking warehouse status: {str(e)}")
        return 'ERROR'

def start_warehouse():
    """Start the Databricks SQL warehouse if it is stopped."""
    warehouse_id = http_path.split('/')[-1]
    url = f"{workspace_url}/api/2.0/sql/warehouses/{warehouse_id}/start"
    try:
        resp = requests.post(url, headers=headers, verify=False)
        if resp.status_code == 200:
            print("🟡 Starting Databricks SQL Warehouse...")
            return True
        else:
            print(f"Error starting warehouse: {resp.status_code} - {resp.text}")
            return False
    except Exception as e:
        print(f"Exception starting warehouse: {str(e)}")
        return False

def test_connection():
    """Test connection to Databricks, start warehouse if needed, and print status."""
    warehouse_status = get_warehouse_status()
    print(f"Warehouse status: {warehouse_status}")
    if warehouse_status in ['STOPPED', 'STOPPING', 'DELETED']:
        print("🔴 Warehouse is not running. Attempting to start...")
        started = start_warehouse()
        if not started:
            print("❌ Failed to start warehouse.")
            return False
        # Wait for warehouse to be RUNNING
        for _ in range(30):
            time.sleep(5)
            warehouse_status = get_warehouse_status()
            print(f"Waiting for warehouse... Status: {warehouse_status}")
            if warehouse_status == 'RUNNING':
                break
        if warehouse_status != 'RUNNING':
            print("❌ Warehouse did not start in time.")
            return False
    elif warehouse_status != 'RUNNING':
        print(f"❌ Warehouse not available: {warehouse_status}")
        return False
    print("✅ Databricks warehouse is running. Testing SQL connection...")
    try:
        response = execute_sql_statement("SELECT 1 as test;")
        if response is not None and 'result' in response:
            print("✅ Databricks connected successfully!")
            return True
        else:
            print("❌ Databricks SQL test failed.")
            return False
    except Exception as e:
        print(f"❌ Connection failed: {str(e)}")
        return False

def get_connection_status():
    """Return a summary status for UI indicator."""
    warehouse_status = get_warehouse_status()
    if warehouse_status == 'RUNNING':
        try:
            response = execute_sql_statement("SELECT 1 as test;")
            if response is not None and 'result' in response:
                return {'connected': True, 'warehouse_status': warehouse_status}
        except Exception:
            pass
    return {'connected': False, 'warehouse_status': warehouse_status}

def init_db():
    """Initialize the database with the schema."""
    try:
        # Create schema inline instead of reading from file
        schema = """
        CREATE TABLE IF NOT EXISTS catalogs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS schemas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            catalog_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (catalog_id) REFERENCES catalogs (id),
            UNIQUE(catalog_id, name)
        );
        
        CREATE TABLE IF NOT EXISTS tables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            schema_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            type TEXT,
            data_source_format TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (schema_id) REFERENCES schemas (id),
            UNIQUE(schema_id, name)
        );
        
        CREATE TABLE IF NOT EXISTS columns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            data_type TEXT,
            is_nullable TEXT,
            full_data_type TEXT,
            numeric_precision INTEGER,
            character_maximum_length INTEGER,
            comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (table_id) REFERENCES tables (id),
            UNIQUE(table_id, name)
        );
        
        CREATE TABLE IF NOT EXISTS query_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT UNIQUE NOT NULL,
            result TEXT NOT NULL,
            timestamp REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS analysis_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            analysis_type TEXT NOT NULL,
            tables_analyzed TEXT NOT NULL,
            sql_query TEXT,
            analysis_result TEXT NOT NULL,
            metrics TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS selected_tables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            table_id INTEGER NOT NULL,
            selected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (table_id) REFERENCES tables (id)
        );
        
        CREATE TABLE IF NOT EXISTS performance_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_name TEXT NOT NULL,
            metrics TEXT NOT NULL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS metadata_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_key TEXT UNIQUE NOT NULL,
            metadata_json TEXT NOT NULL,
            cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
        
        conn = connect_db()
        conn.executescript(schema)
        conn.commit()
        conn.close()
        print("✓ Database initialized")
    except Exception as e:
        print(f"❌ Database error: {str(e)}")
        raise

def clear_query_cache():
    try:
        conn = connect_db()
        conn.execute('DELETE FROM query_cache')
        conn.commit()
        conn.close()
    except Exception as e:
        print('Error clearing query cache:', e)

def execute_sql_statement(statement, use_cache=True, cache_ttl=3600):
    """Execute a SQL statement in Databricks and return the response.
    
    Args:
        statement: The SQL statement to execute
        use_cache: Whether to use the local SQLite cache
        cache_ttl: Cache time-to-live in seconds (default: 1 hour)
    """
    clear_query_cache()
    conn = None
    cursor = None
    # No debug prints here
    
    # Check if we have a cached result
    if use_cache:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT result, timestamp FROM query_cache WHERE query = ?",
            (statement,)
        )
        cached = cursor.fetchone()
        
        if cached:
            now = time.time()
            cache_time = cached['timestamp']
            
            # If cache is still valid, return it
            if now - cache_time < cache_ttl:
                conn.close()
                return json.loads(cached['result'])
    
    # No valid cache, execute the query
    try:
        response = requests.post(
            f'{workspace_url}/api/2.0/sql/statements',
            headers=headers,
            json={"statement": statement, "warehouse_id": http_path.split('/')[-1]},
            verify=False
        )
        
        # Check if the request was successful
        if response.status_code == 200:
            result = response.json()
            
            # Cache the result if caching is enabled
            if use_cache and conn and cursor:
                cursor.execute(
                    """INSERT OR REPLACE INTO query_cache (query, result, timestamp) 
                    VALUES (?, ?, ?)""",
                    (statement, json.dumps(result), time.time())
                )
                conn.commit()
            
            if conn:
                conn.close()
                
            return result
        else:
            print(f"❌ SQL execution failed: {response.status_code}")
            if conn:
                conn.close()
            return None
    except Exception as e:
        print(f"❌ SQL execution error: {str(e)}")
        if conn:
            conn.close()
        return None

def get_catalogs():
    """Fetch all catalogs from Databricks."""
    response = execute_sql_statement("SHOW CATALOGS;")
    if response and 'result' in response and 'data_array' in response['result']:
        catalogs = [{"name": catalog[0]} for catalog in response['result']['data_array']]
        return catalogs
    return []

def get_schemas(catalog_name):
    """Fetch all schemas for a given catalog from Databricks."""
    query = f"SELECT schema_name FROM {catalog_name}.information_schema.schemata;"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        schemas = [{"name": schema[0], "catalog": catalog_name} for schema in response['result']['data_array']]
        return schemas
    return []

def get_tables(catalog_name, schema_name):
    """Fetch all tables for a given schema from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}';"
    response = execute_sql_statement(query)
    if response and 'result' in response and 'data_array' in response['result']:
        # Return only the table names as a list of strings
        tables = [table[2] for table in response['result']['data_array']]
        return tables
    return []

def get_columns(catalog_name, schema_name, table_name):
    """Fetch all columns for a given table from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.columns WHERE table_schema = '{schema_name}' AND table_name = '{table_name}';"
    print(f"[get_columns] SQL: {query}")
    response = execute_sql_statement(query)
    print(f"[get_columns] Raw response: {response}")
    if response and 'result' in response and 'data_array' in response['result']:
        columns = []
        for column in response['result']['data_array']:
            column_info = {
                "catalog": column[0],
                "schema": column[1],
                "table": column[2],
                "name": column[3],
                "data_type": column[8] if len(column) > 8 else "",
                "is_nullable": column[6] if len(column) > 6 else "",
                "full_data_type": column[7] if len(column) > 7 else "",
                "numeric_precision": column[10] if len(column) > 10 else "",
                "character_maximum_length": column[9] if len(column) > 9 else "",
                "comment": column[18] if len(column) > 18 else ""
            }
            columns.append(column_info)
        return columns
    return []

def get_table_details(catalog_name, schema_name, table_name):
    """Get detailed information about a table using DESCRIBE DETAIL."""
    try:
        query = f"DESCRIBE DETAIL {catalog_name}.{schema_name}.{table_name};"
        print(f"[get_table_details] SQL: {query}")
        response = execute_sql_statement(query)
        print(f"[get_table_details] Raw response: {response}")
        if response and 'result' in response and 'data_array' in response['result']:
            detail_rows = response['result']['data_array']
            if detail_rows and len(detail_rows) > 0:
                try:
                    # Check if column_meta exists in the response
                    if 'column_meta' in response['result']:
                        column_names = [col['name'] for col in response['result']['column_meta']]
                        detail_dict = dict(zip(column_names, detail_rows[0]))
                    else:
                        # Fallback: use default column names for DESCRIBE DETAIL
                        default_columns = ['name', 'type', 'comment', 'location', 'provider', 'owner', 'created_time', 'last_modified', 'sizeInBytes', 'numFiles', 'format']
                        detail_dict = dict(zip(default_columns, detail_rows[0]))
                    # Extract size and file count with better error handling
                    size_bytes = 0
                    file_count = 0
                    format_type = ""
                    try:
                        size_bytes = int(detail_dict.get('sizeInBytes', 0))
                    except (ValueError, TypeError):
                        pass
                    try:
                        file_count = int(detail_dict.get('numFiles', 0))
                    except (ValueError, TypeError):
                        pass
                    format_type = detail_dict.get('format', '')
                    return {
                        "size_bytes": size_bytes,
                        "file_count": file_count,
                        "format": format_type
                    }
                except (KeyError, IndexError, ValueError) as e:
                    print(f"Error parsing table details for {catalog_name}.{schema_name}.{table_name}: {e}")
        # If we can't get details, try a simpler approach
        try:
            # Try to get basic table info
            basic_query = f"SELECT COUNT(*) as row_count FROM {catalog_name}.{schema_name}.{table_name} LIMIT 1;"
            print(f"[get_table_details] Fallback SQL: {basic_query}")
            basic_response = execute_sql_statement(basic_query)
            print(f"[get_table_details] Fallback raw response: {basic_response}")
            # Return basic info with estimated metrics
            return {
                "size_bytes": 1024,  # 1KB default
                "file_count": 1,     # 1 file default
                "format": "delta"    # Default format
            }
        except Exception as e:
            print(f"Error getting basic table info for {catalog_name}.{schema_name}.{table_name}: {e}")
    except Exception as e:
        print(f"Error in get_table_details for {catalog_name}.{schema_name}.{table_name}: {e}")
    # Default values if anything goes wrong
    return {
        "size_bytes": 1024,
        "file_count": 1,
        "format": "delta"
    }

def get_query_history(table_name=None, limit=10):
    """Get recent query history from Databricks, optionally filtered by table."""
    try:
        # Try to get actual query history from Databricks
        if table_name:
            query = f"""
            SELECT 
                query_text,
                duration_ms,
                executed_at,
                status
            FROM system.query_history 
            WHERE query_text LIKE '%{table_name}%'
            ORDER BY executed_at DESC 
            LIMIT {limit}
            """
        else:
            query = f"""
            SELECT 
                query_text,
                duration_ms,
                executed_at,
                status
            FROM system.query_history 
            ORDER BY executed_at DESC 
            LIMIT {limit}
            """
        
        response = execute_sql_statement(query)
        
        if response and 'result' in response and 'data_array' in response['result']:
            queries = []
            for row in response['result']['data_array']:
                queries.append({
                    'query_text': row[0] if len(row) > 0 else '',
                    'duration_ms': int(row[1]) if len(row) > 1 and row[1] else 0,
                    'executed_at': row[2] if len(row) > 2 else '',
                    'status': row[3] if len(row) > 3 else 'UNKNOWN'
                })
            return queries
    except Exception as e:
        print(f"Error getting query history: {e}")
    
    # Return sample data for demonstration if real data is not available
    sample_queries = [
        {
            'query_text': f'SELECT * FROM {table_name} LIMIT 100' if table_name else 'SELECT COUNT(*) FROM table_name',
            'duration_ms': 1500,
            'executed_at': '2025-07-04T03:00:00Z',
            'status': 'FINISHED'
        },
        {
            'query_text': f'DESCRIBE {table_name}' if table_name else 'DESCRIBE table_name',
            'duration_ms': 250,
            'executed_at': '2025-07-04T02:45:00Z',
            'status': 'FINISHED'
        }
    ]
    
    return sample_queries[:limit]

def save_catalog_to_db(catalog):
    """Save a catalog to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO catalogs (name) VALUES (?)",
        (catalog['name'],)
    )
    conn.commit()
    # Get the ID of the inserted catalog
    cursor.execute("SELECT id FROM catalogs WHERE name = ?", (catalog['name'],))
    catalog_id = cursor.fetchone()['id']
    conn.close()
    return catalog_id

def save_schema_to_db(schema, catalog_id):
    """Save a schema to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO schemas (catalog_id, name) VALUES (?, ?)",
        (catalog_id, schema['name'])
    )
    conn.commit()
    # Get the ID of the inserted schema
    cursor.execute("SELECT id FROM schemas WHERE catalog_id = ? AND name = ?", 
                 (catalog_id, schema['name']))
    schema_id = cursor.fetchone()['id']
    conn.close()
    return schema_id

def save_table_to_db(table, schema_id):
    """Save a table to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT OR IGNORE INTO tables 
        (schema_id, name, type, data_source_format) 
        VALUES (?, ?, ?, ?)""",
        (schema_id, table['name'], table['type'], table.get('data_source_format', ''))
    )
    conn.commit()
    # Get the ID of the inserted table
    cursor.execute("SELECT id FROM tables WHERE schema_id = ? AND name = ?", 
                 (schema_id, table['name']))
    table_id = cursor.fetchone()['id']
    conn.close()
    return table_id

def save_column_to_db(column, table_id):
    """Save a column to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT OR IGNORE INTO columns 
        (table_id, name, data_type, is_nullable, full_data_type, 
         numeric_precision, max_length, comment) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            table_id, 
            column['name'], 
            column.get('data_type', ''), 
            column.get('is_nullable', ''), 
            column.get('full_data_type', ''),
            column.get('numeric_precision', ''), 
            column.get('character_maximum_length', ''), 
            column.get('comment', '')
        )
    )
    conn.commit()
    conn.close()

def save_selected_table(table_id, session_id):
    """Save a selected table for analysis."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO selected_tables (table_id, session_id) VALUES (?, ?)",
        (table_id, session_id)
    )
    conn.commit()
    conn.close()

def get_selected_tables(session_id):
    """Get all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """SELECT t.id, t.name, s.name as schema_name, c.name as catalog_name
        FROM selected_tables st
        JOIN tables t ON st.table_id = t.id
        JOIN schemas s ON t.schema_id = s.id
        JOIN catalogs c ON s.catalog_id = c.id
        WHERE st.session_id = ?""",
        (session_id,)
    )
    tables = cursor.fetchall()
    conn.close()
    return tables

def save_analysis_to_history(analysis_type, tables_analyzed, analysis_result):
    """Save an analysis to the history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO analysis_history 
        (analysis_type, tables_analyzed, analysis_result, created_at) 
        VALUES (?, ?, ?, datetime('now'))""",
        (analysis_type, tables_analyzed, analysis_result)
    )
    conn.commit()
    conn.close()

def get_analysis_history():
    """Get all analysis history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history ORDER BY created_at DESC")
    history = cursor.fetchall()
    conn.close()
    return history

def get_analysis_by_id(analysis_id):
    """Get a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history WHERE id = ?", (analysis_id,))
    analysis = cursor.fetchone()
    conn.close()
    return analysis

def delete_analysis(analysis_id):
    """Delete a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analysis_history WHERE id = ?", (analysis_id,))
    conn.commit()
    conn.close()

def save_performance_metrics(table_name, metrics):
    """Save performance metrics for a table."""
    conn = connect_db()
    cursor = conn.cursor()
    # Convert metrics to JSON string
    metrics_json = json.dumps(metrics)
    cursor.execute(
        """INSERT OR REPLACE INTO performance_metrics 
        (table_name, metrics, collected_at) 
        VALUES (?, ?, datetime('now'))""",
        (table_name, metrics_json)
    )
    conn.commit()
    conn.close()

def clear_selected_tables(session_id):
    """Clear all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM selected_tables WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()