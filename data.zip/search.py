import sqlite3
import random
import string
import pandas as pd
import numpy as np
import hashlib
import json
import time
from datetime import datetime
import sqlite3
from typing import Dict, List, Tuple, Any
import re

# Simulate Spark Assist AI API calls
class SparkAssistAI:
    def __init__(self):
        from config import AI_API_KEY
        self.api_key = AI_API_KEY
    
    def analyze_schema(self, schema_info: str) -> Dict:
        """Simulate Spark Assist AI schema analysis"""
        # In production, this would call the actual Spark Assist API
        analysis = {
            'normalization_level': random.choice(['1NF', '2NF', '3NF', 'BCNF']),
            'denormalization_opportunities': [],
            'performance_issues': [],
            'architectural_violations': [],
            'recommendations': []
        }
        
        # Simulate AI analysis based on schema patterns
        if 'duplicate_columns' in schema_info.lower():
            analysis['denormalization_opportunities'].append('High column redundancy detected')
            analysis['recommendations'].append('Consider normalizing duplicate columns')
        
        if 'large_columns' in schema_info.lower():
            analysis['performance_issues'].append('Tables with 300+ columns may cause performance issues')
            analysis['recommendations'].append('Consider vertical partitioning')
        
        return analysis
    
    def suggest_normalization(self, table_schemas: Dict) -> Dict:
        """Simulate Spark Assist AI normalization suggestions"""
        suggestions = {
            'tables_to_normalize': [],
            'join_strategies': [],
            'partitioning_recommendations': [],
            'indexing_strategies': []
        }
        
        for table_name, schema in table_schemas.items():
            if len(schema) > 100:
                suggestions['tables_to_normalize'].append({
                    'table': table_name,
                    'reason': 'Too many columns (denormalized)',
                    'suggested_tables': [f"{table_name}_core", f"{table_name}_details", f"{table_name}_metadata"]
                })
        
        return suggestions

class DataArchitectureAnalyzer:
    def __init__(self):
        self.spark_assist_ai = SparkAssistAI()
        self.architectural_standards = self._define_architectural_standards()
    
    def _define_architectural_standards(self) -> Dict:
        """Define 20 architectural standards for data design"""
        return {
            'normalization': {
                '1NF': 'First Normal Form - Atomic values, no repeating groups',
                '2NF': 'Second Normal Form - 1NF + no partial dependencies',
                '3NF': 'Third Normal Form - 2NF + no transitive dependencies',
                'BCNF': 'Boyce-Codd Normal Form - 3NF + every determinant is a candidate key'
            },
            'performance': {
                'indexing': 'Proper indexing on frequently queried columns',
                'partitioning': 'Large tables partitioned for better performance',
                'query_optimization': 'Queries optimized for minimal I/O operations',
                'connection_pooling': 'Database connections properly pooled'
            },
            'scalability': {
                'horizontal_scaling': 'Ability to add more servers/nodes',
                'vertical_scaling': 'Ability to add more resources to existing servers',
                'sharding': 'Data distributed across multiple databases',
                'caching': 'Frequently accessed data cached appropriately'
            },
            'security': {
                'encryption': 'Data encrypted at rest and in transit',
                'access_control': 'Proper user permissions and role-based access',
                'audit_trail': 'All data changes logged and auditable',
                'data_masking': 'Sensitive data masked in non-production environments'
            },
            'data_quality': {
                'constraints': 'Proper constraints to ensure data integrity',
                'validation': 'Data validation rules implemented',
                'consistency': 'Data consistency across related tables',
                'completeness': 'Required data fields properly enforced'
            },
            'maintainability': {
                'naming_conventions': 'Consistent naming conventions across all objects',
                'documentation': 'Schema and relationships properly documented',
                'version_control': 'Database changes version controlled',
                'backup_strategy': 'Regular backups with recovery procedures'
            }
        }
    
    def create_test_database(self, db_path: str = 'architecture_test.db'):
        """Create a test database with various normalization levels"""
        conn = sqlite3.connect(db_path)
        
        # Create normalized tables (3NF)
        conn.execute('''
            CREATE TABLE IF NOT EXISTS patients (
                patient_id INTEGER PRIMARY KEY,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                date_of_birth DATE,
                email TEXT UNIQUE
            )
        ''')
        
        conn.execute('''
            CREATE TABLE IF NOT EXISTS departments (
                dept_id INTEGER PRIMARY KEY,
                dept_name TEXT NOT NULL,
                location TEXT
            )
        ''')
        
        conn.execute('''
            CREATE TABLE IF NOT EXISTS doctors (
                doctor_id INTEGER PRIMARY KEY,
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                specialization TEXT,
                dept_id INTEGER,
                FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
            )
        ''')
        
        conn.execute('''
            CREATE TABLE IF NOT EXISTS appointments (
                appointment_id INTEGER PRIMARY KEY,
                patient_id INTEGER,
                doctor_id INTEGER,
                appointment_date DATETIME,
                status TEXT,
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
                FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
            )
        ''')
        
        # Create denormalized table (violates normalization)
        conn.execute('''
            CREATE TABLE IF NOT EXISTS denormalized_appointments (
                appointment_id INTEGER PRIMARY KEY,
                patient_first_name TEXT,
                patient_last_name TEXT,
                patient_email TEXT,
                doctor_first_name TEXT,
                doctor_last_name TEXT,
                doctor_specialization TEXT,
                dept_name TEXT,
                dept_location TEXT,
                appointment_date DATETIME,
                status TEXT
            )
        ''')
        
        # Create large denormalized table (300+ columns)
        columns = [f"column_{i:03d} TEXT" for i in range(1, 301)]
        columns_sql = ", ".join(columns)
        conn.execute(f'''
            CREATE TABLE IF NOT EXISTS large_denormalized_table (
                id INTEGER PRIMARY KEY,
                {columns_sql}
            )
        ''')
        
        # Insert sample data
        self._insert_sample_data(conn)
        
        conn.commit()
        conn.close()
        print("✓ Test database created")
    
    def _insert_sample_data(self, conn):
        """Insert sample data into test tables"""
        # Insert patients
        patients_data = [
            (1, 'John', 'Doe', '1990-01-15', 'john.doe@email.com'),
            (2, 'Jane', 'Smith', '1985-03-22', 'jane.smith@email.com'),
            (3, 'Bob', 'Johnson', '1978-07-10', 'bob.johnson@email.com')
        ]
        conn.executemany('INSERT INTO patients VALUES (?, ?, ?, ?, ?)', patients_data)
        
        # Insert departments
        depts_data = [
            (1, 'Cardiology', 'Floor 3'),
            (2, 'Neurology', 'Floor 4'),
            (3, 'Pediatrics', 'Floor 2')
        ]
        conn.executemany('INSERT INTO departments VALUES (?, ?, ?)', depts_data)
        
        # Insert doctors
        doctors_data = [
            (1, 'Dr. Alice', 'Brown', 'Cardiologist', 1),
            (2, 'Dr. Charlie', 'Wilson', 'Neurologist', 2),
            (3, 'Dr. Diana', 'Davis', 'Pediatrician', 3)
        ]
        conn.executemany('INSERT INTO doctors VALUES (?, ?, ?, ?, ?)', doctors_data)
        
        # Insert appointments
        appointments_data = [
            (1, 1, 1, '2024-01-15 10:00:00', 'Scheduled'),
            (2, 2, 2, '2024-01-16 14:30:00', 'Completed'),
            (3, 3, 3, '2024-01-17 09:15:00', 'Scheduled')
        ]
        conn.executemany('INSERT INTO appointments VALUES (?, ?, ?, ?, ?)', appointments_data)
        
        # Insert denormalized appointments
        denorm_data = [
            (1, 'John', 'Doe', 'john.doe@email.com', 'Dr. Alice', 'Brown', 'Cardiologist', 'Cardiology', 'Floor 3', '2024-01-15 10:00:00', 'Scheduled'),
            (2, 'Jane', 'Smith', 'jane.smith@email.com', 'Dr. Charlie', 'Wilson', 'Neurologist', 'Neurology', 'Floor 4', '2024-01-16 14:30:00', 'Completed')
        ]
        conn.executemany('INSERT INTO denormalized_appointments VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', denorm_data)
        
        # Insert large denormalized data
        for i in range(1, 4):
            values = [i] + [f"data_{i}_{j}" for j in range(1, 301)]
            placeholders = ",".join(["?"] * 301)
            conn.execute(f"INSERT INTO large_denormalized_table VALUES ({placeholders})", values)
    
    def analyze_normalization(self, db_path: str) -> Dict:
        """Analyze normalization levels of tables"""
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        tables = [row[0] for row in cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        
        normalization_analysis = {}
        
        for table in tables:
            # Get table schema
            cursor.execute(f"PRAGMA table_info({table})")
            columns = cursor.fetchall()
            
            # Get foreign keys
            cursor.execute(f"PRAGMA foreign_key_list({table})")
            foreign_keys = cursor.fetchall()
            
            # Analyze normalization level
            analysis = self._determine_normalization_level(columns, foreign_keys, table)
            normalization_analysis[table] = analysis
        
        conn.close()
        return normalization_analysis
    
    def _determine_normalization_level(self, columns: List, foreign_keys: List, table_name: str) -> Dict:
        """Determine the normalization level of a table"""
        analysis = {
            'table_name': table_name,
            'column_count': len(columns),
            'normalization_level': 'Unknown',
            'violations': [],
            'recommendations': []
        }
        
        # Check for 1NF violations (repeating groups, non-atomic values)
        has_1nf_violations = False
        for col in columns:
            col_name = col[1]
            if ',' in col_name or ';' in col_name:
                has_1nf_violations = True
                analysis['violations'].append(f"Column {col_name} may contain non-atomic values")
        
        if has_1nf_violations:
            analysis['normalization_level'] = 'Not 1NF'
            analysis['recommendations'].append('Break down non-atomic columns into separate columns')
            return analysis
        
        # Check for 2NF violations (partial dependencies)
        primary_keys = [col for col in columns if col[5] == 1]  # Primary key columns
        if len(primary_keys) == 1:
            # Single primary key, check for partial dependencies
            pk_name = primary_keys[0][1]
            non_pk_columns = [col for col in columns if col[5] != 1]
            
            # Simple heuristic: if table has many columns and few foreign keys, might have partial dependencies
            if len(non_pk_columns) > 10 and len(foreign_keys) < 3:
                analysis['violations'].append('Potential partial dependencies detected')
                analysis['recommendations'].append('Consider decomposing into smaller tables')
        
        # Check for 3NF violations (transitive dependencies)
        if len(foreign_keys) == 0 and len(columns) > 5:
            analysis['violations'].append('Potential transitive dependencies (no foreign keys)')
            analysis['recommendations'].append('Consider adding foreign key relationships')
        
        # Determine final normalization level
        if len(analysis['violations']) == 0:
            if len(foreign_keys) > 0:
                analysis['normalization_level'] = '3NF or higher'
            else:
                analysis['normalization_level'] = '2NF'
        elif 'partial dependencies' in str(analysis['violations']):
            analysis['normalization_level'] = '1NF'
        else:
            analysis['normalization_level'] = '2NF'
        
        return analysis
    
    def generate_embeddings_and_store(self, db_path: str):
        """Generate embeddings for schema and store in vector database"""
        conn = sqlite3.connect(db_path)
        
        # Get all tables and their schemas
        tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        
        vectors = []
        metadata_list = []
        ids = []
        
        for table in tables:
            # Get table schema
            cursor = conn.execute(f"PRAGMA table_info({table})")
            columns = cursor.fetchall()
            
            # Create schema text
            schema_text = f"Table: {table}\n"
            for col in columns:
                schema_text += f"  {col[1]} {col[2]}"
                if col[5] == 1:
                    schema_text += " PRIMARY KEY"
                schema_text += "\n"
            
            # Generate embedding
            embedding = self._generate_embedding(schema_text)
            
            # Create metadata
            metadata = {
                'table_name': table,
                'column_count': len(columns),
                'schema_text': schema_text,
                'columns': [col[1] for col in columns],
                'types': [col[2] for col in columns]
            }
            
            vectors.append(embedding)
            metadata_list.append(metadata)
            ids.append(f"table_{table}")
        
        # Store in vector database
        # This part of the code is now effectively removed as VectorDatabase is removed.
        # The function signature and return value are kept for now, but the actual storage
        # logic is removed.
        print(f"✓ Generated embeddings for {len(tables)} tables (stubbed)")
    
    def _generate_embedding(self, text: str) -> np.ndarray:
        """Generate embedding for text (simulate OpenAI/Spark Assist embedding)"""
        # In production, use actual embedding API
        hash_obj = hashlib.md5(text.encode())
        hash_bytes = hash_obj.digest()
        vector = []
        for i in range(0, len(hash_bytes), 4):
            chunk = hash_bytes[i:i+4]
            if len(chunk) == 4:
                value = int.from_bytes(chunk, byteorder='big')
                vector.append(value / (2**32 - 1))
        while len(vector) < 128:
            vector.append(0.0)
        return np.array(vector[:128])
    
    def find_similar_tables(self, query: str, top_k: int = 5) -> List[Dict]:
        """Find similar tables using vector search"""
        # This function is now effectively removed as VectorDatabase is removed.
        # The function signature and return value are kept for now, but the actual search
        # logic is removed.
        print(f"✓ Finding similar tables (stubbed for '{query}' with top_k={top_k})")
        return []
    
    def suggest_denormalization(self, table_schemas: Dict) -> Dict:
        """Suggest denormalization opportunities"""
        suggestions = {
            'tables_to_denormalize': [],
            'join_optimizations': [],
            'performance_improvements': []
        }
        
        # Analyze for denormalization opportunities
        for table_name, schema in table_schemas.items():
            if schema['normalization_level'] in ['3NF or higher', 'BCNF']:
                # Check if table is frequently joined
                if schema['column_count'] < 20:  # Small tables good for denormalization
                    suggestions['tables_to_denormalize'].append({
                        'table': table_name,
                        'reason': 'Small normalized table, good candidate for denormalization',
                        'benefit': 'Reduce joins, improve query performance'
                    })
        
        return suggestions
    
    def suggest_normalization(self, table_schemas: Dict) -> Dict:
        """Suggest normalization improvements"""
        suggestions = {
            'tables_to_normalize': [],
            'decomposition_strategies': [],
            'foreign_key_additions': []
        }
        
        for table_name, schema in table_schemas.items():
            if schema['column_count'] > 50:  # Large tables
                suggestions['tables_to_normalize'].append({
                    'table': table_name,
                    'reason': 'Large table with many columns',
                    'suggested_decomposition': [
                        f"{table_name}_core",
                        f"{table_name}_details",
                        f"{table_name}_metadata"
                    ]
                })
        
        return suggestions
    
    def test_architectural_standards(self, db_path: str) -> Dict:
        """Test compliance with 20 architectural standards"""
        conn = sqlite3.connect(db_path)
        
        standards_compliance = {}
        
        # Test each category of standards
        for category, standards in self.architectural_standards.items():
            standards_compliance[category] = {}
            
            for standard_name, description in standards.items():
                compliance = self._test_standard(conn, category, standard_name, description)
                standards_compliance[category][standard_name] = compliance
        
        conn.close()
        return standards_compliance
    
    def _test_standard(self, conn, category: str, standard_name: str, description: str) -> Dict:
        """Test compliance with a specific architectural standard"""
        compliance = {
            'standard': standard_name,
            'description': description,
            'compliant': False,
            'score': 0.0,
            'issues': [],
            'recommendations': []
        }
        
        if category == 'normalization':
            compliance = self._test_normalization_standard(conn, standard_name, compliance)
        elif category == 'performance':
            compliance = self._test_performance_standard(conn, standard_name, compliance)
        elif category == 'scalability':
            compliance = self._test_scalability_standard(conn, standard_name, compliance)
        elif category == 'security':
            compliance = self._test_security_standard(conn, standard_name, compliance)
        elif category == 'data_quality':
            compliance = self._test_data_quality_standard(conn, standard_name, compliance)
        elif category == 'maintainability':
            compliance = self._test_maintainability_standard(conn, standard_name, compliance)
        
        return compliance
    
    def _test_normalization_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test normalization standards"""
        if standard_name == '1NF':
            # Check for atomic values
            tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            atomic_violations = 0
            
            for table in tables:
                cursor = conn.execute(f"PRAGMA table_info({table})")
                columns = cursor.fetchall()
                for col in columns:
                    if ',' in col[1] or ';' in col[1]:
                        atomic_violations += 1
            
            compliance['compliant'] = atomic_violations == 0
            compliance['score'] = 1.0 if atomic_violations == 0 else 0.5
            if atomic_violations > 0:
                compliance['issues'].append(f"Found {atomic_violations} potential non-atomic columns")
        
        return compliance
    
    def _test_performance_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test performance standards"""
        if standard_name == 'indexing':
            # Check for indexes
            indexes = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='index'")]
            compliance['compliant'] = len(indexes) > 0
            compliance['score'] = min(1.0, len(indexes) / 5.0)  # Score based on number of indexes
            if len(indexes) == 0:
                compliance['issues'].append("No indexes found")
                compliance['recommendations'].append("Add indexes on frequently queried columns")
        
        return compliance
    
    def _test_scalability_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test scalability standards"""
        if standard_name == 'horizontal_scaling':
            # Check table sizes
            tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            large_tables = 0
            
            for table in tables:
                count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                if count > 1000:
                    large_tables += 1
            
            compliance['compliant'] = large_tables == 0
            compliance['score'] = 1.0 if large_tables == 0 else 0.3
            if large_tables > 0:
                compliance['issues'].append(f"Found {large_tables} large tables")
                compliance['recommendations'].append("Consider partitioning large tables")
        
        return compliance
    
    def _test_security_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test security standards"""
        if standard_name == 'encryption':
            # SQLite doesn't have built-in encryption, so this is a placeholder
            compliance['compliant'] = False
            compliance['score'] = 0.0
            compliance['issues'].append("SQLite doesn't have built-in encryption")
            compliance['recommendations'].append("Consider using encrypted SQLite or external encryption")
        
        return compliance
    
    def _test_data_quality_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test data quality standards"""
        if standard_name == 'constraints':
            # Check for constraints
            tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            tables_with_constraints = 0
            
            for table in tables:
                cursor = conn.execute(f"PRAGMA table_info({table})")
                columns = cursor.fetchall()
                for col in columns:
                    if col[3] == 1 or col[5] == 1:  # NOT NULL or PRIMARY KEY
                        tables_with_constraints += 1
                        break
            
            compliance['compliant'] = tables_with_constraints > 0
            compliance['score'] = min(1.0, tables_with_constraints / len(tables))
            if tables_with_constraints == 0:
                compliance['issues'].append("No constraints found")
                compliance['recommendations'].append("Add NOT NULL and PRIMARY KEY constraints")
        
        return compliance
    
    def _test_maintainability_standard(self, conn, standard_name: str, compliance: Dict) -> Dict:
        """Test maintainability standards"""
        if standard_name == 'naming_conventions':
            # Check naming conventions
            tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
            consistent_naming = 0
            
            for table in tables:
                if re.match(r'^[a-z_]+$', table):  # lowercase with underscores
                    consistent_naming += 1
            
            compliance['compliant'] = consistent_naming == len(tables)
            compliance['score'] = consistent_naming / len(tables) if tables else 1.0
            if consistent_naming < len(tables):
                compliance['issues'].append("Inconsistent naming conventions")
                compliance['recommendations'].append("Use consistent lowercase_with_underscores naming")
        
        return compliance
    
    def generate_ai_recommendations(self, analysis_results: Dict) -> Dict:
        """Generate AI-powered recommendations using Spark Assist"""
        recommendations = {
            'normalization_recommendations': [],
            'performance_recommendations': [],
            'architectural_recommendations': [],
            'priority_actions': []
        }
        
        # Analyze normalization results
        for table_name, analysis in analysis_results.get('normalization', {}).items():
            if analysis.get('normalization_level') == 'Not 1NF':
                recommendations['normalization_recommendations'].append({
                    'table': table_name,
                    'action': 'Normalize to 1NF',
                    'priority': 'High',
                    'benefit': 'Improve data integrity and query performance'
                })
        
        # Analyze architectural standards
        for category, standards in analysis_results.get('architectural_standards', {}).items():
            for standard_name, compliance in standards.items():
                if not compliance.get('compliant', True):
                    recommendations['architectural_recommendations'].append({
                        'category': category,
                        'standard': standard_name,
                        'issue': compliance.get('issues', ['Unknown issue'])[0],
                        'recommendation': compliance.get('recommendations', ['Review standard'])[0],
                        'priority': 'Medium'
                    })
        
        # Generate priority actions
        high_priority = [r for r in recommendations['normalization_recommendations'] if r['priority'] == 'High']
        recommendations['priority_actions'] = high_priority[:3]  # Top 3 priority actions
        
        return recommendations

def main():
    """Main execution function"""
    print("="*80)
    print("ADVANCED DATA ARCHITECTURE ANALYSIS WITH AI")
    print("="*80)
    
    analyzer = DataArchitectureAnalyzer()
    
    # Step 1: Create test database
    print("\n1. CREATING TEST DATABASE...")
    analyzer.create_test_database('architecture_test.db')
    
    # Step 2: Analyze normalization
    print("\n2. ANALYZING NORMALIZATION...")
    normalization_analysis = analyzer.analyze_normalization('architecture_test.db')
    
    print("\nNormalization Analysis Results:")
    for table, analysis in normalization_analysis.items():
        print(f"  {table}: {analysis['normalization_level']}")
        if analysis['violations']:
            print(f"    Violations: {analysis['violations']}")
    
    # Step 3: Generate embeddings and store in vector database
    print("\n3. GENERATING EMBEDDINGS AND STORING IN VECTOR DATABASE...")
    analyzer.generate_embeddings_and_store('architecture_test.db')
    
    # Step 4: Test architectural standards
    print("\n4. TESTING 20 ARCHITECTURAL STANDARDS...")
    standards_compliance = analyzer.test_architectural_standards('architecture_test.db')
    
    print("\nArchitectural Standards Compliance:")
    for category, standards in standards_compliance.items():
        print(f"\n  {category.upper()}:")
        for standard, compliance in standards.items():
            status = "✓" if compliance['compliant'] else "✗"
            print(f"    {status} {standard}: {compliance['score']:.1%}")
    
    # Step 5: Find similar tables
    print("\n5. FINDING SIMILAR TABLES...")
    similar_tables = analyzer.find_similar_tables("appointment patient doctor", top_k=3)
    print("\nSimilar tables for 'appointment patient doctor':")
    for result in similar_tables:
        print(f"  {result['metadata']['table_name']} (stubbed similarity)")
    
    # Step 6: Generate AI recommendations
    print("\n6. GENERATING AI RECOMMENDATIONS...")
    analysis_results = {
        'normalization': normalization_analysis,
        'architectural_standards': standards_compliance
    }
    ai_recommendations = analyzer.generate_ai_recommendations(analysis_results)
    
    print("\nAI Recommendations:")
    print("\nPriority Actions:")
    for action in ai_recommendations['priority_actions']:
        print(f"  • {action['action']} for table {action['table']} ({action['priority']} priority)")
    
    print("\nArchitectural Recommendations:")
    for rec in ai_recommendations['architectural_recommendations'][:5]:  # Show top 5
        print(f"  • {rec['category']}/{rec['standard']}: {rec['recommendation']}")
    
    # Step 7: Summary
    print("\n" + "="*80)
    print("ANALYSIS SUMMARY")
    print("="*80)
    
    total_standards = sum(len(standards) for standards in analyzer.architectural_standards.values())
    compliant_standards = sum(
        sum(1 for standard in standards.values() if standard['compliant'])
        for standards in standards_compliance.values()
    )
    
    print(f"✓ Analyzed {len(normalization_analysis)} tables for normalization")
    print(f"✓ Tested compliance with {total_standards} architectural standards")
    print(f"✓ {compliant_standards}/{total_standards} standards compliant ({compliant_standards/total_standards:.1%})")
    print(f"✓ Generated embeddings and stored in vector database (stubbed)")
    print(f"✓ Generated AI-powered recommendations")
    print(f"✓ Successfully implemented comprehensive data architecture analysis!")
    
    return {
        'normalization_analysis': normalization_analysis,
        'standards_compliance': standards_compliance,
        'ai_recommendations': ai_recommendations,
        'similar_tables': similar_tables
    }

if __name__ == "__main__":
    results = main() 