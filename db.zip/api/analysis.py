import json
import datetime
import time
from typing import List, Dict, Any, Optional
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import db
import ai
from analyzer import TreeOfTablesAnalyzer
from .db import db_manager

class AnalysisService:
    def __init__(self):
        self.tree_analyzer = TreeOfTablesAnalyzer()
    
    def run_analysis(self, selected_tables: List[Dict], analysis_type: str, 
                    sql_query: Optional[str] = None) -> Dict[str, Any]:
        """
        Run comprehensive analysis on selected tables using ToT chunked tree-based AI analysis.
        - For each table, load as DataFrame
        - Build ToT tree (chunks of 10 columns)
        - Send each chunk's metadata to real AI (ai_engine.ai_analyze_chunk_metadata)
        - Aggregate results up the tree (chunk -> table -> database)
        - Return cumulative answer and tree structure
        """
        try:
            print("🚀 Starting ToT Tree-of-Table Analysis...")
            def safe_json(obj):
                try:
                    return json.dumps(obj, indent=2)
                except TypeError:
                    if hasattr(obj, 'dict'):
                        return json.dumps(obj.dict(), indent=2)
                    elif isinstance(obj, list):
                        return json.dumps([o.dict() if hasattr(o, 'dict') else o for o in obj], indent=2)
                    else:
                        return str(obj)
            print(f"Selected tables received: {safe_json(selected_tables)}")
            selected_tables = [t.dict() if not isinstance(t, dict) and hasattr(t, 'dict') else t for t in selected_tables]

            # Step 1: Connection & Discovery from Databricks
            print("📡 Connecting to Databricks...")
            if not db.test_connection():
                return {
                    "success": False, 
                    "error": "Failed to connect to Databricks"
                }

            # Step 2: Table Data Loading
            print("📋 Loading Table Data for ToT Analysis...")
            dataframes = {}
            tables_for_tot = []
            for table_info in selected_tables:
                if isinstance(table_info, dict):
                    if 'catalog' in table_info and 'schema_name' in table_info and 'name' in table_info:
                        catalog_name = table_info['catalog']
                        schema_name = table_info['schema_name']
                        table_name = table_info['name']
                        full_name = f"{catalog_name}.{schema_name}.{table_name}"
                        tables_for_tot.append({'catalog': catalog_name, 'schema': schema_name, 'name': table_name})
                        print(f"  📊 Loading {full_name} as DataFrame...")
                        try:
                            df = self.tree_analyzer.load_table_from_databricks(catalog_name, schema_name, table_name, limit=1000)
                            dataframes[full_name] = df
                        except Exception as e:
                            print(f"❌ Failed to load {full_name}: {e}")
                            return {"success": False, "error": f"Failed to load {full_name}: {e}"}
                    else:
                        continue
                else:
                    continue

            # Dataset summary (business intro + technical)
            num_tables = len(dataframes)
            total_columns = sum(len(df.columns) for df in dataframes.values())
            table_names = list(dataframes.keys())
            tech_summary = f"Dataset contains {num_tables} tables, {total_columns} columns. Example tables: {', '.join(table_names[:3])}{'...' if num_tables > 3 else ''}."
            # Estimate analysis time (simple heuristic)
            est_time_sec = int(num_tables * 2 + total_columns * 0.1)
            time_summary = f"Estimated analysis time: {est_time_sec} seconds."
            # Use Gemini to generate a business intro
            from client import get_spark_assist_analysis
            business_intro_prompt = (
                "You are a business analyst. Write a polished, executive-style summary (3-4 sentences) for the start of a data analysis report. "
                f"The dataset consists of {num_tables} tables and {total_columns} columns. "
                f"The tables include: {', '.join(table_names[:3])}{'...' if num_tables > 3 else ''}. "
                "Highlight the business value, key relationships (e.g., between regions, suppliers, customers, parts), and actionable outcomes such as optimizing logistics, improving customer targeting, or driving revenue growth. "
                "Blend this business context smoothly with the technical summary and estimated analysis time, so the result is a single, high-level, executive summary paragraph."
            )
            time.sleep(5)
            business_intro = get_spark_assist_analysis(business_intro_prompt)
            dataset_summary = f"{business_intro.strip()} {tech_summary} {time_summary}"

            # Step 3: Build ToT Tree and Run Chunked AI Analysis
            print("🌳 Building ToT Tree and Running Chunked AI Analysis...")
            progress_log = []
            def progress_callback(msg):
                print(msg)
                progress_log.append(msg)
            tot_result = self.tree_analyzer.tot_full_analysis(
                tables_for_tot, dataframes, ai.ai_analyze_chunk_metadata, analysis_type, progress_callback
            )

            # Step 4: Results & Reporting
            print("📊 Compiling ToT Results...")
            analysis_result = {
                'analysis_type': analysis_type,
                'tables_analyzed': list(dataframes.keys()),
                'dataset_summary': dataset_summary,
                'tot_tree_summary': tot_result['summary'],
                'tot_tree': tot_result['tree'],
                'progress_log': progress_log,
                'timestamp': datetime.datetime.now().isoformat()
            }

            # Store result in database
            analysis_id = db_manager.store_analysis_result(
                analysis_type, list(dataframes.keys()), sql_query, analysis_result, None
            )

            return {
                "success": True,
                "analysis_id": analysis_id,
                "results": analysis_result,
                "metrics": None
            }

        except Exception as e:
            print(f"❌ ToT Analysis failed: {str(e)}")
            return {
                "success": False,
                "error": f"ToT Analysis failed: {str(e)}"
            }

    def get_analysis_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get analysis history from database."""
        return db_manager.get_analysis_history(limit)
    
    def get_analysis_by_id(self, analysis_id: int) -> Optional[Dict[str, Any]]:
        """Get specific analysis result by ID."""
        return db_manager.get_analysis_by_id(analysis_id)
    
    def delete_analysis(self, analysis_id: int) -> bool:
        """Delete analysis result by ID."""
        return db_manager.delete_analysis(analysis_id)

# Global analysis service instance
analysis_service = AnalysisService() 