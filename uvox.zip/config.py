import os

# Ultravox API configuration
# Use the environment variable if set, otherwise use the provided key
ULTRAVOX_API_KEY = os.environ.get('ULTRAVOX_API_KEY', "nkqMwypO.2YRPM3LA91G2UCSjRxj46UtFWLW5a2Od")

# Ultravox API URL
ULTRAVOX_API_URL = "https://api.ultravox.ai/api"

# Error messages
ERROR_MESSAGES = {
    402: "Payment required. This API key has reached its usage limit or requires a subscription.",
    403: "Forbidden. The API key might be invalid or expired.",
    404: "Not found. The requested resource doesn't exist.",
    429: "Rate limit exceeded. Too many requests made to the API.",
    500: "Server error. Something went wrong on the Ultravox servers.",
    502: "Bad gateway. The Ultravox API is temporarily unavailable."
}

# Default system prompt for the assistant
SYSTEM_PROMPT = """
You are a helpful assistant. In case someone asks, you can get a random cat fact via the `getCatFact` tool.
"""

# Example tool configuration for cat facts
EXAMPLE_TOOL = [
    {
        "temporaryTool": {
            "modelToolName": "getCatFact",
            "description": "Returns back a random cat fact",
            "http": {
                "baseUrlPattern": "https://catfact.ninja/fact",
                "httpMethod": "GET",
            },
        }
    }
]

# Default voice for the assistant
DEFAULT_VOICE = "Mark"
