/**
 * AeroOptima.ai - Mermaid Charts Module
 * Handles generation and rendering of Mermaid.js diagrams
 */

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Mermaid
    initMermaid();
    
    // Find all mermaid containers and add rendering controls
    setupMermaidContainers();
});

/**
 * Escape HTML special characters to prevent XSS
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    const element = document.createElement('div');
    element.textContent = text;
    return element.innerHTML;
}

/**
 * Clean and standardize Mermaid diagram code
 * @param {string} code - Mermaid diagram code
 * @returns {string} Cleaned code
 */
function cleanMermaidCode(code) {
    if (!code) return '';
    
    // Remove any markdown code fence markers, asterisks or unwanted chars
    let cleanCode = code
        .replace(/\*/g, '')                // Remove asterisks
        .replace(/```mermaid/gi, '')       // Remove mermaid code blocks with case insensitivity
        .replace(/```/g, '')               // Remove all code block markers
        .replace(/^mermaid$/gim, '')       // Remove standalone "mermaid" text
        .trim();
    
    // Ensure the flowchart/diagram starts with the proper directive
    if (!/^(?:graph|flowchart|gantt|sequenceDiagram|classDiagram|stateDiagram|er[Dd]iagram|pie|timeline)\s+/m.test(cleanCode)) {
        // Check if there's a directive somewhere in the text
        const directiveMatch = cleanCode.match(/(?:graph|flowchart|gantt|sequenceDiagram|classDiagram|stateDiagram|er[Dd]iagram|pie|timeline)\s+/);
        if (directiveMatch) {
            // Extract everything from the directive onward
            cleanCode = cleanCode.substring(directiveMatch.index);
        } else if (cleanCode.includes('-->') || cleanCode.includes('--')) {
            // Looks like a flowchart without directive
            cleanCode = 'graph TD\n' + cleanCode;
        } else if (cleanCode.includes('section') && cleanCode.includes(':')) {
            // Looks like a timeline diagram
            cleanCode = 'timeline\n' + cleanCode;
        }
    }
    
    return cleanCode;
}

/**
 * Initialize Mermaid.js with configuration
 */
function initMermaid() {
    if (typeof mermaid !== 'undefined') {
        try {
            // Reset mermaid if it was previously initialized
            if (mermaid.mermaidAPI && mermaid.mermaidAPI.reset) {
                mermaid.mermaidAPI.reset();
            }
            
            // Configure mermaid with version 9.4.3 compatible settings
            mermaid.initialize({
                startOnLoad: false,  // We'll render manually to ensure proper initialization
                theme: 'neutral',
                securityLevel: 'loose',  // Required for some rendering features
                logLevel: 'error',
                flowchart: {
                    useMaxWidth: true,
                    htmlLabels: true,
                    curve: 'linear',
                    nodeSpacing: 50,
                    rankSpacing: 50
                },
                gantt: {
                    titleTopMargin: 25,
                    barHeight: 20,
                    barGap: 4,
                    topPadding: 50,
                    leftPadding: 75,
                    gridLineStartPadding: 35,
                    fontSize: 12,
                    fontFamily: '"IBM Plex Sans", sans-serif',
                    numberSectionStyles: 4,
                    displayMode: 'compact'
                }
            });
            
            console.log('Mermaid initialized successfully');
            
            // Process any existing diagrams
            setTimeout(() => {
                try {
                    mermaid.init(undefined, '.mermaid');
                } catch (err) {
                    console.warn('Mermaid initial rendering error:', err.message);
                }
            }, 100);
        } catch (error) {
            console.error('Mermaid initialization error:', error);
        }
    } else {
        console.warn('Mermaid library not loaded');
    }
}

/**
 * Setup all mermaid containers with rendering controls
 */
function setupMermaidContainers() {
    const containers = document.querySelectorAll('.mermaid-container');
    
    containers.forEach(container => {
        // Add controls if not already present
        if (!container.querySelector('.mermaid-controls')) {
            const controlsDiv = document.createElement('div');
            controlsDiv.className = 'mermaid-controls mb-2 d-flex justify-content-end';
            
            // Add refresh button
            const refreshBtn = document.createElement('button');
            refreshBtn.className = 'btn btn-sm btn-outline-secondary me-2';
            refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
            refreshBtn.addEventListener('click', function() {
                refreshMermaidDiagram(container);
            });
            
            // Add download button
            const downloadBtn = document.createElement('button');
            downloadBtn.className = 'btn btn-sm btn-outline-primary';
            downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download SVG';
            downloadBtn.addEventListener('click', function() {
                downloadMermaidSVG(container);
            });
            
            // Add buttons to controls
            controlsDiv.appendChild(refreshBtn);
            controlsDiv.appendChild(downloadBtn);
            
            // Add controls to container
            container.prepend(controlsDiv);
        }
    });
}

/**
 * Generate a mermaid diagram using Gemini
 * @param {string} type - Type of chart (flowchart, gantt, etc.)
 * @param {Object} data - Data for the chart
 * @param {string} targetElementId - ID of element to render chart in
 */
function generateMermaidDiagram(type, data, targetElementId) {
    const targetElement = document.getElementById(targetElementId);
    if (!targetElement) return;
    
    // Show loading state
    targetElement.innerHTML = '<div class="spinner"></div><p class="text-center">Generating diagram...</p>';
    
    // Determine API endpoint based on type
    let endpoint;
    switch (type) {
        case 'flowchart':
            endpoint = '/api/generate-flowchart';
            break;
        case 'timeline':
            endpoint = '/api/generate-timeline-chart';
            break;
        case 'optimizer-flow':
            endpoint = '/api/generate-flowchart'; // Uses the same endpoint with different data
            break;
        default:
            endpoint = '/api/generate-flowchart';
    }
    
    // Send to API
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Get the diagram code (each endpoint returns it in a different property)
        let diagramCode;
        if (data.flowchart) {
            diagramCode = data.flowchart;
        } else if (data.chart) {
            diagramCode = data.chart;
        } else {
            diagramCode = Object.values(data)[0]; // Fallback to first property
        }

        // Clean the Mermaid diagram code
        diagramCode = cleanMermaidCode(diagramCode);
        
        console.log('Rendering Mermaid diagram:', diagramCode);
        
        // Create container with controls
        targetElement.innerHTML = `
            <div class="mermaid-container">
                <div class="mermaid-controls mb-2 d-flex justify-content-end">
                    <button class="btn btn-sm btn-outline-secondary me-2" onclick="refreshMermaidDiagram(this.closest('.mermaid-container'))">
                        <i class="fas fa-sync-alt"></i> Refresh
                    </button>
                    <button class="btn btn-sm btn-outline-primary" onclick="downloadMermaidSVG(this.closest('.mermaid-container'))">
                        <i class="fas fa-download"></i> Download SVG
                    </button>
                </div>
                <div class="mermaid">
${diagramCode}
                </div>
            </div>
        `;
        
        // Initialize Mermaid with config and render
        if (typeof mermaid !== 'undefined') {
            try {
                // Reset mermaid to clear any previous configurations
                if (mermaid.mermaidAPI && mermaid.mermaidAPI.reset) {
                    mermaid.mermaidAPI.reset();
                }
                
                // Configure mermaid with version 9.4.3 compatible settings
                mermaid.initialize({
                    startOnLoad: false,  // We'll render manually
                    theme: 'neutral',
                    securityLevel: 'loose',  // Required for some rendering features
                    logLevel: 'error',
                    flowchart: {
                        htmlLabels: true,
                        curve: 'linear',  // More reliable than 'basis'
                        useMaxWidth: true,
                        nodeSpacing: 50,
                        rankSpacing: 50
                    },
                    gantt: {
                        titleTopMargin: 25,
                        barHeight: 20,
                        barGap: 4,
                        topPadding: 50,
                        leftPadding: 75,
                        fontSize: 12,
                        displayMode: 'compact'
                    }
                });
                
                // Render the diagram
                mermaid.init(undefined, targetElement.querySelector('.mermaid'));
            } catch (error) {
                console.error('Mermaid rendering error:', error);
                targetElement.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Error rendering diagram: ${error.message}
                        <hr>
                        <pre class="small text-muted">${escapeHtml(diagramCode)}</pre>
                    </div>
                `;
            }
        } else {
            console.error('Mermaid library not loaded');
            targetElement.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Unable to render diagram. Mermaid library not loaded.
                </div>
            `;
        }
    })
    .catch(error => {
        // Show error message
        targetElement.innerHTML = `<div class="alert alert-danger">Failed to generate diagram: ${error.message}</div>`;
        console.error('Diagram generation error:', error);
    });
}

/**
 * Refresh a mermaid diagram
 * @param {HTMLElement} container - Mermaid container element
 */
function refreshMermaidDiagram(container) {
    const mermaidDiv = container.querySelector('.mermaid');
    if (!mermaidDiv) return;
    
    // Get the diagram definition
    let definition = mermaidDiv.textContent.trim();
    
    // Clean the Mermaid diagram code
    definition = cleanMermaidCode(definition);
    
    // Create a temporary placeholder while refreshing
    const tempDiv = document.createElement('div');
    tempDiv.className = 'text-center p-3';
    tempDiv.innerHTML = '<div class="spinner"></div><p>Refreshing diagram...</p>';
    
    // Replace mermaid div with placeholder
    mermaidDiv.replaceWith(tempDiv);
    
    // Create a new mermaid div
    const newMermaidDiv = document.createElement('div');
    newMermaidDiv.className = 'mermaid';
    newMermaidDiv.textContent = definition;
    
    // Replace placeholder with new mermaid div
    setTimeout(() => {
        tempDiv.replaceWith(newMermaidDiv);
        
        // Render the diagram with enhanced configuration
        if (typeof mermaid !== 'undefined') {
            try {
                // Reset mermaid to clear any previous configurations
                if (mermaid.mermaidAPI && mermaid.mermaidAPI.reset) {
                    mermaid.mermaidAPI.reset();
                }
                
                // Configure mermaid with version 9.4.3 compatible settings
                mermaid.initialize({
                    startOnLoad: false,
                    theme: 'neutral',
                    securityLevel: 'loose',
                    logLevel: 'error',
                    flowchart: {
                        htmlLabels: true,
                        curve: 'linear',
                        useMaxWidth: true,
                        nodeSpacing: 50,
                        rankSpacing: 50
                    },
                    gantt: {
                        titleTopMargin: 25,
                        barHeight: 20,
                        barGap: 4,
                        topPadding: 50,
                        leftPadding: 75,
                        fontSize: 12,
                        displayMode: 'compact'
                    }
                });
                
                // Render the diagram
                mermaid.init(undefined, newMermaidDiv);
            } catch (error) {
                console.error('Mermaid refresh error:', error);
                newMermaidDiv.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Error refreshing diagram: ${error.message}
                    </div>
                `;
            }
        } else {
            console.warn('Mermaid library not loaded during refresh');
        }
    }, 300);
}

/**
 * Download a mermaid diagram as SVG
 * @param {HTMLElement} container - Mermaid container element
 */
function downloadMermaidSVG(container) {
    const svg = container.querySelector('svg');
    if (!svg) return;
    
    // Get the title from the diagram or use default
    let title = 'diagram';
    const titleElement = svg.querySelector('title');
    if (titleElement) {
        title = titleElement.textContent.replace(/\s+/g, '_').toLowerCase();
    }
    
    // Get SVG content
    const svgContent = svg.outerHTML;
    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    
    // Create download link
    const link = document.createElement('a');
    link.href = url;
    link.download = `aerooptima_${title}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

/**
 * Render a timeline diagram for a sequence of events (using flowchart)
 * @param {Array} events - Array of timeline events
 * @param {string} targetElementId - ID of element to render chart in
 */
function renderTimeline(events, targetElementId) {
    const targetElement = document.getElementById(targetElementId);
    if (!targetElement || !events || !events.length) return;
    
    // Sort events by timestamp
    events.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
    
    // Format times as HH:MM
    const formatTime = (date) => {
        return new Date(date).toTimeString().substring(0, 5);
    };
    
    // Start building the flowchart with proper syntax for Mermaid 11.6.0
    let flowCode = `graph LR
    %% Incident Timeline
    `;
    
    // Generate node IDs
    const nodeIds = events.map((_, index) => `event${index + 1}`);
    
    // Create nodes for each event with timestamps
    events.forEach((event, index) => {
        const timestamp = formatTime(event.timestamp);
        const nodeId = nodeIds[index];
        const eventCategory = event.category || 'Events';
        
        // Use different node shapes based on category
        let nodeShape = '';
        if (eventCategory.toLowerCase().includes('decision')) {
            nodeShape = '{'; // Rhombus for decision points
        } else if (eventCategory.toLowerCase().includes('outcome') || index === events.length - 1) {
            nodeShape = '(['; // Stadium shape for outcomes
        } else if (index === 0) {
            nodeShape = '(['; // Stadium shape for start
        } else {
            nodeShape = '['; // Rectangle for regular events
        }
        
        const closeShape = nodeShape === '{' ? '}' : nodeShape === '([' ? '])' : ']';
        flowCode += `    ${nodeId}${nodeShape}${timestamp} - ${event.event}${closeShape}\n`;
    });
    
    // Connect the nodes in sequence
    for (let i = 0; i < nodeIds.length - 1; i++) {
        flowCode += `    ${nodeIds[i]} --> ${nodeIds[i + 1]}\n`;
    }
    
    // Create subgraphs for categories if there are multiple
    const categories = [...new Set(events.map(e => e.category || 'Events'))];
    if (categories.length > 1) {
        flowCode += '\n';
        categories.forEach(category => {
            // Filter event indices for this category
            const categoryIndices = events
                .map((e, i) => ((e.category || 'Events') === category) ? i : -1)
                .filter(i => i !== -1);
            
            if (categoryIndices.length > 0) {
                // Start subgraph
                flowCode += `    subgraph ${category}\n`;
                
                // Add node IDs
                categoryIndices.forEach(i => {
                    flowCode += `    ${nodeIds[i]}\n`;
                });
                
                // End subgraph
                flowCode += '    end\n';
            }
        });
    }
    
    // Create container with controls
    targetElement.innerHTML = `
        <div class="mermaid-container">
            <div class="mermaid-controls mb-2 d-flex justify-content-end">
                <button class="btn btn-sm btn-outline-secondary me-2" onclick="refreshMermaidDiagram(this.closest('.mermaid-container'))">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
                <button class="btn btn-sm btn-outline-primary" onclick="downloadMermaidSVG(this.closest('.mermaid-container'))">
                    <i class="fas fa-download"></i> Download SVG
                </button>
            </div>
            <div class="mermaid">
${flowCode}
            </div>
        </div>
    `;
    
    // Initialize Mermaid with config and render
    if (typeof mermaid !== 'undefined') {
        try {
            // Reset mermaid to clear any previous configurations
            if (mermaid.mermaidAPI && mermaid.mermaidAPI.reset) {
                mermaid.mermaidAPI.reset();
            }
            
            // Configure mermaid with version 9.4.3 compatible settings
            mermaid.initialize({
                startOnLoad: false,  // We'll render manually
                theme: 'neutral',
                securityLevel: 'loose',  // Required for some rendering features
                logLevel: 'error',
                flowchart: {
                    htmlLabels: true,
                    curve: 'linear',  // More reliable than 'basis'
                    useMaxWidth: true,
                    nodeSpacing: 50,
                    rankSpacing: 50
                },
                gantt: {
                    titleTopMargin: 25,
                    barHeight: 20,
                    barGap: 4,
                    topPadding: 50,
                    leftPadding: 75,
                    fontSize: 12,
                    displayMode: 'compact'
                }
            });
            
            // Render the diagram
            mermaid.init(undefined, targetElement.querySelector('.mermaid'));
        } catch (error) {
            console.error('Mermaid rendering error:', error);
            targetElement.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Error rendering diagram: ${error.message}
                    <hr>
                    <pre class="small text-muted">${escapeHtml(flowCode)}</pre>
                </div>
            `;
        }
    }
}

/**
 * Legacy function to render a Gantt chart for a timeline of events (kept for backwards compatibility)
 * @param {Array} events - Array of timeline events
 * @param {string} targetElementId - ID of element to render chart in
 */
function renderTimelineGantt(events, targetElementId) {
    // Call the new function instead
    renderTimeline(events, targetElementId);
}

/**
 * Render a process flow diagram for optimization
 * @param {string} scenario - Optimization scenario description
 * @param {string} targetElementId - ID of element to render chart in
 */
function renderOptimizationFlow(scenario, targetElementId) {
    // Use the generic function with specific settings
    generateMermaidDiagram('optimizer-flow', { scenario: scenario }, targetElementId);
}

/**
 * Render the AeroOptima architecture diagram
 * @param {string} targetElementId - ID of element to render chart in
 */
function renderArchitectureDiagram(targetElementId) {
    const targetElement = document.getElementById(targetElementId);
    if (!targetElement) return;
    
    // Define the architecture diagram
    const diagramCode = `graph LR
    DataHub([Data Hub]) -->|populates| LiveWatch([Live Watch])
    DataHub -->|provides history| Debrief([Debrief])
    LiveWatch -->|triggers| Optimizer([Optimizer])
    LiveWatch -->|incident data| Debrief
    Optimizer -->|recovery plans| Debrief
    
    subgraph Data Sources
    CrewData[(Crew Data)]
    AircraftData[(Aircraft Data)]
    FlightData[(Flight Data)]
    WeatherData[(Weather Data)]
    end
    
    subgraph External Systems
    Gemini{{Gemini LLM}}
    end
    
    CrewData --> DataHub
    AircraftData --> DataHub
    FlightData --> DataHub
    WeatherData --> DataHub
    
    Gemini -.->|enhances| LiveWatch
    Gemini -.->|analyzes| Optimizer
    Gemini -.->|explains| Debrief
    `;
    
    // Create container with controls
    targetElement.innerHTML = `
        <div class="mermaid-container">
            <div class="mermaid-controls mb-2 d-flex justify-content-end">
                <button class="btn btn-sm btn-outline-secondary me-2" onclick="refreshMermaidDiagram(this.closest('.mermaid-container'))">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
                <button class="btn btn-sm btn-outline-primary" onclick="downloadMermaidSVG(this.closest('.mermaid-container'))">
                    <i class="fas fa-download"></i> Download SVG
                </button>
            </div>
            <div class="mermaid">
                ${diagramCode}
            </div>
        </div>
    `;
    
    // Render the diagram
    if (typeof mermaid !== 'undefined') {
        mermaid.init(undefined, targetElement.querySelector('.mermaid'));
    }
}
