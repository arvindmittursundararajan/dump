import os
import csv
import requests
import config  # Import the config module

# Define your Databricks workspace URL and API key from config
workspace_url = f'https://{config.server_hostname}'
access_token = config.access_token

# Set the headers for authentication
headers = {
    'Authorization': f'Bearer {access_token}',
    'Content-Type': 'application/json',
}

# Create output directory
output_dir = 'output'
os.makedirs(output_dir, exist_ok=True)

def clear_output_directory():
    """Delete all files in the output directory."""
    for filename in os.listdir(output_dir):
        file_path = os.path.join(output_dir, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
            print(f"Deleted {filename}")
        except Exception as e:
            print(f"Error deleting {filename}: {e}")

def write_tables_to_csv(tables_data):
    with open(os.path.join(output_dir, 'tables.csv'), mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Catalog", "Schema", "Table Name", "Type", "Data Source Format"])
        writer.writerows(tables_data)

def write_columns_to_csv(columns_data, table_name):
    with open(os.path.join(output_dir, f'columns_{table_name}.csv'), mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Catalog", "Schema", "Table", "Column Name", "Data Type", "Is Nullable", "Full Data Type", "Numeric Precision", "Max Length", "Comment"])
        writer.writerows(columns_data)

def show_catalogs():
    """Fetch and display catalogs from Databricks."""
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": "SHOW CATALOGS;", "warehouse_id": config.http_path.split('/')[-1]}
    )
    if response.status_code == 200:
        catalogs = response.json()
        if 'result' in catalogs and 'data_array' in catalogs['result']:
            catalog_names = [catalog[0] for catalog in catalogs['result']['data_array']]
            print("Catalogs:")
            for i, catalog in enumerate(catalog_names, start=1):
                print(f"{i}. {catalog}")
            return catalog_names
        else:
            print("Unexpected response format:", catalogs)
            return []
    else:
        print("Error fetching catalogs:", response.json())
        return []

def use_catalog(catalog_name):
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": f"USE CATALOG {catalog_name};", "warehouse_id": config.http_path.split('/')[-1]}
    )
    return response.status_code == 200

def show_schemas(catalog_name):
    query = f"SELECT schema_name FROM {catalog_name}.information_schema.schemata;"
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": query, "warehouse_id": config.http_path.split('/')[-1]}
    )
    
    if response.status_code == 200:
        schemas = response.json()
        if 'result' in schemas and 'data_array' in schemas['result']:
            schema_names = [schema[0] for schema in schemas['result']['data_array']]
            print("Schemas:")
            for i, schema in enumerate(schema_names):
                print(f"{i + 1}. {schema}")
            return schema_names
        else:
            print("Unexpected response format:", schemas)
            return []
    else:
        print("Error fetching schemas:", response.json())
        return []

def show_tables(catalog_name, schema_name):
    query = f"SELECT * FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}';"
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": query, "warehouse_id": config.http_path.split('/')[-1]}
    )
    
    if response.status_code == 200:
        tables = response.json()
        tables_data = []
        print("Tables:")
        for i, table in enumerate(tables['result']['data_array'], start=1):
            table_info = {
                "catalog": table[0],
                "schema": table[1],
                "name": table[2],
                "type": table[3],
                "data_source_format": table[13]
            }
            tables_data.append([table_info['catalog'], table_info['schema'], table_info['name'], table_info['type'], table_info['data_source_format']])
            print(f"{i}. Name: {table_info['name']}, Type: {table_info['type']}, Format: {table_info['data_source_format']}")
        
        return tables_data
    else:
        print("Error fetching tables:", response.json())
        return []

def show_columns(catalog_name, schema_name, table_name):
    query = f"SELECT * FROM {catalog_name}.information_schema.columns WHERE table_schema = '{schema_name}' AND table_name = '{table_name}';"
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": query, "warehouse_id": config.http_path.split('/')[-1]}
    )
    
    if response.status_code == 200:
        columns = response.json()
        columns_data = []
        print(f"Columns in {table_name}:")
        for column in columns['result']['data_array']:
            column_info = {
                "catalog": column[0],
                "schema": column[1],
                "table": column[2],
                "name": column[3],
                "data_type": column[8],
                "is_nullable": column[6],
                "full_data_type": column[7],
                "numeric_precision": column[10],
                "character_maximum_length": column[9],
                "comment": column[18]
            }
            columns_data.append([column_info['catalog'], column_info['schema'], column_info['table'], column_info['name'], column_info['data_type'], column_info['is_nullable'], column_info['full_data_type'], column_info['numeric_precision'], column_info['character_maximum_length'], column_info['comment']])
            print(f"- Name: {column_info['name']}, Type: {column_info['full_data_type']}, Nullable: {column_info['is_nullable']}, Precision: {column_info['numeric_precision']}, Max Length: {column_info['character_maximum_length']}, Comment: {column_info['comment']}")
        
        return columns_data
    else:
        print("Error fetching columns:", response.json())
        return []

def select_and_store_tables(tables_data):
    table_indices = input("Enter the table numbers you want to select (comma-separated, e.g., 1,3,5): ")
    selected_indices = [int(i.strip()) - 1 for i in table_indices.split(",") if i.strip().isdigit()]
    
    for index in selected_indices:
        if 0 <= index < len(tables_data):
            selected_table = tables_data[index]
            print(f"Fetching columns for table: {selected_table[2]}")
            columns_data = show_columns(selected_table[0], selected_table[1], selected_table[2])
            if columns_data:
                write_columns_to_csv(columns_data, selected_table[2])  # Save columns to CSV
        else:
            print(f"Table index {index + 1} is out of range.")

# Main interaction loop
while True:
    print("\n--- Databricks SQL Navigation ---")
    print("1. List all catalogs")
    print("2. Delete and recreate output files")
    print("3. Refresh data")
    print("4. Exit")
    choice = input("Choose an option: ")

    if choice == '1':
        catalogs = show_catalogs()
        if catalogs:
            while True:
                try:
                    catalog_choice = int(input("Select a catalog by number: ")) - 1
                    if 0 <= catalog_choice < len(catalogs):
                        selected_catalog = catalogs[catalog_choice]
                        if use_catalog(selected_catalog):
                            print(f"Switched to catalog: {selected_catalog}")

                            # Show schemas for the selected catalog
                            schemas = show_schemas(selected_catalog)
                            if schemas:
                                while True:
                                    schema_choice = int(input("Select a schema by number: ")) - 1
                                    if 0 <= schema_choice < len(schemas):
                                        selected_schema = schemas[schema_choice]
                                        print(f"Switched to schema: {selected_schema}")

                                        # Show tables using the specified SQL query
                                        tables_data = show_tables(selected_catalog, selected_schema)
                                        if tables_data:
                                            select_and_store_tables(tables_data)  # Select tables to save
                                        break  # Exit the schema selection loop
                                    else:
                                        print("Invalid schema choice. Please select a valid number.")
                            break  # Exit the catalog selection loop
                    else:
                        print("Invalid catalog choice. Please select a valid number.")
                except ValueError:
                    print("Invalid input. Please enter a number.")
    
    elif choice == '2':
        clear_output_directory()  # Clear all files in the output directory
        print("All output files have been deleted.")
    
    elif choice == '3':
        print("Refreshing data...")
        continue
    
    elif choice == '4':
        print("Exiting...")
        break
    
    else:
        print("Invalid option. Please try again.")
