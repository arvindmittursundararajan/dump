import os
import requests
import sqlite3
from config import DATABRICKS_SERVER, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN

# Define your Databricks workspace URL and API key from config
workspace_url = f'https://{DATABRICKS_SERVER}'
access_token = DATABRICKS_TOKEN
http_path = DATABRICKS_HTTP_PATH

# Set the headers for authentication
headers = {
    'Authorization': f'Bearer {access_token}',
    'Content-Type': 'application/json',
}

def connect_db():
    """Connect to the SQLite database."""
    conn = sqlite3.connect('adw_workbench.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database with the schema."""
    with open('schema.sql', 'r') as f:
        schema = f.read()
    conn = connect_db()
    conn.executescript(schema)
    conn.commit()
    conn.close()

def execute_sql_statement(statement):
    """Execute a SQL statement in Databricks and return the response."""
    response = requests.post(
        f'{workspace_url}/api/2.0/sql/statements',
        headers=headers,
        json={"statement": statement, "warehouse_id": http_path.split('/')[-1]}
    )
    return response.json() if response.status_code == 200 else None

def get_catalogs():
    """Fetch all catalogs from Databricks."""
    response = execute_sql_statement("SHOW CATALOGS;")
    
    if response and 'result' in response and 'data_array' in response['result']:
        catalogs = [{"name": catalog[0]} for catalog in response['result']['data_array']]
        return catalogs
    return []

def get_schemas(catalog_name):
    """Fetch all schemas for a given catalog from Databricks."""
    query = f"SELECT schema_name FROM {catalog_name}.information_schema.schemata;"
    response = execute_sql_statement(query)
    
    if response and 'result' in response and 'data_array' in response['result']:
        schemas = [{"name": schema[0], "catalog": catalog_name} for schema in response['result']['data_array']]
        return schemas
    return []

def get_tables(catalog_name, schema_name):
    """Fetch all tables for a given schema from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.tables WHERE table_schema = '{schema_name}';"
    response = execute_sql_statement(query)
    
    if response and 'result' in response and 'data_array' in response['result']:
        tables = []
        for table in response['result']['data_array']:
            table_info = {
                "catalog": table[0],
                "schema": table[1],
                "name": table[2],
                "type": table[3],
                "data_source_format": table[13]
            }
            tables.append(table_info)
        return tables
    return []

def get_columns(catalog_name, schema_name, table_name):
    """Fetch all columns for a given table from Databricks."""
    query = f"SELECT * FROM {catalog_name}.information_schema.columns WHERE table_schema = '{schema_name}' AND table_name = '{table_name}';"
    response = execute_sql_statement(query)
    
    if response and 'result' in response and 'data_array' in response['result']:
        columns = []
        for column in response['result']['data_array']:
            column_info = {
                "catalog": column[0],
                "schema": column[1],
                "table": column[2],
                "name": column[3],
                "data_type": column[8],
                "is_nullable": column[6],
                "full_data_type": column[7],
                "numeric_precision": column[10],
                "character_maximum_length": column[9],
                "comment": column[18]
            }
            columns.append(column_info)
        return columns
    return []

def get_table_details(catalog_name, schema_name, table_name):
    """Get detailed information about a table using DESCRIBE DETAIL."""
    query = f"DESCRIBE DETAIL {catalog_name}.{schema_name}.{table_name};"
    response = execute_sql_statement(query)
    
    if response and 'result' in response and 'data_array' in response['result']:
        detail_rows = response['result']['data_array']
        if detail_rows:
            # Process the response which contains table details
            # Format may vary, but this typically contains file count, size, etc.
            return {
                "size_bytes": detail_rows[0][2] if len(detail_rows[0]) > 2 else None,
                "file_count": detail_rows[0][3] if len(detail_rows[0]) > 3 else None,
                "format": detail_rows[0][1] if len(detail_rows[0]) > 1 else None
            }
    return {}

def get_query_history(table_name=None, limit=10):
    """Get recent query history from Databricks, optionally filtered by table."""
    url = f"{workspace_url}/api/2.0/sql/history/queries"
    params = {"max_results": limit}
    
    if table_name:
        params["filter"] = f"query_text LIKE '%{table_name}%'"
    
    response = requests.get(
        url,
        headers=headers,
        params=params
    )
    
    if response.status_code == 200:
        return response.json().get('results', [])
    return []

def save_catalog_to_db(catalog):
    """Save a catalog to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO catalogs (name) VALUES (?)",
        (catalog['name'],)
    )
    conn.commit()
    # Get the ID of the inserted catalog
    cursor.execute("SELECT id FROM catalogs WHERE name = ?", (catalog['name'],))
    catalog_id = cursor.fetchone()['id']
    conn.close()
    return catalog_id

def save_schema_to_db(schema, catalog_id):
    """Save a schema to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO schemas (catalog_id, name) VALUES (?, ?)",
        (catalog_id, schema['name'])
    )
    conn.commit()
    # Get the ID of the inserted schema
    cursor.execute("SELECT id FROM schemas WHERE catalog_id = ? AND name = ?", 
                   (catalog_id, schema['name']))
    schema_id = cursor.fetchone()['id']
    conn.close()
    return schema_id

def save_table_to_db(table, schema_id):
    """Save a table to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR IGNORE INTO tables (schema_id, name, type, data_source_format) VALUES (?, ?, ?, ?)",
        (schema_id, table['name'], table.get('type', ''), table.get('data_source_format', ''))
    )
    conn.commit()
    # Get the ID of the inserted table
    cursor.execute("SELECT id FROM tables WHERE schema_id = ? AND name = ?", 
                   (schema_id, table['name']))
    table_id = cursor.fetchone()['id']
    conn.close()
    return table_id

def save_column_to_db(column, table_id):
    """Save a column to the database."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT OR IGNORE INTO columns 
           (table_id, name, data_type, is_nullable, full_data_type, numeric_precision, max_length, comment) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (table_id, column['name'], column.get('data_type', ''), column.get('is_nullable', ''),
         column.get('full_data_type', ''), column.get('numeric_precision', ''),
         column.get('character_maximum_length', ''), column.get('comment', ''))
    )
    conn.commit()
    conn.close()

def save_selected_table(table_id, session_id):
    """Save a selected table for analysis."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO selected_tables (table_id, session_id) VALUES (?, ?)",
        (table_id, session_id)
    )
    conn.commit()
    conn.close()

def get_selected_tables(session_id):
    """Get all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.id, t.name as table_name, s.name as schema_name, c.name as catalog_name,
               t.type as table_type, t.data_source_format 
        FROM selected_tables st
        JOIN tables t ON st.table_id = t.id
        JOIN schemas s ON t.schema_id = s.id
        JOIN catalogs c ON s.catalog_id = c.id
        WHERE st.session_id = ?
    """, (session_id,))
    
    # Convert sqlite3.Row objects to dictionaries
    selected_tables = []
    column_names = [description[0] for description in cursor.description]
    for row in cursor.fetchall():
        table_dict = dict(zip(column_names, row))
        selected_tables.append(table_dict)
        
    conn.close()
    return selected_tables

def save_analysis_to_history(analysis_type, tables_analyzed, analysis_result):
    """Save an analysis to the history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO analysis_history (analysis_type, tables_analyzed, analysis_result) VALUES (?, ?, ?)",
        (analysis_type, tables_analyzed, analysis_result)
    )
    conn.commit()
    history_id = cursor.lastrowid
    conn.close()
    return history_id

def get_analysis_history():
    """Get all analysis history."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history ORDER BY created_at DESC")
    history = cursor.fetchall()
    conn.close()
    return history

def get_analysis_by_id(analysis_id):
    """Get a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analysis_history WHERE id = ?", (analysis_id,))
    analysis = cursor.fetchone()
    conn.close()
    return analysis

def delete_analysis(analysis_id):
    """Delete a specific analysis by ID."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analysis_history WHERE id = ?", (analysis_id,))
    conn.commit()
    conn.close()
    return True

def save_performance_metrics(table_name, metrics):
    """Save performance metrics for a table."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        """INSERT INTO performance_metrics 
           (table_name, query_duration, scanned_bytes, file_count, table_size_bytes) 
           VALUES (?, ?, ?, ?, ?)""",
        (table_name, metrics.get('query_duration'), metrics.get('scanned_bytes'),
         metrics.get('file_count'), metrics.get('table_size_bytes'))
    )
    conn.commit()
    conn.close()

def clear_selected_tables(session_id):
    """Clear all selected tables for a session."""
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM selected_tables WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()
