from flask import render_template, request, jsonify, session
from app import app
from models import db, DocumentVersion
import config
from confluence_api import ConfluenceAPI
from gemini_ai import GeminiAI
from datetime import datetime
import json

confluence_api = ConfluenceAPI()
gemini_ai = GeminiAI()

def clean_markdown_from_response(content):
    """Clean markdown formatting from AI responses"""
    if not content:
        return content
    
    # Remove markdown code blocks
    content = content.replace('```html', '').replace('```', '')
    
    # Remove any leading/trailing whitespace
    content = content.strip()
    
    # Clean up common markdown artifacts
    lines = content.split('\n')
    cleaned_lines = []
    
    for line in lines:
        # Skip lines that are just markdown artifacts
        if line.strip() in ['```html', '```', 'html', '```json', 'json']:
            continue
        cleaned_lines.append(line)
    
    return '\n'.join(cleaned_lines).strip()

@app.route('/')
def index():
    # Get existing pages from session or initialize empty
    pages = session.get('sample_pages', [])
    
    return render_template('index.html', 
                         pages=pages,
                         rewriting_options=config.REWRITING_OPTIONS,
                         tone_options=config.TONE_OPTIONS,
                         length_options=config.LENGTH_OPTIONS)

@app.route('/generate_sample_pages', methods=['POST'])
def generate_sample_pages():
    """Generate sample developer documentation pages in Confluence"""
    try:
        # Get available spaces
        spaces = confluence_api.get_all_spaces()
        if not spaces:
            return jsonify({'success': False, 'error': 'No Confluence spaces available'})
        
        # Use the first available space
        space_key = spaces[0]['key']
        created_pages = []
        
        # Create sample pages
        for sample_doc in config.SAMPLE_DOCS:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            title = f"{sample_doc['title']} - {timestamp}"
            
            result = confluence_api.create_page(space_key, title, sample_doc['content'])
            if result:
                created_pages.append({
                    'id': result['id'],
                    'title': result['title'],
                    'content': sample_doc['content'],
                    'space_key': space_key
                })
        
        # Store pages in session
        session['sample_pages'] = created_pages
        
        return jsonify({
            'success': True, 
            'pages': created_pages,
            'message': f'Successfully created {len(created_pages)} sample documentation pages'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_page/<page_id>')
def get_page(page_id):
    """Get specific page content"""
    try:
        # First check session pages
        pages = session.get('sample_pages', [])
        for page in pages:
            if page['id'] == page_id:
                return jsonify({'success': True, 'page': page})
        
        # If not in session, try to fetch from Confluence
        page_data = confluence_api.get_page_content(page_id)
        if page_data:
            page = {
                'id': page_data['id'],
                'title': page_data['title'],
                'content': page_data['body']['storage']['value']
            }
            return jsonify({'success': True, 'page': page})
        else:
            return jsonify({'success': False, 'error': 'Page not found'})
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/analyze_page', methods=['POST'])
def analyze_page():
    """Analyze page content against style guides"""
    try:
        data = request.get_json()
        page_content = data.get('content', '')
        
        if not page_content:
            return jsonify({'success': False, 'error': 'No content provided'})
        
        # Analyze with Gemini AI
        analysis_results = gemini_ai.analyze_documentation(
            page_content, 
            config.STYLE_GUIDE_PROMPTS
        )
        
        return jsonify({
            'success': True, 
            'analysis': analysis_results,
            'style_guides': config.STYLE_GUIDE_PROMPTS
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/generate_rewriting_options', methods=['POST'])
def generate_rewriting_options():
    """Generate LLM-powered rewriting options for specific content"""
    try:
        data = request.get_json()
        page_content = data.get('content', '')
        
        if not page_content:
            return jsonify({'success': False, 'error': 'No content provided'})
        
        # Generate options with Gemini AI
        generated_options = gemini_ai.generate_rewriting_options(page_content)
        
        # Combine with default options
        all_options = config.REWRITING_OPTIONS + generated_options
        
        return jsonify({
            'success': True, 
            'options': all_options
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/rewrite_content', methods=['POST'])
def rewrite_content():
    """Rewrite content based on user selections"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        content = data.get('content', '')
        selected_options = data.get('selected_options', [])
        tone = data.get('tone', 'professional')
        length = data.get('length', 'medium')
        custom_instruction = data.get('custom_instruction', '')
        
        if not content:
            return jsonify({'success': False, 'error': 'No content provided'})
        
        # Find length option details
        length_option = next((opt for opt in config.LENGTH_OPTIONS if opt['id'] == length), config.LENGTH_OPTIONS[1])
        
        # Get selected option descriptions
        option_descriptions = []
        all_options = config.REWRITING_OPTIONS
        for option_id in selected_options:
            option = next((opt for opt in all_options if opt['id'] == option_id), None)
            if option:
                option_descriptions.append(option['description'])
        
        # Rewrite content
        rewritten_content = gemini_ai.rewrite_content(
            content, 
            option_descriptions, 
            tone, 
            length_option,
            custom_instruction
        )
        
        # Clean markdown formatting from the response
        rewritten_content = clean_markdown_from_response(rewritten_content)
        
        # Only update Confluence and database if page_id is provided (not in preview mode)
        if page_id:
            pages = session.get('sample_pages', [])
            for i, page in enumerate(pages):
                if page['id'] == page_id:
                    # Update page in Confluence
                    updated_title = f"Enhanced {page['title']}"
                    confluence_result = confluence_api.update_page(page_id, updated_title, rewritten_content)
                    
                    if confluence_result:
                        # Save new version to database
                        DocumentVersion.create_new_version(
                            page_id=page_id,
                            title=updated_title,
                            content=rewritten_content,
                            space_key=page.get('space_key', 'UNKNOWN'),
                            tone=tone,
                            length=length,
                            options=json.dumps(selected_options),
                            instructions=custom_instruction
                        )
                        
                        # Update session data
                        pages[i]['content'] = rewritten_content
                        pages[i]['title'] = updated_title
                        session['sample_pages'] = pages
                    break
        
        return jsonify({
            'success': True, 
            'rewritten_content': rewritten_content,
            'message': 'Content successfully rewritten and updated'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/cleanup_pages', methods=['POST'])
def cleanup_pages():
    """Delete all sample pages from Confluence"""
    try:
        pages = session.get('sample_pages', [])
        deleted_count = 0
        
        for page in pages:
            if confluence_api.delete_page(page['id']):
                deleted_count += 1
        
        # Clear session
        session.pop('sample_pages', None)
        
        return jsonify({
            'success': True, 
            'message': f'Successfully deleted {deleted_count} pages'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/save_original_version', methods=['POST'])
def save_original_version():
    """Save the original version (version 0) to database"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        title = data.get('title')
        content = data.get('content')
        space_key = data.get('space_key', 'UNKNOWN')
        
        # Check if version 0 already exists
        existing = DocumentVersion.query.filter_by(
            confluence_page_id=page_id,
            version_number=0
        ).first()
        
        if not existing:
            # Create version 0 (original)
            DocumentVersion.create_new_version(
                page_id=page_id,
                title=title,
                content=content,
                space_key=space_key
            )
            
            # Set it as version 0
            latest = DocumentVersion.query.filter_by(
                confluence_page_id=page_id
            ).order_by(DocumentVersion.version_number.desc()).first()
            
            if latest:
                latest.version_number = 0
                db.session.commit()
        
        return jsonify({'success': True, 'message': 'Original version saved'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_versions/<page_id>')
def get_versions(page_id):
    """Get all versions for a specific page"""
    try:
        versions = DocumentVersion.get_all_versions(page_id)
        version_data = []
        
        for version in versions:
            version_data.append({
                'id': version.id,
                'version_number': version.version_number,
                'title': version.title,
                'created_at': version.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                'is_current': version.is_current,
                'tone_used': version.tone_used,
                'length_used': version.length_used,
                'rewriting_options': json.loads(version.rewriting_options) if version.rewriting_options else [],
                'custom_instructions': version.custom_instructions
            })
        
        return jsonify({'success': True, 'versions': version_data})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/load_version', methods=['POST'])
def load_version():
    """Load a specific version of a document"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        version_number = data.get('version_number')
        
        # Set the selected version as current
        version = DocumentVersion.set_current_version(page_id, version_number)
        
        if version:
            return jsonify({
                'success': True,
                'version': {
                    'title': version.title,
                    'content': version.content,
                    'version_number': version.version_number,
                    'created_at': version.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    'custom_instructions': version.custom_instructions,
                    'tone_used': version.tone_used,
                    'length_used': version.length_used
                }
            })
        else:
            return jsonify({'success': False, 'error': 'Version not found'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/update_confluence', methods=['POST'])
def update_confluence():
    """Update the Confluence page with the current version"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        
        # Get current version from database
        current_version = DocumentVersion.get_current_version(page_id)
        
        if not current_version:
            return jsonify({'success': False, 'error': 'No current version found'})
        
        # Save the previous Confluence content as a new version before updating
        current_confluence = confluence_api.get_page_content(page_id)
        if current_confluence:
            # Create a backup version of what's currently in Confluence
            DocumentVersion.create_new_version(
                page_id=page_id,
                title=f"Backup - {current_confluence['title']}",
                content=current_confluence['body']['storage']['value'],
                space_key=current_version.space_key
            )
        
        # Update Confluence with the current version
        result = confluence_api.update_page(
            page_id, 
            current_version.title, 
            current_version.content
        )
        
        if result:
            return jsonify({
                'success': True, 
                'message': 'Confluence page updated successfully'
            })
        else:
            return jsonify({
                'success': False, 
                'error': 'Failed to update Confluence page'
            })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/save_new_version', methods=['POST'])
def save_new_version():
    """Save a new version without updating Confluence"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        content = data.get('content', '')
        title = data.get('title', '')
        selected_options = data.get('selected_options', [])
        tone = data.get('tone', 'professional')
        length = data.get('length', 'medium')
        custom_instruction = data.get('custom_instruction', '')
        
        if not page_id or not content:
            return jsonify({'success': False, 'error': 'Page ID and content required'})
        
        # Get space key from existing page data
        pages = session.get('sample_pages', [])
        space_key = 'UNKNOWN'
        for page in pages:
            if page['id'] == page_id:
                space_key = page.get('space_key', 'UNKNOWN')
                break
        
        # Save new version to database
        new_version = DocumentVersion.create_new_version(
            page_id=page_id,
            title=title,
            content=content,
            space_key=space_key,
            tone=tone,
            length=length,
            options=json.dumps(selected_options),
            instructions=custom_instruction
        )
        
        return jsonify({
            'success': True, 
            'message': f'Version {new_version.version_number} saved successfully',
            'version_number': new_version.version_number
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/delete_version', methods=['POST'])
def delete_version():
    """Delete a specific version of a document"""
    try:
        data = request.get_json()
        page_id = data.get('page_id')
        version_number = data.get('version_number')
        
        if not page_id or version_number is None:
            return jsonify({'success': False, 'error': 'Page ID and version number required'})
        
        # Don't allow deletion of version 0 (original)
        if version_number == 0:
            return jsonify({'success': False, 'error': 'Cannot delete the original version (v0)'})
        
        # Find and delete the version
        version = DocumentVersion.query.filter_by(
            confluence_page_id=page_id,
            version_number=version_number
        ).first()
        
        if not version:
            return jsonify({'success': False, 'error': 'Version not found'})
        
        # If this was the current version, set the latest remaining version as current
        was_current = version.is_current
        
        db.session.delete(version)
        db.session.commit()
        
        if was_current:
            # Find the latest remaining version and set it as current
            latest_version = DocumentVersion.query.filter_by(
                confluence_page_id=page_id
            ).order_by(DocumentVersion.version_number.desc()).first()
            
            if latest_version:
                # Reset all versions to not current
                DocumentVersion.query.filter_by(
                    confluence_page_id=page_id
                ).update({'is_current': False})
                
                # Set the latest as current
                latest_version.is_current = True
                db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Version {version_number} deleted successfully'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
