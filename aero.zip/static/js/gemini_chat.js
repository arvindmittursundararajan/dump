/**
 * AeroOptima.ai - Gemini Chat Module
 * Handles interactions with the Gemini API via the chat interface
 */

// Store conversation history
let conversationHistory = [];

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Get the chat elements
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const chatSendBtn = document.getElementById('chat-send');
    const chatPanel = document.getElementById('chat-panel');
    const chatToggle = document.getElementById('chat-toggle');
    const chatMinimize = document.getElementById('chat-minimize');
    const closeChat = document.getElementById('close-chat');
    
    // If chat elements exist, initialize chat functionality
    if (chatPanel && chatMessages && chatInput && chatSendBtn) {
        // Initialize with a welcome message
        addBotMessage('Welcome to AeroOptima AI. How can I help optimize your airline operations today?');
        
        // Handle send button click
        chatSendBtn.addEventListener('click', function() {
            sendChatMessage();
        });
        
        // Handle enter key in input (allow shift+enter for new line)
        chatInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendChatMessage();
            }
            
            // Auto-resize textarea
            setTimeout(() => {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            }, 0);
        });
        
        // Handle input focus
        chatInput.addEventListener('focus', function() {
            // Hide suggested questions when input is focused
            const suggestedQuestions = document.querySelector('.suggested-questions');
            if (suggestedQuestions) {
                suggestedQuestions.style.display = 'none';
            }
        });
        
        // Handle input blur
        chatInput.addEventListener('blur', function() {
            // Only show suggested questions if there's no conversation yet
            if (conversationHistory.length <= 1) {
                const suggestedQuestions = document.querySelector('.suggested-questions');
                if (suggestedQuestions) {
                    suggestedQuestions.style.display = 'block';
                }
            }
        });
        
        // Handle chat toggle
        if (chatToggle) {
            chatToggle.addEventListener('click', function() {
                chatPanel.classList.toggle('d-none');
                
                // Update button text based on visibility
                if (chatPanel.classList.contains('d-none')) {
                    chatToggle.innerHTML = '<i class="fas fa-comment"></i> Show Gemini';
                } else {
                    chatToggle.innerHTML = '<i class="fas fa-comment-dots"></i> Hide Gemini';
                    // Focus the input when opening
                    chatInput.focus();
                }
            });
        }
        
        // Handle chat minimize
        if (chatMinimize) {
            chatMinimize.addEventListener('click', function() {
                // Toggle a minimized class
                chatPanel.classList.toggle('minimized');
                
                if (chatPanel.classList.contains('minimized')) {
                    this.innerHTML = '<i class="fas fa-expand"></i>';
                    this.title = 'Expand';
                } else {
                    this.innerHTML = '<i class="fas fa-minus"></i>';
                    this.title = 'Minimize';
                }
            });
        }
        
        // Handle close chat
        if (closeChat) {
            closeChat.addEventListener('click', function() {
                chatPanel.classList.add('d-none');
                chatToggle.innerHTML = '<i class="fas fa-comment"></i> Show Gemini';
            });
        }
        
        // Handle suggested questions
        document.querySelectorAll('.suggested-question').forEach(question => {
            question.addEventListener('click', function() {
                const text = this.getAttribute('data-question');
                if (text) {
                    chatInput.value = text;
                    chatInput.focus();
                    sendChatMessage();
                }
            });
        });
    }
});

/**
 * Send a chat message to the Gemini API
 */
function sendChatMessage() {
    const chatInput = document.getElementById('chat-input');
    const message = chatInput.value.trim();
    
    if (message) {
        // Add user message to chat
        addUserMessage(message);
        
        // Add to conversation history
        conversationHistory.push({
            role: 'user',
            content: message
        });
        
        // Clear input and reset height
        chatInput.value = '';
        chatInput.style.height = 'auto';
        
        // Add typing indicator
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'chat-message bot typing-indicator';
        typingIndicator.id = 'typing-indicator';
        typingIndicator.textContent = 'Thinking';
        document.getElementById('chat-messages').appendChild(typingIndicator);
        
        // Scroll to bottom
        scrollChatToBottom();
        
        // Get contextual information based on current page
        const context = getPageContext();
        
        // Create payload
        const data = {
            message: message,
            history: conversationHistory,
            context: context
        };
        
        // Send to API
        fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Remove typing indicator
            document.getElementById('typing-indicator')?.remove();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Add response to chat
            addBotMessage(data.response);
            
            // Add to conversation history
            conversationHistory.push({
                role: 'assistant',
                content: data.response
            });
            
            // Limit conversation history to last 10 messages (5 exchanges)
            if (conversationHistory.length > 10) {
                conversationHistory = conversationHistory.slice(conversationHistory.length - 10);
            }
            
            // Hide suggested questions after first exchange
            if (conversationHistory.length > 2) {
                const suggestedQuestions = document.querySelector('.suggested-questions');
                if (suggestedQuestions) {
                    suggestedQuestions.style.display = 'none';
                }
            }
        })
        .catch(error => {
            // Remove typing indicator
            document.getElementById('typing-indicator')?.remove();
            
            // Show error message
            addBotMessage(`Sorry, I encountered an error: ${error.message}. Please try again.`);
            console.error('Chat error:', error);
        });
    }
}

/**
 * Add a user message to the chat interface
 * @param {string} text - Message text
 */
function addUserMessage(text) {
    const chatMessages = document.getElementById('chat-messages');
    
    if (chatMessages) {
        // Create message element
        const message = document.createElement('div');
        message.className = 'chat-message user';
        message.textContent = text;
        
        // Add to chat
        chatMessages.appendChild(message);
        
        // Scroll to bottom
        scrollChatToBottom();
    }
}

/**
 * Add a bot message to the chat interface
 * @param {string} text - Message text
 */
function addBotMessage(text) {
    const chatMessages = document.getElementById('chat-messages');
    
    if (chatMessages) {
        // Create message element
        const message = document.createElement('div');
        message.className = 'chat-message bot';
        
        // Add formatted message text
        message.innerHTML = formatBotMessage(text);
        
        // Add to chat
        chatMessages.appendChild(message);
        
        // Scroll to bottom
        scrollChatToBottom();
    }
}

/**
 * Format bot message with markdown-like syntax
 * @param {string} text - Message text
 * @returns {string} Formatted HTML
 */
function formatBotMessage(text) {
    // Replace URLs with links
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    text = text.replace(urlRegex, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
    
    // Replace **bold** with <strong>
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    
    // Replace *italic* with <em>
    text = text.replace(/\*(.*?)\*/g, '<em>$1</em>');
    
    // Replace line breaks with <br>
    text = text.replace(/\n/g, '<br>');
    
    return text;
}

/**
 * Scroll the chat container to the bottom
 */
function scrollChatToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

/**
 * Get contextual information from the current page
 * @returns {Object} Context object with page-specific data
 */
function getPageContext() {
    // Default context
    const context = {
        page: getCurrentPage()
    };
    
    // Add page-specific context
    switch (context.page) {
        case 'data_hub':
            // Add data sources information
            const dataSources = document.querySelectorAll('.data-source-card');
            if (dataSources.length > 0) {
                context.dataSources = Array.from(dataSources).map(card => {
                    return {
                        name: card.querySelector('.card-title')?.textContent || '',
                        category: card.dataset.category || '',
                        lastUpdated: card.dataset.lastUpdated || '',
                        rowCount: card.dataset.rowCount || '0'
                    };
                });
            }
            break;
            
        case 'live_watch':
            // Add alerts information
            const alerts = document.querySelectorAll('.alert-item');
            if (alerts.length > 0) {
                context.alerts = Array.from(alerts).map(alert => {
                    return {
                        title: alert.querySelector('h6')?.textContent || '',
                        severity: alert.dataset.severity || '',
                        timestamp: alert.dataset.timestamp || ''
                    };
                });
            }
            
            // Add active rules
            const rules = document.querySelectorAll('.rule-card');
            if (rules.length > 0) {
                context.rules = Array.from(rules).map(rule => {
                    return {
                        name: rule.querySelector('h6')?.textContent || '',
                        category: rule.dataset.category || ''
                    };
                });
            }
            break;
            
        case 'optimizer':
            // Add optimization plans information
            const plans = document.querySelectorAll('.plan-card');
            if (plans.length > 0) {
                context.plans = Array.from(plans).map(plan => {
                    return {
                        name: plan.querySelector('h5')?.textContent || '',
                        scenario: plan.dataset.scenario || '',
                        status: plan.dataset.status || '',
                        score: plan.dataset.score || '0'
                    };
                });
            }
            
            // Add selected plan details
            const selectedPlan = document.querySelector('.plan-card.active');
            if (selectedPlan) {
                context.selectedPlan = selectedPlan.dataset.id || '';
            }
            break;
            
        case 'debrief':
            // Add incidents information
            const incidents = document.querySelectorAll('.incident-card');
            if (incidents.length > 0) {
                context.incidents = Array.from(incidents).map(incident => {
                    return {
                        title: incident.querySelector('h5')?.textContent || '',
                        startTime: incident.dataset.startTime || '',
                        category: incident.dataset.category || '',
                        severity: incident.dataset.severity || ''
                    };
                });
            }
            
            // Add selected incident details
            const selectedIncident = document.querySelector('.incident-card.active');
            if (selectedIncident) {
                context.selectedIncident = selectedIncident.dataset.id || '';
            }
            break;
    }
    
    return context;
}

/**
 * Get the current page from the URL or active nav item
 * @returns {string} Current page name
 */
function getCurrentPage() {
    // Check URL path
    const path = window.location.pathname;
    
    if (path.includes('live-watch')) {
        return 'live_watch';
    } else if (path.includes('optimizer')) {
        return 'optimizer';
    } else if (path.includes('debrief')) {
        return 'debrief';
    } else if (path.includes('data-hub') || path === '/') {
        return 'data_hub';
    }
    
    // Fallback: check active nav item
    const activeNav = document.querySelector('.nav-link.active');
    if (activeNav) {
        const href = activeNav.getAttribute('href');
        if (href.includes('live-watch')) {
            return 'live_watch';
        } else if (href.includes('optimizer')) {
            return 'optimizer';
        } else if (href.includes('debrief')) {
            return 'debrief';
        } else {
            return 'data_hub';
        }
    }
    
    // Default
    return 'data_hub';
}

/**
 * Pass a specific query to Gemini related to the current page
 * @param {string} query - The query to send to Gemini
 * @param {string} targetElementId - The ID of the element to update with the response
 */
function askGemini(query, targetElementId) {
    const target = document.getElementById(targetElementId);
    if (!target) return;
    
    // Show loading state
    target.innerHTML = '<div class="spinner"></div><p class="text-center">Processing request...</p>';
    
    // Get contextual information
    const context = getPageContext();
    
    // Create payload
    const data = {
        message: query,
        context: context
    };
    
    // Send to API
    fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Format the response with markdown
        const formattedResponse = formatBotMessage(data.response);
        
        // Update target element with response
        target.innerHTML = `<div class="p-3 bg-light rounded">${formattedResponse}</div>`;
    })
    .catch(error => {
        // Show error message
        target.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error: ${error.message}
            </div>
        `;
        console.error('Gemini API error:', error);
    });
}