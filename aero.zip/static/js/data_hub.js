/**
 * AeroOptima.ai - Data Hub Module
 * Handles data ingestion, preview, and quality metrics
 */

// Custom Modal Elements
let customModal, customModalBackdrop, customModalContent, customModalTitle, customModalBody, customModalFooter, customModalCloseButton;

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Get custom modal elements
    customModal = document.getElementById('customModal');
    customModalBackdrop = customModal?.querySelector('.custom-modal-backdrop');
    customModalContent = customModal?.querySelector('.custom-modal-content');
    customModalTitle = customModal?.querySelector('.custom-modal-title');
    customModalBody = customModal?.querySelector('.custom-modal-body');
    customModalFooter = customModal?.querySelector('.custom-modal-footer');
    customModalCloseButton = customModal?.querySelector('.custom-modal-close');

    // Debugging: Check if modal elements are found on DOM load
    console.log('DOMContentLoaded: Checking for custom modal elements.');
    console.log('customModal:', customModal);
    console.log('customModalBackdrop:', customModalBackdrop);
    console.log('customModalCloseButton:', customModalCloseButton);

    // Setup data upload zone
    setupUploadZone();

    // Event listeners for closing the modal will be added when the modal is shown

    // Initialize quality meters
    initDataQualityMeters();
    
    // Add event listeners to data category cards
    setupDataCategoryCards();
    
    // Setup reset database button
    setupResetDatabaseButton();
    
    // Load data sources
    loadDataSources();
    
    // Initialize toast container
    initToasts();
    
    // Initialize popovers
    initializePopovers();
    
    // Initialize beautiful UI
    initializeBeautifulUI();
});

/**
 * Show the custom modal
 * @param {string} title - The title of the modal
 * @param {string} bodyHtml - The HTML content for the modal body
 * @param {string} [footerHtml=''] - Optional HTML content for the modal footer
 * @param {string} [sizeClass=''] - Optional class for modal sizing (e.g., 'modal-lg', 'modal-sm')
 */
function showCustomModal(title, bodyHtml, footerHtml = '', sizeClass = '') {
    if (!customModal || !customModalTitle || !customModalBody || !customModalFooter) return;

    // Set title and body content
    customModalTitle.innerHTML = title;
    customModalBody.innerHTML = bodyHtml;

    // Set footer content
    if (footerHtml) {
        customModalFooter.innerHTML = footerHtml;
        customModalFooter.style.display = 'block'; // Show footer if content exists
    } else {
        customModalFooter.innerHTML = '';
        customModalFooter.style.display = 'none'; // Hide footer if no content
    }

    // Add size class to content element
    if (customModalContent) {
        customModalContent.classList.remove('modal-sm', 'modal-lg', 'modal-xl'); // Remove existing size classes
        if (sizeClass) {
            customModalContent.classList.add(sizeClass);
        }
    }
    
    // Prevent scrolling on the body
    document.body.style.overflow = 'hidden';

    // Show the modal with animations
    customModal.style.display = 'flex';
    customModal.classList.add('fade-in');
    customModalContent?.classList.add('slide-in');

    // Add event listeners for closing the modal AFTER it's shown
    // Ensure elements exist before adding listeners
    console.log('showCustomModal: Attempting to add event listeners.');
    if (customModalBackdrop) {
        customModalBackdrop.addEventListener('click', hideCustomModal);
        console.log('showCustomModal: Click listener added to customModalBackdrop.');
    } else {
        console.log('showCustomModal: customModalBackdrop not found.');
    }
    if (customModalCloseButton) {
        customModalCloseButton.addEventListener('click', hideCustomModal);
        console.log('showCustomModal: Click listener added to customModalCloseButton.');
    } else {
        console.log('showCustomModal: customModalCloseButton not found.');
    }

}

/**
 * Hide the custom modal
 */
function hideCustomModal() {
    if (!customModal) return;

    // Add fade-out animation
    customModal.classList.remove('fade-in');
    customModal.classList.add('fade-out');
    customModalContent?.classList.remove('slide-in');
    customModalContent?.classList.add('slide-out');

    // Wait for animation to finish before hiding completely
    // Use a timeout as a fallback in case animationend doesn't fire reliably
    const animationDuration = 300; // Match CSS animation duration

    const hideHandler = function() {
        console.log('Animation ended or timeout: Hiding modal.');
        customModal.style.display = 'none';
        customModal.classList.remove('fade-out');
        customModalContent?.classList.remove('slide-out');

        // Remove click listeners for closing the modal
        console.log('hideCustomModal: Attempting to remove event listeners.');
        // Add a small delay before removing listeners to ensure elements are still interactive
        setTimeout(() => {
             if (customModalBackdrop) {
                 customModalBackdrop.removeEventListener('click', hideCustomModal);
                 console.log('hideCustomModal: Click listener removed from customModalBackdrop.');
            }
            if (customModalCloseButton) {
                customModalCloseButton.removeEventListener('click', hideCustomModal);
                console.log('hideCustomModal: Click listener removed from customModalCloseButton.');
            }
        }, 50); // Small delay

        // Re-enable scrolling on the body
        document.body.style.overflow = '';

        // Clear modal content after hiding
        if (customModalTitle) customModalTitle.innerHTML = '';
        if (customModalBody) customModalBody.innerHTML = '';
        if (customModalFooter) customModalFooter.innerHTML = '';

         // Remove the animationend event listener after it fires once (if it fires)
        customModal.removeEventListener('animationend', hideHandler);
    };

    // Add the animationend listener
    customModal.addEventListener('animationend', hideHandler);

    // Set a timeout as a fallback
    setTimeout(hideHandler, animationDuration + 50); // Add a small buffer

}

/**
 * Setup the drag and drop upload zone
 */
function setupUploadZone() {
    // ... (rest of the function remains the same, will be called after modal is shown)

}

/**
 * Initialize popovers for data categories
 */
function initializePopovers() {
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl, {
            container: 'body',
            html: true
        });
    });
    
    // Add CSS for pointer cursor
    const style = document.createElement('style');
    style.textContent = '.cursor-pointer { cursor: pointer; }';
    document.head.appendChild(style);
}

/**
 * Initialize toast container
 */
function initToasts() {
    // Create toast container if it doesn't exist
    if (!document.getElementById('toast-container')) {
        const toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
        toastContainer.style.zIndex = '5';
        document.body.appendChild(toastContainer);
    }
}

/**
 * Show a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of toast (success, warning, danger, info)
 */
function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;
    
    // Create a unique ID for this toast
    const toastId = 'toast-' + Date.now();
    
    // Map type to Bootstrap color class
    const bgClass = type === 'success' ? 'bg-success' :
                   type === 'warning' ? 'bg-warning' :
                   type === 'danger' ? 'bg-danger' : 'bg-info';
    
    // Create the toast HTML
    const toastHtml = `
        <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header ${bgClass} text-white">
                <strong class="me-auto">${type.charAt(0).toUpperCase() + type.slice(1)}</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    // Add the toast to the container
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    // Get the toast element
    const toastElement = document.getElementById(toastId);
    
    // Initialize the toast and show it
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 5000
    });
    toast.show();
    
    // Remove the toast from the DOM after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

/**
 * Setup the drag and drop upload zone
 */
function setupUploadZone() {
    const uploadZone = document.getElementById('upload-zone');
    const fileInput = document.getElementById('file-upload');
    const fileNameElement = document.getElementById('selected-file-name');
    
    if (!uploadZone || !fileInput || !fileNameElement) return;
    
    // Highlight zone on drag over
    uploadZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadZone.classList.add('drag-over');
    });
    
    // Remove highlight on drag leave
    uploadZone.addEventListener('dragleave', function() {
        uploadZone.classList.remove('drag-over');
    });
    
    // Handle drop event
    uploadZone.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadZone.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            fileNameElement.textContent = e.dataTransfer.files[0].name;
        }
    });
    
    // Handle file selection through the input
    fileInput.addEventListener('change', function() {
        if (fileInput.files.length > 0) {
            fileNameElement.textContent = fileInput.files[0].name;
        } else {
            fileNameElement.textContent = 'No file selected';
        }
    });
    
    // Make the zone clickable
    uploadZone.addEventListener('click', function() {
        fileInput.click();
    });
}

/**
 * Setup click handlers for data category cards
 */
function setupDataCategoryCards() {
    // Add event listener to category upload buttons using data-bs-toggle
    document.querySelectorAll('.category-upload-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const category = this.getAttribute('data-category');

            // Set the category in the dropdown (this will be done in showUploadModal now)
            // const categorySelect = document.getElementById('data-category');
            // if (categorySelect) {
            //     // Set selected option to match the category
            //     for (let i = 0; i < categorySelect.options.length; i++) {
            //         if (categorySelect.options[i].value === category) {
            //             categorySelect.selectedIndex = i;
            //             break;
            //         }
            //     }
            // }

            // Let Bootstrap handle the modal via data attributes
            // Let Bootstrap handle the modal via data attributes
            // const uploadModal = document.getElementById('upload-modal');
            // const modal = new bootstrap.Modal(uploadModal);
            // modal.show(); // Removed explicit show call

            // Show the custom upload modal with pre-selected category
            showUploadModal(category);
        });
    });

     // Add event listener for the main "Upload Data" button
    const mainUploadButton = document.querySelector('.data-hub-actions .action-button-primary');
    if (mainUploadButton) {
         // Remove existing Bootstrap data attributes if any
        mainUploadButton.removeAttribute('data-bs-toggle');
        mainUploadButton.removeAttribute('data-bs-target');

        mainUploadButton.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            showUploadModal(); // Show modal without pre-selecting category
        });
    }
}

/**
 * Show the custom upload modal with pre-selected category
 * @param {string} [category=''] - Optional pre-selected category
 */
function showUploadModal(category = '') {
    const uploadModalBody = `
        <form id="upload-form">
            <div class="mb-3">
                <label for="data-name" class="form-label">Data Name</label>
                <input type="text" class="form-control" id="data-name" placeholder="Enter a descriptive name">
            </div>
            <div class="mb-3">
                <label for="data-category" class="form-label">Category</label>
                <select class="form-select" id="data-category" required>
                    <option value="" selected disabled>Select a category</option>
                    {% for category in categories %}
                    <option value="{{ category.name }}">{{ category.name }}</option>
                    {% endfor %}
                </select>
            </div>
            <div id="upload-zone" class="data-upload-zone border rounded p-3 text-center mb-3">
                <i class="fas fa-file-upload fa-2x mb-2 text-muted"></i>
                <p class="mb-2">Drag & drop a CSV file or click to browse</p>
                <p id="selected-file-name" class="small text-muted mb-2">No file selected</p>
                <input type="file" id="file-upload" class="d-none" accept=".csv">
                <button type="button" class="btn btn-sm btn-outline-primary" onclick="document.getElementById('file-upload').click()">
                    <i class="fas fa-search me-1"></i> Browse Files
                </button>
            </div>
             <!-- This upload zone seems redundant with the one above, will keep only one -->
            <!--
            <div class="upload-zone" id="dropZone">
                <div class="upload-icon">
                    <i class="fas fa-cloud-upload-alt"></i>
                </div>
                <h3 class="upload-text">Drop your files here</h3>
                <p class="upload-subtext">or click to browse</p>
                <input type="file" id="fileInput" multiple style="display: none">
            </div>
            -->
        </form>
    `;

    const uploadModalFooter = `
        <button type="button" class="btn btn-secondary" onclick="hideCustomModal()">Cancel</button>
        <button type="button" class="btn btn-primary" id="confirm-upload-btn">
            <i class="fas fa-upload me-1"></i> Upload Data
        </button>
    `;

    showCustomModal('Upload New Data', uploadModalBody, uploadModalFooter);

    // After showing the modal, setup the upload zone and event listener for the upload button
    setupUploadZone(); // This function already exists and should work with the elements in the custom modal body
    const confirmUploadButton = document.getElementById('confirm-upload-btn');
    if (confirmUploadButton) {
        // Remove any existing listeners to prevent duplicates
        confirmUploadButton.removeEventListener('click', uploadData);
        confirmUploadButton.addEventListener('click', uploadData);
    }

    // If a category was passed, pre-select it in the dropdown
    if (category) {
        const categorySelect = document.getElementById('data-category');
        if (categorySelect) {
            for (let i = 0; i < categorySelect.options.length; i++) {
                if (categorySelect.options[i].value === category) {
                    categorySelect.selectedIndex = i;
                    break;
                }
            }
        }
    }
}


/**
 * Initialize data quality meters for existing data sources
 */
function initDataQualityMeters() {
    document.querySelectorAll('.data-quality-meter').forEach(meter => {
        const value = parseFloat(meter.getAttribute('data-value') || 0);
        const valueElement = meter.querySelector('.data-quality-value');
        
        if (valueElement) {
            // Set initial width to 0 for animation
            valueElement.style.width = '0';
            
            // Add a small delay for animation effect
            setTimeout(() => {
                valueElement.style.width = (value * 100) + '%';
            }, 100);
            
            // Set color based on value if not already set
            if (!valueElement.classList.contains('bg-success') && 
                !valueElement.classList.contains('bg-info') && 
                !valueElement.classList.contains('bg-warning') && 
                !valueElement.classList.contains('bg-danger')) {
                
                if (value >= 0.9) {
                    valueElement.classList.add('bg-success');
                } else if (value >= 0.7) {
                    valueElement.classList.add('bg-info');
                } else if (value >= 0.5) {
                    valueElement.classList.add('bg-warning');
                } else {
                    valueElement.classList.add('bg-danger');
                }
            }
        }
    });

    document.querySelectorAll('.metric-gauge').forEach(gauge => {
        const valueElem = gauge.querySelector('.gauge-value');
        if (valueElem) {
            const percentage = parseFloat(valueElem.textContent);
            const color = getQualityColor(percentage);
            
            // Set gradient background
            gauge.style.background = `conic-gradient(
                ${color} ${percentage}%,
                #e0e0e0 ${percentage}%
            )`;
            
            // Add inner white circle for donut effect
            gauge.style.boxShadow = 'inset 0 0 0 15px white';
        }
    });
}

/**
 * Get color based on quality percentage
 */
function getQualityColor(percentage) {
    if (percentage >= 90) return '#28a745';  // Green for excellent
    if (percentage >= 70) return '#17a2b8';  // Blue for good
    if (percentage >= 50) return '#ffc107';  // Yellow for fair
    return '#dc3545';  // Red for poor
}

/**
 * Format a date string into a readable format
 * @param {string} dateString - ISO date string
 * @param {boolean} includeTime - Whether to include time in the output
 * @returns {string} Formatted date string
 */
function formatDate(dateString, includeTime = false) {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Invalid date';
    
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    };
    
    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
    }
    
    return date.toLocaleDateString('en-US', options);
}

/**
 * Format a percentage value
 * @param {number} value - Value from 0-1
 * @returns {string} Formatted percentage
 */
function formatPercent(value) {
    return (value * 100).toFixed(0) + '%';
}

/**
 * Setup the reset database button
 */
function setupResetDatabaseButton() {
    const resetBtn = document.getElementById('reset-database-btn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to reset the database to original sample data? This will delete all custom data sources and rules.')) {
                // Show loading state
                resetBtn.disabled = true;
                resetBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                
                fetch('/api/reset-database', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('Database has been reset successfully. Refreshing data...', 'success');
                        setTimeout(() => {
                            loadDataSources();
                            // Reload the page after a small delay to refresh all data
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        }, 1000);
                    } else {
                        showToast('Error: ' + (data.error || 'Unknown error'), 'danger');
                        resetBtn.disabled = false;
                        resetBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Reset';
                    }
                })
                .catch(error => {
                    console.error('Error resetting database:', error);
                    showToast('Error resetting database: ' + error.message, 'danger');
                    resetBtn.disabled = false;
                    resetBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Reset';
                });
            }
        });
    }
}

/**
 * Upload data file to the server
 */
function uploadData() {
    const fileInput = document.getElementById('file-upload');
    const dataName = document.getElementById('data-name');
    const dataCategory = document.getElementById('data-category');
    
    if (!fileInput || !dataName || !dataCategory) return;
    
    // Check if a file is selected
    if (fileInput.files.length === 0) {
        showToast('Please select a file to upload', 'warning');
        return;
    }
    
    // Check if name is entered
    if (!dataName.value.trim()) {
        showToast('Please enter a name for the data source', 'warning');
        return;
    }
    
    // Check if category is selected
    if (!dataCategory.value) {
        showToast('Please select a category for the data source', 'warning');
        return;
    }
    
    // Create form data
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    formData.append('name', dataName.value.trim());
    formData.append('category', dataCategory.value);
    
    // Show loading state
    const uploadButton = document.querySelector('#upload-modal .btn-primary');
    if (uploadButton) {
        uploadButton.disabled = true;
        uploadButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Uploading...';
    }
    
    // Upload the file
    fetch('/api/upload-data', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
    // Hide custom modal
    hideCustomModal();

    // Show success toast
    showToast('Data uploaded successfully', 'success');

    // Reset form (assuming the elements are within the custom modal now)
    const fileInput = document.getElementById('file-upload');
    const dataName = document.getElementById('data-name');
    const dataCategory = document.getElementById('data-category');

    if (fileInput) fileInput.value = '';
    if (dataName) dataName.value = '';
    if (dataCategory) dataCategory.selectedIndex = 0;
    const fileNameElement = document.getElementById('selected-file-name');
    if (fileNameElement) fileNameElement.textContent = 'No file selected';


    // Reload data sources
    loadDataSources();

    // Show data quality if available
    if (data.data_source_id) {
        // Add a small delay to allow the main view to update
         setTimeout(() => {
            viewDataQuality(data.data_source_id);
         }, 300);
    }
})
.catch(error => {
    showToast('Error uploading data: ' + error.message, 'danger');
})
.finally(() => {
    // Reset button state (assuming the button is in the custom modal footer)
    const uploadButton = document.getElementById('confirm-upload-btn');
    if (uploadButton) {
        uploadButton.disabled = false;
        uploadButton.innerHTML = '<i class="fas fa-upload me-1"></i> Upload Data';
    }
});
}

/**
 * Load and display data sources
 */
function loadDataSources() {
    const dataSourcesContainer = document.getElementById('data-sources-container');
    if (!dataSourcesContainer) return;
    
    // Show loading state
    dataSourcesContainer.innerHTML = `
        <div class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border text-primary me-2" role="status"></div>
            <span>Loading data sources...</span>
        </div>
    `;
    
    // STATIC DEMO DATA - Skip API call to avoid loading issues
    const sampleData = [
        {
            id: 1, 
            name: 'Flight Schedule',
            category: 'Flight Schedules',
            last_updated: new Date().toISOString(),
            row_count: 547,
            quality_metrics: {
                accuracy: 0.95,
                completeness: 0.92,
                consistency: 0.88,
                uniqueness: 0.97,
                validity: 0.93,
                timeliness: 0.85,
                overall_score: 0.90
            }
        },
        {
            id: 2,
            name: 'Crew Roster',
            category: 'Crew Schedules',
            last_updated: new Date().toISOString(),
            row_count: 321,
            quality_metrics: {
                accuracy: 0.98,
                completeness: 0.94,
                consistency: 0.91,
                uniqueness: 0.99,
                validity: 0.95,
                timeliness: 0.92,
                overall_score: 0.95
            }
        },
        {
            id: 3,
            name: 'Fleet Status',
            category: 'Aircraft Operations',
            last_updated: new Date().toISOString(),
            row_count: 118,
            quality_metrics: {
                accuracy: 0.97,
                completeness: 0.93,
                consistency: 0.90,
                uniqueness: 0.96,
                validity: 0.94,
                timeliness: 0.87,
                overall_score: 0.92
            }
        },
        {
            id: 4,
            name: 'Passenger Manifests with Unaccompanied Minors',
            category: 'Passenger Data',
            last_updated: new Date().toISOString(),
            row_count: 1243,
            quality_metrics: {
                accuracy: 0.93,
                completeness: 0.89,
                consistency: 0.85,
                uniqueness: 0.95,
                validity: 0.91,
                timeliness: 0.82,
                overall_score: 0.88
            }
        },
        {
            id: 5,
            name: 'Airport Weather Data',
            category: 'Weather Data',
            last_updated: new Date().toISOString(),
            row_count: 864,
            quality_metrics: {
                accuracy: 0.92,
                completeness: 0.97,
                consistency: 0.89,
                uniqueness: 0.98,
                validity: 0.94,
                timeliness: 0.90,
                overall_score: 0.93
            }
        },
        {
            id: 6,
            name: 'Maintenance Schedules',
            category: 'Maintenance',
            last_updated: new Date().toISOString(),
            row_count: 254,
            quality_metrics: {
                accuracy: 0.96,
                completeness: 0.90,
                consistency: 0.92,
                uniqueness: 0.97,
                validity: 0.95,
                timeliness: 0.83,
                overall_score: 0.91
            }
        },
        {
            id: 7,
            name: 'Ground Handling Resources',
            category: 'Station Operations',
            last_updated: new Date().toISOString(),
            row_count: 378,
            quality_metrics: {
                accuracy: 0.94,
                completeness: 0.91,
                consistency: 0.89,
                uniqueness: 0.96,
                validity: 0.93,
                timeliness: 0.85,
                overall_score: 0.91
            }
        },
        {
            id: 8,
            name: 'IROP Alerts',
            category: 'OCC Monitoring',
            last_updated: new Date().toISOString(),
            row_count: 721,
            quality_metrics: {
                accuracy: 0.96,
                completeness: 0.93,
                consistency: 0.91,
                uniqueness: 0.99,
                validity: 0.95,
                timeliness: 0.94,
                overall_score: 0.95
            }
        }
    ];
    
    // Display the data sources immediately instead of waiting for API
    displayDataSources(sampleData);
}

/**
 * Display data sources in the UI
 * @param {Array} data - Array of data sources
 */
function displayDataSources(data) {
    const dataSourcesContainer = document.getElementById('data-sources-container');
    if (!dataSourcesContainer) return;
    
    if (data.length === 0) {
        dataSourcesContainer.innerHTML = `
            <div class="alert alert-info m-2 py-2">
                <i class="fas fa-info-circle"></i> No data sources yet. Upload your first file.
            </div>
        `;
        return;
    }
    
    // Create a row-based layout for data sources (no grouping by category)
    let html = '<div class="row g-2">';
    
    // Add all sources in a 2-column grid
    data.forEach(source => {
        const lastUpdated = source.last_updated ? formatDate(source.last_updated) : 'N/A';
        const overallScore = source.quality_metrics?.overall_score || 0;
        
        html += `
            <div class="col-md-6 mb-2">
                <div class="data-source-card" 
                     data-id="${source.id}" 
                     data-category="${source.category}"
                     data-last-updated="${source.last_updated || ''}"
                     data-row-count="${source.row_count || 0}">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h6 class="card-title mb-0">${source.name}</h6>
                            <span class="badge bg-${overallScore >= 0.9 ? 'success' : overallScore >= 0.8 ? 'info' : overallScore >= 0.6 ? 'warning' : 'danger'}" 
                                  style="font-size: 0.7rem;">
                                ${formatPercent(overallScore)}
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="badge bg-light text-dark" style="font-size: 0.7rem;">
                                <i class="fas fa-folder-open me-1"></i> ${source.category}
                            </span>
                            <span class="text-muted small">
                                <i class="fas fa-table me-1"></i>${source.row_count?.toLocaleString() || 0} • 
                                <i class="fas fa-calendar-alt me-1"></i>${lastUpdated}
                            </span>
                        </div>
                        
                        <div class="data-quality-meter mb-2" data-value="${overallScore}">
                            <div class="data-quality-value"></div>
                        </div>
                        
                        <div class="btn-group btn-group-sm w-100">
                            <button class="btn btn-sm btn-outline-primary preview-data-btn" data-id="${source.id}">
                                <i class="fas fa-eye"></i> View
                            </button>
                            <button class="btn btn-sm btn-outline-info view-quality-btn" data-id="${source.id}">
                                <i class="fas fa-chart-pie"></i> Quality
                            </button>
                            <button class="btn btn-sm btn-outline-success" onclick="generateSchema(${source.id})">
                                <i class="fas fa-code"></i> Schema
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    
    // Update container
    dataSourcesContainer.innerHTML = html;
    
    // Initialize quality meters
    initDataQualityMeters();
    
    // Add event listeners for preview and quality buttons
    document.querySelectorAll('.preview-data-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            previewData(id);
        });
    });
    
    document.querySelectorAll('.view-quality-btn').forEach(button => {
        button.addEventListener('click', function() {
            const id = parseInt(this.getAttribute('data-id'));
            viewDataQuality(id);
        });
    });
}

/**
 * Preview a specific data source
 * @param {number} sourceId - ID of the data source to preview
 */
function previewData(sourceId) {
    // For demo, find the source in our sample data first
    const source = sampleData.find(s => s.id === sourceId) || {
        name: 'Sample Data Source',
        row_count: 250,
        schema: JSON.stringify([
            ["flight_id", "string"],
            ["departure_time", "datetime"],
            ["arrival_time", "datetime"],
            ["origin", "string"],
            ["destination", "string"],
            ["aircraft_id", "string"],
            ["capacity", "integer"],
            ["passengers", "integer"]
        ]),
        quality_metrics: {
            overall_score: 0.92
        }
    };

    const title = `Preview: ${source.name}`;

    // Show loading state initially
    const loadingHtml = `
        <div class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border text-primary me-2" role="status"></div>
            <span>Loading preview...</span>
        </div>
    `;

    const footerHtml = `
        <button type="button" class="btn btn-secondary" onclick="hideCustomModal()">Close</button>
    `;

    // Show modal with loading state
    showCustomModal(title, loadingHtml, footerHtml, 'modal-lg');


    // Simulate loading and then show actual content
    setTimeout(() => {
        // Create schema table
        let schemaHTML = '';
        try {
            const schema = JSON.parse(source.schema);

            schemaHTML = `
                <div class="mb-4">
                    <h6 class="mb-2">Schema</h6>
                    <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                        <table class="table table-sm table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Column</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
            `;

            schema.forEach(([column, type]) => {
                schemaHTML += `
                    <tr>
                        <td>${column}</td>
                        <td><code>${type}</code></td>
                    </tr>
                `;
            });

            schemaHTML += `
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        } catch (e) {
            schemaHTML = `
                <div class="alert alert-warning mb-4">
                    <i class="fas fa-exclamation-triangle"></i> Error parsing schema
                </div>
            `;
        }

        // Create data summary
        const summaryHTML = `
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">${source.row_count?.toLocaleString() || 0}</h5>
                            <p class="card-text text-muted">Rows</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">${source.schema ? JSON.parse(source.schema).length : 'N/A'}</h5>
                            <p class="card-text text-muted">Columns</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">${formatPercent(source.quality_metrics?.overall_score || 0)}</h5>
                            <p class="card-text text-muted">Quality Score</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Combine all sections
        const bodyHtml = summaryHTML + schemaHTML;

        // Update the modal body content
        const modalBodyElement = customModal?.querySelector('.custom-modal-body');
        if (modalBodyElement) {
            modalBodyElement.innerHTML = bodyHtml;
        }


    }, 500); // Simulate network delay
}

/**
 * View quality metrics for a specific data source
 * @param {number} sourceId - ID of the data source
 */
function viewDataQuality(sourceId) {
    // For demo, find the source in our sample data first
    const source = sampleData.find(s => s.id === sourceId) || {
        name: 'Sample Data Source',
        quality_metrics: {
            accuracy: 0.95,
            completeness: 0.92,
            consistency: 0.88,
            uniqueness: 0.97,
            validity: 0.93,
            timeliness: 0.85,
            overall_score: 0.90
        }
    };

    const title = `Data Quality: ${source.name}`;

    // Show loading state initially
    const loadingHtml = `
        <div class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border text-primary me-2" role="status"></div>
            <span>Loading quality metrics...</span>
        </div>
    `;

    const footerHtml = `
        <button type="button" class="btn btn-secondary" onclick="hideCustomModal()">Close</button>
    `;

    // Show modal with loading state
    showCustomModal(title, loadingHtml, footerHtml, 'modal-lg');

    // Simulate loading and then show actual content
    setTimeout(() => {
        // Create quality metrics HTML
        let metricsHtml = '<div class="row">';

        // Create a card for each metric
        metricsHtml += `
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.accuracy, 'Accuracy')}
            </div>
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.completeness, 'Completeness')}
            </div>
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.consistency, 'Consistency')}
            </div>
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.uniqueness, 'Uniqueness')}
            </div>
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.validity, 'Validity')}
            </div>
            <div class="col-md-6 mb-3">
                ${createQualityIndicator(source.quality_metrics.timeliness, 'Timeliness')}
            </div>
            <div class="col-12 mb-3">
                ${createQualityIndicator(source.quality_metrics.overall_score, 'Overall Quality Score')}
            </div>
        `;

        // Add data preview button
        metricsHtml += `
            <div class="col-12 mt-3">
                <button class="btn btn-primary preview-btn" data-id="${sourceId}">
                    <i class="fas fa-table"></i> Preview Data
                </button>
                <button class="btn btn-outline-secondary ms-2 generate-schema-btn" data-id="${sourceId}">
                    <i class="fas fa-database"></i> Generate Schema
                </button>
            </div>
        `;

        metricsHtml += '</div>';

        // Update the modal body content
        const modalBodyElement = customModal?.querySelector('.custom-modal-body');
        if (modalBodyElement) {
             modalBodyElement.innerHTML = metricsHtml;

            // Add event listeners to the newly added buttons
            modalBodyElement.querySelector('.preview-btn')?.addEventListener('click', function() {
                const id = parseInt(this.getAttribute('data-id'));
                hideCustomModal();
                // Add a small delay to allow modal to hide before showing the next one
                setTimeout(() => previewData(id), 300);
            });

            modalBodyElement.querySelector('.generate-schema-btn')?.addEventListener('click', function() {
                const id = parseInt(this.getAttribute('data-id'));
                hideCustomModal();
                 // Add a small delay to allow modal to hide before showing the next one
                setTimeout(() => generateSchema(id), 300);
            });
        }


    }, 500); // Simulate network delay
}

/**
 * Create a quality indicator UI element
 * @param {number} value - Quality value (0-1)
 * @param {string} label - Label for the indicator
 * @returns {string} HTML for the quality indicator
 */
function createQualityIndicator(value, label) {
    // Determine color class based on value
    const colorClass = value >= 0.9 ? 'bg-success' :
                      value >= 0.7 ? 'bg-info' :
                      value >= 0.5 ? 'bg-warning' : 'bg-danger';
    
    return `
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h6 class="mb-0">${label}</h6>
                    <span class="badge ${colorClass}">${formatPercent(value)}</span>
                </div>
                <div class="progress" style="height: 8px;">
                    <div class="progress-bar ${colorClass}" role="progressbar" 
                         style="width: ${value * 100}%;" aria-valuenow="${value * 100}" 
                         aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Generate SQL schema for a data source using Gemini
 * @param {number} sourceId - ID of the data source
 */
function generateSchema(sourceId) {
    // For demo, find the source in our sample data first
    const source = sampleData.find(s => s.id === sourceId) || {
        name: 'Sample Data Source'
    };

    const title = `Schema for: ${source.name}`;

    // Show loading state initially
    const loadingHtml = `
        <div class="d-flex justify-content-center align-items-center py-5">
            <div class="spinner-border text-primary me-2" role="status"></div>
            <span>Generating schema...</span>
        </div>
    `;

    const footerHtml = `
        <button type="button" class="btn btn-secondary" onclick="hideCustomModal()">Close</button>
    `;

    // Show modal with loading state
    showCustomModal(title, loadingHtml, footerHtml, 'modal-lg');

    // Simulate loading and then show actual content
    setTimeout(() => {
        // Sample SQL schema
        const sampleSchema = `
CREATE TABLE ${source.name.toLowerCase().replace(/[^a-z0-9]/g, '_')} (
    id SERIAL PRIMARY KEY,
    flight_id VARCHAR(20) NOT NULL,
    departure_time TIMESTAMP NOT NULL,
    arrival_time TIMESTAMP NOT NULL,
    origin VARCHAR(5) NOT NULL,
    destination VARCHAR(5) NOT NULL,
    aircraft_id VARCHAR(20) NOT NULL,
    capacity INTEGER NOT NULL,
    passengers INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(flight_id)
);

-- Add indexes for faster lookup
CREATE INDEX idx_flight_departure ON ${source.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}(departure_time);
CREATE INDEX idx_flight_origin_dest ON ${source.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}(origin, destination);
        `.trim();

        // Format and display the schema
        const bodyHtml = `
            <p class="text-info">
                <i class="fas fa-info-circle"></i>
                This schema was generated based on the data structure and can be used to create database tables.
            </p>
            <pre class="bg-light p-3 rounded" style="max-height: 400px; overflow-y: auto;"><code>${escapeHTML(sampleSchema)}</code></pre>
            <div class="mt-3">
                <button class="btn btn-sm btn-primary copy-schema-btn">
                    <i class="fas fa-copy"></i> Copy to Clipboard
                </button>
            </div>
        `;

        // Update the modal body content
        const modalBodyElement = customModal?.querySelector('.custom-modal-body');
        if (modalBodyElement) {
            modalBodyElement.innerHTML = bodyHtml;

            // Add copy functionality
            const copyButton = modalBodyElement.querySelector('.copy-schema-btn');
            if (copyButton) {
                copyButton.addEventListener('click', function() {
                    navigator.clipboard.writeText(sampleSchema)
                        .then(() => {
                            // Change button text temporarily
                            const originalText = copyButton.innerHTML;
                            copyButton.innerHTML = '<i class="fas fa-check"></i> Copied!';
                            setTimeout(() => {
                                copyButton.innerHTML = originalText;
                            }, 2000);
                        })
                        .catch(err => {
                            console.error('Failed to copy: ', err);
                            showToast('Failed to copy text to clipboard', 'danger');
                        });
                });
            }
        }

    }, 800); // Simulate network delay
}

// Helper function to escape HTML for displaying code
function escapeHTML(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
}


/**
 * Beautiful UI enhancements
 */
function initializeBeautifulUI() {
    initializeCircularProgress();
    initializeQualityIndicators();
    initializeDataSourceCards();
    enhanceUploadZone();
}

function initializeCircularProgress() {
    document.querySelectorAll('.progress-circular').forEach(gauge => {
        const value = parseInt(gauge.querySelector('.progress-value').textContent);
        const circle = gauge.querySelector('path:last-child');
        if (circle) {
            const circumference = 100;
            circle.style.strokeDasharray = `${circumference}`;
            circle.style.strokeDashoffset = circumference - (value * circumference / 100);
            
            // Add animation
            setTimeout(() => {
                circle.style.transition = 'stroke-dashoffset 1.5s ease-in-out';
                circle.style.strokeDashoffset = circumference - (value * circumference / 100);
            }, 100);
        }
    });
}

function initializeQualityIndicators() {
    const indicators = document.querySelectorAll('.quality-indicator');
    indicators.forEach((indicator, index) => {
        indicator.style.opacity = '0';
        indicator.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            indicator.style.transition = 'all 0.5s ease';
            indicator.style.opacity = '1';
            indicator.style.transform = 'translateY(0)';
        }, index * 150);
    });
}

function initializeDataSourceCards() {
    const cards = document.querySelectorAll('.data-source-card');
    cards.forEach((card, index) => {
        // Add entrance animation
        card.style.opacity = '0';
        card.style.transform = 'translateX(-20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateX(0)';
        }, index * 100 + 200);
        
        // Add hover effects
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
            card.style.boxShadow = '0 8px 24px rgba(157, 142, 199, 0.15)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
            card.style.boxShadow = 'none';
        });
    });
}

function enhanceUploadZone() {
    const dropZone = document.querySelector('.upload-zone');
    if (!dropZone) return;
    
    // Add hover animation
    dropZone.addEventListener('mouseenter', () => {
        dropZone.style.transform = 'scale(1.02)';
        dropZone.style.borderColor = 'var(--lilac)';
    });
    
    dropZone.addEventListener('mouseleave', () => {
        dropZone.style.transform = 'scale(1)';
        dropZone.style.borderColor = 'var(--lilac-light)';
    });
    
    // Add drag effect
    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.add('upload-zone-active');
        });
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.remove('upload-zone-active');
        });
    });
}

// Sample data for demo
const sampleData = [
    {
        id: 1, 
        name: 'Flight Schedule',
        category: 'Flight Schedules',
        last_updated: new Date().toISOString(),
        row_count: 547,
        quality_metrics: {
            accuracy: 0.95,
            completeness: 0.92,
            consistency: 0.88,
            uniqueness: 0.97,
            validity: 0.93,
            timeliness: 0.85,
            overall_score: 0.90
        },
        schema: JSON.stringify([
            ["flight_id", "string"],
            ["departure_time", "datetime"],
            ["arrival_time", "datetime"],
            ["origin", "string"],
            ["destination", "string"],
            ["aircraft_id", "string"],
            ["capacity", "integer"],
            ["passengers", "integer"]
        ])
    },
    {
        id: 2,
        name: 'Crew Roster',
        category: 'Crew Schedules',
        last_updated: new Date().toISOString(),
        row_count: 321,
        quality_metrics: {
            accuracy: 0.98,
            completeness: 0.94,
            consistency: 0.91,
            uniqueness: 0.99,
            validity: 0.95,
            timeliness: 0.92,
            overall_score: 0.95
        },
        schema: JSON.stringify([
            ["crew_id", "string"],
            ["name", "string"],
            ["position", "string"],
            ["base", "string"],
            ["qualification", "string"],
            ["duty_time_remaining", "float"],
            ["rest_required", "float"]
        ])
    },
    {
        id: 3,
        name: 'Fleet Status',
        category: 'Aircraft Operations',
        last_updated: new Date().toISOString(),
        row_count: 118,
        quality_metrics: {
            accuracy: 0.97,
            completeness: 0.93,
            consistency: 0.90,
            uniqueness: 0.96,
            validity: 0.94,
            timeliness: 0.87,
            overall_score: 0.92
        },
        schema: JSON.stringify([
            ["aircraft_id", "string"],
            ["aircraft_type", "string"],
            ["capacity", "integer"],
            ["range_nm", "float"],
            ["status", "string"],
            ["maintenance_status", "string"],
            ["next_maintenance", "datetime"]
        ])
    },
    {
        id: 4,
        name: 'Passenger Manifests with Unaccompanied Minors',
        category: 'Passenger Data',
        last_updated: new Date().toISOString(),
        row_count: 1243,
        quality_metrics: {
            accuracy: 0.93,
            completeness: 0.89,
            consistency: 0.85,
            uniqueness: 0.95,
            validity: 0.91,
            timeliness: 0.82,
            overall_score: 0.88
        },
        schema: JSON.stringify([
            ["passenger_id", "string"],
            ["flight_id", "string"],
            ["booking_reference", "string"],
            ["name", "string"],
            ["age", "integer"],
            ["special_service", "string"],
            ["seat_number", "string"],
            ["is_unaccompanied_minor", "boolean"],
            ["guardian_contact", "string"]
        ])
    },
    {
        id: 5,
        name: 'Airport Weather Data',
        category: 'Weather Data',
        last_updated: new Date().toISOString(),
        row_count: 864,
        quality_metrics: {
            accuracy: 0.92,
            completeness: 0.97,
            consistency: 0.89,
            uniqueness: 0.98,
            validity: 0.94,
            timeliness: 0.90,
            overall_score: 0.93
        },
        schema: JSON.stringify([
            ["airport_code", "string"],
            ["timestamp", "datetime"],
            ["temperature", "float"],
            ["wind_speed", "float"],
            ["wind_direction", "integer"],
            ["visibility", "float"],
            ["precipitation", "float"],
            ["conditions", "string"]
        ])
    },
    {
        id: 6,
        name: 'Maintenance Schedules',
        category: 'Maintenance',
        last_updated: new Date().toISOString(),
        row_count: 254,
        quality_metrics: {
            accuracy: 0.96,
            completeness: 0.90,
            consistency: 0.92,
            uniqueness: 0.97,
            validity: 0.95,
            timeliness: 0.83,
            overall_score: 0.91
        },
        schema: JSON.stringify([
            ["maintenance_id", "string"],
            ["aircraft_id", "string"],
            ["maintenance_type", "string"],
            ["scheduled_start", "datetime"],
            ["scheduled_end", "datetime"],
            ["facility", "string"],
            ["status", "string"]
        ])
    },
    {
        id: 7,
        name: 'Ground Handling Resources',
        category: 'Station Operations',
        last_updated: new Date().toISOString(),
        row_count: 378,
        quality_metrics: {
            accuracy: 0.94,
            completeness: 0.91,
            consistency: 0.89,
            uniqueness: 0.96,
            validity: 0.93,
            timeliness: 0.85,
            overall_score: 0.91
        },
        schema: JSON.stringify([
            ["resource_id", "string"],
            ["airport_code", "string"],
            ["resource_type", "string"],
            ["capacity", "integer"],
            ["available", "integer"],
            ["status", "string"]
        ])
    },
    {
        id: 8,
        name: 'IROP Alerts',
        category: 'OCC Monitoring',
        last_updated: new Date().toISOString(),
        row_count: 721,
        quality_metrics: {
            accuracy: 0.96,
            completeness: 0.93,
            consistency: 0.91,
            uniqueness: 0.99,
            validity: 0.95,
            timeliness: 0.94,
            overall_score: 0.95
        },
        schema: JSON.stringify([
            ["alert_id", "string"],
            ["timestamp", "datetime"],
            ["category", "string"],
            ["severity", "string"],
            ["affected_entity", "string"],
            ["description", "string"],
            ["status", "string"]
        ])
    }
];