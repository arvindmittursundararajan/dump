/**
 * AeroOptima.ai - Live Watch Module
 * Handles real-time alerts, rule management, and anomaly detection
 */

// Keep track of current alerts and rules
let currentAlerts = [];
let currentRules = [];

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Load only active alerts by default
    loadAlerts({ is_active: 'true' });
    loadRules();
    
    // Setup alert filter controls
    setupAlertFilters();
    
    // Setup rule creation form
    setupRuleForm();
    
    // Set up polling for new alerts (every 30 seconds)
    setInterval(loadAlerts, 30000);

    // Bind scenario items
    document.querySelectorAll('.scenario-item').forEach(item => {
        item.addEventListener('click', function() {
            const q = this.getAttribute('data-scenario');
            document.getElementById('nl-query-input').value = q;
            processNLQuery();
        });
    });

    // Bind View All Rules modal show event
    const viewAllModal = document.getElementById('view-all-rules-modal');
    if (viewAllModal) {
        viewAllModal.addEventListener('show.bs.modal', loadAllRules);
    }
});

/**
 * Load alerts from the API
 * @param {Object} filters - Optional filters for alerts
 */
function loadAlerts(filters = {}) {
    const alertsContainer = document.getElementById('alerts-container');
    if (!alertsContainer) return;
    
    // Build query string from filters
    let queryParams = new URLSearchParams();
    if (filters.severity) queryParams.append('severity', filters.severity);
    if (filters.category) queryParams.append('category', filters.category);
    if (filters.is_active !== undefined) queryParams.append('is_active', filters.is_active);
    if (filters.limit) queryParams.append('limit', filters.limit);
    
    const queryString = queryParams.toString();
    const url = `/api/alerts${queryString ? '?' + queryString : ''}`;
    
    // Only show loading on first load
    if (currentAlerts.length === 0) {
        alertsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading alerts...</p>';
    }
    
    // Fetch alerts
    fetch(url)
        .then(response => response.json())
        .then(data => {
            // Store current alerts
            currentAlerts = data;
            
            if (data.length === 0) {
                alertsContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No alerts match your filters. All systems nominal.
                    </div>
                `;
                return;
            }
            
            // Create HTML
            let html = '';
            
            // Group by severity for better visibility
            const severityOrder = ['critical', 'warning', 'info'];
            
            for (const severity of severityOrder) {
                const severityAlerts = data.filter(alert => alert.severity === severity);
                
                if (severityAlerts.length === 0) continue;
                
                // Add severity heading
                html += `
                    <div class="mb-3">
                        <h5 class="${severity === 'critical' ? 'text-danger' : severity === 'warning' ? 'text-warning' : 'text-info'}">
                            ${severity.charAt(0).toUpperCase() + severity.slice(1)} Alerts (${severityAlerts.length})
                        </h5>
                `;
                
                // Add alerts for this severity
                severityAlerts.forEach(alert => {
                    const alertClass = severity === 'critical' ? 'alert-critical' : 
                                      severity === 'warning' ? 'alert-warning' : 'alert-info';
                                      
                    html += `
                        <div class="alert-item ${alertClass}" 
                             data-id="${alert.id}" 
                             data-severity="${alert.severity}"
                             data-timestamp="${alert.timestamp}"
                             onclick="viewAlertDetails(${alert.id})">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">${alert.title}</h6>
                                <span class="badge ${severity === 'critical' ? 'bg-danger' : 
                                                    severity === 'warning' ? 'bg-warning' : 'bg-info'}">
                                    ${severity}
                                </span>
                            </div>
                            <p class="mb-1 small text-muted">
                                ${alert.category} • ${formatDate(alert.timestamp)}
                            </p>
                            <p class="mb-0 small">${truncateText(alert.description, 100)}</p>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            // Update container
            alertsContainer.innerHTML = html;
        })
        .catch(error => {
            alertsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading alerts: ${error.message}
                </div>
            `;
            console.error('Failed to load alerts:', error);
        });
}

/**
 * Load rules from the API
 */
function loadRules() {
    const rulesContainer = document.getElementById('rules-container');
    if (!rulesContainer) return;
    
    // Show loading state
    rulesContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading rules...</p>';
    
    // Fetch rules
    fetch('/api/rules')
        .then(response => response.json())
        .then(data => {
            // Store current rules
            currentRules = data;
            
            if (data.length === 0) {
                rulesContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No rules defined yet. Create your first rule to start monitoring.
                    </div>
                `;
                return;
            }
            
            // Create HTML
            let html = '';
            
            // Group by category for better organization
            const groupedRules = {};
            data.forEach(rule => {
                if (!groupedRules[rule.category]) {
                    groupedRules[rule.category] = [];
                }
                groupedRules[rule.category].push(rule);
            });
            
            // Add rules by category
            for (const category in groupedRules) {
                html += `
                    <div class="mb-3">
                        <h6 class="mb-2">${category}</h6>
                `;
                
                // Add rules for this category
                groupedRules[category].forEach(rule => {
                    const isActive = rule.is_active ? 'bg-light' : 'bg-light-gray text-muted';
                    const severityClass = rule.severity === 'critical' ? 'border-danger' : 
                                          rule.severity === 'warning' ? 'border-warning' : 'border-info';
                                         
                    html += `
                        <div class="active-rule mb-3" 
                             data-id="${rule.id}"
                             data-category="${rule.category}"
                             onclick="viewRuleDetails(${rule.id})">
                            <div class="rule-header">
                                <h6 class="rule-name">${rule.name}</h6>
                                <span class="rule-status badge ${rule.severity === 'critical' ? 'bg-danger' : 
                                                    rule.severity === 'warning' ? 'bg-warning' : 'bg-info'}">
                                    ${rule.severity}
                                </span>
                            </div>
                            <p class="rule-description">
                                <code>${truncateText(rule.rule_text, 80)}</code>
                            </p>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            // Update container
            rulesContainer.innerHTML = html;
        })
        .catch(error => {
            rulesContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading rules: ${error.message}
                </div>
            `;
            console.error('Failed to load rules:', error);
        });
}

/**
 * Setup alert filter controls
 */
function setupAlertFilters() {
    const filterForm = document.getElementById('alert-filter-form');
    
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get filter values
            const severity = document.getElementById('filter-severity').value;
            const category = document.getElementById('filter-category').value;
            const isActive = document.getElementById('filter-active').checked;
            
            // Apply filters
            loadAlerts({
                severity: severity || undefined,
                category: category || undefined,
                is_active: isActive.toString()
            });
        });
        
        // Reset filters button
        document.getElementById('reset-filters')?.addEventListener('click', function() {
            document.getElementById('filter-severity').value = '';
            document.getElementById('filter-category').value = '';
            document.getElementById('filter-active').checked = true;
            
            // Reload active alerts only
            loadAlerts({
                severity: undefined,
                category: undefined,
                is_active: 'true'
            });
        });
    }
}

/**
 * Setup rule creation form
 */
function setupRuleForm() {
    const ruleForm = document.getElementById('rule-form');
    
    if (ruleForm) {
        ruleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('rule-name').value;
            const description = document.getElementById('rule-description').value;
            const ruleText = document.getElementById('rule-text').value;
            const category = document.getElementById('rule-category').value;
            const severity = document.getElementById('rule-severity').value;
            
            // Validate
            if (!name || !ruleText) {
                showToast('Name and rule expression are required', 'warning');
                return;
            }
            
            // Create rule data
            const ruleData = {
                name,
                description,
                rule_text: ruleText,
                category,
                severity,
                is_active: true
            };
            
            // Show loading state
            const submitBtn = ruleForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating...';
            
            // Send to API
            fetch('/api/rules', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(ruleData)
            })
            .then(response => response.json())
            .then(data => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Show success message
                showToast('Rule created successfully', 'success');
                
                // Reset form
                ruleForm.reset();
                
                // Close modal if open
                const modal = bootstrap.Modal.getInstance(document.getElementById('new-rule-modal'));
                if (modal) {
                    modal.hide();
                }
                
                // Reload rules
                loadRules();
            })
            .catch(error => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                // Show error message
                showToast('Failed to create rule: ' + error.message, 'danger');
                console.error('Rule creation error:', error);
            });
        });
    }
}

/**
 * View detailed information about an alert
 * @param {number} alertId - ID of the alert
 */
function viewAlertDetails(alertId) {
    const detailsModal = new bootstrap.Modal(document.getElementById('alert-details-modal'));
    const modalTitle = document.getElementById('alert-detail-title');
    const detailsContainer = document.getElementById('alert-details-container');
    
    if (detailsContainer && modalTitle) {
        // Show loading state
        detailsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading alert details...</p>';
        
        // Show modal while loading
        detailsModal.show();
        
        // Fetch alert details
        fetch(`/api/alerts/${alertId}`)
            .then(response => response.json())
            .then(alert => {
                // Set modal title
                modalTitle.textContent = alert.title;
                
                // Format severity badge
                const severityBadge = alert.severity === 'critical' ? 'bg-danger' : 
                                     alert.severity === 'warning' ? 'bg-warning' : 'bg-info';
                
                // Format entity badges
                let entitiesHtml = '';
                if (alert.affected_entities) {
                    for (const [entityType, entityId] of Object.entries(alert.affected_entities)) {
                        entitiesHtml += `
                            <span class="badge bg-secondary me-1">
                                ${entityType}: ${entityId}
                            </span>
                        `;
                    }
                }
                
                // Create resolution form or show resolution info
                let resolutionHtml = '';
                if (alert.is_active) {
                    resolutionHtml = `
                        <div class="mt-4">
                            <h6>Resolve Alert</h6>
                            <form id="resolve-form">
                                <div class="mb-3">
                                    <label for="resolution-notes" class="form-label">Resolution Notes</label>
                                    <textarea class="form-control" id="resolution-notes" rows="3" placeholder="Describe how this alert was resolved..."></textarea>
                                </div>
                                <button type="button" class="btn btn-success" onclick="resolveAlert(${alertId})">
                                    <i class="fas fa-check"></i> Mark as Resolved
                                </button>
                            </form>
                        </div>
                    `;
                } else {
                    resolutionHtml = `
                        <div class="mt-4">
                            <h6>Resolution</h6>
                            <div class="alert alert-success">
                                <p><strong>Resolved at:</strong> ${formatDate(alert.resolved_at)}</p>
                                <p><strong>Notes:</strong> ${alert.resolution_notes || 'No notes provided'}</p>
                            </div>
                        </div>
                    `;
                }
                
                // Create details HTML
                const detailsHtml = `
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Category:</strong> ${alert.category}</p>
                            <p><strong>Source:</strong> ${alert.source}</p>
                            <p>
                                <strong>Severity:</strong> 
                                <span class="badge ${severityBadge}">${alert.severity}</span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Created:</strong> ${formatDate(alert.timestamp)}</p>
                            <p><strong>Status:</strong> ${alert.is_active ? 'Active' : 'Resolved'}</p>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <h6>Description</h6>
                        <p>${alert.description || 'No description provided'}</p>
                    </div>
                    
                    <div class="mt-3">
                        <h6>Affected Entities</h6>
                        <div>${entitiesHtml || 'No specific entities affected'}</div>
                    </div>
                    
                    ${resolutionHtml}
                    
                    <div class="mt-4">
                        <button class="btn btn-outline-primary" onclick="askGeminiAboutAlert(${alertId})">
                            <i class="fas fa-robot"></i> Ask Gemini About This Alert
                        </button>
                    </div>
                    
                    <div id="gemini-analysis" class="mt-3"></div>
                `;
                
                // Update container
                detailsContainer.innerHTML = detailsHtml;
            })
            .catch(error => {
                detailsContainer.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> Error loading alert details: ${error.message}
                    </div>
                `;
                console.error('Failed to load alert details:', error);
            });
    }
}

/**
 * Mark an alert as resolved
 * @param {number} alertId - ID of the alert to resolve
 */
function resolveAlert(alertId) {
    const resolutionNotes = document.getElementById('resolution-notes')?.value || '';
    
    // Show loading state
    const resolveBtn = document.querySelector('#resolve-form button');
    const originalBtnText = resolveBtn.innerHTML;
    resolveBtn.disabled = true;
    resolveBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Resolving...';
    
    // Call API to resolve
    fetch(`/api/alerts/${alertId}/resolve`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            resolution_notes: resolutionNotes
        })
    })
    .then(response => response.json())
    .then(data => {
        // Reset button state
        resolveBtn.disabled = false;
        resolveBtn.innerHTML = originalBtnText;
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Alert resolved successfully', 'success');
        
        // Close modal if open
        const modal = bootstrap.Modal.getInstance(document.getElementById('alert-details-modal'));
        if (modal) {
            modal.hide();
        }
        
        // Reload alerts
        loadAlerts();
    })
    .catch(error => {
        // Reset button state
        resolveBtn.disabled = false;
        resolveBtn.innerHTML = originalBtnText;
        
        // Show error message
        showToast('Failed to resolve alert: ' + error.message, 'danger');
        console.error('Alert resolution error:', error);
    });
}

/**
 * View detailed information about a rule
 * @param {number} ruleId - ID of the rule
 */
function viewRuleDetails(ruleId) {
    // Find the rule in our current rules
    const rule = currentRules.find(r => r.id === ruleId);
    if (!rule) {
        showToast('Rule not found', 'danger');
        return;
    }
    
    const detailsModal = new bootstrap.Modal(document.getElementById('rule-details-modal'));
    const modalTitle = document.getElementById('rule-detail-title');
    const detailsContainer = document.getElementById('rule-details-container');
    
    if (detailsContainer && modalTitle) {
        // Set modal title
        modalTitle.textContent = rule.name;
        
        // Format severity badge
        const severityBadge = rule.severity === 'critical' ? 'bg-danger' : 
                             rule.severity === 'warning' ? 'bg-warning' : 'bg-info';
                             
        // Create details HTML
        const detailsHtml = `
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Category:</strong> ${rule.category}</p>
                    <p>
                        <strong>Severity:</strong> 
                        <span class="badge ${severityBadge}">${rule.severity}</span>
                    </p>
                    <p><strong>Status:</strong> ${rule.is_active ? 'Active' : 'Inactive'}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Created:</strong> ${formatDate(rule.created_at)}</p>
                    <p><strong>Last Updated:</strong> ${formatDate(rule.updated_at)}</p>
                </div>
            </div>
            
            <div class="mt-3">
                <h6>Description</h6>
                <p>${rule.description || 'No description provided'}</p>
            </div>
            
            <div class="mt-3">
                <h6>Rule Expression</h6>
                <pre class="bg-light p-3 rounded"><code>${rule.rule_text}</code></pre>
            </div>
            
            <div class="mt-4">
                <div class="d-flex">
                    <button class="btn btn-primary me-2" onclick="testRule(${rule.id})">
                        <i class="fas fa-vial"></i> Test Rule
                    </button>
                    <button class="btn btn-outline-secondary me-2" onclick="toggleRuleStatus(${rule.id}, ${!rule.is_active})">
                        <i class="fas fa-${rule.is_active ? 'pause' : 'play'}"></i> ${rule.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button class="btn btn-outline-danger" onclick="deleteRule(${rule.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
            
            <div id="rule-test-container" class="mt-4 d-none">
                <h6>Test Rule with Sample Data</h6>
                <div class="mb-3">
                    <textarea class="form-control" id="test-data" rows="5" placeholder='{"flight_delay": 45, "passenger_count": 120, "is_international": true}'></textarea>
                    <div class="form-text">Enter JSON data to test against the rule</div>
                </div>
                <button class="btn btn-primary" onclick="runRuleTest(${rule.id})">
                    <i class="fas fa-play"></i> Run Test
                </button>
                <div id="test-result" class="mt-3"></div>
            </div>
        `;
        
        // Update container
        detailsContainer.innerHTML = detailsHtml;
        
        // Show modal
        detailsModal.show();
    }
}

/**
 * Show the rule test interface
 * @param {number} ruleId - ID of the rule to test
 */
function testRule(ruleId) {
    const testContainer = document.getElementById('rule-test-container');
    if (testContainer) {
        testContainer.classList.remove('d-none');
        
        // Focus on the test data textarea
        document.getElementById('test-data')?.focus();
    }
}

/**
 * Run a test of a rule with provided data
 * @param {number} ruleId - ID of the rule to test
 */
function runRuleTest(ruleId) {
    const testDataText = document.getElementById('test-data')?.value;
    const resultContainer = document.getElementById('test-result');
    
    if (!testDataText || !resultContainer) {
        showToast('Please enter test data in valid JSON format', 'warning');
        return;
    }
    
    // Parse JSON
    let testData;
    try {
        testData = JSON.parse(testDataText);
    } catch (e) {
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Invalid JSON: ${e.message}
            </div>
        `;
        return;
    }
    
    // Show loading state
    resultContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Testing rule...</p>';
    
    // Call API to test
    fetch(`/api/rules/${ruleId}/evaluate`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(testData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show result
        if (data.result === true) {
            resultContainer.innerHTML = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <strong>Rule Matched!</strong> The test data would trigger this rule.
                </div>
            `;
        } else {
            resultContainer.innerHTML = `
                <div class="alert alert-secondary">
                    <i class="fas fa-times-circle"></i> <strong>No Match.</strong> The test data would not trigger this rule.
                </div>
            `;
        }
    })
    .catch(error => {
        // Show error message
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error testing rule: ${error.message}
            </div>
        `;
        console.error('Rule test error:', error);
    });
}

/**
 * Toggle the active status of a rule
 * @param {number} ruleId - ID of the rule
 * @param {boolean} isActive - New active status
 */
function toggleRuleStatus(ruleId, isActive) {
    // Find the rule
    const rule = currentRules.find(r => r.id === ruleId);
    if (!rule) {
        showToast('Rule not found', 'danger');
        return;
    }
    
    // Update the rule
    fetch(`/api/rules/${ruleId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            is_active: isActive
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast(`Rule ${isActive ? 'activated' : 'deactivated'} successfully`, 'success');
        
        // Close modal if open
        const modal = bootstrap.Modal.getInstance(document.getElementById('rule-details-modal'));
        if (modal) {
            modal.hide();
        }
        
        // Reload rules
        loadRules();
    })
    .catch(error => {
        // Show error message
        showToast('Failed to update rule: ' + error.message, 'danger');
        console.error('Rule update error:', error);
    });
}

/**
 * Delete a rule
 * @param {number} ruleId - ID of the rule to delete
 */
function deleteRule(ruleId) {
    // Confirm deletion
    if (!confirm('Are you sure you want to delete this rule? This action cannot be undone.')) {
        return;
    }
    
    // For this demo, we'll just deactivate the rule since we don't have a DELETE endpoint
    toggleRuleStatus(ruleId, false);
}

/**
 * Use Gemini to get insights about an alert
 * @param {number} alertId - ID of the alert
 */
function askGeminiAboutAlert(alertId) {
    // Find the alert
    const alert = currentAlerts.find(a => a.id === alertId);
    if (!alert) {
        showToast('Alert not found', 'danger');
        return;
    }
    
    const analysisContainer = document.getElementById('gemini-analysis');
    if (!analysisContainer) return;
    
    // Show loading state
    analysisContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Asking Gemini for insights...</p>';
    
    // Form a question for Gemini about this alert
    const query = `Analyze this alert and suggest possible causes and solutions: 
        Title: ${alert.title}
        Description: ${alert.description}
        Category: ${alert.category}
        Severity: ${alert.severity}
        Affected entities: ${JSON.stringify(alert.affected_entities || {})}`;
    
    // Ask Gemini
    askGemini(query, 'gemini-analysis');
}

/**
 * Process a natural language query for alerts
 */
function processNLQuery() {
    const queryInput = document.getElementById('nl-query-input');
    const resultsContainer = document.getElementById('nl-query-results');
    
    if (!queryInput || !resultsContainer) return;
    
    const query = queryInput.value.trim();
    if (!query) {
        showToast('Please enter a query', 'warning');
        return;
    }
    
    // Show loading state
    resultsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Processing query...</p>';
    
    // Send to API
    fetch('/api/nl-query', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            query, 
            execute: true,
            context: 'monitoring' // Add context to help with query generation
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        let resultHtml = '';
        
        // Add the generated query
        resultHtml += `
            <div class="card mb-3">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">Generated ${data.query_type === 'sql' ? 'SQL' : 'Rule'}</h6>
                </div>
                <div class="card-body bg-light">
                    <pre class="mb-0"><code>${data.generated_query}</code></pre>
                </div>
            </div>
        `;
        
        // Add the results if available
        if (data.query_type === 'sql' && data.data) {
            if (data.data.length > 0) {
                // Extract column names from first row
                const columns = Object.keys(data.data[0]);
                
                resultHtml += `
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h6 class="mb-0">Results (${data.data.length} ${data.data.length === 1 ? 'row' : 'rows'})</h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-sm table-striped mb-0">
                                    <thead>
                                        <tr>
                                            ${columns.map(col => `<th>${col}</th>`).join('')}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${data.data.map(row => `
                                            <tr>
                                                ${columns.map(col => `<td>${row[col] !== null ? row[col] : '<em>null</em>'}</td>`).join('')}
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                resultHtml += `
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-2"></i> The query returned no results.
                    </div>
                `;
            }
        } else if (data.query_type === 'rule') {
            if (data.valid) {
                resultHtml += `
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i> This rule expression is valid and can be used in a new rule.
                        <button class="btn btn-sm btn-outline-success ms-2" onclick="createRuleFromQuery('${data.generated_query}')">
                            <i class="fas fa-plus me-1"></i> Create Rule
                        </button>
                    </div>
                `;
            } else if (data.error) {
                resultHtml += `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i> ${data.error}
                    </div>
                `;
            }
        }
        
        // Show result
        resultsContainer.innerHTML = resultHtml;
    })
    .catch(error => {
        // Show error message
        resultsContainer.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error processing query: ${error.message}
            </div>
        `;
        console.error('NL query error:', error);
    });
}

// Add helper function to create rule from query
function createRuleFromQuery(ruleText) {
    // Open the new rule modal
    const modal = new bootstrap.Modal(document.getElementById('new-rule-modal'));
    modal.show();
    
    // Set the rule text
    document.getElementById('rule-text').value = ruleText;
}

/**
 * Truncate text with ellipsis if it exceeds max length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
function truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Load all rules into the View All Rules modal
 */
function loadAllRules() {
    const container = document.getElementById('view-all-rules-container');
    if (!container) return;
    // Show loading state
    container.innerHTML = '<div class="spinner"></div><p class="text-center">Loading rules...</p>';
    fetch('/api/rules')
        .then(response => response.json())
        .then(data => {
            if (data.error) throw new Error(data.error);
            if (!Array.isArray(data) || data.length === 0) {
                container.innerHTML = '<div class="alert alert-info"><i class="fas fa-info-circle"></i> No rules defined yet.</div>';
                return;
            }
            let html = '<ul class="list-group">';
            data.forEach(rule => {
                html += `<li class="list-group-item d-flex justify-content-between align-items-start">
                           <div class="me-2">
                             <div><strong>${rule.name}</strong> <small class="text-muted">(${rule.category})</small></div>
                             <code>${rule.rule_text}</code>
                           </div>
                           <span class="badge ${rule.severity === 'critical' ? 'bg-danger' : rule.severity === 'warning' ? 'bg-warning' : 'bg-info'}">
                             ${rule.severity}
                           </span>
                         </li>`;
            });
            html += '</ul>';
            container.innerHTML = html;
        })
        .catch(error => {
            container.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Error loading rules: ${error.message}</div>`;
            console.error('Failed to load all rules:', error);
        });
}
