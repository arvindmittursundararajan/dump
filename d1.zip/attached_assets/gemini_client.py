import os
import json
import requests
from config import GEMINI_API_KEY

GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Analysis prompts from the analysis_prompts.py file
ANALYSIS_PROMPT = """
You are a data modeling expert analyzing a database schema. Provide a detailed analysis of the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

Analysis Type: {analysis_type}

Please provide a thorough analysis focusing on the {analysis_type} aspects. Format your response using Markdown, including headers, bullet points, and code blocks where appropriate.

Include the following sections in your analysis:
1. Overview of the schema
2. Key entities and relationships
3. Strengths of the current schema
4. Potential issues or weaknesses
5. Recommendations for improvement

Focus specifically on {analysis_type} considerations.
"""

DIAGRAM_PROMPT = """
You are a data modeling expert generating a database diagram. Create a {0} diagram for the following database schema using mermaid.js syntax:

Database: {1}
Tables: {2}

Schema Information:
{3}

Instructions for diagram type: {0}

If the diagram type is conceptual, logical, physical, or erd:
- Use erDiagram syntax (starts with 'erDiagram')
- For conceptual: Show only entity names and relationships, no attributes
- For logical: Show entity names, primary keys, and relationships
- For physical: Include all columns with data types and constraints
- Use proper cardinality notation (||--o|, etc.)

If the diagram type is dependency:
- Use flowchart syntax (starts with 'flowchart TD')
- Show tables as nodes with dependencies flowing in direction of foreign key relationships
- Use different node shapes for different types of tables
- Connect related tables with arrows indicating dependency direction

If the diagram type is hierarchical:
- Use classDiagram syntax (starts with 'classDiagram')
- Organize tables in a hierarchical structure with parent/child relationships
- Show inheritance or composition relationships where appropriate
- Include key fields and relationships

Return ONLY the mermaid.js code without any explanation or additional text. The code should be in a format that can be directly used with mermaid.js.
"""

MAPPING_SHEET_PROMPT = """
You are a data governance specialist creating a comprehensive data mapping sheet. Generate detailed metadata for each table in the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

For each table, provide the following information in a structured format:
1. Technical name (the actual table name)
2. Business name (a user-friendly name for the table)
3. Description (purpose and contents of the table)
4. Entity type (transactional, master data, reference, etc.)
5. Classification (public, internal, confidential, restricted)
6. List of columns, each with:
   - Technical name
   - Business name
   - Data type
   - Description
   - Domain values (possible values or constraints)
   - Business rules
   - Sample values (2-3 example values)

Format your response as a structured JSON object that can be easily parsed. Use the following schema:
{
  "tables": [
    {
      "technical_name": "string",
      "business_name": "string",
      "description": "string",
      "entity_type": "string",
      "classification": "string", 
      "columns": [
        {
          "technical_name": "string",
          "business_name": "string",
          "data_type": "string",
          "description": "string",
          "domain_values": "string",
          "business_rules": "string",
          "sample_values": ["string", "string"]
        }
      ]
    }
  ]
}

Make educated guesses where necessary based on column names and data types, but keep them plausible.
"""

COMPLIANCE_PROMPT = """
You are a data compliance and governance expert. Perform a CASTLE (Compliance, Auditability, Security, Traceability, Lineage, Ethics) assessment on the following database schema:

Database: {database}
Tables: {tables}

Schema Information:
{schema_info}

For each dimension of the CASTLE framework, provide:
1. A score from 1 (Poor) to 5 (Excellent)
2. Key strengths (2-3 points)
3. Key weaknesses (2-3 points)
4. Specific recommendations for improvement (2-3 points)

Also provide an overall weighted score for the entire schema.

Additionally, include the following readability scores for the schema:
1. Flesch-Kincaid Readability Score (0-100, where higher means more readable)
2. Gunning Fog Index (measures text complexity, where lower means more readable)

These scores should evaluate the naming conventions, descriptions, and overall clarity of the database schema.

Format your response as a structured JSON object that can be easily parsed. Use the following schema:
{
  "overall_score": float,
  "readability_scores": {
    "flesch_kincaid": float,
    "gunning_fog": float,
    "summary": "string"
  },
  "compliance": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "auditability": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "security": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "traceability": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "lineage": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  },
  "ethics": {
    "score": int,
    "strengths": ["string", "string", "string"],
    "weaknesses": ["string", "string", "string"],
    "recommendations": ["string", "string", "string"]
  }
}

Base your assessment on industry standards and best practices for data governance and management.
"""

QUERY_PROMPT = """
You are a SQL expert with deep knowledge of database schemas. Generate a SQL query for the following natural language prompt:

Database: {database}
Natural Language Query: {prompt}

Schema Information:
{schema_info}

Generate a valid SQL query that answers the user's question. Consider:
1. The appropriate tables to query
2. Required joins to connect related tables
3. Proper filtering conditions
4. Any aggregations or calculations needed
5. Sorting or limiting results as appropriate

Return ONLY the SQL query without any explanation or additional text. The query should be executable against the provided schema.
"""

DOMAIN_ANALYSIS_PROMPT = """
You are a data modeling expert analyzing database schemas. Generate:
1. A brief 2-3 sentence overview of what this database represents
2. A simple conceptual diagram showing key entities and relationships

Database(s): {databases}
Tables: {tables}

Schema Information:
{schema_info}

For the domain description:
- Keep it extremely concise (2-3 short sentences maximum)
- Use simple everyday language for non-technical users
- Mention only the main purpose and key entities
- Avoid all technical terms

For the diagram:
- Create a minimalist mermaid.js flowchart diagram
- Use flowchart LR syntax (left-to-right orientation)
- Include only 4-6 most important entities
- Use simple labels and relationship descriptions
- Keep it black and white with simple styling
- Example styling: classDef default fill:#fff,stroke:#000,stroke-width:1px;

Format your response with the description first, followed by the mermaid diagram code in a code block.
"""

def get_prompt_for_analysis_type(analysis_type):
    """Get the correct prompt for a given analysis type."""
    if analysis_type == "mapping_sheet":
        return MAPPING_SHEET_PROMPT
    elif analysis_type == "compliance":
        return COMPLIANCE_PROMPT
    elif analysis_type == "domain":
        return DOMAIN_ANALYSIS_PROMPT
    elif analysis_type == "query":
        return QUERY_PROMPT
    elif analysis_type.startswith("diagram_"):
        return DIAGRAM_PROMPT
    else:
        return ANALYSIS_PROMPT

def send_to_gemini(prompt, api_key=GEMINI_API_KEY):
    """Send a prompt to Gemini API and get a response."""
    if not api_key:
        return "No Gemini API key provided. Please configure the GEMINI_API_KEY in config.py."
    
    try:
        params = {
            'key': api_key,
        }
        
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 32,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        
        response = requests.post(
            GEMINI_API_URL,
            params=params,
            json=request_body
        )
        
        if response.status_code == 200:
            response_json = response.json()
            if 'candidates' in response_json and len(response_json['candidates']) > 0:
                return response_json['candidates'][0]['content']['parts'][0]['text']
            else:
                return "No valid response from Gemini API."
        else:
            return f"Error from Gemini API: {response.status_code} - {response.text}"
    
    except Exception as e:
        return f"Error calling Gemini API: {str(e)}"

def analyze_schema(database_name, tables, schema_info, analysis_type="general", output_format="html"):
    """Analyze the schema using the Gemini API."""
    prompt = get_prompt_for_analysis_type(analysis_type)
    
    # Enhance prompt to request HTML format with emojis if not a specialized type
    if output_format == "html" and not analysis_type.startswith("diagram_") and not analysis_type in ["compliance", "mapping_sheet"]:
        # Add HTML formatting instruction to the prompt
        html_instruction = """
        Format your response as rich HTML with appropriate headings, lists, and styling.
        Use emojis liberally to make the content engaging and visually appealing.
        Common emojis to use:
        - 📊 For data insights
        - ✅ For strengths and recommendations
        - ⚠️ For warnings and issues
        - 📈 For performance topics
        - 🔍 For analysis sections
        - 📋 For summary sections
        - 🔄 For relationships
        - 🏆 For best practices
        
        Return the analysis as HTML that can be directly inserted into a webpage.
        Place important performance metrics and table size information at the TOP of your response.
        """
        if "Please provide a thorough analysis" in prompt:
            # This is for the general analysis prompt - add HTML instructions
            prompt = prompt.replace("Format your response using Markdown", 
                                   "Format your response as HTML with emojis")
            prompt += html_instruction
    
    if analysis_type.startswith("diagram_"):
        diagram_type = analysis_type.split("_")[1]
        formatted_prompt = prompt.format(diagram_type, database_name, tables, schema_info)
    else:
        formatted_prompt = prompt.format(
            database=database_name,
            tables=tables,
            schema_info=schema_info,
            analysis_type=analysis_type,
            databases=database_name,  # For domain prompt
            prompt=""  # For query prompt
        )
    
    return send_to_gemini(formatted_prompt)

def format_analysis_result(result, analysis_type):
    """Format the analysis result for display."""
    if analysis_type.startswith("diagram_"):
        # For diagram analysis, wrap the mermaid code in a div for rendering
        result = f"""
        <div class="mermaid">
        {result}
        </div>
        """
    elif analysis_type == "compliance":
        try:
            # Try to parse the result as JSON and format it
            data = json.loads(result)
            html = """
            <div class="compliance-report">
                <div class="summary-section">
                    <h2>Overall CASTLE Score: {0:.1f}/5.0</h2>
                    <div class="readability">
                        <h3>Readability Scores</h3>
                        <p>Flesch-Kincaid: {1:.1f}/100 - Higher is better</p>
                        <p>Gunning Fog: {2:.1f} - Lower is better</p>
                        <p><em>{3}</em></p>
                    </div>
                </div>
                
                <div class="scores-section">
                    <h2>Dimension Scores</h2>
                    <div class="score-cards">
            """.format(
                data["overall_score"],
                data["readability_scores"]["flesch_kincaid"],
                data["readability_scores"]["gunning_fog"],
                data["readability_scores"]["summary"]
            )
            
            # Add each dimension
            for dimension in ["compliance", "auditability", "security", "traceability", "lineage", "ethics"]:
                html += """
                <div class="score-card">
                    <h3>{0} <span class="score">{1}/5</span></h3>
                    <div class="card-section">
                        <h4>✅ Strengths</h4>
                        <ul>
                """.format(dimension.capitalize(), data[dimension]["score"])
                
                for strength in data[dimension]["strengths"]:
                    html += f"<li>{strength}</li>"
                
                html += """
                        </ul>
                    </div>
                    <div class="card-section">
                        <h4>❌ Weaknesses</h4>
                        <ul>
                """
                
                for weakness in data[dimension]["weaknesses"]:
                    html += f"<li>{weakness}</li>"
                
                html += """
                        </ul>
                    </div>
                    <div class="card-section">
                        <h4>📝 Recommendations</h4>
                        <ul>
                """
                
                for rec in data[dimension]["recommendations"]:
                    html += f"<li>{rec}</li>"
                
                html += """
                        </ul>
                    </div>
                </div>
                """
            
            html += """
                    </div>
                </div>
            </div>
            """
            
            return html
        except json.JSONDecodeError:
            # If JSON parsing fails, return the raw response
            return result
    elif analysis_type == "mapping_sheet":
        try:
            # Try to parse the result as JSON and format it as a table
            data = json.loads(result)
            html = "<div class='mapping-sheet'>"
            
            for table in data["tables"]:
                html += f"""
                <div class="table-section">
                    <h2>{table['business_name']} <span class="technical-name">({table['technical_name']})</span></h2>
                    <p><strong>Description:</strong> {table['description']}</p>
                    <p><strong>Entity Type:</strong> {table['entity_type']} | <strong>Classification:</strong> {table['classification']}</p>
                    
                    <h3>Columns</h3>
                    <table class="columns-table">
                        <thead>
                            <tr>
                                <th>Technical Name</th>
                                <th>Business Name</th>
                                <th>Data Type</th>
                                <th>Description</th>
                                <th>Domain Values</th>
                                <th>Business Rules</th>
                                <th>Sample Values</th>
                            </tr>
                        </thead>
                        <tbody>
                """
                
                for column in table["columns"]:
                    sample_values = ", ".join(column["sample_values"]) if "sample_values" in column else ""
                    html += f"""
                    <tr>
                        <td>{column['technical_name']}</td>
                        <td>{column['business_name']}</td>
                        <td>{column['data_type']}</td>
                        <td>{column['description']}</td>
                        <td>{column['domain_values']}</td>
                        <td>{column['business_rules']}</td>
                        <td>{sample_values}</td>
                    </tr>
                    """
                
                html += """
                        </tbody>
                    </table>
                </div>
                """
            
            html += "</div>"
            return html
        except json.JSONDecodeError:
            # If JSON parsing fails, return the raw response
            return result
    
    # For other analysis types, convert markdown to HTML
    # For now, just return the raw text
    return result
