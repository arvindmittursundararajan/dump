from flask import Blueprint, render_template, request, jsonify, current_app
from models import Incident, OptimizationPlan
from app import db
from datetime import datetime
import json
from services.gemini_service import get_gemini_response, clean_text

debrief_bp = Blueprint('debrief', __name__)

@debrief_bp.route('/debrief')
def debrief():
    """Render the debrief page"""
    incidents = Incident.query.order_by(Incident.start_time.desc()).limit(10).all()
    # Get optimization plans for reference
    plans = OptimizationPlan.query.filter_by(status="completed").order_by(OptimizationPlan.created_at.desc()).limit(10).all()
    
    return render_template('debrief.html', 
                          incidents=incidents,
                          plans=plans,
                          active_page='debrief')

@debrief_bp.route('/api/incidents', methods=['GET'])
def get_incidents():
    """API endpoint to get all incidents"""
    incidents = Incident.query.order_by(Incident.start_time.desc()).all()
    result = []
    for incident in incidents:
        result.append({
            'id': incident.id,
            'title': incident.title,
            'description': incident.description,
            'start_time': incident.start_time.isoformat(),
            'end_time': incident.end_time.isoformat() if incident.end_time else None,
            'category': incident.category,
            'severity': incident.severity
        })
    return jsonify(result)

@debrief_bp.route('/api/incidents/<int:incident_id>', methods=['GET'])
def get_incident(incident_id):
    """API endpoint to get a specific incident"""
    incident = Incident.query.get_or_404(incident_id)
    return jsonify({
        'id': incident.id,
        'title': incident.title,
        'description': incident.description,
        'start_time': incident.start_time.isoformat(),
        'end_time': incident.end_time.isoformat() if incident.end_time else None,
        'category': incident.category,
        'severity': incident.severity,
        'timeline': incident.timeline,
        'affected_entities': incident.affected_entities,
        'root_cause': incident.root_cause,
        'resolution': incident.resolution,
        'lessons_learned': incident.lessons_learned,
        'optimization_plan_id': incident.optimization_plan_id
    })

@debrief_bp.route('/api/incidents', methods=['POST'])
def create_incident():
    """API endpoint to create a new incident"""
    data = request.json
    
    if not data or 'title' not in data or 'start_time' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Parse dates
    try:
        start_time = datetime.fromisoformat(data['start_time'])
        end_time = datetime.fromisoformat(data['end_time']) if 'end_time' in data and data['end_time'] else None
    except ValueError:
        return jsonify({'error': 'Invalid date format'}), 400
    
    # Create the incident
    incident = Incident(
        title=data['title'],
        description=data.get('description', ''),
        start_time=start_time,
        end_time=end_time,
        category=data.get('category', 'General'),
        severity=data.get('severity', 'medium'),
        timeline=data.get('timeline', []),
        affected_entities=data.get('affected_entities', []),
        root_cause=data.get('root_cause', ''),
        resolution=data.get('resolution', ''),
        lessons_learned=data.get('lessons_learned', ''),
        optimization_plan_id=data.get('optimization_plan_id')
    )
    
    db.session.add(incident)
    db.session.commit()
    
    return jsonify({
        'id': incident.id,
        'title': incident.title,
        'start_time': incident.start_time.isoformat(),
        'category': incident.category,
        'severity': incident.severity
    })

@debrief_bp.route('/api/incidents/<int:incident_id>/timeline', methods=['POST'])
def add_timeline_event(incident_id):
    """API endpoint to add an event to an incident timeline"""
    incident = Incident.query.get_or_404(incident_id)
    data = request.json
    
    if not data or 'event' not in data or 'timestamp' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Initialize timeline if needed
    if not incident.timeline:
        incident.timeline = []
    
    # Add the event
    timeline_event = {
        'timestamp': data['timestamp'],
        'event': data['event'],
        'category': data.get('category', 'general'),
        'metadata': data.get('metadata', {})
    }
    
    incident.timeline.append(timeline_event)
    db.session.commit()
    
    return jsonify({'success': True, 'timeline': incident.timeline})

@debrief_bp.route('/api/incidents/<int:incident_id>/root-cause', methods=['POST'])
def generate_root_cause(incident_id):
    """API endpoint to generate root cause analysis using Gemini"""
    incident = Incident.query.get_or_404(incident_id)
    
    # Prepare the incident data for the prompt
    incident_data = {
        'title': incident.title,
        'description': incident.description,
        'timeline': incident.timeline,
        'affected_entities': incident.affected_entities
    }
    
    # Get the prompt template
    with open('prompts/rca_prompt.txt', 'r') as f:
        prompt = f.read()
    
    # Add incident data to prompt
    full_prompt = prompt + "\n\nIncident Data: " + json.dumps(incident_data)
    
    try:
        response = get_gemini_response(full_prompt)
        
        # Update the incident with the generated root cause
        incident.root_cause = response
        db.session.commit()
        
        return jsonify({'root_cause': response})
    except Exception as e:
        current_app.logger.error(f"Error generating root cause analysis: {str(e)}")
        return jsonify({'error': str(e)}), 500

@debrief_bp.route('/api/incidents/<int:incident_id>/postmortem', methods=['POST'])
def generate_postmortem(incident_id):
    """API endpoint to generate a postmortem report using Gemini"""
    incident = Incident.query.get_or_404(incident_id)
    
    # Ensure we have root cause analysis
    if not incident.root_cause:
        return jsonify({'error': 'Root cause analysis must be completed first'}), 400
    
    # Prepare the incident data for the prompt
    incident_data = {
        'title': incident.title,
        'description': incident.description,
        'timeline': incident.timeline,
        'affected_entities': incident.affected_entities,
        'root_cause': incident.root_cause,
        'resolution': incident.resolution
    }
    
    # Get the prompt template
    with open('prompts/postmortem_prompt.txt', 'r') as f:
        prompt = f.read()
    
    # Add incident data to prompt
    full_prompt = prompt + "\n\nIncident Data: " + json.dumps(incident_data)
    
    try:
        response = get_gemini_response(full_prompt)
        
        # Update the incident with the generated lessons learned
        incident.lessons_learned = response
        db.session.commit()
        
        return jsonify({'postmortem': response})
    except Exception as e:
        current_app.logger.error(f"Error generating postmortem: {str(e)}")
        return jsonify({'error': str(e)}), 500

@debrief_bp.route('/api/generate-timeline-chart', methods=['POST'])
def generate_timeline_chart():
    """API endpoint to generate a mermaid.js timeline chart"""
    data = request.json
    
    if not data or 'events' not in data:
        return jsonify({'error': 'No events provided'}), 400
    
    events = data['events']
    
    with open('prompts/timeline_chart.txt', 'r') as f:
        prompt = f.read()
    
    full_prompt = prompt + "\n\nEvents: " + json.dumps(events)
    
    try:
        # Get the raw response
        raw_response = get_gemini_response(full_prompt)
        
        # Apply special Mermaid-specific cleaning
        cleaned_chart = clean_text(raw_response, is_mermaid=True)
        
        # Fix any inconsistencies in the response
        # Ensure it starts with "graph LR" for a horizontal flowchart
        if not cleaned_chart.startswith("graph LR"):
            cleaned_chart = "graph LR\n" + cleaned_chart
        
        # Ensure proper title is displayed in a comment
        if "title Incident Timeline" not in cleaned_chart and "%% Incident Timeline" not in cleaned_chart:
            lines = cleaned_chart.split('\n')
            # Insert after graph TD
            for i, line in enumerate(lines):
                if line.startswith("graph"):
                    lines.insert(i+1, "    %% Incident Timeline")
                    break
            cleaned_chart = '\n'.join(lines)
        
        # Log the generated chart for debugging
        current_app.logger.info(f"Generated timeline chart (after fixes, first 100 chars): {cleaned_chart[:100]}...")
        
        return jsonify({'chart': cleaned_chart})
    except Exception as e:
        current_app.logger.error(f"Error generating timeline chart: {str(e)}")
        return jsonify({'error': str(e)}), 500
