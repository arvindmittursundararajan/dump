import json
import logging
from rule_engine import Rule as RuleEngine
from models import Rule, Alert
from app import db
from datetime import datetime

logger = logging.getLogger(__name__)

def get_all_rules():
    """Get all rules from the database"""
    rules = Rule.query.all()
    result = []
    for rule in rules:
        result.append({
            'id': rule.id,
            'name': rule.name,
            'description': rule.description,
            'rule_text': rule.rule_text,
            'category': rule.category,
            'severity': rule.severity,
            'is_active': rule.is_active,
            'created_at': rule.created_at.isoformat() if rule.created_at else None,
            'updated_at': rule.updated_at.isoformat() if rule.updated_at else None,
            'metadata': rule.rule_config
        })
    return result

def evaluate_rule(rule_text, data):
    """
    Evaluate a rule against data using the rule-engine library
    Returns True if the rule matches, False otherwise
    """
    try:
        rule = RuleEngine(rule_text)
        return rule.matches(data)
    except Exception as e:
        logger.error(f"Error evaluating rule: {str(e)}")
        raise ValueError(f"Invalid rule: {str(e)}")

def parse_rule_text(rule_text):
    """
    Parse a rule from text format to a structured format
    Example input: "flight.delay > 30 and crew.duty_time_remaining < 60"
    """
    try:
        # This is a simplified parser - in a real system, you'd use a more robust approach
        parts = rule_text.split(' and ')
        conditions = []
        
        for part in parts:
            # Split on comparison operators
            for op in ['>=', '<=', '!=', '==', '>', '<']:
                if op in part:
                    left, right = part.split(op, 1)
                    conditions.append({
                        'left': left.strip(),
                        'operator': op,
                        'right': right.strip()
                    })
                    break
        
        return conditions
    except Exception as e:
        logger.error(f"Error parsing rule text: {str(e)}")
        return None

def create_alert_from_rule(rule, data, source):
    """
    Create an alert from a rule that matches data
    Returns the created alert
    """
    try:
        conditions = parse_rule_text(rule.rule_text)
        description = f"Rule '{rule.name}' triggered."
        if conditions:
            description += " Conditions: " + ", ".join([
                f"{c['left']} {c['operator']} {c['right']}" for c in conditions
            ])
        
        # Determine which entities are affected
        affected_entities = {}
        if isinstance(data, dict):
            # Extract entity IDs based on common patterns
            if 'flight_id' in data or 'flight_number' in data:
                affected_entities['flight'] = data.get('flight_id') or data.get('flight_number')
            if 'aircraft_id' in data or 'registration' in data:
                affected_entities['aircraft'] = data.get('aircraft_id') or data.get('registration')
            if 'crew_id' in data or 'staff_id' in data:
                affected_entities['crew'] = data.get('crew_id') or data.get('staff_id')
        
        # Create the alert
        alert = Alert(
            title=rule.name,
            description=description,
            severity=rule.severity,
            category=rule.category,
            source=source,
            is_active=True,
            affected_entities=affected_entities,
            metadata=data
        )
        
        db.session.add(alert)
        db.session.commit()
        
        return alert
    
    except Exception as e:
        db.session.rollback()
        logger.exception(f"Error creating alert from rule: {str(e)}")
        return None

def evaluate_all_rules_against_data(data, source):
    """
    Evaluate all active rules against a data point
    Returns a list of triggered alerts
    """
    alerts = []
    rules = Rule.query.filter_by(is_active=True).all()
    
    for rule in rules:
        try:
            if evaluate_rule(rule.rule_text, data):
                alert = create_alert_from_rule(rule, data, source)
                if alert:
                    alerts.append(alert)
        except Exception as e:
            logger.error(f"Error evaluating rule {rule.id}: {str(e)}")
    
    return alerts
