import React from 'react';
import { Box, Typography } from '@mui/material';

const Footer = () => {
  return (
    <Box component="footer" sx={{ background: '#f5f5f5', py: 2, mt: 4 }}>
      <Box sx={{ maxWidth: 1200, mx: 'auto', px: 2 }}>
        <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: 'center', gap: 2 }}>
          <Typography variant="body2" color="text.secondary">
            &copy; 2025 ADW <span style={{ color: '#dc2626' }}>Data Modeller</span>
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Disclaimer: AI-generated content and results may not be accurate. Please verify all critical information independently.
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default Footer; 