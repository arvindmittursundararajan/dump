// Documentation Rewriter JavaScript Application

class DocRewriter {
    constructor() {
        this.currentPageId = null;
        this.currentPageContent = '';
        this.analysisResults = [];
        this.isAnalyzing = false;
        this.isRewriting = false;
        this.loadingModalInstance = null;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadInitialData();
    }
    
    bindEvents() {
        // Generate sample pages
        document.getElementById('generatePagesBtn')?.addEventListener('click', () => {
            this.generateSamplePages();
        });
        
        // Cleanup pages
        document.getElementById('cleanupPagesBtn')?.addEventListener('click', () => {
            this.cleanupPages();
        });
        
        // Page selection
        document.addEventListener('click', (e) => {
            if (e.target.closest('.page-btn')) {
                const pageId = e.target.closest('.page-btn').dataset.pageId;
                this.selectPage(pageId);
            }
        });
        
        // Analysis
        document.getElementById('analyzeBtn')?.addEventListener('click', () => {
            this.analyzePage();
        });
        
        // Generate smart options
        document.getElementById('generateOptionsBtn')?.addEventListener('click', () => {
            this.generateSmartOptions();
        });
        
        // Preview content
        document.getElementById('previewBtn')?.addEventListener('click', () => {
            this.previewRewrite();
        });
        
        // Save version
        document.getElementById('saveVersionBtn')?.addEventListener('click', () => {
            this.saveNewVersion();
        });
        
        // Form changes
        document.querySelectorAll('#rewritingOptions input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateRewriteButtonState();
            });
        });
        
        // Version management - both sidebar and navbar
        document.getElementById('loadVersionBtn')?.addEventListener('click', () => {
            this.loadSelectedVersion();
        });
        
        document.getElementById('navLoadVersionBtn')?.addEventListener('click', () => {
            this.loadSelectedVersion();
        });
        
        document.getElementById('navDeleteVersionBtn')?.addEventListener('click', () => {
            this.deleteSelectedVersion();
        });
        
        document.getElementById('updateConfluenceBtn')?.addEventListener('click', () => {
            this.updateConfluenceWithCurrentVersion();
        });
        
        document.getElementById('versionSelect')?.addEventListener('change', () => {
            this.updateVersionButtonState();
        });
        
        document.getElementById('navVersionSelect')?.addEventListener('change', () => {
            this.updateVersionButtonState();
        });
    }
    
    loadInitialData() {
        // Load pages from window.appData if available
        if (window.appData && window.appData.pages) {
            this.updatePagesList(window.appData.pages);
        }
    }
    
    async generateSamplePages() {
        this.showLoading();
        
        try {
            const response = await fetch('/generate_sample_pages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updatePagesList(data.pages);
                this.showAlert('success', data.message);
                
                // Add cleanup button if not present
                this.addCleanupButton();
            } else {
                this.showAlert('danger', data.error || 'Failed to generate sample pages');
            }
        } catch (error) {
            this.showAlert('danger', 'Error generating sample pages: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    async cleanupPages() {
        if (!confirm('Are you sure you want to delete all sample pages from Confluence?')) {
            return;
        }
        
        this.showLoading();
        
        try {
            const response = await fetch('/cleanup_pages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updatePagesList([]);
                this.clearArticleContent();
                this.clearAnalysisResults();
                this.showAlert('success', data.message);
                
                // Remove cleanup button
                document.getElementById('cleanupPagesBtn')?.remove();
            } else {
                this.showAlert('danger', data.error || 'Failed to cleanup pages');
            }
        } catch (error) {
            this.showAlert('danger', 'Error cleaning up pages: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    updatePagesList(pages) {
        const pagesList = document.getElementById('pagesList');
        
        if (pages.length === 0) {
            pagesList.innerHTML = `
                <div class="text-muted text-center py-4">
                    <i class="fas fa-folder-open fa-2x mb-2"></i>
                    <p class="mb-0">No pages available</p>
                    <small>Click "Generate Sample Pages" to get started</small>
                </div>
            `;
            return;
        }
        
        pagesList.innerHTML = pages.map(page => `
            <div class="page-item mb-2" data-page-id="${page.id}">
                <button class="btn btn-outline-dark w-100 text-start page-btn" data-page-id="${page.id}">
                    <i class="fas fa-file-text me-2"></i>
                    <span class="page-title">${page.title.length > 40 ? page.title.substring(0, 40) + '...' : page.title}</span>
                </button>
            </div>
        `).join('');
    }
    
    async selectPage(pageId) {
        // Update active state
        document.querySelectorAll('.page-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-page-id="${pageId}"]`)?.classList.add('active');
        
        this.currentPageId = pageId;
        this.showLoading();
        
        try {
            const response = await fetch(`/get_page/${pageId}`);
            const data = await response.json();
            
            if (data.success) {
                this.currentPageContent = data.page.content;
                this.displayArticleContent(data.page.title, data.page.content);
                this.enableAnalysisControls();
                this.clearAnalysisResults();
                
                // Always load the latest version when selecting a page
                await this.loadLatestVersion();
            } else {
                this.showAlert('danger', data.error || 'Failed to load page');
            }
        } catch (error) {
            this.showAlert('danger', 'Error loading page: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    displayArticleContent(title, content) {
        const articleContent = document.getElementById('articleContent');
        articleContent.innerHTML = `
            <div class="article-header mb-4">
                <h1 class="article-title">${this.escapeHtml(title)}</h1>
            </div>
            <div class="article-body">
                ${content}
            </div>
        `;
        
        // Force scrollbar to appear immediately by adding content height
        const contentArea = document.querySelector('.content-area');
        if (contentArea) {
            contentArea.style.overflowY = 'auto';
            contentArea.classList.add('show-scroll');
        }
        
        this.showNavbarVersionControls();
    }
    
    enableAnalysisControls() {
        const analyzeBtn = document.getElementById('analyzeBtn');
        const generateOptionsBtn = document.getElementById('generateOptionsBtn');
        
        if (analyzeBtn) {
            analyzeBtn.disabled = false;
        }
        if (generateOptionsBtn) {
            generateOptionsBtn.disabled = false;
        }
        
        this.updateRewriteButtonState();
        this.loadVersionsForPage();
        this.saveOriginalVersion();
    }
    
    async analyzePage() {
        if (!this.currentPageContent || this.isAnalyzing) return;
        
        this.isAnalyzing = true;
        const analyzeBtn = document.getElementById('analyzeBtn');
        const originalText = analyzeBtn.innerHTML;
        
        analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Analyzing...';
        analyzeBtn.disabled = true;
        
        try {
            const response = await fetch('/analyze_page', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    content: this.currentPageContent
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.analysisResults = data.analysis;
                this.displayAnalysisResults(data.analysis);
                this.highlightGapsInContent(data.analysis);
                this.showAlert('success', 'Documentation analysis completed');
            } else {
                this.showAlert('danger', data.error || 'Failed to analyze page');
            }
        } catch (error) {
            this.showAlert('danger', 'Error analyzing page: ' + error.message);
        } finally {
            this.isAnalyzing = false;
            analyzeBtn.innerHTML = originalText;
            analyzeBtn.disabled = false;
        }
    }
    
    displayAnalysisResults(results) {
        const analysisResults = document.getElementById('analysisResults');
        
        if (results.length === 0) {
            analysisResults.innerHTML = `
                <div class="text-center py-4">
                    <i class="fas fa-check-circle text-success mb-2" style="font-size: 1.5rem;"></i>
                    <p class="text-success mb-1" style="font-size: 0.9rem; font-weight: 500;">Good documentation</p>
                    <small class="text-muted">No major issues found</small>
                </div>
            `;
            return;
        }
        
        const typeConfig = {
            'clarity': { color: 'warning', icon: 'fas fa-lightbulb', label: 'Clarity' },
            'completeness': { color: 'danger', icon: 'fas fa-exclamation-triangle', label: 'Completeness' }, 
            'code_examples': { color: 'info', icon: 'fas fa-code', label: 'Code Examples' },
            'structure': { color: 'secondary', icon: 'fas fa-sitemap', label: 'Structure' },
            'terminology': { color: 'primary', icon: 'fas fa-book', label: 'Terminology' },
            'accessibility': { color: 'success', icon: 'fas fa-universal-access', label: 'Accessibility' }
        };
        
        let html = `
            <div class="border-bottom border-danger mb-3 pb-2">
                <h6 class="text-dark mb-0">
                    <i class="fas fa-search me-2 text-danger"></i>
                    Analysis Results (${results.length} items)
                </h6>
            </div>
        `;
        
        results.forEach((result, index) => {
            const config = typeConfig[result.type] || { color: 'secondary', icon: 'fas fa-info', label: 'Other' };
            const title = result.title || `${config.label} Issue`;
            
            html += `
                <div class="border rounded mb-2 p-3 bg-light" data-type="${result.type}">
                    <div class="d-flex align-items-start">
                        <i class="${config.icon} text-${config.color} me-2" style="font-size: 0.875rem; margin-top: 2px;"></i>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="text-dark" style="font-size: 0.875rem; font-weight: 500;">${this.escapeHtml(title)}</span>
                                <small class="text-muted">${config.label}</small>
                            </div>
                            <p class="text-muted mb-2" style="font-size: 0.8rem; line-height: 1.4;">${this.escapeHtml(result.description)}</p>
                            
                            ${result.problematic_text ? `
                            <div class="mb-2">
                                <small class="text-muted">Found text:</small>
                                <div class="bg-white p-2 rounded border" style="font-size: 0.75rem;">
                                    <code class="text-dark">${this.escapeHtml(result.problematic_text)}</code>
                                </div>
                            </div>
                            ` : ''}
                            
                            <div>
                                <small class="text-muted">Suggestion:</small>
                                <div class="bg-white p-2 rounded border" style="font-size: 0.8rem; line-height: 1.4;">
                                    ${result.suggestion || this.escapeHtml(result.suggestion)}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });
        
        analysisResults.innerHTML = html;
    }
    
    highlightGapsInContent(results) {
        const articleBody = document.querySelector('.article-body');
        if (!articleBody) return;
        
        let content = articleBody.innerHTML;
        
        results.forEach(result => {
            if (result.problematic_text && result.problematic_text.length > 10) {
                const regex = new RegExp(this.escapeRegex(result.problematic_text), 'gi');
                content = content.replace(regex, `<span class="highlight-gap" title="${this.escapeHtml(result.description)}">${result.problematic_text}</span>`);
            }
        });
        
        articleBody.innerHTML = content;
    }
    
    async generateSmartOptions() {
        if (!this.currentPageContent) return;
        
        const generateBtn = document.getElementById('generateOptionsBtn');
        const originalText = generateBtn.innerHTML;
        
        generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Generating...';
        generateBtn.disabled = true;
        
        try {
            const response = await fetch('/generate_rewriting_options', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    content: this.currentPageContent
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.updateRewritingOptions(data.options);
                this.showAlert('success', 'Smart rewriting options generated');
            } else {
                this.showAlert('danger', data.error || 'Failed to generate options');
            }
        } catch (error) {
            this.showAlert('danger', 'Error generating options: ' + error.message);
        } finally {
            generateBtn.innerHTML = originalText;
            generateBtn.disabled = false;
        }
    }
    
    updateRewritingOptions(options) {
        const container = document.getElementById('rewritingOptions');
        
        container.innerHTML = options.map(option => `
            <div class="form-check form-check-sm mb-1">
                <input class="form-check-input" type="checkbox" id="option_${option.id}" value="${option.id}">
                <label class="form-check-label small text-dark" for="option_${option.id}">
                    ${this.escapeHtml(option.label)}
                </label>
            </div>
        `).join('');
        
        // Re-bind checkbox events
        container.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateRewriteButtonState();
            });
        });
    }
    
    updateRewriteButtonState() {
        const previewBtn = document.getElementById('previewBtn');
        const hasSelection = document.querySelectorAll('#rewritingOptions input[type="checkbox"]:checked').length > 0;
        const hasContent = this.currentPageContent.length > 0;
        
        if (previewBtn) {
            previewBtn.disabled = !hasSelection || !hasContent || this.isRewriting;
        }
    }
    
    async previewRewrite() {
        if (!this.currentPageContent || this.isRewriting) return;
        
        const selectedOptions = Array.from(document.querySelectorAll('#rewritingOptions input[type="checkbox"]:checked'))
            .map(cb => cb.value);
        
        if (selectedOptions.length === 0) {
            this.showAlert('warning', 'Please select at least one improvement option');
            return;
        }
        
        this.isRewriting = true;
        const previewBtn = document.getElementById('previewBtn');
        const originalText = previewBtn.innerHTML;
        
        previewBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating Preview...';
        previewBtn.disabled = true;
        
        try {
            const tone = document.getElementById('toneSelect').value;
            const length = document.getElementById('lengthSelect').value;
            const customInstructions = document.getElementById('customInstructions').value;
            
            const response = await fetch('/rewrite_content', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: null, // Don't save to database or update Confluence during preview
                    content: this.currentPageContent,
                    selected_options: selectedOptions,
                    tone: tone,
                    length: length,
                    custom_instruction: customInstructions
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.previewedContent = this.cleanMarkdownFromContent(data.rewritten_content);
                this.displayPreview(this.previewedContent);
                this.showAlert('success', 'Preview generated successfully');
                
                // Show save button
                const saveBtn = document.getElementById('saveVersionBtn');
                if (saveBtn) {
                    saveBtn.style.display = 'block';
                    saveBtn.disabled = false;
                }
            } else {
                this.showAlert('danger', data.error || 'Failed to generate preview');
            }
        } catch (error) {
            this.showAlert('danger', 'Error generating preview: ' + error.message);
        } finally {
            this.isRewriting = false;
            previewBtn.innerHTML = originalText;
            previewBtn.disabled = false;
        }
    }
    
    async saveNewVersion() {
        if (!this.previewedContent || !this.currentPageId) return;
        
        this.showLoading();
        
        try {
            const selectedOptions = Array.from(document.querySelectorAll('#rewritingOptions input[type="checkbox"]:checked'))
                .map(cb => cb.value);
            const tone = document.getElementById('toneSelect').value;
            const length = document.getElementById('lengthSelect').value;
            const customInstructions = document.getElementById('customInstructions').value;
            
            // Save to database by calling the backend with the previewed content
            const response = await fetch('/save_new_version', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: this.currentPageId,
                    content: this.previewedContent,
                    title: `Enhanced ${document.querySelector('.article-title')?.textContent || 'Document'}`,
                    selected_options: selectedOptions,
                    tone: tone,
                    length: length,
                    custom_instruction: customInstructions
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.currentPageContent = this.previewedContent;
                this.displayRewrittenContent(this.previewedContent);
                this.showAlert('success', 'New version saved successfully');
                
                // Hide preview area and save button
                document.getElementById('previewArea').style.display = 'none';
                document.getElementById('saveVersionBtn').style.display = 'none';
                
                // Refresh versions list
                this.loadVersionsForPage();
                this.clearAnalysisResults();
            } else {
                this.showAlert('danger', data.error || 'Failed to save version');
            }
        } catch (error) {
            this.showAlert('danger', 'Error saving version: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    displayPreview(content) {
        // Display preview in main article area instead of below button
        const articleContent = document.getElementById('articleContent');
        if (articleContent) {
            articleContent.innerHTML = `
                <div class="alert alert-info mb-3">
                    <i class="fas fa-eye me-2"></i>
                    <strong>Preview Mode:</strong> This is a preview of the rewritten content
                </div>
                <div class="article-body">
                    ${this.cleanMarkdownFromContent(content)}
                </div>
            `;
            
            // Show save version button
            const saveVersionBtn = document.getElementById('saveVersionBtn');
            if (saveVersionBtn) {
                saveVersionBtn.style.display = 'inline-block';
            }
        }
    }
    
    cleanMarkdownFromContent(content) {
        // Remove markdown code blocks and other formatting
        return content
            .replace(/```html\s*/gi, '')
            .replace(/```\s*$/gm, '')
            .replace(/^\s*```\s*/gm, '')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .trim();
    }
    
    displayRewrittenContent(content) {
        const articleBody = document.querySelector('.article-body');
        if (articleBody) {
            articleBody.innerHTML = content;
            
            // Add a visual indicator that content was rewritten
            const indicator = document.createElement('div');
            indicator.className = 'alert alert-success mt-3';
            indicator.innerHTML = '<i class="fas fa-check-circle me-2"></i>Content successfully rewritten and updated in Confluence';
            articleBody.appendChild(indicator);
            
            // Remove indicator after 5 seconds
            setTimeout(() => {
                indicator.remove();
            }, 5000);
        }
    }
    
    clearArticleContent() {
        const articleContent = document.getElementById('articleContent');
        articleContent.innerHTML = `
            <div class="text-center py-5 text-muted">
                <i class="fas fa-file-alt fa-3x mb-3"></i>
                <h4>Select a Documentation Page</h4>
                <p>Choose a page from the sidebar to view and analyze its content</p>
            </div>
        `;
        
        this.currentPageId = null;
        this.currentPageContent = '';
        
        // Disable controls
        const analyzeBtn = document.getElementById('analyzeBtn');
        const generateOptionsBtn = document.getElementById('generateOptionsBtn');
        const rewriteBtn = document.getElementById('rewriteBtn');
        
        if (analyzeBtn) analyzeBtn.disabled = true;
        if (generateOptionsBtn) generateOptionsBtn.disabled = true;
        if (rewriteBtn) rewriteBtn.disabled = true;
    }
    
    clearAnalysisResults() {
        const analysisResults = document.getElementById('analysisResults');
        analysisResults.innerHTML = `
            <div class="text-center py-4 text-muted">
                <i class="fas fa-chart-line fa-2x mb-2"></i>
                <p class="mb-0">Click "Analyze Documentation" to identify gaps</p>
            </div>
        `;
        this.analysisResults = [];
    }
    
    addCleanupButton() {
        if (document.getElementById('cleanupPagesBtn')) return;
        
        const generateBtn = document.getElementById('generatePagesBtn');
        const cleanupBtn = document.createElement('button');
        cleanupBtn.id = 'cleanupPagesBtn';
        cleanupBtn.className = 'btn btn-outline-danger w-100 mb-3';
        cleanupBtn.innerHTML = '<i class="fas fa-trash me-2"></i>Cleanup Pages';
        
        cleanupBtn.addEventListener('click', () => {
            this.cleanupPages();
        });
        
        generateBtn.parentNode.insertBefore(cleanupBtn, generateBtn.nextSibling);
    }
    
    showLoading() {
        try {
            const loadingModal = document.getElementById('loadingModal');
            if (loadingModal) {
                // Clear any existing instance first
                this.forceHideLoading();
                
                // Create new instance
                this.loadingModalInstance = new bootstrap.Modal(loadingModal, {
                    backdrop: 'static',
                    keyboard: false
                });
                this.loadingModalInstance.show();
                
                // Auto-hide after 30 seconds as failsafe
                setTimeout(() => {
                    this.hideLoading();
                }, 30000);
            }
        } catch (error) {
            console.error('Error showing loading modal:', error);
        }
    }
    
    hideLoading() {
        try {
            if (this.loadingModalInstance) {
                this.loadingModalInstance.hide();
                this.loadingModalInstance = null;
            }
            this.forceHideLoading();
        } catch (error) {
            console.error('Error hiding loading modal:', error);
            this.forceHideLoading();
        }
    }
    
    forceHideLoading() {
        // Force cleanup of any modal state
        const loadingModal = document.getElementById('loadingModal');
        if (loadingModal) {
            loadingModal.classList.remove('show');
            loadingModal.style.display = 'none';
            loadingModal.setAttribute('aria-hidden', 'true');
        }
        
        // Remove backdrop
        const backdrops = document.querySelectorAll('.modal-backdrop');
        backdrops.forEach(backdrop => backdrop.remove());
        
        // Reset body state
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
    }
    
    showAlert(type, message) {
        const alertContainer = document.getElementById('alertContainer');
        const alertId = 'alert-' + Date.now();
        
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
                ${this.escapeHtml(message)}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        alertContainer.insertAdjacentHTML('beforeend', alertHtml);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            const alert = document.getElementById(alertId);
            if (alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        }, 5000);
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    showNavbarVersionControls() {
        const navControls = document.getElementById('navbarVersionControls');
        if (navControls) {
            navControls.style.display = 'flex';
            navControls.classList.add('show');
        }
    }

    hideNavbarVersionControls() {
        const navControls = document.getElementById('navbarVersionControls');
        if (navControls) {
            navControls.style.display = 'none';
            navControls.classList.remove('show');
        }
    }
    
    // Version Management Functions
    async saveOriginalVersion() {
        if (!this.currentPageId || !this.currentPageContent) return;
        
        const pages = window.appData?.pages || [];
        const currentPage = pages.find(p => p.id === this.currentPageId);
        
        if (!currentPage) return;
        
        try {
            await fetch('/save_original_version', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: this.currentPageId,
                    title: currentPage.title,
                    content: this.currentPageContent,
                    space_key: currentPage.space_key || 'UNKNOWN'
                })
            });
        } catch (error) {
            console.log('Note: Could not save original version:', error.message);
        }
    }
    
    async loadVersionsForPage() {
        if (!this.currentPageId) return;
        
        try {
            const response = await fetch(`/get_versions/${this.currentPageId}`);
            const data = await response.json();
            
            if (data.success) {
                this.updateVersionDropdown(data.versions);
            }
        } catch (error) {
            console.log('Could not load versions:', error.message);
        }
    }
    
    async loadLatestVersion() {
        if (!this.currentPageId) return;
        
        try {
            const response = await fetch(`/get_versions/${this.currentPageId}`);
            const data = await response.json();
            
            if (data.success && data.versions.length > 0) {
                // Find the version with the highest version_number
                const latestVersion = data.versions.reduce((latest, current) => 
                    current.version_number > latest.version_number ? current : latest
                );
                
                if (latestVersion) {
                    // Load the latest version content
                    const loadResponse = await fetch('/load_version', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            page_id: this.currentPageId,
                            version_number: latestVersion.version_number
                        })
                    });
                    
                    const loadData = await loadResponse.json();
                    
                    if (loadData.success) {
                        this.currentPageContent = loadData.version.content;
                        this.displayArticleContent(loadData.version.title, loadData.version.content);
                        
                        // Load saved custom instructions if they exist
                        if (loadData.version.custom_instructions) {
                            const customInstructionsInput = document.getElementById('customInstructions');
                            if (customInstructionsInput) {
                                customInstructionsInput.value = loadData.version.custom_instructions;
                            }
                        } else {
                            // Clear custom instructions if none saved
                            const customInstructionsInput = document.getElementById('customInstructions');
                            if (customInstructionsInput) {
                                customInstructionsInput.value = '';
                            }
                        }
                        
                        // Update the dropdown to reflect current version
                        this.updateVersionDropdown(data.versions);
                        
                        // Set the dropdown to show the loaded version
                        const navVersionSelect = document.getElementById('navVersionSelect');
                        if (navVersionSelect) {
                            navVersionSelect.value = latestVersion.version_number;
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Error loading latest version:', error);
        }
    }
    
    updateVersionDropdown(versions) {
        const versionSelects = ['versionSelect', 'navVersionSelect'];
        const updateBtn = document.getElementById('updateConfluenceBtn');
        
        versionSelects.forEach(selectId => {
            const versionSelect = document.getElementById(selectId);
            if (!versionSelect) return;
            
            versionSelect.innerHTML = '<option value="">Select version...</option>';
            
            versions.forEach(version => {
                const option = document.createElement('option');
                option.value = version.version_number;
                option.textContent = `v${version.version_number} - ${version.title} (${version.created_at})${version.is_current ? ' [Current]' : ''}`;
                if (version.is_current) {
                    option.selected = true;
                }
                versionSelect.appendChild(option);
            });
            
            versionSelect.disabled = versions.length === 0;
        });
        
        if (updateBtn) {
            updateBtn.disabled = versions.length === 0;
        }
        
        this.updateVersionButtonState();
    }
    
    updateVersionButtonState() {
        const versionSelects = ['versionSelect', 'navVersionSelect'];
        const loadBtns = ['loadVersionBtn', 'navLoadVersionBtn'];
        
        versionSelects.forEach((selectId, index) => {
            const versionSelect = document.getElementById(selectId);
            const loadBtn = document.getElementById(loadBtns[index]);
            
            if (versionSelect && loadBtn) {
                loadBtn.disabled = !versionSelect.value;
                
                // Sync selections between both dropdowns
                if (versionSelect.value && selectId === 'versionSelect') {
                    const navSelect = document.getElementById('navVersionSelect');
                    if (navSelect) navSelect.value = versionSelect.value;
                } else if (versionSelect.value && selectId === 'navVersionSelect') {
                    const sidebarSelect = document.getElementById('versionSelect');
                    if (sidebarSelect) sidebarSelect.value = versionSelect.value;
                }
            }
        });
        
        // Handle delete button state
        const navDeleteBtn = document.getElementById('navDeleteVersionBtn');
        const navVersionSelect = document.getElementById('navVersionSelect');
        const selectedVersion = navVersionSelect?.value;
        
        if (navDeleteBtn) {
            navDeleteBtn.disabled = !selectedVersion || selectedVersion == 0;
        }
    }
    
    async deleteSelectedVersion() {
        const navVersionSelect = document.getElementById('navVersionSelect');
        const versionSelect = document.getElementById('versionSelect');
        
        const versionValue = navVersionSelect?.value || versionSelect?.value;
        
        if (!versionValue || !this.currentPageId) return;
        
        if (versionValue == 0) {
            this.showAlert('warning', 'Cannot delete the original version (v0)');
            return;
        }
        
        // Confirm deletion
        if (!confirm(`Are you sure you want to delete version ${versionValue}? This action cannot be undone.`)) {
            return;
        }
        
        this.showLoading();
        
        try {
            const response = await fetch('/delete_version', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: this.currentPageId,
                    version_number: parseInt(versionValue)
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('success', data.message);
                
                // Reload versions list
                await this.loadVersionsForPage();
                
                // Load the latest version automatically
                await this.loadLatestVersion();
            } else {
                this.showAlert('danger', data.error || 'Failed to delete version');
            }
        } catch (error) {
            this.showAlert('danger', 'Error deleting version: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    async loadSelectedVersion() {
        // Get version from either navbar or sidebar select
        const navVersionSelect = document.getElementById('navVersionSelect');
        const sidebarVersionSelect = document.getElementById('versionSelect');
        
        const versionValue = navVersionSelect?.value || sidebarVersionSelect?.value;
        
        if (!versionValue || !this.currentPageId) return;
        
        this.showLoading();
        
        try {
            const response = await fetch('/load_version', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: this.currentPageId,
                    version_number: parseInt(versionValue)
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.currentPageContent = data.version.content;
                this.displayArticleContent(data.version.title, data.version.content);
                this.showAlert('success', `Loaded version ${data.version.version_number}`);
                this.clearAnalysisResults();
                
                // Load saved custom instructions if they exist
                if (data.version.custom_instructions) {
                    const customInstructionsInput = document.getElementById('customInstructions');
                    if (customInstructionsInput) {
                        customInstructionsInput.value = data.version.custom_instructions;
                    }
                } else {
                    // Clear custom instructions if none saved
                    const customInstructionsInput = document.getElementById('customInstructions');
                    if (customInstructionsInput) {
                        customInstructionsInput.value = '';
                    }
                }
                
                // Update the dropdown to reflect current version
                this.loadVersionsForPage();
            } else {
                this.showAlert('danger', data.error || 'Failed to load version');
            }
        } catch (error) {
            this.showAlert('danger', 'Error loading version: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
    
    async updateConfluenceWithCurrentVersion() {
        if (!this.currentPageId) return;
        
        const confirmed = confirm(
            'This will update the Confluence page with the current version. ' +
            'The existing Confluence content will be backed up first. Continue?'
        );
        
        if (!confirmed) return;
        
        this.showLoading();
        
        try {
            const response = await fetch('/update_confluence', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    page_id: this.currentPageId
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('success', 'Confluence page updated successfully!');
                this.loadVersionsForPage(); // Refresh versions list
            } else {
                this.showAlert('danger', data.error || 'Failed to update Confluence');
            }
        } catch (error) {
            this.showAlert('danger', 'Error updating Confluence: ' + error.message);
        } finally {
            this.hideLoading();
        }
    }
}

// Global error handler to ensure loading modal is hidden
window.addEventListener('error', (event) => {
    console.error('Global error caught:', event.error);
    // Force hide loading modal using the class method if available
    if (window.docRewriterInstance) {
        window.docRewriterInstance.forceHideLoading();
    } else {
        // Fallback cleanup
        const loadingModal = document.getElementById('loadingModal');
        if (loadingModal) {
            loadingModal.classList.remove('show');
            loadingModal.style.display = 'none';
        }
        const backdrops = document.querySelectorAll('.modal-backdrop');
        backdrops.forEach(backdrop => backdrop.remove());
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';
    }
});

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.docRewriterInstance = new DocRewriter();
});
