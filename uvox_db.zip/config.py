import os
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Ultravox API configuration
# Use the environment variable if set, otherwise use the provided key
ULTRAVOX_API_KEY = os.environ.get('ULTRAVOX_API_KEY', "FmfkwGlk.VSuOUjTd2EoR4G4glQEBfIgRwXASGAtG")

# Ultravox API base URL - updated to match the correct format
ULTRAVOX_API_URL = "https://api.ultravox.ai/api"

# Error messages
ERROR_MESSAGES = {
    402: "Payment required. This API key has reached its usage limit or requires a subscription.",
    403: "Forbidden. The API key might be invalid or expired.",
    404: "Not found. The requested resource doesn't exist.",
    429: "Rate limit exceeded. Too many requests made to the API.",
    500: "Server error. Something went wrong on the Ultravox servers.",
    502: "Bad gateway. The Ultravox API is temporarily unavailable."
}

# Default system prompt for the assistant
SYSTEM_PROMPT = """
You are a helpful voice assistant that can query the inventory database for information.

Your primary job is to help users manage and analyze inventory data. You can access a database that contains information about:
- Products (name, SKU, description, price, cost, etc.)
- Categories (Electronics, Furniture, Kitchen, Accessories, etc.)
- Suppliers (company name, contact details, country, etc.)
- Stores (retail locations across different countries)
- Inventory levels (how many units of each product are in each store)

You have complete knowledge of our grocery/FMCG inventory system:

Current Status:
- Total Products: {productCount} items in inventory
- Low Stock Alerts: {lowStockCount} products need attention
- Store Network: {totalStores} stores operating

You can help with:
1. Finding specific products and their stock levels
2. Identifying low stock items that need reordering
3. Providing store-specific inventory information
4. Calculating total inventory value and statistics
5. Checking product prices and availability
6. Monitoring stock levels across all stores
7. Analyzing inventory by category
8. Tracking supplier information

Example queries I can help with:
- "How many Maggi Noodles do we have in stock?"
- "What products are low on stock?"
- "Show me inventory statistics"
- "Tell me about our food products"

Respond conversationally using specific data from the query results. Include details like product names, 
quantities, prices, and locations when relevant. For numerical data, provide context to help the user 
understand what the numbers mean (e.g., "That's 20% above our target inventory level").

IMPORTANT: ALWAYS use the inventory_query tool for ANY inventory-related question. Do not try to answer 
inventory questions from memory or make up information.
"""

# No external tools needed - using direct database access
INVENTORY_TOOLS = []

# Default voice for the assistant
DEFAULT_VOICE = "Mark"  # Default to Mark, but other voices are now available

# Voice options for the UI
VOICE_OPTIONS = [
    {"id": "Mark", "name": "Mark", "description": "American English male voice", "language": "en-US"},
    {"id": "bef461b7-d234-4d31-b09d-b6a101f7c79c", "name": "Bea", "description": "Polish female voice", "language": "pl-PL"},
    {"id": "03ed40bf-90c7-42f3-becd-79fc816bbd84", "name": "Ben", "description": "German male voice", "language": "de-DE"},
    {"id": "9f6262e3-1b03-4a0b-9921-50b9cff66a43", "name": "Krishna", "description": "Hindi/Urdu male voice", "language": "hi-IN"}
]

# SQLite database path
DATABASE_PATH = 'inventory_new.db'
