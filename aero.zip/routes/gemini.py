from flask import Blueprint, request, jsonify
import google.generativeai as genai
import os
from datetime import datetime

gemini_bp = Blueprint('gemini', __name__)

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
model = genai.GenerativeModel('gemini-pro')

@gemini_bp.route('/api/gemini/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'No message provided'}), 400

        user_message = data['message']
        context = data.get('context', {})

        # Create a prompt with context
        prompt = f"""
        Context: User is on page {context.get('page', 'unknown')} at {context.get('timestamp', datetime.now().isoformat())}
        
        User message: {user_message}
        
        Please provide a helpful response that is:
        1. Concise and clear
        2. Relevant to airline operations and optimization
        3. Professional and informative
        """

        # Generate response
        response = model.generate_content(prompt)
        
        return jsonify({
            'response': response.text,
            'timestamp': datetime.now().isoformat()
        })

    except Exception as e:
        print(f"Error in Gemini chat: {str(e)}")
        return jsonify({'error': 'Failed to process chat request'}), 500 