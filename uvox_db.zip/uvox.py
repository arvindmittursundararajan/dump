import os
import logging
import requests
import json
from flask import Flask, render_template, jsonify, request
from config import ULTRAVOX_API_KEY, ULTRAVOX_API_URL, DEFAULT_VOICE, ERROR_MESSAGES, DATABASE_PATH
import uvox_db as db

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "ultravox-voice-chat-secret")

# Create necessary folders if they don't exist
os.makedirs('static', exist_ok=True)
os.makedirs('templates', exist_ok=True)

def ultravox_request(method, path, **kwargs):
    """
    Helper function to make requests to the Ultravox API
    """
    if not path.startswith('/'):
        path = '/' + path
    
    url = ULTRAVOX_API_URL + path
    headers = {"X-API-Key": ULTRAVOX_API_KEY}
    
    if 'headers' in kwargs:
        kwargs['headers'].update(headers)
    else:
        kwargs['headers'] = headers
    
    # Disable SSL certificate verification
    kwargs['verify'] = False
    
    try:
        logger.debug(f"Making {method} request to {url}")
        response = requests.request(method, url, **kwargs)
        
        logger.debug(f"Response status: {response.status_code}")
        
        if response.status_code >= 400:
            logger.error(f"API error response: {response.text}")
        
        return response
    except requests.exceptions.RequestException as e:
        logger.error(f"API request error: {e}")
        return None

def gather_database_context():
    """Gather all database information using simple SELECT * queries to show complete raw data"""
    context = []
    
    try:
        tables = {
            'PRODUCT': db.get_products(),
            'CATEGORY': db.get_categories(),
            'CUSTOMER': db.get_customers(),
            'SUPPLIER': db.get_suppliers(),
            'STORE': db.get_stores()
        }
        
        for table_name, data in tables.items():
            if data:
                context.append(f"\n{table_name} TABLE RAW DATA:")
                for row in data:
                    row_dict = dict(row)
                    field_data = []
                    for key, value in row_dict.items():
                        field_data.append(f"{key}: {value}")
                    context.append(" | ".join(field_data))
                context.append("-" * 80)
                
    except Exception as e:
        logger.error(f"Error gathering database context: {e}")
        context.append("Error retrieving complete database data")
    
    return "\n".join(context)

@app.route('/')
def index():
    """Main page of the application"""
    from config import VOICE_OPTIONS
    return render_template('uvox.html', voice_options=VOICE_OPTIONS)

@app.route('/start_call', methods=['POST'])
def start_call():
    """Start a new voice call with Ultravox API and connect it to our database"""
    try:
        if not ULTRAVOX_API_KEY:
            return jsonify({
                "error": "Ultravox API key is not configured. Please set the ULTRAVOX_API_KEY environment variable."
            }), 401
        
        data = request.json or {}
        selected_voice = data.get('voice', DEFAULT_VOICE)
        from config import VOICE_OPTIONS
        valid_voice_ids = [voice['id'] for voice in VOICE_OPTIONS]
        if selected_voice not in valid_voice_ids:
            selected_voice = DEFAULT_VOICE
        logger.debug(f"Using voice: {selected_voice}")
        
        # Get table counts
        product_count = len(db.get_products())
        category_count = len(db.get_categories())
        customer_count = len(db.get_customers())
        supplier_count = len(db.get_suppliers())
        store_count = len(db.get_stores())

        # Get database context
        database_context = gather_database_context()

        # Format the system prompt
        base_prompt = f"""
You have direct access to complete raw data from these database tables using SELECT * queries:
- Products ({product_count} total items)
- Categories ({category_count} total items)
- Customers ({customer_count} total records)
- Suppliers ({supplier_count} total records)
- Stores ({store_count} total locations)

The system uses simple SELECT * queries to retrieve all raw data from these tables:

1. PRODUCT table:
   - id: unique product identifier
   - name: product name
   - sku: stock keeping unit code
   - category: product category
   - quantity: current stock quantity
   - price: selling price
   - cost_price: purchase cost
   - supplier_id: supplier reference
   - reorder_level: minimum stock level
   - last_updated: last update timestamp

2. CATEGORY table:
   - id: unique category identifier
   - name: category name
   - description: category description
   - created_at: creation timestamp
   - updated_at: last update timestamp

3. CUSTOMER table:
   - id: unique customer identifier
   - name: customer name
   - email: customer email
   - phone: contact number
   - address: customer address
   - is_active: active status
   - created_at: creation timestamp
   - updated_at: last update timestamp

4. SUPPLIER table:
   - id: unique supplier identifier
   - name: supplier name
   - contact_person: contact person name
   - email: supplier email
   - phone: contact number
   - address: supplier address
   - is_active: active status
   - created_at: creation timestamp
   - updated_at: last update timestamp

5. STORE table:
   - id: unique store identifier
   - country_code: 2-letter country code
   - country_name: full country name
   - store_name: name of the store
   - currency_symbol: local currency symbol
   - is_active: active status

For all queries, I will include all relevant fields from these tables."""
        
        formatted_prompt = base_prompt + "\n\nDetailed Inventory Information:\n" + database_context

        # Set the languageHint for speech recognition
        language_hint = None
        for voice in VOICE_OPTIONS:
            if voice['id'] == selected_voice:
                language_hint = voice.get('language', 'en-US')[:16]
                break

        call_data = {
            "systemPrompt": formatted_prompt,
            "voice": selected_voice,
            "initialState": {
                "databaseConnection": True,
                "tables": {
                    "products": product_count,
                    "categories": category_count,
                    "customers": customer_count,
                    "suppliers": supplier_count,
                    "stores": store_count
                }
            }
        }
        
        if language_hint:
            call_data["languageHint"] = language_hint
        
        logger.debug(f"Starting call with data: {json.dumps(call_data)}")
        response = ultravox_request("POST", "/calls", json=call_data)
        
        if response and response.status_code == 201:
            call_details = response.json()
            logger.debug(f"Call created successfully: {call_details}")
            return jsonify(call_details)
        else:
            if response:
                status_code = response.status_code
                friendly_error = ERROR_MESSAGES.get(status_code, f"Unknown error (status code: {status_code})") 
                
                try:
                    response_json = response.json()
                    api_detail = response_json.get('detail', '')
                except Exception:
                    api_detail = response.text if hasattr(response, 'text') else ''
                
                error_message = f"API Error: {friendly_error}"
                if api_detail:
                    error_message += f" - {api_detail}"
                
                logger.error(f"API error: {status_code} - {error_message}")
                
                if status_code == 402:
                    error_msg = "API limit reached. This Ultravox API key has reached its usage limit or requires a subscription."
                    logger.error(f"API limit error: {api_detail}")
                    return jsonify({
                        "error": error_msg,
                        "detail": api_detail,
                        "status": "payment_required"
                    }), 402
                
                return jsonify({"error": error_message}), status_code
            else:
                error_message = "Failed to connect to Ultravox API. Please check your connection."
                logger.error(error_message)
                return jsonify({"error": error_message}), 500
    
    except Exception as e:
        logger.exception("Error starting call")
        return jsonify({"error": str(e)}), 500

@app.route('/api/tools/inventory_query', methods=['POST'])
def tool_inventory_query():
    """Handle inventory query tool calls from Ultravox"""
    try:
        data = request.json
        logger.debug(f"Received tool call: {data}")
        
        if not data:
            return jsonify({"error": "Missing request data"}), 400
        
        if 'arguments' in data:
            arguments = data['arguments']
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except:
                    logger.warning(f"Failed to parse arguments as JSON: {arguments}")
                    arguments = {"query": arguments}
            query_text = arguments.get('query', '')
        elif 'query' in data:
            query_text = data['query']
        else:
            return jsonify({"error": "Missing query parameter"}), 400
        
        if not query_text:
            return jsonify({"error": "Empty query parameter"}), 400
            
        logger.debug(f"Processing inventory query: {query_text}")
        
        response = db.process_inventory_query(query_text)
        return jsonify(response)
    
    except Exception as e:
        error_message = f"Error processing inventory query: {str(e)}"
        logger.exception(error_message)
        return jsonify({
            "error": error_message,
            "found": False,
            "message": "Sorry, there was an error processing your query."
        }), 500
