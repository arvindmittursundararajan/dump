import os
import json
import datetime
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, g, abort
from werkzeug.middleware.proxy_fix import ProxyFix
import databricks_api
import gemini_client
from config import ANALYSIS_TYPES

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "adw_workbench_secret")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialize database
def get_db():
    """Connect to the application's SQLite database."""
    if 'db' not in g:
        g.db = sqlite3.connect(
            databricks_api.DATABASE_PATH,
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    """Close the database connection at the end of the request."""
    db = g.pop('db', None)
    if db is not None:
        db.close()

app.teardown_appcontext(close_db)

# Initialize database schema
def init_db():
    """Initialize the database schema."""
    databricks_api.init_db()
    
# Initialize DB at startup
with app.app_context():
    init_db()

@app.before_request
def log_request_info():
    print(f"\n[Flask] {request.method} {request.path} Headers: {dict(request.headers)}")
    if request.is_json:
        print(f"[Flask] JSON body: {request.get_json(silent=True)}")
    else:
        print(f"[Flask] Form body: {request.form}")

# Routes
@app.route('/')
def index():
    """Home page - show schema selection UI."""
    # Fetch catalogs from Databricks
    catalogs = databricks_api.get_catalogs()
    
    return render_template('index.html', 
                          catalogs=catalogs, 
                          analysis_types=ANALYSIS_TYPES)

@app.route('/get_schemas/<catalog_name>')
def get_schemas(catalog_name):
    """API endpoint to get schemas for a selected catalog."""
    try:
        schemas = databricks_api.get_schemas(catalog_name)
        return jsonify(schemas)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_tables/<catalog_name>/<schema_name>')
def get_tables(catalog_name, schema_name):
    """API endpoint to get tables for a selected schema."""
    try:
        tables = databricks_api.get_tables(catalog_name, schema_name)
        return jsonify(tables)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_columns/<catalog_name>/<schema_name>/<table_name>')
def get_columns(catalog_name, schema_name, table_name):
    """API endpoint to get columns for a selected table."""
    try:
        columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
        return jsonify(columns)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/analysis', methods=['POST'])
def analyze():
    """Run analysis on selected tables."""
    try:
        # Check if this is an AJAX request with JSON
        if request.is_json:
            data = request.get_json()
            selected_tables = data.get('selected_tables', [])
            analysis_type = data.get('analysis_type', 'general')
            sql_query = data.get('sql_query', '')
        else:
            selected_tables = request.form.get('selected_tables', '')
            analysis_type = request.form.get('analysis_type', 'general')
            sql_query = request.form.get('sql_query', '')
            try:
                selected_tables = json.loads(selected_tables)
            except Exception:
                selected_tables = []

        # If no tables selected, return error
        if not selected_tables or len(selected_tables) == 0:
            return jsonify({"success": False, "error": "Please select at least one table for analysis."}), 400

        # Build schema metadata for Gemini prompt
        schema_metadata = {}
        table_names = []
        for t in selected_tables:
            if isinstance(t, dict):
                if 'catalog' in t and 'schema' in t and 'name' in t:
                    catalog_name = t['catalog']
                    schema_name = t['schema']
                    table_name = t['name']
                    table_names.append(f"{catalog_name}.{schema_name}.{table_name}")
                elif 'fullName' in t:
                    parts = t['fullName'].split('.')
                    if len(parts) == 3:
                        catalog_name, schema_name, table_name = parts
                        table_names.append(t['fullName'])
                    else:
                        continue
                elif 'full_name' in t:
                    parts = t['full_name'].split('.')
                    if len(parts) == 3:
                        catalog_name, schema_name, table_name = parts
                        table_names.append(t['full_name'])
                    else:
                        continue
                else:
                    continue
            else:
                continue
            # Get columns and details for this table
            columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
            details = databricks_api.get_table_details(catalog_name, schema_name, table_name)
            schema_metadata[f"{catalog_name}.{schema_name}.{table_name}"] = {
                "columns": columns,
                "details": details
            }
        # Generate prompt and call Gemini
        prompt = gemini_client.create_analysis_prompt(schema_metadata, analysis_type, sql_query)
        print("\n--- GEMINI PROMPT SENT FROM FLASK ENDPOINT ---\n")
        print(prompt)
        print("\n--- END GEMINI PROMPT ---\n")
        try:
            analysis_result = gemini_client.generate_analysis(prompt)
        except Exception as e:
            return jsonify({"success": False, "error": f"Gemini API error: {str(e)}"}), 500
        metrics = {}  # Optionally fill with real metrics if needed
        return jsonify({
            "success": True,
            "analysis_id": 1,
            "analysis_result": analysis_result,
            "tables_analyzed": ", ".join(table_names),
            "metrics": metrics
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/history')
def history():
    """Show analysis history."""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute(
        """SELECT id, analysis_type, tables_analyzed, sql_query, created_at 
        FROM analysis_history 
        ORDER BY created_at DESC"""
    )
    
    history_items = cursor.fetchall()
    
    return render_template('history.html', history=history_items)

@app.route('/history/<int:analysis_id>', methods=['GET', 'POST'])
def view_analysis(analysis_id):
    """View a saved analysis."""
    db = get_db()
    cursor = db.cursor()
    
    # If POST, it means we're re-running the analysis with a new analysis type
    if request.method == 'POST':
        new_analysis_type = request.form.get('analysis_type')
        
        # Get the existing analysis to reuse tables and SQL
        cursor.execute(
            "SELECT tables_analyzed, sql_query FROM analysis_history WHERE id = ?",
            (analysis_id,)
        )
        existing = cursor.fetchone()
        
        if not existing:
            flash("Analysis not found", "error")
            return redirect(url_for('history'))
            
        tables_string = existing['tables_analyzed']
        sql_query = existing['sql_query']
        
        # Parse tables into the format needed for reanalysis
        tables_list = []
        for table_str in tables_string.split(", "):
            parts = table_str.split(".")
            if len(parts) == 3:
                tables_list.append({
                    "catalog": parts[0],
                    "schema": parts[1],
                    "name": parts[2]
                })
        
        # Rebuild schema metadata
        schema_metadata = {}
        metrics = {}
        
        for table in tables_list:
            catalog_name = table['catalog']
            schema_name = table['schema']
            table_name = table['name']
            
            # Get columns for this table
            columns = databricks_api.get_columns(catalog_name, schema_name, table_name)
            full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
            
            # Get table details
            table_details = databricks_api.get_table_details(catalog_name, schema_name, table_name)
            
            # Get query history for this table
            table_queries = databricks_api.get_query_history(table_name, limit=5)
            
            # Calculate average query duration
            avg_duration = 0
            if table_queries:
                durations = [q['duration_ms'] for q in table_queries]
                avg_duration = sum(durations) / len(durations) if durations else 0
            
            # Store schema metadata
            schema_metadata[full_table_name] = {
                "columns": columns,
                "details": table_details
            }
            
            # Store metrics
            metrics[full_table_name] = {
                "table_size_bytes": table_details.get("size_bytes", 0),
                "file_count": table_details.get("file_count", 0),
                "format": table_details.get("format", "unknown"),
                "query_duration_ms": avg_duration,
                "queries": table_queries
            }
        
        # Generate new analysis using the AI model
        prompt = gemini_client.create_analysis_prompt(schema_metadata, new_analysis_type, sql_query)
        analysis_result = gemini_client.generate_analysis(prompt)
        
        # Save as a new analysis in the DB
        cursor.execute(
            """INSERT INTO analysis_history 
            (analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at) 
            VALUES (?, ?, ?, ?, ?, ?)""",
            (
                new_analysis_type, 
                tables_string,
                sql_query,
                analysis_result,
                json.dumps(metrics),
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
        )
        db.commit()
        new_analysis_id = cursor.lastrowid
        
        return redirect(url_for('view_analysis', analysis_id=new_analysis_id))
    
    # GET request - show the analysis
    cursor.execute(
        """SELECT id, analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at 
        FROM analysis_history 
        WHERE id = ?""",
        (analysis_id,)
    )
    
    analysis = cursor.fetchone()
    
    if not analysis:
        abort(404)
        
    metrics = json.loads(analysis['metrics']) if analysis['metrics'] else {}
    
    # Already have types as a dictionary
    
    return render_template('analysis.html',
                          analysis_id=analysis_id,
                          analysis_result=analysis['analysis_result'],
                          analysis_type=analysis['analysis_type'],
                          tables_analyzed=analysis['tables_analyzed'],
                          analysis_date=analysis['created_at'],
                          metrics=metrics,
                          sql_query=analysis['sql_query'],
                          from_history=True,
                          analysis_types=ANALYSIS_TYPES)

@app.route('/history/delete/<int:analysis_id>', methods=['POST'])
def delete_analysis(analysis_id):
    """Delete an analysis from history."""
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM analysis_history WHERE id = ?", (analysis_id,))
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.errorhandler(404)
def handle_404(e):
    if request.path == '/analysis' and (request.is_json or request.headers.get('Accept') == 'application/json'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def handle_500(e):
    if request.path == '/analysis' and (request.is_json or request.headers.get('Accept') == 'application/json'):
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    return render_template('500.html'), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)