/**
 * AeroOptima.ai - Optimizer Module
 * Handles optimization plan creation, execution, and management
 */

// Keep track of current optimization plans
let currentPlans = [];
let selectedPlanId = null;

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Load optimization plans
    loadOptimizationPlans();
    
    // Setup plan creation form
    setupPlanForm();
    
    // Initialize constraint builder
    initConstraintBuilder();
});

/**
 * Load optimization plans from the API
 */
function loadOptimizationPlans() {
    const plansContainer = document.getElementById('plans-container');
    if (!plansContainer) return;
    
    // Show loading state
    plansContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading optimization plans...</p>';
    
    // Fetch plans
    fetch('/api/plans')
        .then(response => response.json())
        .then(data => {
            // Store current plans
            currentPlans = data;
            
            if (data.length === 0) {
                plansContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No optimization plans yet. Create your first plan to get started.
                    </div>
                `;
                return;
            }
            
            // Create HTML
            let html = '';
            
            // Add plans
            data.forEach(plan => {
                const statusBadge = getStatusBadge(plan.status);
                const scoreHtml = plan.score !== null ? `
                    <div class="mt-2">
                        <small class="text-muted">Score: </small>
                        <div class="score-indicator">
                            <div class="score-value bg-${getScoreColor(plan.score)}" style="width: ${plan.score * 100}%"></div>
                        </div>
                    </div>
                ` : '';
                
                html += `
                    <div class="card plan-card mb-3 ${selectedPlanId === plan.id ? 'active' : ''}"
                         data-id="${plan.id}"
                         data-scenario="${plan.scenario}"
                         data-status="${plan.status}"
                         data-score="${plan.score || 0}"
                         onclick="selectPlan(${plan.id})">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <h5 class="card-title">${plan.name}</h5>
                                <span class="badge ${statusBadge}">${plan.status}</span>
                            </div>
                            <p class="card-text small">${truncateText(plan.description || plan.scenario, 100)}</p>
                            ${scoreHtml}
                            <div class="mt-2 small text-muted">
                                Created: ${formatDate(plan.created_at)} • Version: ${plan.version}
                            </div>
                        </div>
                    </div>
                `;
            });
            
            // Update container
            plansContainer.innerHTML = html;
            
            // Select first plan if none selected
            if (!selectedPlanId && data.length > 0) {
                selectPlan(data[0].id);
            }
        })
        .catch(error => {
            plansContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading optimization plans: ${error.message}
                </div>
            `;
            console.error('Failed to load optimization plans:', error);
        });
}

/**
 * Setup plan creation form
 */
function setupPlanForm() {
    const planForm = document.getElementById('plan-form');
    
    if (planForm) {
        planForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('plan-name').value;
            const description = document.getElementById('plan-description').value;
            const scenario = document.getElementById('plan-scenario').value;
            
            // Get constraints from builder
            const constraints = getConstraints();
            
            // Get weights
            const weights = {
                cost: parseFloat(document.getElementById('weight-cost').value) || 0.25,
                on_time_performance: parseFloat(document.getElementById('weight-otp').value) || 0.25,
                crew_legality: parseFloat(document.getElementById('weight-crew').value) || 0.2,
                passenger_impact: parseFloat(document.getElementById('weight-pax').value) || 0.15,
                maintenance_compliance: parseFloat(document.getElementById('weight-maintenance').value) || 0.15
            };
            
            // Validate
            if (!name || !scenario) {
                showToast('Name and scenario are required', 'warning');
                return;
            }
            
            // Create plan data
            const planData = {
                name,
                description,
                scenario,
                constraints,
                objective_weights: weights
            };
            
            // Show loading state
            const submitBtn = planForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating...';
            
            // Send to API
            fetch('/api/plans', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(planData)
            })
            .then(response => response.json())
            .then(data => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Show success message
                showToast('Plan created successfully', 'success');
                
                // Reset form
                planForm.reset();
                
                // Close modal if open
                const modal = bootstrap.Modal.getInstance(document.getElementById('new-plan-modal'));
                if (modal) {
                    modal.hide();
                }
                
                // Reload plans and select the new one
                loadOptimizationPlans();
                setTimeout(() => {
                    selectPlan(data.id);
                }, 500);
            })
            .catch(error => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                // Show error message
                showToast('Failed to create plan: ' + error.message, 'danger');
                console.error('Plan creation error:', error);
            });
        });
    }
}

/**
 * Initialize constraint builder with dynamic fields
 */
function initConstraintBuilder() {
    const constraintContainer = document.getElementById('constraint-container');
    const addConstraintBtn = document.getElementById('add-constraint');
    
    if (constraintContainer && addConstraintBtn) {
        // Add event listener for adding new constraints
        addConstraintBtn.addEventListener('click', function() {
            addConstraintField();
        });
        
        // Add initial constraint field
        addConstraintField();
    }
}

/**
 * Add a new constraint field to the builder
 */
function addConstraintField() {
    const constraintContainer = document.getElementById('constraint-container');
    if (!constraintContainer) return;
    
    // Create a unique ID for this constraint
    const constraintId = 'constraint-' + Date.now();
    
    // Create constraint HTML
    const constraintHtml = `
        <div class="constraint-field mb-3" id="${constraintId}">
            <div class="input-group">
                <select class="form-select constraint-type">
                    <option value="">Select constraint type</option>
                    <option value="max_delay_minutes">Maximum Delay (minutes)</option>
                    <option value="min_connection_time">Minimum Connection Time (minutes)</option>
                    <option value="min_turnaround_minutes">Minimum Turnaround Time (minutes)</option>
                    <option value="required_crew_count">Required Crew Count</option>
                    <option value="position_required">Crew Position Required</option>
                    <option value="flight_ids">Specific Flight IDs</option>
                    <option value="no_overnight_transit_um">No Overnight Transit for UMs</option>
                    <option value="max_connections_um">Maximum Connections for UMs</option>
                    <option value="min_staff_at_transit">Minimum Staff at Transit Station</option>
                </select>
                <input type="text" class="form-control constraint-value" placeholder="Value">
                <button class="btn btn-outline-danger" type="button" onclick="removeConstraint('${constraintId}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    `;
    
    // Add to container
    constraintContainer.insertAdjacentHTML('beforeend', constraintHtml);
}

/**
 * Remove a constraint field from the builder
 * @param {string} constraintId - ID of the constraint field to remove
 */
function removeConstraint(constraintId) {
    const constraintField = document.getElementById(constraintId);
    if (constraintField) {
        constraintField.remove();
    }
}

/**
 * Get constraints from the builder
 * @returns {Object} Constraints object
 */
function getConstraints() {
    const constraintFields = document.querySelectorAll('.constraint-field');
    const constraints = {};
    
    constraintFields.forEach(field => {
        const typeSelect = field.querySelector('.constraint-type');
        const valueInput = field.querySelector('.constraint-value');
        
        if (typeSelect.value && valueInput.value) {
            // Handle different value types
            let value = valueInput.value;
            
            // Convert to number for numeric constraints
            if (['max_delay_minutes', 'min_connection_time', 'min_turnaround_minutes', 'required_crew_count', 'max_connections_um', 'min_staff_at_transit'].includes(typeSelect.value)) {
                value = parseInt(value, 10);
            }
            
            // Handle array values
            if (typeSelect.value === 'flight_ids') {
                value = value.split(',').map(id => parseInt(id.trim(), 10));
            }
            
            // Handle boolean values
            if (typeSelect.value === 'no_overnight_transit_um') {
                value = value.toLowerCase() === 'true';
            }
            
            constraints[typeSelect.value] = value;
        }
    });
    
    return constraints;
}

/**
 * Select a plan and show its details
 * @param {number} planId - ID of the plan to select
 */
function selectPlan(planId) {
    selectedPlanId = planId;
    
    // Update UI to show selected plan
    const planCards = document.querySelectorAll('.plan-card');
    planCards.forEach(card => {
        if (parseInt(card.dataset.id, 10) === planId) {
            card.classList.add('active');
        } else {
            card.classList.remove('active');
        }
    });
    
    // Load plan details
    loadPlanDetails(planId);
}

/**
 * Load details for a specific plan
 * @param {number} planId - ID of the plan
 */
function loadPlanDetails(planId) {
    const detailsContainer = document.getElementById('plan-details-container');
    if (!detailsContainer) return;
    
    // Show loading state
    detailsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading plan details...</p>';
    
    // Fetch plan details
    fetch(`/api/plans/${planId}`)
        .then(response => response.json())
        .then(plan => {
            // Create constraints HTML
            let constraintsHtml = '';
            if (plan.constraints && Object.keys(plan.constraints).length > 0) {
                constraintsHtml = '<div class="mb-3"><h6>Constraints</h6><div>';
                
                for (const [key, value] of Object.entries(plan.constraints)) {
                    const formattedKey = key.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
                    constraintsHtml += `<span class="constraint-tag">${formattedKey}: ${value}</span>`;
                }
                
                constraintsHtml += '</div></div>';
            }
            
            // Create weights HTML
            let weightsHtml = '';
            if (plan.objective_weights) {
                weightsHtml = `
                    <div class="mb-3">
                        <h6>Objective Weights</h6>
                        <div class="row">
                `;
                
                for (const [key, value] of Object.entries(plan.objective_weights)) {
                    const formattedKey = key.replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
                    weightsHtml += `
                        <div class="col-md-4 col-6 mb-2">
                            <div class="small text-muted">${formattedKey}</div>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: ${value * 100}%" 
                                     aria-valuenow="${value * 100}" aria-valuemin="0" aria-valuemax="100">
                                    ${Math.round(value * 100)}%
                                </div>
                            </div>
                        </div>
                    `;
                }
                
                weightsHtml += '</div></div>';
            }
            
            // Create results HTML
            let resultsHtml = '';
            if (plan.status === 'completed' && plan.results) {
                resultsHtml = '<div class="mt-4"><h5>Optimization Results</h5>';
                
                // Handle different result types
                if (plan.results.crew_assignments && plan.results.crew_assignments.length > 0) {
                    resultsHtml += `
                        <div class="mb-4">
                            <h6>Crew Assignments (${plan.results.crew_assignments.length})</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>Crew</th>
                                            <th>Flight</th>
                                            <th>Departure</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                    `;
                    
                    plan.results.crew_assignments.forEach(assignment => {
                        resultsHtml += `
                            <tr>
                                <td>${assignment.crew_name || assignment.crew_id}</td>
                                <td>${assignment.flight_number}</td>
                                <td>${formatDate(assignment.departure)}</td>
                                <td><span class="badge bg-primary">${assignment.action}</span></td>
                            </tr>
                        `;
                    });
                    
                    resultsHtml += '</tbody></table></div>';
                }
                
                if (plan.results.aircraft_assignments && plan.results.aircraft_assignments.length > 0) {
                    resultsHtml += `
                        <div class="mb-4">
                            <h6>Aircraft Assignments (${plan.results.aircraft_assignments.length})</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>Aircraft</th>
                                            <th>Flight</th>
                                            <th>Departure</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                    `;
                    
                    plan.results.aircraft_assignments.forEach(assignment => {
                        resultsHtml += `
                            <tr>
                                <td>${assignment.registration} (${assignment.aircraft_type})</td>
                                <td>${assignment.flight_number}</td>
                                <td>${formatDate(assignment.departure)}</td>
                                <td><span class="badge bg-primary">${assignment.action}</span></td>
                            </tr>
                        `;
                    });
                    
                    resultsHtml += '</tbody></table></div>';
                }
                
                if (plan.results.schedule_changes && plan.results.schedule_changes.length > 0) {
                    resultsHtml += `
                        <div class="mb-4">
                            <h6>Schedule Changes (${plan.results.schedule_changes.length})</h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>Flight</th>
                                            <th>Original</th>
                                            <th>New</th>
                                            <th>Delay</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                    `;
                    
                    plan.results.schedule_changes.forEach(change => {
                        resultsHtml += `
                            <tr>
                                <td>${change.flight_number}</td>
                                <td>${formatDate(change.original_departure)}</td>
                                <td>${formatDate(change.new_departure)}</td>
                                <td><span class="badge bg-warning">${change.delay_minutes} min</span></td>
                            </tr>
                        `;
                    });
                    
                    resultsHtml += '</tbody></table></div>';
                }
                
                // Add total cost/score
                if (plan.score !== null) {
                    resultsHtml += `
                        <div class="card bg-light mb-3">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <h6 class="mb-0">Optimization Score</h6>
                                        <p class="text-muted mb-0 small">Higher is better</p>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="score-indicator">
                                            <div class="score-value bg-${getScoreColor(plan.score)}" style="width: ${plan.score * 100}%"></div>
                                        </div>
                                        <div class="text-end mt-1">
                                            <strong>${formatPercent(plan.score)}</strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                }
                
                resultsHtml += '</div>';
            }
            
            // Create action buttons based on status
            let actionsHtml = '';
            if (plan.status === 'draft') {
                actionsHtml = `
                    <button class="btn btn-primary me-2" onclick="runPlan(${plan.id})">
                        <i class="fas fa-play"></i> Run Optimization
                    </button>
                `;
            } else if (plan.status === 'completed') {
                actionsHtml = `
                    <button class="btn btn-outline-primary me-2" onclick="getSummary(${plan.id})">
                        <i class="fas fa-file-alt"></i> Get Summary
                    </button>
                `;
            }
            
            // Always show clone button
            actionsHtml += `
                <button class="btn btn-outline-secondary me-2" onclick="clonePlan(${plan.id})">
                    <i class="fas fa-copy"></i> Clone
                </button>
            `;
            
            // Create visualization button if completed
            if (plan.status === 'completed') {
                actionsHtml += `
                    <button class="btn btn-outline-info" onclick="visualizePlan(${plan.id})">
                        <i class="fas fa-project-diagram"></i> Visualize
                    </button>
                `;
            }
            
            // Create the details HTML
            const detailsHtml = `
                <div class="mb-3">
                    <h4>${plan.name}</h4>
                    <p>${plan.description || plan.scenario}</p>
                </div>
                
                <div class="mb-3">
                    <span class="badge ${getStatusBadge(plan.status)} me-2">${plan.status}</span>
                    <small class="text-muted">Created: ${formatDate(plan.created_at)} • Version: ${plan.version}</small>
                </div>
                
                ${constraintsHtml}
                ${weightsHtml}
                
                <div class="mt-3 mb-4">
                    ${actionsHtml}
                </div>
                
                <div id="summary-container" class="mb-4 d-none"></div>
                <div id="visualization-container" class="mb-4 d-none"></div>
                
                ${resultsHtml}
            `;
            
            // Update container
            detailsContainer.innerHTML = detailsHtml;
        })
        .catch(error => {
            detailsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading plan details: ${error.message}
                </div>
            `;
            console.error('Failed to load plan details:', error);
        });
}

/**
 * Run an optimization plan
 * @param {number} planId - ID of the plan to run
 */
function runPlan(planId) {
    const detailsContainer = document.getElementById('plan-details-container');
    if (!detailsContainer) return;
    
    // Show loading state
    detailsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Running optimization...</p><p class="text-center text-muted">This may take a few moments</p>';
    
    // Call API to run the plan
    fetch(`/api/plans/${planId}/run`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Optimization completed successfully', 'success');
        
        // Reload plans and select this one
        loadOptimizationPlans();
        setTimeout(() => {
            selectPlan(planId);
        }, 500);
    })
    .catch(error => {
        // Show error message in details container
        detailsContainer.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error running optimization: ${error.message}
            </div>
            <button class="btn btn-primary" onclick="selectPlan(${planId})">
                <i class="fas fa-arrow-left"></i> Back to Plan Details
            </button>
        `;
        console.error('Optimization error:', error);
    });
}

/**
 * Get a natural language summary of a plan
 * @param {number} planId - ID of the plan
 */
function getSummary(planId) {
    const summaryContainer = document.getElementById('summary-container');
    if (!summaryContainer) return;
    
    // Show container and loading state
    summaryContainer.classList.remove('d-none');
    summaryContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Generating summary...</p>';
    
    // Call API to get summary
    fetch(`/api/plans/${planId}/summary`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Show summary
            summaryContainer.innerHTML = `
                <div class="card bg-light">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Plan Summary</h5>
                            <button class="btn btn-sm btn-outline-secondary" onclick="document.getElementById('summary-container').classList.add('d-none')">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <p>${data.summary.replace(/\n/g, '<br>')}</p>
                    </div>
                </div>
            `;
        })
        .catch(error => {
            // Show error message
            summaryContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error generating summary: ${error.message}
                </div>
            `;
            console.error('Summary generation error:', error);
        });
}

/**
 * Clone an existing plan
 * @param {number} planId - ID of the plan to clone
 */
function clonePlan(planId) {
    // Call API to clone the plan
    fetch(`/api/plans/${planId}/clone`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Plan cloned successfully', 'success');
        
        // Reload plans and select the new one
        loadOptimizationPlans();
        setTimeout(() => {
            selectPlan(data.id);
        }, 500);
    })
    .catch(error => {
        // Show error message
        showToast('Failed to clone plan: ' + error.message, 'danger');
        console.error('Plan cloning error:', error);
    });
}

/**
 * Visualize an optimization plan with Mermaid.js
 * @param {number} planId - ID of the plan
 */
function visualizePlan(planId) {
    const visualizationContainer = document.getElementById('visualization-container');
    if (!visualizationContainer) return;
    
    // Find the plan
    const plan = currentPlans.find(p => p.id === planId);
    if (!plan) return;
    
    // Show container and loading state
    visualizationContainer.classList.remove('d-none');
    visualizationContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Generating visualization...</p>';
    
    // Generate the flowchart
    renderOptimizationFlow(plan.scenario, 'visualization-container');
}

/**
 * Get badge class for plan status
 * @param {string} status - Plan status
 * @returns {string} Bootstrap badge class
 */
function getStatusBadge(status) {
    switch (status) {
        case 'completed':
            return 'bg-success';
        case 'running':
            return 'bg-primary';
        case 'failed':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

/**
 * Get color class for score value
 * @param {number} score - Score value (0-1)
 * @returns {string} Bootstrap color class
 */
function getScoreColor(score) {
    if (score >= 0.8) {
        return 'success';
    } else if (score >= 0.6) {
        return 'info';
    } else if (score >= 0.4) {
        return 'warning';
    } else {
        return 'danger';
    }
}

/**
 * Truncate text with ellipsis if it exceeds max length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
function truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Escape HTML special characters to prevent XSS
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    const element = document.createElement('div');
    element.textContent = text;
    return element.innerHTML;
}

/**
 * Render an optimization flow chart using Mermaid.js
 * @param {string} scenario - Optimization scenario description
 * @param {string} containerId - ID of the container to render in
 */
function renderOptimizationFlow(scenario, containerId) {
    if (!scenario) {
        return;
    }
    
    const container = document.getElementById(containerId);
    if (!container) {
        console.error('Optimization flow container not found:', containerId);
        return;
    }
    
    // Show loading state
    container.innerHTML = '<div class="spinner"></div><p class="text-center">Generating flowchart...</p>';
    
    // Call the API to generate the flowchart
    fetch('/api/generate-flowchart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ scenario: scenario })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (!data.flowchart) {
            throw new Error('No flowchart data received');
        }
        
        // Clean the mermaid flowchart data thoroughly
        let cleanFlowchart = data.flowchart
            .replace(/\*/g, '')                // Remove asterisks
            .replace(/```mermaid/gi, '')       // Remove mermaid code blocks with case insensitivity
            .replace(/```/g, '')               // Remove all code block markers
            .replace(/^mermaid$/gim, '')       // Remove standalone "mermaid" text
            .trim();
        
        // Ensure the flowchart starts with the proper graph directive
        if (!cleanFlowchart.trim().startsWith('graph ')) {
            const graphMatch = cleanFlowchart.match(/graph\s+(TD|TB|BT|RL|LR)/i);
            if (graphMatch) {
                // Extract everything from the graph directive onward
                cleanFlowchart = cleanFlowchart.substring(graphMatch.index);
            } else {
                // If no graph directive found, add one
                cleanFlowchart = 'graph TD\n' + cleanFlowchart;
            }
        }
        
        console.log('Cleaned flowchart:', cleanFlowchart);
        
        // Render the flowchart using Mermaid
        container.innerHTML = `<div class="mermaid">${cleanFlowchart}</div>`;
        
        // Initialize Mermaid with config
        if (window.mermaid) {
            try {
                // Reset mermaid to clear any previous configurations
                window.mermaid.mermaidAPI.reset();
                
                // Configure mermaid with version 9.4.3 compatible settings
                window.mermaid.initialize({
                    startOnLoad: false,  // We'll render manually
                    theme: 'neutral',
                    securityLevel: 'loose',  // Required for some rendering features
                    logLevel: 'error',
                    flowchart: {
                        htmlLabels: true,
                        curve: 'linear',  // More reliable than 'basis'
                        useMaxWidth: true,
                        nodeSpacing: 50,  // Provide more space between nodes
                        rankSpacing: 50   // Provide more space between ranks
                    }
                });
                
                // Try-catch to handle mermaid parsing errors
                window.mermaid.init(undefined, document.querySelector('.mermaid'));
            } catch (error) {
                console.error('Mermaid parsing error:', error);
                container.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Error rendering flowchart: ${error.message}
                        <hr>
                        <pre class="small text-muted">${escapeHtml(cleanFlowchart)}</pre>
                    </div>
                `;
            }
        } else {
            console.error('Mermaid library not loaded');
            container.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Unable to render flowchart. Mermaid library not loaded.
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error generating flowchart:', error);
        container.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error generating flowchart: ${error.message}
            </div>
        `;
    });
}
