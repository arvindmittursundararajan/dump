"""
ADW Data Modeller API Package
"""

__version__ = "1.0.0"
__author__ = "ADW Data Modeller Team" 