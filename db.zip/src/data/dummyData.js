// Dummy jobs data
export const dummyJobs = Array.from({ length: 42 }, (_, i) => ({
  id: i + 1,
  name: `Job #${i + 1}`,
  schedule: ['Daily', 'Weekly', 'Monthly', 'Once'][i % 4],
  active: i % 2 === 0,
  lastRun: `2024-06-${(i % 30) + 1}`,
  nextRun: `2024-07-${(i % 30) + 1}`
}));

// Dummy rules data
export const dummyRules = Array.from({ length: 73 }, (_, i) => ({
  id: i + 1,
  name: `Rule #${i + 1}`,
  type: ['Validation', 'Completeness', 'Format', 'Range', 'Custom'][i % 5],
  category: ['Quality', 'Compliance', 'Security', 'Business'][i % 4],
  severity: ['Low', 'Medium', 'High', 'Critical'][i % 4],
  active: i % 3 !== 0
}));

// Dummy datasets with tier information
export const dummyDatasets = Array.from({ length: 25 }, (_, i) => {
  const tiers = ['Diamond', 'Amber', 'Ivory', 'Carbon'];
  const tier = tiers[i % 4];
  const qualityScores = {
    'Diamond': Math.floor(Math.random() * 10) + 90, // 90-100
    'Amber': Math.floor(Math.random() * 19) + 70,   // 70-89
    'Ivory': Math.floor(Math.random() * 19) + 50,   // 50-69
    'Carbon': Math.floor(Math.random() * 49) + 0    // 0-49
  };
  
  return {
    id: i + 1,
    name: `Dataset ${i + 1}`,
    tier: tier,
    qualityScore: qualityScores[tier],
    lastAnalyzed: `2024-06-${(i % 30) + 1}`,
    team: `Team ${String.fromCharCode(65 + (i % 8))}`, // Team A-H
    issueCount: Math.floor(Math.random() * 20) + 1
  };
});

// Calculate tier counts
export const tierCounts = {
  Diamond: dummyDatasets.filter(d => d.tier === 'Diamond').length,
  Amber: dummyDatasets.filter(d => d.tier === 'Amber').length,
  Ivory: dummyDatasets.filter(d => d.tier === 'Ivory').length,
  Carbon: dummyDatasets.filter(d => d.tier === 'Carbon').length
};

// Mock progression data for demonstration
export const datasetProgression = {
  'Dataset 1': [
    { date: '2024-03-01', tier: 'Carbon' },
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-05-01', tier: 'Amber' },
    { date: '2024-06-01', tier: 'Diamond' },
  ],
  'Dataset 2': [
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-05-01', tier: 'Amber' },
    { date: '2024-06-01', tier: 'Amber' },
  ],
  'Dataset 3': [
    { date: '2024-03-01', tier: 'Carbon' },
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-06-01', tier: 'Ivory' },
  ],
  'Dataset 4': [
    { date: '2024-05-01', tier: 'Carbon' },
    { date: '2024-06-01', tier: 'Carbon' },
  ],
  'Dataset 5': [
    { date: '2024-03-01', tier: 'Amber' },
    { date: '2024-04-01', tier: 'Amber' },
    { date: '2024-05-01', tier: 'Diamond' },
    { date: '2024-06-01', tier: 'Diamond' },
  ],
  'Dataset 6': [
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-05-01', tier: 'Amber' },
    { date: '2024-06-01', tier: 'Amber' },
  ],
  'Dataset 7': [
    { date: '2024-03-01', tier: 'Carbon' },
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-06-01', tier: 'Ivory' },
  ],
  'Dataset 8': [
    { date: '2024-05-01', tier: 'Carbon' },
    { date: '2024-06-01', tier: 'Carbon' },
  ],
  'Dataset 9': [
    { date: '2024-03-01', tier: 'Amber' },
    { date: '2024-04-01', tier: 'Diamond' },
    { date: '2024-06-01', tier: 'Diamond' },
  ],
  'Dataset 10': [
    { date: '2024-04-01', tier: 'Ivory' },
    { date: '2024-05-01', tier: 'Amber' },
    { date: '2024-06-01', tier: 'Amber' },
  ],
}; 