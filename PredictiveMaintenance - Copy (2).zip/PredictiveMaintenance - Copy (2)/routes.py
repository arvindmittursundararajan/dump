import os
import csv
import json
import pandas as pd
from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, jsonify, flash, send_from_directory, session
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash
from sqlalchemy import func

from app import db
from models import Machine, Part, SensorData, MaintenanceRecord, Alert, FileMetadata, AiInteraction, PredictiveModel, User
from utils import process_with_gemini, allowed_file, detect_anomalies, calculate_failure_probability, analyze_sensor_data, process_csv_data
from run_seed import seed_database

def register_routes(app):
    # Login route
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password_hash, password):
                session['user_id'] = user.id
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'danger')
        return render_template('login.html')

    # Logout route
    @app.route('/logout')
    def logout():
        session.pop('user_id', None)
        flash('Logged out successfully.', 'success')
        return redirect(url_for('login'))

    # Protect all routes except login/logout
    @app.before_request
    def require_login():
        allowed_routes = ['login', 'static']
        if request.endpoint not in allowed_routes and not session.get('user_id'):
            return redirect(url_for('login'))

    # Serve uploads
    @app.route('/uploads/<filename>')
    def uploaded_file(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    
    # Dashboard route
    @app.route('/')
    @app.route('/dashboard')
    def dashboard():
        # Get counts for dashboard metrics
        machine_count = db.session.query(Machine).count()
        part_count = db.session.query(Part).count()
        
        # Get machine statuses
        status_counts = db.session.query(
            Machine.status, func.count(Machine.id)
        ).group_by(Machine.status).all()
        status_data = {status: count for status, count in status_counts}
        
        # Get recent alerts
        recent_alerts = db.session.query(Alert).order_by(Alert.timestamp.desc()).limit(10).all()
        
        # Get all machines for the tree view
        machines = db.session.query(Machine).all()

        # New metrics
        maintenance_count = db.session.query(MaintenanceRecord).count()
        alert_count = db.session.query(Alert).count()
        technician_count = db.session.query(MaintenanceRecord.technician).distinct().count()
        scheduled_maintenance_count = db.session.query(MaintenanceRecord).filter(MaintenanceRecord.status == 'scheduled').count()
        completed_maintenance_count = db.session.query(MaintenanceRecord).filter(MaintenanceRecord.status == 'completed').count()

        return render_template('dashboard.html', 
                              machine_count=machine_count,
                              part_count=part_count,
                              status_data=status_data,
                              recent_alerts=recent_alerts,
                              machines=machines,
                              maintenance_count=maintenance_count,
                              alert_count=alert_count,
                              technician_count=technician_count,
                              scheduled_maintenance_count=scheduled_maintenance_count,
                              completed_maintenance_count=completed_maintenance_count)
                              
    # Database reset route
    @app.route('/reset', methods=['GET', 'POST'])
    def reset_database():
        if request.method == 'POST':
            # Check for confirmation checkbox
            if request.form.get('confirm_reset') == 'on':
                try:
                    # Drop all tables
                    db.drop_all()
                    
                    # Recreate all tables
                    db.create_all()
                    
                    # Repopulate with sample data if requested
                    if request.form.get('seed_data') == 'on':
                        seed_database()
                    
                    flash('Database has been reset successfully.', 'success')
                    return redirect(url_for('dashboard'))
                except Exception as e:
                    flash(f'Error resetting database: {str(e)}', 'danger')
                    return redirect(url_for('reset_database'))
            else:
                flash('Please confirm that you understand the consequences of resetting the database.', 'warning')
                return redirect(url_for('reset_database'))
        
        return render_template('reset.html')
    
    # API route to get machine and parts hierarchy
    @app.route('/api/asset-tree')
    def asset_tree():
        machines = Machine.query.all()
        # Group machines by location (factory/plant)
        locations = {}
        for machine in machines:
            loc = machine.location or 'Unknown Site'
            if loc not in locations:
                locations[loc] = []
            locations[loc].append(machine)
        tree_data = []
        for loc, loc_machines in locations.items():
            location_node = {
                'id': f'location-{loc.replace(" ", "-").lower()}',
                'text': loc,
                'type': 'location',
                'children': []
            }
            for machine in loc_machines:
                # Add health circle to machine text
                health_color = '#28a745' if machine.status == 'operational' else ('#ffc107' if machine.status == 'warning' else '#dc3545')
                health_circle = f'<span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:{health_color};margin-right:7px;vertical-align:middle;border:1.5px solid #222;"></span>'
                machine_node = {
                    'id': f'machine-{machine.id}',
                    'text': health_circle + machine.name,
                    'type': 'machine',
                    'machine_id': machine.id,
                    'status': machine.status,
                    'children': []
                }
                # Get top-level parts (no parent part)
                top_parts = db.session.query(Part).filter(Part.machine_id == machine.id, Part.parent_part_id == None).all()
                for part in top_parts:
                    part_node = build_part_tree(part)
                    machine_node['children'].append(part_node)
                location_node['children'].append(machine_node)
            tree_data.append(location_node)
        return jsonify(tree_data)
    
    def build_part_tree(part):
        """Recursively build the part tree"""
        # Add health circle to part text
        health_color = '#28a745' if part.status == 'operational' else ('#ffc107' if part.status == 'warning' else '#dc3545')
        health_circle = f'<span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:{health_color};margin-right:7px;vertical-align:middle;border:1.5px solid #222;"></span>'
        part_node = {
            'id': f'part-{part.id}',
            'text': health_circle + part.name,
            'type': 'part',
            'part_id': part.id,
            'machine_id': part.machine_id,
            'status': part.status,
            'children': []
        }
        
        # Get child parts
        child_parts = db.session.query(Part).filter(Part.parent_part_id == part.id).all()
        
        for child in child_parts:
            child_node = build_part_tree(child)
            part_node['children'].append(child_node)
            
        return part_node
    
    # Gemini prompt for AI recommendations (HTML, no markdown, no asterisks)
    def build_gemini_prompt(asset_name, issue_summary, actions, color="#e53935"):
        html = f'''
        <div style="display:flex;align-items:stretch;border-radius:10px;box-shadow:0 2px 12px rgba(220,53,69,0.08);overflow:hidden;margin-bottom:1rem;background:#fff;">
            <div style="width:10px;background:{color};border-top-left-radius:10px;border-bottom-left-radius:10px;"></div>
            <div style="padding:1.2rem 1.5rem 1.2rem 1.2rem;flex:1;">
                <h4 style="margin-top:0;margin-bottom:0.7rem;font-size:1.25rem;color:#b71c1c;font-weight:700;letter-spacing:0.5px;">Maintenance Recommendations for {asset_name}</h4>
                <div style="margin-bottom:0.7rem;font-size:1.05rem;color:#333;">{issue_summary}</div>
                <ul style="padding-left:1.2em;margin-bottom:0.7rem;">
                    {''.join([f'<li style="margin-bottom:0.3em;">{a}</li>' for a in actions])}
                </ul>
            </div>
        </div>
        '''
        return html
    
    # API route to get asset details
    @app.route('/api/asset/<asset_type>/<int:asset_id>')
    def get_asset_details(asset_type, asset_id):
        if asset_type == 'machine':
            asset = db.session.get(Machine, asset_id)
            if not asset:
                return jsonify({'error': 'Machine not found'}), 404
            
            # Get recent sensor data for this machine
            sensor_data = db.session.query(SensorData).filter(SensorData.machine_id == asset_id).order_by(SensorData.timestamp.desc()).limit(100).all()
            
            # Get all parts for this machine
            parts = db.session.query(Part).filter(Part.machine_id == asset_id).all()
            parts_data = [{'id': p.id, 'name': p.name, 'status': p.status} for p in parts]
            
            # Get maintenance history
            maintenance = db.session.query(MaintenanceRecord).filter(MaintenanceRecord.machine_id == asset_id).order_by(MaintenanceRecord.start_date.desc()).limit(5).all()
            maintenance_data = [{
                'id': m.id,
                'type': m.maintenance_type,
                'start_date': m.start_date.strftime('%Y-%m-%d'),
                'end_date': m.end_date.strftime('%Y-%m-%d') if m.end_date else 'Ongoing',
                'status': m.status,
                'cost': m.cost
            } for m in maintenance]
            
            # Get alerts
            alerts = db.session.query(Alert).filter(Alert.machine_id == asset_id, Alert.part_id == None).order_by(Alert.timestamp.desc()).limit(5).all()
            alerts_data = [{
                'id': a.id,
                'type': a.alert_type,
                'message': a.message,
                'severity': a.severity,
                'timestamp': a.timestamp.strftime('%Y-%m-%d %H:%M')
            } for a in alerts]
            
            # Process sensor data for chart
            sensor_types = list(set([sd.sensor_type for sd in sensor_data]))
            chart_data = {}
            
            for s_type in sensor_types:
                data_points = db.session.query(SensorData).filter(SensorData.machine_id == asset_id, SensorData.sensor_type == s_type).order_by(SensorData.timestamp).limit(100).all()
                chart_data[s_type] = {
                    'labels': [dp.timestamp.strftime('%Y-%m-%d %H:%M') for dp in data_points],
                    'values': [dp.value for dp in data_points],
                    'anomalies': [dp.is_anomaly for dp in data_points]
                }
            
            # Get AI insights
            ai_insights = db.session.query(AiInteraction).filter(AiInteraction.machine_id == asset_id, AiInteraction.part_id == None).order_by(AiInteraction.timestamp.desc()).first()
            ai_recommendation = ai_insights.response if ai_insights else None
            
            if not ai_recommendation:
                # Generate a recommendation based on the asset's status and sensor data
                query = f"Analyze this machine: {asset.name}, Status: {asset.status}. "
                if sensor_data:
                    query += f"Recent sensor data shows values ranging from {min([sd.value for sd in sensor_data])} to {max([sd.value for sd in sensor_data])}. "
                if alerts_data:
                    query += f"Recent alerts: {', '.join([a['type'] for a in alerts_data])}. "
                query += "What maintenance recommendations would you provide?"
                
                ai_recommendation = process_with_gemini(query)
                
                # Save the AI interaction
                new_interaction = AiInteraction(
                    query=query,
                    response=ai_recommendation,
                    machine_id=asset_id,
                    timestamp=datetime.utcnow()
                )
                db.session.add(new_interaction)
                db.session.commit()
                
            result = {
                'id': asset.id,
                'name': asset.name,
                'description': asset.description,
                'asset_type': asset.asset_type,
                'status': asset.status,
                'parts': parts_data,
                'chart_data': chart_data,
                'maintenance_history': maintenance_data,
                'alerts': alerts_data,
                'ai_recommendation': ai_recommendation
            }
        elif asset_type == 'part':
            part = db.session.get(Part, asset_id)
            if not part:
                return jsonify({'error': 'Part not found'}), 404
            
            # Get sensor data for this part
            sensor_data = db.session.query(SensorData).filter(SensorData.part_id == asset_id).order_by(SensorData.timestamp.desc()).limit(100).all()
            
            # Get metadata
            metadata = db.session.query(FileMetadata).filter(FileMetadata.part_id == asset_id).all()
            metadata_data = [{
                'id': m.id,
                'type': m.metadata_type,
                'title': m.title,
                'description': m.description,
                'file_path': m.file_path,
                'upload_date': m.upload_date.strftime('%Y-%m-%d')
            } for m in metadata]
            
            # Get alerts
            alerts = db.session.query(Alert).filter(Alert.part_id == asset_id).order_by(Alert.timestamp.desc()).limit(5).all()
            alerts_data = [{
                'id': a.id,
                'type': a.alert_type,
                'message': a.message,
                'severity': a.severity,
                'timestamp': a.timestamp.strftime('%Y-%m-%d %H:%M')
            } for a in alerts]
            
            # Process sensor data for chart
            sensor_types = list(set([sd.sensor_type for sd in sensor_data]))
            chart_data = {}
            
            for s_type in sensor_types:
                data_points = db.session.query(SensorData).filter(SensorData.part_id == asset_id, SensorData.sensor_type == s_type).order_by(SensorData.timestamp).limit(100).all()
                chart_data[s_type] = {
                    'labels': [dp.timestamp.strftime('%Y-%m-%d %H:%M') for dp in data_points],
                    'values': [dp.value for dp in data_points],
                    'anomalies': [dp.is_anomaly for dp in data_points]
                }
            
            # Get AI insights
            ai_insights = db.session.query(AiInteraction).filter(AiInteraction.part_id == asset_id).order_by(AiInteraction.timestamp.desc()).first()
            ai_recommendation = ai_insights.response if ai_insights else None
            
            if not ai_recommendation:
                # Generate a recommendation based on the part's status and sensor data
                query = f"Analyze this part: {part.name}, Status: {part.status}. "
                if sensor_data:
                    query += f"Recent sensor data shows values ranging from {min([sd.value for sd in sensor_data])} to {max([sd.value for sd in sensor_data])}. "
                if alerts_data:
                    query += f"Recent alerts: {', '.join([a['type'] for a in alerts_data])}. "
                query += "What maintenance recommendations would you provide?"
                
                ai_recommendation = process_with_gemini(query)
                
                # Save the AI interaction
                new_interaction = AiInteraction(
                    query=query,
                    response=ai_recommendation,
                    part_id=asset_id,
                    timestamp=datetime.utcnow()
                )
                db.session.add(new_interaction)
                db.session.commit()
            
            # Get parent machine and part
            machine = Machine.query.get(part.machine_id)
            parent_part = Part.query.get(part.parent_part_id) if part.parent_part_id else None
            
            result = {
                'id': part.id,
                'name': part.name,
                'description': part.description,
                'part_type': part.part_type,
                'status': part.status,
                'machine_id': part.machine_id,
                'machine_name': machine.name,
                'parent_part_id': part.parent_part_id,
                'parent_part_name': parent_part.name if parent_part else None,
                'chart_data': chart_data,
                'metadata': metadata_data,
                'alerts': alerts_data,
                'ai_recommendation': ai_recommendation,
                'expected_lifetime_hours': part.expected_lifetime_hours,
                'installation_date': part.installation_date.strftime('%Y-%m-%d') if part.installation_date else None
            }
        else:
            return jsonify({'error': 'Invalid asset type'}), 400
            
        return jsonify(result)
    
    # Route to handle AI questions
    @app.route('/api/ask-ai', methods=['POST'])
    def ask_ai():
        data = request.json
        question = data.get('question')
        machine_id = data.get('machine_id')
        part_id = data.get('part_id')
        
        if not question:
            return jsonify({'error': 'No question provided'}), 400
        
        # Gather asset details for context
        asset_details = None
        if machine_id:
            machine = Machine.query.get(machine_id)
            if machine:
                # Get recent alerts
                alerts = Alert.query.filter_by(machine_id=machine_id).order_by(Alert.timestamp.desc()).limit(5).all()
                alerts_data = [{
                    'type': a.alert_type,
                    'severity': a.severity,
                    'message': a.message
                } for a in alerts]
                # Get recent sensor data summary
                sensor_data = SensorData.query.filter_by(machine_id=machine_id).all()
                sensor_summary = {}
                if sensor_data:
                    for s_type in set([s.sensor_type for s in sensor_data]):
                        vals = [s.value for s in sensor_data if s.sensor_type == s_type]
                        anomalies = [s.is_anomaly for s in sensor_data if s.sensor_type == s_type]
                        if vals:
                            sensor_summary[s_type] = {
                                'min': min(vals),
                                'max': max(vals),
                                'mean': sum(vals)/len(vals),
                                'anomaly_count': sum(anomalies)
                            }
                # Get recent maintenance
                maintenance = MaintenanceRecord.query.filter_by(machine_id=machine_id).order_by(MaintenanceRecord.start_date.desc()).limit(5).all()
                maintenance_data = [{
                    'type': m.maintenance_type,
                    'status': m.status,
                    'start_date': m.start_date.strftime('%Y-%m-%d')
                } for m in maintenance]
                asset_details = {
                    'name': machine.name,
                    'type': machine.asset_type,
                    'status': machine.status,
                    'alerts': alerts_data,
                    'sensor_data': sensor_summary,
                    'maintenance_history': maintenance_data
                }
        elif part_id:
            part = Part.query.get(part_id)
            if part:
                # Get recent alerts
                alerts = Alert.query.filter_by(part_id=part_id).order_by(Alert.timestamp.desc()).limit(5).all()
                alerts_data = [{
                    'type': a.alert_type,
                    'severity': a.severity,
                    'message': a.message
                } for a in alerts]
                # Get recent sensor data summary
                sensor_data = SensorData.query.filter_by(part_id=part_id).all()
                sensor_summary = {}
                if sensor_data:
                    for s_type in set([s.sensor_type for s in sensor_data]):
                        vals = [s.value for s in sensor_data if s.sensor_type == s_type]
                        anomalies = [s.is_anomaly for s in sensor_data if s.sensor_type == s_type]
                        if vals:
                            sensor_summary[s_type] = {
                                'min': min(vals),
                                'max': max(vals),
                                'mean': sum(vals)/len(vals),
                                'anomaly_count': sum(anomalies)
                            }
                # Get recent maintenance
                maintenance = MaintenanceRecord.query.filter_by(part_id=part_id).order_by(MaintenanceRecord.start_date.desc()).limit(5).all()
                maintenance_data = [{
                    'type': m.maintenance_type,
                    'status': m.status,
                    'start_date': m.start_date.strftime('%Y-%m-%d')
                } for m in maintenance]
                asset_details = {
                    'name': part.name,
                    'type': part.part_type,
                    'status': part.status,
                    'alerts': alerts_data,
                    'sensor_data': sensor_summary,
                    'maintenance_history': maintenance_data
                }
        # Process the question with Gemini, passing asset details
        response = process_with_gemini(question, asset_details=asset_details)
        # Save the interaction
        new_interaction = AiInteraction(
            query=question,
            response=response,
            machine_id=machine_id,
            part_id=part_id,
            timestamp=datetime.utcnow()
        )
        db.session.add(new_interaction)
        db.session.commit()
        return jsonify({'response': response})
    
    # Ingest page route
    @app.route('/ingest')
    def ingest():
        return render_template('ingest.html')
    
    # Route to handle CSV file upload
    @app.route('/api/upload-sensor-data', methods=['POST'])
    def upload_sensor_data():
        if 'file' not in request.files:
            flash('No file part')
            return jsonify({'success': False, 'message': 'No file part'}), 400
            
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return jsonify({'success': False, 'message': 'No selected file'}), 400
            
        if file and allowed_file(file.filename, {'csv'}):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Get machine and part IDs
            machine_id = request.form.get('machine_id', type=int)
            part_id = request.form.get('part_id', type=int)
            
            # Process the CSV file
            result = process_csv_data(filepath, machine_id, part_id)
            
            if result['success']:
                flash(f'Successfully processed {result["count"]} records')
                return jsonify({'success': True, 'count': result['count']})
            else:
                flash(f'Error: {result["message"]}')
                return jsonify({'success': False, 'message': result['message']}), 400
        else:
            flash('Invalid file type. Please upload a CSV file.')
            return jsonify({'success': False, 'message': 'Invalid file type'}), 400
    
    # API to get a list of machines
    @app.route('/api/machines')
    def get_machines():
        machines = Machine.query.all()
        return jsonify([{
            'id': m.id, 
            'name': m.name,
            'status': m.status,
            'location': m.location
        } for m in machines])
    
    # API to get parts for a machine
    @app.route('/api/machine/<int:machine_id>/parts')
    def get_machine_parts(machine_id):
        parts = Part.query.filter_by(machine_id=machine_id).all()
        return jsonify([{
            'id': p.id, 
            'name': p.name,
            'status': p.status,
            'part_type': p.part_type
        } for p in parts])
    
    # API to get sensor data for visualization
    @app.route('/api/sensor-data')
    def get_sensor_data():
        machine_id = request.args.get('machine_id', type=int)
        part_id = request.args.get('part_id', type=int)
        sensor_type = request.args.get('sensor_type')
        days = request.args.get('days', 30, type=int)
        
        # Define query filters
        filters = {}
        if machine_id:
            filters['machine_id'] = machine_id
        if part_id:
            filters['part_id'] = part_id
        if sensor_type:
            filters['sensor_type'] = sensor_type
            
        # Get data for the specified period
        start_date = datetime.utcnow() - timedelta(days=days)
        data = SensorData.query.filter_by(**filters).filter(
            SensorData.timestamp > start_date
        ).order_by(SensorData.timestamp).all()
        
        # Format data for response
        result = [{
            'id': d.id,
            'timestamp': d.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'value': d.value,
            'sensor_type': d.sensor_type,
            'unit': d.unit,
            'is_anomaly': d.is_anomaly
        } for d in data]
        
        return jsonify(result)
    
    # Route for maintenance page
    @app.route('/maintenance')
    def maintenance():
        records = MaintenanceRecord.query.order_by(MaintenanceRecord.start_date.desc()).all()
        machines = Machine.query.all()
        return render_template('maintenance.html', records=records, machines=machines)
    
    # API to add a maintenance record
    @app.route('/api/maintenance', methods=['POST'])
    def add_maintenance():
        data = request.json
        
        try:
            record = MaintenanceRecord(
                machine_id=data['machine_id'],
                part_id=data.get('part_id'),
                maintenance_type=data['maintenance_type'],
                start_date=datetime.strptime(data['start_date'], '%Y-%m-%d'),
                end_date=datetime.strptime(data['end_date'], '%Y-%m-%d') if data.get('end_date') else None,
                technician=data['technician'],
                status=data['status'],
                cost=data.get('cost'),
                description=data.get('description'),
                notes=data.get('notes')
            )
            
            db.session.add(record)
            db.session.commit()
            
            return jsonify({'success': True, 'id': record.id})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
    
    @app.route('/api/maintenance/<int:maintenance_id>', methods=['GET'])
    def get_maintenance_record(maintenance_id):
        record = MaintenanceRecord.query.get_or_404(maintenance_id)
        return jsonify({
            'id': record.id,
            'machine_id': record.machine_id,
            'part_id': record.part_id,
            'maintenance_type': record.maintenance_type,
            'start_date': record.start_date.strftime('%Y-%m-%d'),
            'end_date': record.end_date.strftime('%Y-%m-%d') if record.end_date else '',
            'technician': record.technician,
            'status': record.status,
            'cost': record.cost,
            'description': record.description,
            'notes': record.notes
        })

    @app.route('/api/maintenance/<int:maintenance_id>', methods=['PUT'])
    def update_maintenance_record(maintenance_id):
        data = request.json
        record = MaintenanceRecord.query.get_or_404(maintenance_id)
        record.machine_id = data['machine_id']
        record.part_id = data.get('part_id')
        record.maintenance_type = data['maintenance_type']
        record.start_date = datetime.strptime(data['start_date'], '%Y-%m-%d')
        record.end_date = datetime.strptime(data['end_date'], '%Y-%m-%d') if data.get('end_date') else None
        record.technician = data['technician']
        record.status = data['status']
        record.cost = data.get('cost')
        record.description = data.get('description')
        record.notes = data.get('notes')
        db.session.commit()
        return jsonify({'success': True})

    @app.route('/api/maintenance/<int:maintenance_id>', methods=['DELETE'])
    def delete_maintenance_record(maintenance_id):
        record = MaintenanceRecord.query.get_or_404(maintenance_id)
        db.session.delete(record)
        db.session.commit()
        return jsonify({'success': True})
    
    @app.route('/maintenance/search')
    def search_maintenance():
        query = request.args.get('q', '').strip().lower()
        results = []
        if query:
            records = MaintenanceRecord.query.all()
            for record in records:
                if (
                    query in (record.maintenance_type or '').lower() or
                    query in (record.technician or '').lower() or
                    query in (record.status or '').lower() or
                    query in (record.description or '').lower() or
                    query in (record.notes or '').lower()
                ):
                    results.append({
                        'id': record.id,
                        'machine_id': record.machine_id,
                        'maintenance_type': record.maintenance_type,
                        'start_date': record.start_date,
                        'end_date': record.end_date,
                        'technician': record.technician,
                        'status': record.status,
                        'cost': record.cost,
                        'description': record.description,
                        'notes': record.notes
                    })
        return jsonify(results)
    
    # Route for visualize page
    @app.route('/visualize')
    def visualize():
        machines = Machine.query.all()
        return render_template('visualize.html', machines=machines)
    
    # API to get failure probabilities
    @app.route('/api/failure-probabilities')
    def get_failure_probabilities():
        machine_id = request.args.get('machine_id', type=int)
        
        if machine_id:
            parts = Part.query.filter_by(machine_id=machine_id).all()
        else:
            parts = Part.query.all()
        
        result = []
        for part in parts:
            probability = calculate_failure_probability(part.id)
            machine = Machine.query.get(part.machine_id)
            
            result.append({
                'id': part.id,
                'name': part.name,
                'machine_id': part.machine_id,
                'machine_name': machine.name,
                'probability': probability,
                'status': part.status
            })
        
        return jsonify(result)
    
    # API to add a new machine
    @app.route('/api/machine', methods=['POST'])
    def add_machine():
        data = request.json
        
        try:
            machine = Machine(
                name=data['name'],
                description=data.get('description'),
                asset_type=data.get('asset_type'),
                location=data.get('location'),
                manufacturer=data.get('manufacturer'),
                model_number=data.get('model_number'),
                serial_number=data.get('serial_number'),
                installation_date=datetime.strptime(data['installation_date'], '%Y-%m-%d').date() if data.get('installation_date') else None,
                status=data.get('status', 'operational')
            )
            
            db.session.add(machine)
            db.session.commit()
            
            return jsonify({'success': True, 'id': machine.id})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
    
    # API to add a new part
    @app.route('/api/part', methods=['POST'])
    def add_part():
        data = request.json
        
        try:
            part = Part(
                machine_id=data['machine_id'],
                parent_part_id=data.get('parent_part_id'),
                name=data['name'],
                description=data.get('description'),
                part_type=data.get('part_type'),
                manufacturer=data.get('manufacturer'),
                part_number=data.get('part_number'),
                installation_date=datetime.strptime(data['installation_date'], '%Y-%m-%d').date() if data.get('installation_date') else None,
                expected_lifetime_hours=data.get('expected_lifetime_hours'),
                status=data.get('status', 'operational')
            )
            
            db.session.add(part)
            db.session.commit()
            
            return jsonify({'success': True, 'id': part.id})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
    
    # API to update machine status
    @app.route('/api/machines/<int:machine_id>/status', methods=['PUT'])
    def update_machine_status(machine_id):
        data = request.json
        
        try:
            machine = db.session.get(Machine, machine_id)
            if not machine:
                return jsonify({'success': False, 'message': 'Machine not found'}), 404
                
            machine.status = data['status']
            db.session.commit()
            
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
    
    # API to update part status
    @app.route('/api/parts/<int:part_id>/status', methods=['PUT'])
    def update_part_status(part_id):
        data = request.json
        
        try:
            part = db.session.get(Part, part_id)
            if not part:
                return jsonify({'success': False, 'message': 'Part not found'}), 404
                
            part.status = data['status']
            db.session.commit()
            
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
    
    @app.route('/api/part/<int:part_id>')
    def get_part_details(part_id):
        part = Part.query.get_or_404(part_id)
        machine = Machine.query.get(part.machine_id)
        # Get last maintenance
        last_maintenance = MaintenanceRecord.query.filter_by(part_id=part_id).order_by(MaintenanceRecord.end_date.desc()).first()
        return jsonify({
            'id': part.id,
            'name': part.name,
            'status': part.status,
            'probability': calculate_failure_probability(part.id),
            'machine_id': part.machine_id,
            'machine_name': machine.name if machine else '',
            'last_maintenance': last_maintenance.end_date.strftime('%Y-%m-%d') if last_maintenance and last_maintenance.end_date else 'N/A',
            'notes': part.description or ''
        })
    
    @app.route('/api/machine/<int:machine_id>', methods=['DELETE'])
    def delete_machine(machine_id):
        machine = Machine.query.get_or_404(machine_id)
        try:
            db.session.delete(machine)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400

    @app.route('/api/part/<int:part_id>', methods=['DELETE'])
    def delete_part(part_id):
        part = Part.query.get_or_404(part_id)
        try:
            db.session.delete(part)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 400
