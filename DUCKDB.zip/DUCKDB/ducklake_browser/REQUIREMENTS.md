# DuckLake Browser UI — Detailed Requirements

## 1. Overview
DuckLake Browser is a modern web UI for DuckDB and DuckLake, enabling users to explore, query, ingest, and visualize data from local and cloud lakehouse sources. It is designed for data engineers, analysts, and scientists who want a powerful, intuitive interface for all their analytics needs.

---

## 2. User Roles
- **Admin:** Full access to all features, including catalog management and user management.
- **Analyst:** Can run queries, ingest data, manage tables, and visualize results.
- **Viewer:** Can browse data, run saved queries, and view results.

---

## 3. Core Features & User Stories

### 3.1 Home / Dashboard
- As a user, I want to see quick stats (number of catalogs, tables, recent queries, system health) when I log in.
- As a user, I want to see recent activity and shortcuts to common actions.

### 3.2 SQL Editor
- As a user, I want a SQL editor with syntax highlighting, autocomplete, and query history.
- As a user, I want to run queries against any attached DuckLake catalog or DuckDB table.
- As a user, I want to see query results in a table, with options to export (CSV, Parquet, Arrow) and visualize.
- As a user, I want to save and share queries.

### 3.3 Data Catalog / Explorer
- As a user, I want to browse all attached catalogs, schemas, and tables.
- As a user, I want to view table schemas, sample data, and metadata (row count, size, last updated).
- As an admin, I want to attach/detach new catalogs (S3, GCS, Azure, local files).

### 3.4 Ingestion & Upload
- As a user, I want to upload CSV, Parquet, or Arrow files and ingest them into DuckLake/DuckDB.
- As a user, I want to ingest data from cloud storage (S3, GCS, Azure) via URL or credentials.
- As a user, I want to see ingestion progress, errors, and success messages.

### 3.5 Table Management
- As a user, I want to create, drop, rename, and edit tables.
- As a user, I want to view and edit table schemas.
- As a user, I want to preview, filter, and paginate table data.

### 3.6 Query History & Saved Queries
- As a user, I want to see a list of past queries with timestamps, status, and results.
- As a user, I want to save favorite queries for reuse and share them with team members.

### 3.7 Visualization
- As a user, I want to visualize query results as bar, line, pie, scatter, and custom charts.
- As a user, I want a drag-and-drop chart builder for non-SQL users.

### 3.8 Lakehouse Management
- As an admin, I want to attach/detach DuckLake catalogs.
- As an admin, I want to configure cloud storage endpoints and credentials.
- As an admin, I want to monitor catalog health and sync status.

### 3.9 User Management (Optional)
- As an admin, I want to manage users, roles, and permissions.
- As an admin, I want to see audit logs for data access and query execution.

### 3.10 Settings
- As a user, I want to configure DuckDB/DuckLake settings (threads, memory, extensions).
- As a user, I want to manage API keys, integrations, and notifications.

---

## 4. Technical Requirements

### 4.1 Backend
- Python 3.9+
- Flask (REST API)
- DuckDB Python API
- DuckLake extension (must be loadable)
- Support for concurrent queries and ingestion
- Secure file upload and cloud credential management
- User authentication (Flask-Login or Authlib)
- API for all frontend features

### 4.2 Frontend
USE BOOTSTRAP
- Responsive design (desktop, tablet, mobile)
- SQL editor with Monaco or CodeMirror
- Data grid for results (AG Grid, React Table, or similar)
- Charting (Plotly, Chart.js, or ECharts)
- File upload UI
- Modal dialogs for table/catalog management
- User login/logout screens

### 4.3 Deployment
- Docker support (for local/cloud deployment)
- Configurable environment variables (for DB paths, cloud keys, etc.)
- HTTPS support

### 4.4 Security
- Input validation and sanitization
- Secure credential storage
- Role-based access control
- Audit logging (optional)

---

## 5. Stretch Goals
- Real-time query progress and cancellation
- Collaboration (shared queries, comments)
- Notebook mode (mix SQL, markdown, and charts)
- ML/AI integration (run models on data)
- Plugin system for custom analytics

---

## 6. Non-Functional Requirements
- Fast query execution and UI responsiveness
- Scalable to large datasets (cloud lakehouse)
- Accessible (WCAG 2.1 AA compliance)
- Internationalization (i18n) support

---

*This requirements document is the foundation for building the DuckLake Browser UI. Next steps: scaffold the Flask backend and React frontend, then implement core features screen by screen.* 