// Main JavaScript for ADW Workbench
document.addEventListener('DOMContentLoaded', function() {
    
    // Elements
    const catalogSelect = document.getElementById('catalog-select');
    const schemaSelect = document.getElementById('schema-select');
    const tableSelect = document.getElementById('table-select');
    const analysisTypeSelect = document.getElementById('analysis-type');
    const sqlInput = document.getElementById('sql-input');
    const selectedTablesList = document.getElementById('selected-tables');
    const runAnalysisBtn = document.getElementById('run-analysis-btn');
    const clearSelectionBtn = document.getElementById('clear-selection-btn');
    const loadingSpinner = document.getElementById('loading-spinner');
    const resultsPanel = document.getElementById('results-panel');
    
    // Loading spinner functions
    function showLoadingSpinner(targetElement) {
        if (!targetElement) return;
        
        // Save existing content
        const originalContent = targetElement.innerHTML;
        targetElement.dataset.originalContent = originalContent;
        
        // Create and add spinner
        const spinner = document.createElement('div');
        spinner.className = 'loading-spinner-container';
        spinner.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner-ring"></div>
                <div class="spinner-inner"></div>
            </div>
            <div class="spinner-text">Loading data...</div>
        `;
        
        targetElement.innerHTML = '';
        targetElement.appendChild(spinner);
    }
    
    function removeLoadingSpinner(targetElement) {
        if (!targetElement) return;
        
        const spinner = targetElement.querySelector('.loading-spinner-container');
        if (spinner) {
            // Add fade-out animation
            spinner.classList.add('fade-out');
            
            setTimeout(() => {
                // If original content was saved, restore it
                if (targetElement.dataset.originalContent) {
                    targetElement.innerHTML = targetElement.dataset.originalContent;
                    delete targetElement.dataset.originalContent;
                } else {
                    targetElement.innerHTML = '';
                }
            }, 300);
        }
    }
    
    // Initialization
    initSelects();
    setupEventListeners();
    
    // Initialize the select dropdowns
    function initSelects() {
        if (catalogSelect) {
            // Catalogs are loaded directly in the HTML template
            catalogSelect.addEventListener('change', function() {
                loadSchemas(this.value);
                schemaSelect.innerHTML = '<option value="">Select a schema</option>';
                tableSelect.innerHTML = '<option value="">Select a table</option>';
            });
        }
        
        if (schemaSelect) {
            schemaSelect.addEventListener('change', function() {
                if (this.value && catalogSelect.value) {
                    loadTables(catalogSelect.value, this.value);
                } else {
                    tableSelect.innerHTML = '<option value="">Select a table</option>';
                }
            });
        }
        
        if (tableSelect) {
            tableSelect.addEventListener('change', function() {
                // Enable the "Add Table" button if a table is selected
                const addTableBtn = document.getElementById('add-table-btn');
                if (addTableBtn) {
                    addTableBtn.disabled = !this.value;
                }
            });
        }
    }
    
    // Set up event listeners
    function setupEventListeners() {
        // Add Table button
        const addTableBtn = document.getElementById('add-table-btn');
        if (addTableBtn) {
            addTableBtn.addEventListener('click', function() {
                addSelectedTable();
            });
        }
        
        // Clear Selection button
        if (clearSelectionBtn) {
            clearSelectionBtn.addEventListener('click', function() {
                clearSelection();
            });
        }
        
        // Run Analysis button
        if (runAnalysisBtn) {
            runAnalysisBtn.addEventListener('click', function() {
                runAnalysis();
            });
        }
    }
    
    // Load schemas for a selected catalog
    function loadSchemas(catalogName) {
        if (!catalogName) return;
        
        // Show loading spinner
        const schemaContainer = document.getElementById('schema-select-container');
        if (schemaContainer) {
            showLoadingSpinner(schemaContainer);
        } else {
            // Fallback if container not found
            schemaSelect.innerHTML = '<option value="">Loading...</option>';
        }
        
        fetch(`/schemas/${catalogName}`)
            .then(response => response.json())
            .then(data => {
                if (schemaContainer) {
                    // Remove spinner and restore select
                    removeLoadingSpinner(schemaContainer);
                    schemaContainer.appendChild(schemaSelect);
                }
                
                schemaSelect.innerHTML = '<option value="">Select a schema</option>';
                data.forEach(schema => {
                    const option = document.createElement('option');
                    option.value = schema.name;
                    option.textContent = schema.name;
                    schemaSelect.appendChild(option);
                });
                
                // Add animation class
                schemaSelect.classList.add('animated-select');
            })
            .catch(error => {
                console.error('Error loading schemas:', error);
                schemaSelect.innerHTML = '<option value="">Error loading schemas</option>';
                
                if (schemaContainer) {
                    removeLoadingSpinner(schemaContainer);
                    schemaContainer.appendChild(schemaSelect);
                }
            });
    }
    
    // Load tables for a selected schema
    function loadTables(catalogName, schemaName) {
        if (!catalogName || !schemaName) return;
        
        // Show loading spinner
        const tableContainer = document.getElementById('table-select-container');
        if (tableContainer) {
            showLoadingSpinner(tableContainer);
        } else {
            // Fallback if container not found
            tableSelect.innerHTML = '<option value="">Loading...</option>';
        }
        
        fetch(`/tables/${catalogName}/${schemaName}`)
            .then(response => response.json())
            .then(data => {
                if (tableContainer) {
                    // Remove spinner and restore select
                    removeLoadingSpinner(tableContainer);
                    tableContainer.appendChild(tableSelect);
                }
                
                tableSelect.innerHTML = '<option value="">Select a table</option>';
                data.forEach(table => {
                    const option = document.createElement('option');
                    option.value = table.name;
                    option.textContent = `${table.name} (${table.type})`;
                    option.dataset.type = table.type;
                    option.dataset.format = table.data_source_format;
                    tableSelect.appendChild(option);
                });
                
                // Add animation class
                tableSelect.classList.add('animated-select');
            })
            .catch(error => {
                console.error('Error loading tables:', error);
                tableSelect.innerHTML = '<option value="">Error loading tables</option>';
                
                if (tableContainer) {
                    removeLoadingSpinner(tableContainer);
                    tableContainer.appendChild(tableSelect);
                }
            });
    }
    
    // Add the currently selected table to the analysis list
    function addSelectedTable() {
        if (!catalogSelect.value || !schemaSelect.value || !tableSelect.value) {
            showToast('Please select a catalog, schema, and table', 'warning');
            return;
        }
        
        const selectedOption = tableSelect.options[tableSelect.selectedIndex];
        const tableType = selectedOption.dataset.type || '';
        const tableFormat = selectedOption.dataset.format || '';
        
        // Add the table to the database via API
        fetch('/select_table', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                catalog: catalogSelect.value,
                schema: schemaSelect.value,
                table: tableSelect.value,
                type: tableType,
                data_source_format: tableFormat
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add to UI list
                addTableToUI(catalogSelect.value, schemaSelect.value, tableSelect.value, tableType);
                showToast(data.message, 'success');
            } else {
                showToast(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error adding table:', error);
            showToast('Error adding table to selection', 'danger');
        });
    }
    
    // Add a table to the UI selected tables list with red background and white text
    function addTableToUI(catalog, schema, table, type) {
        if (!selectedTablesList) return;
        
        const tableItem = document.createElement('div');
        tableItem.className = 'btn-selected-table';
        tableItem.dataset.catalog = catalog;
        tableItem.dataset.schema = schema;
        tableItem.dataset.table = table;
        
        tableItem.innerHTML = `
            <div>
                <span class="badge bg-light text-dark me-1">${type || 'TABLE'}</span>
                <strong>${catalog}.${schema}.${table}</strong>
            </div>
            <span class="remove-icon">&times;</span>
        `;
        
        // Add event listener to the remove button
        const removeIcon = tableItem.querySelector('.remove-icon');
        removeIcon.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent event bubbling
            
            // Add fade-out animation
            tableItem.style.opacity = '0';
            tableItem.style.transform = 'translateY(-10px)';
            
            setTimeout(() => {
                selectedTablesList.removeChild(tableItem);
                
                // Check if no tables left and disable run button if needed
                if (selectedTablesList.children.length === 0) {
                    runAnalysisBtn.disabled = true;
                }
            }, 300);
        });
        
        // Add entrance animation
        tableItem.style.opacity = '0';
        tableItem.style.transform = 'translateY(10px)';
        selectedTablesList.appendChild(tableItem);
        
        // Trigger animation after a short delay (allows DOM to update)
        setTimeout(() => {
            tableItem.style.opacity = '1';
            tableItem.style.transform = 'translateY(0)';
        }, 10);
        
        // Enable the Run Analysis button
        runAnalysisBtn.disabled = false;
    }
    
    // Clear all selected tables
    function clearSelection() {
        if (!selectedTablesList) return;
        
        // Call the API to clear selection
        fetch('/clear_selection', {
            method: 'POST',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Clear the UI
                selectedTablesList.innerHTML = '';
                runAnalysisBtn.disabled = true;
                showToast(data.message, 'success');
            } else {
                showToast(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error clearing selection:', error);
            showToast('Error clearing selection', 'danger');
        });
    }
    
    // Run the analysis
    function runAnalysis() {
        if (selectedTablesList.children.length === 0) {
            showToast('Please select at least one table for analysis', 'warning');
            return;
        }
        
        // Show loading state
        if (loadingSpinner) {
            loadingSpinner.classList.remove('d-none');
        }
        
        // Submit the form
        document.getElementById('analysis-form').submit();
    }
    
    // Helper function to show toast notifications
    function showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        // Initialize and show the toast
        const bsToast = new bootstrap.Toast(toast, {
            autohide: true,
            delay: 3000
        });
        bsToast.show();
        
        // Remove the toast from the DOM after it's hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toastContainer.removeChild(toast);
        });
    }
    
    // Initialize any Chart.js charts if present
    initCharts();
    
    function initCharts() {
        const chartElements = document.querySelectorAll('.metric-chart');
        
        chartElements.forEach(function(element) {
            const ctx = element.getContext('2d');
            const chartType = element.dataset.type || 'bar';
            const chartData = JSON.parse(element.dataset.data || '{}');
            
            new Chart(ctx, {
                type: chartType,
                data: chartData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    }
                }
            });
        });
    }
    
    // Initialize mermaid diagrams if any
    if (typeof mermaid !== 'undefined') {
        mermaid.initialize({
            startOnLoad: true,
            theme: 'neutral',
            securityLevel: 'loose',
            fontFamily: '"Inter", sans-serif',
        });
    }
});
