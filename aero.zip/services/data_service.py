import pandas as pd
import numpy as np
from datetime import datetime
import logging
from flask import current_app
from app import db
from models import Flight, Aircraft, Crew

logger = logging.getLogger(__name__)

def analyze_data_quality(df):
    """
    Analyze the quality of a dataframe according to various metrics
    Returns a dictionary with quality metrics
    """
    total_rows = len(df)
    if total_rows == 0:
        return {
            "accuracy": 0,
            "completeness": 0,
            "consistency": 0,
            "uniqueness": 0,
            "validity": 0,
            "timeliness": 0,
            "overall_score": 0
        }
    
    # Completeness: Percentage of non-null values
    completeness = 1 - (df.isna().sum().sum() / (total_rows * len(df.columns)))
    
    # Uniqueness: Check for duplicate rows
    uniqueness = 1 - (df.duplicated().sum() / total_rows)
    
    # Validity: Check basic data types and ranges 
    # (simplified version - would be more complex in a real system)
    validity_checks = []
    for col in df.columns:
        if df[col].dtype == 'datetime64[ns]' or pd.api.types.is_datetime64_any_dtype(df[col]):
            # Check if dates are in a reasonable range
            min_date = pd.Timestamp.min.tz_localize(None)
            max_date = pd.Timestamp.max.tz_localize(None)
            valid_dates = ((df[col] > min_date) & (df[col] < max_date)).mean()
            validity_checks.append(valid_dates)
        elif pd.api.types.is_numeric_dtype(df[col]):
            # Check if numeric values are not infinite
            valid_numbers = (~np.isinf(df[col]) & ~np.isnan(df[col])).mean()
            validity_checks.append(valid_numbers)
        else:
            # For string columns, check if not empty
            valid_strings = (df[col].astype(str).str.strip() != '').mean()
            validity_checks.append(valid_strings)
    
    validity = sum(validity_checks) / len(validity_checks) if validity_checks else 0
    
    # Check for timeliness (assume any date column named 'date', 'timestamp', etc.)
    timeliness = 0
    date_cols = [col for col in df.columns if any(date_term in col.lower() for date_term in ['date', 'time', 'day', 'month', 'year'])]
    if date_cols:
        for col in date_cols:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                # Check how recent the data is (within last 30 days)
                now = pd.Timestamp.now()
                time_diff = (now - df[col].max()).days
                if time_diff <= 30:
                    timeliness = 1 - (time_diff / 30)
                break
    
    # Consistency and accuracy are more complex and would require domain knowledge
    # For this example, we'll use placeholder values
    consistency = 0.9  # Placeholder
    accuracy = 0.9     # Placeholder
    
    # Calculate overall score (weighted average)
    weights = {
        "accuracy": 0.2,
        "completeness": 0.2, 
        "consistency": 0.15,
        "uniqueness": 0.15,
        "validity": 0.15,
        "timeliness": 0.15
    }
    
    scores = {
        "accuracy": accuracy,
        "completeness": completeness,
        "consistency": consistency,
        "uniqueness": uniqueness,
        "validity": validity,
        "timeliness": timeliness
    }
    
    overall_score = sum(scores[metric] * weight for metric, weight in weights.items())
    
    # Add overall score to the results
    scores["overall_score"] = overall_score
    
    return scores

def save_data_to_db(df, category, source_id):
    """
    Save data from a dataframe to the appropriate database tables based on category
    Returns a dictionary with information about what was saved
    """
    if not df.empty:
        try:
            if category.lower() in ['flight schedules', 'commercial schedules']:
                _save_flight_data(df, source_id)
            elif category.lower() in ['aircraft operations', 'aircraft assignments']:
                _save_aircraft_data(df, source_id)
            elif category.lower() in ['crew schedules', 'crew management']:
                _save_crew_data(df, source_id)
            else:
                # Generic save for other categories (not implemented)
                logger.info(f"No specific save method for category: {category}")
            
            return {"success": True, "rows_processed": len(df)}
        
        except Exception as e:
            logger.exception(f"Error saving data to DB: {str(e)}")
            return {"success": False, "error": str(e)}
    
    return {"success": False, "error": "Empty dataframe"}

def _save_flight_data(df, source_id):
    """Save flight schedule data to the Flight model"""
    for _, row in df.iterrows():
        try:
            # Map dataframe columns to Flight model fields
            # This is a simplistic approach - in a real application, you'd want to be more robust
            flight_data = {}
            
            # Try to map common column names to model fields
            if 'flight_number' in df.columns:
                flight_data['flight_number'] = row['flight_number']
            elif 'flight_num' in df.columns:
                flight_data['flight_number'] = row['flight_num']
            else:
                # Required field - can't proceed without it
                logger.warning(f"Could not find flight number column, skipping row")
                continue
            
            # Map origin and destination
            for origin_col in ['origin', 'dep_airport', 'departure_airport', 'from']:
                if origin_col in df.columns:
                    flight_data['origin'] = row[origin_col]
                    break
            
            for dest_col in ['destination', 'arr_airport', 'arrival_airport', 'to']:
                if dest_col in df.columns:
                    flight_data['destination'] = row[dest_col]
                    break
            
            # Map departure and arrival times
            for dep_time_col in ['scheduled_departure', 'dep_time', 'std', 'departure_time']:
                if dep_time_col in df.columns and pd.notna(row[dep_time_col]):
                    flight_data['scheduled_departure'] = pd.to_datetime(row[dep_time_col])
                    break
            
            for arr_time_col in ['scheduled_arrival', 'arr_time', 'sta', 'arrival_time']:
                if arr_time_col in df.columns and pd.notna(row[arr_time_col]):
                    flight_data['scheduled_arrival'] = pd.to_datetime(row[arr_time_col])
                    break
            
            # Map aircraft
            for aircraft_col in ['aircraft_id', 'aircraft', 'tail_number', 'registration']:
                if aircraft_col in df.columns:
                    flight_data['aircraft_id'] = row[aircraft_col]
                    break
            
            # Create new Flight or update existing
            existing_flight = Flight.query.filter_by(
                flight_number=flight_data['flight_number'],
                scheduled_departure=flight_data.get('scheduled_departure')
            ).first()
            
            if existing_flight:
                # Update existing flight
                for key, value in flight_data.items():
                    setattr(existing_flight, key, value)
            else:
                # Create new flight
                flight = Flight(**flight_data)
                db.session.add(flight)
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            logger.exception(f"Error saving flight data: {str(e)}")

def _save_aircraft_data(df, source_id):
    """Save aircraft data to the Aircraft model"""
    for _, row in df.iterrows():
        try:
            # Map dataframe columns to Aircraft model fields
            aircraft_data = {}
            
            # Try to map common column names to model fields
            for reg_col in ['registration', 'tail_number', 'aircraft_id', 'reg']:
                if reg_col in df.columns:
                    aircraft_data['registration'] = row[reg_col]
                    break
            else:
                # Required field - can't proceed without it
                logger.warning("Could not find aircraft registration column, skipping row")
                continue
            
            # Map aircraft type
            for type_col in ['aircraft_type', 'type', 'model']:
                if type_col in df.columns:
                    aircraft_data['aircraft_type'] = row[type_col]
                    break
            
            # Map capacity
            for cap_col in ['capacity', 'seats', 'max_pax']:
                if cap_col in df.columns and pd.notna(row[cap_col]):
                    aircraft_data['capacity'] = int(row[cap_col])
                    break
            
            # Map range
            for range_col in ['range', 'range_nm', 'max_range']:
                if range_col in df.columns and pd.notna(row[range_col]):
                    aircraft_data['range_nm'] = float(row[range_col])
                    break
            
            # Map status
            for status_col in ['status', 'aircraft_status', 'availability']:
                if status_col in df.columns:
                    aircraft_data['status'] = row[status_col]
                    break
            
            # Map maintenance status
            for maint_col in ['maintenance_status', 'maint_status']:
                if maint_col in df.columns:
                    aircraft_data['maintenance_status'] = row[maint_col]
                    break
            
            # Map next maintenance
            for next_maint_col in ['next_maintenance', 'next_check', 'next_service']:
                if next_maint_col in df.columns and pd.notna(row[next_maint_col]):
                    aircraft_data['next_maintenance'] = pd.to_datetime(row[next_maint_col])
                    break
            
            # Create new Aircraft or update existing
            existing_aircraft = Aircraft.query.filter_by(registration=aircraft_data['registration']).first()
            
            if existing_aircraft:
                # Update existing aircraft
                for key, value in aircraft_data.items():
                    setattr(existing_aircraft, key, value)
            else:
                # Create new aircraft
                aircraft = Aircraft(**aircraft_data)
                db.session.add(aircraft)
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            logger.exception(f"Error saving aircraft data: {str(e)}")

def _save_crew_data(df, source_id):
    """Save crew data to the Crew model"""
    for _, row in df.iterrows():
        try:
            # Map dataframe columns to Crew model fields
            crew_data = {}
            
            # Try to map common column names to model fields
            for id_col in ['staff_id', 'crew_id', 'employee_id', 'id']:
                if id_col in df.columns:
                    crew_data['staff_id'] = str(row[id_col])
                    break
            else:
                # Required field - can't proceed without it
                logger.warning("Could not find crew ID column, skipping row")
                continue
            
            # Map name
            for name_col in ['name', 'crew_name', 'full_name']:
                if name_col in df.columns:
                    crew_data['name'] = row[name_col]
                    break
            
            # Map position
            for pos_col in ['position', 'role', 'crew_position', 'job_title']:
                if pos_col in df.columns:
                    crew_data['position'] = row[pos_col]
                    break
            
            # Map qualifications
            for qual_col in ['qualifications', 'quals', 'certifications']:
                if qual_col in df.columns and pd.notna(row[qual_col]):
                    # Assuming qualifications is a JSON string or list
                    if isinstance(row[qual_col], str):
                        try:
                            crew_data['qualifications'] = json.loads(row[qual_col])
                        except:
                            crew_data['qualifications'] = [q.strip() for q in row[qual_col].split(',')]
                    elif isinstance(row[qual_col], list):
                        crew_data['qualifications'] = row[qual_col]
                    break
            
            # Map base
            for base_col in ['base', 'crew_base', 'home_base']:
                if base_col in df.columns:
                    crew_data['base'] = row[base_col]
                    break
            
            # Map status
            for status_col in ['status', 'crew_status', 'availability']:
                if status_col in df.columns:
                    crew_data['status'] = row[status_col]
                    break
            
            # Map duty time remaining
            for duty_col in ['duty_time_remaining', 'remaining_duty', 'duty_left']:
                if duty_col in df.columns and pd.notna(row[duty_col]):
                    crew_data['duty_time_remaining'] = float(row[duty_col])
                    break
            
            # Map rest required
            for rest_col in ['rest_required', 'required_rest', 'rest_time']:
                if rest_col in df.columns and pd.notna(row[rest_col]):
                    crew_data['rest_required'] = float(row[rest_col])
                    break
            
            # Create new Crew or update existing
            existing_crew = Crew.query.filter_by(staff_id=crew_data['staff_id']).first()
            
            if existing_crew:
                # Update existing crew
                for key, value in crew_data.items():
                    setattr(existing_crew, key, value)
            else:
                # Create new crew
                crew = Crew(**crew_data)
                db.session.add(crew)
            
            db.session.commit()
            
        except Exception as e:
            db.session.rollback()
            logger.exception(f"Error saving crew data: {str(e)}")
