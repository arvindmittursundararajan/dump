// Visualize page JavaScript

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize date pickers
    initializeDatePickers();
    
    // Load machines for the filter
    loadMachinesForFilter();
    
    // Set up filter change events
    setupFilterEvents();
    
    // Load initial failure probability data
    loadFailureProbabilities();
});

// Initialize date pickers
function initializeDatePickers() {
    // Use native date inputs with fallback to library if needed
    const dateInputs = document.querySelectorAll('input[type="date"]');
    
    // Set default values (last 30 days)
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);
    
    dateInputs.forEach(input => {
        if (input.id === 'start-date') {
            input.valueAsDate = thirtyDaysAgo;
        } else if (input.id === 'end-date') {
            input.valueAsDate = today;
        }
    });
}

// Load machines for the filter dropdown
function loadMachinesForFilter() {
    const machineSelect = document.getElementById('machine-filter');
    
    if (!machineSelect) return;
    
    // Show loading state
    machineSelect.innerHTML = '<option value="">Loading machines...</option>';
    
    // Fetch machines from API
    fetch('/api/machines')
        .then(response => response.json())
        .then(data => {
            machineSelect.innerHTML = '<option value="">All Machines</option>';
            
            data.forEach(machine => {
                const option = document.createElement('option');
                option.value = machine.id;
                option.textContent = machine.name;
                machineSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading machines:', error);
            machineSelect.innerHTML = '<option value="">Failed to load machines</option>';
        });
}

// Set up filter change events
function setupFilterEvents() {
    // Machine filter change
    const machineFilter = document.getElementById('machine-filter');
    if (machineFilter) {
        machineFilter.addEventListener('change', function() {
            loadPartsForMachine(this.value);
            loadFailureProbabilities(this.value);
        });
    }
    
    // Apply filters button
    const applyButton = document.getElementById('apply-filters');
    if (applyButton) {
        applyButton.addEventListener('click', function() {
            const machineId = document.getElementById('machine-filter').value;
            loadFailureProbabilities(machineId);
        });
    }
}

// Load parts for the selected machine
function loadPartsForMachine(machineId) {
    const partSelect = document.getElementById('part-filter');
    
    if (!partSelect) return;
    
    // Clear part select if no machine is selected
    if (!machineId) {
        partSelect.innerHTML = '<option value="">All Parts</option>';
        return;
    }
    
    // Show loading state
    partSelect.innerHTML = '<option value="">Loading parts...</option>';
    
    // Fetch parts for the selected machine
    fetch(`/api/machine/${machineId}/parts`)
        .then(response => response.json())
        .then(data => {
            partSelect.innerHTML = '<option value="">All Parts</option>';
            
            data.forEach(part => {
                const option = document.createElement('option');
                option.value = part.id;
                option.textContent = part.name;
                partSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading parts:', error);
            partSelect.innerHTML = '<option value="">Failed to load parts</option>';
        });
}

// Load failure probabilities for the chart
function loadFailureProbabilities(machineId) {
    const chartCanvas = document.getElementById('failure-probability-chart');
    const tableContainer = document.getElementById('failure-table');
    if (!chartCanvas || !tableContainer) return;
    // Show loading state
    const ctx = chartCanvas.getContext('2d');
    ctx.clearRect(0, 0, chartCanvas.width, chartCanvas.height);
    ctx.font = '18px Segoe UI';
    ctx.fillStyle = '#888';
    ctx.textAlign = 'center';
    ctx.fillText('Loading failure probability data...', chartCanvas.width / 2, chartCanvas.height / 2);
    tableContainer.innerHTML = '';
    // Build the API URL with filters
    let url = '/api/failure-probabilities';
    if (machineId) {
        url += `?machine_id=${machineId}`;
    }
    // Fetch data
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                ctx.clearRect(0, 0, chartCanvas.width, chartCanvas.height);
                ctx.fillStyle = '#888';
                ctx.fillText('No data available for the selected filters.', chartCanvas.width / 2, chartCanvas.height / 2);
                tableContainer.innerHTML = '';
                return;
            }
            renderFailureProbabilityChart(data, chartCanvas);
            renderFailureTable(data, tableContainer);
        })
        .catch(error => {
            ctx.clearRect(0, 0, chartCanvas.width, chartCanvas.height);
            ctx.fillStyle = '#dc3545';
            ctx.fillText('Failed to load failure probability data.', chartCanvas.width / 2, chartCanvas.height / 2);
            tableContainer.innerHTML = '';
        });
}

// Render modern failure probability chart using Chart.js
let failureChartInstance = null;
function renderFailureProbabilityChart(data, canvas) {
    // Group by machine, flatten to part list
    let parts = [];
    data.forEach(item => parts.push(item));
    // Sort by probability descending
    parts.sort((a, b) => b.probability - a.probability);
    // Limit to top 12 for clarity
    parts = parts.slice(0, 12);
    // Prepare chart data
    const labels = parts.map(p => p.name.length > 18 ? p.name.slice(0, 16) + '…' : p.name);
    const values = parts.map(p => Math.round(p.probability * 100));
    // Destroy previous chart if exists
    if (failureChartInstance) failureChartInstance.destroy();
    failureChartInstance = new Chart(canvas, {
        type: 'horizontalBar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Failure Probability (%)',
                data: values,
                backgroundColor: values.map(v => v > 70 ? '#dc3545' : v > 40 ? '#ff7675' : '#222'),
                borderColor: '#dc3545',
                borderWidth: 2,
                hoverBackgroundColor: '#bd2130',
                barPercentage: 0.7,
                categoryPercentage: 0.7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                display: false
            },
            title: {
                display: false
            },
            scales: {
                xAxes: [{
                    ticks: {
                        beginAtZero: true,
                        fontColor: '#111',
                        fontSize: 14,
                        callback: function(value) { return value + '%'; }
                    },
                    gridLines: {
                        color: '#eee',
                        zeroLineColor: '#dc3545',
                        zeroLineWidth: 2
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Failure Probability (%)',
                        fontColor: '#dc3545',
                        fontSize: 16,
                        fontStyle: 'bold'
                    }
                }],
                yAxes: [{
                    ticks: {
                        fontColor: '#111',
                        fontSize: 15,
                        fontStyle: 'bold'
                    },
                    gridLines: {
                        color: '#f5f5f5',
                        zeroLineColor: '#dc3545',
                        zeroLineWidth: 2
                    }
                }]
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        return data.labels[tooltipItem.index] + ': ' + data.datasets[0].data[tooltipItem.index] + '%';
                    }
                },
                backgroundColor: '#fff',
                titleFontColor: '#dc3545',
                bodyFontColor: '#111',
                borderColor: '#dc3545',
                borderWidth: 1
            },
            animation: {
                duration: 1200,
                easing: 'easeOutQuart'
            }
        }
    });
}

// Render failure probability table
function renderFailureTable(data, container) {
    // Sort data by probability (descending)
    data.sort((a, b) => b.probability - a.probability);
    
    // Create the table
    const table = document.createElement('table');
    table.className = 'table table-striped table-hover';
    
    // Create header
    const thead = document.createElement('thead');
    thead.innerHTML = `
        <tr>
            <th>Machine</th>
            <th>Part</th>
            <th>Status</th>
            <th>Failure Probability</th>
            <th>Actions</th>
        </tr>
    `;
    table.appendChild(thead);
    
    // Create body
    const tbody = document.createElement('tbody');
    
    data.forEach(item => {
        const row = document.createElement('tr');
        
        // Set row color based on probability
        if (item.probability > 0.7) {
            row.className = 'table-danger';
        } else if (item.probability > 0.4) {
            row.className = 'table-warning';
        }
        
        row.innerHTML = `
            <td>${item.machine_name}</td>
            <td>${item.name}</td>
            <td>${item.status}</td>
            <td>
                <div class="progress">
                    <div class="progress-bar bg-danger" role="progressbar" style="width: ${item.probability * 100}%" 
                         aria-valuenow="${item.probability * 100}" aria-valuemin="0" aria-valuemax="100">
                        ${Math.round(item.probability * 100)}%
                    </div>
                </div>
            </td>
            <td>
                <button class="btn btn-sm btn-outline-primary view-part-btn" data-part-id="${item.id}">View</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
    
    table.appendChild(tbody);
    container.appendChild(table);
    
    // Add event listeners to view buttons
    const viewButtons = document.querySelectorAll('.view-part-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const partId = this.dataset.partId;
            showPartDetails(partId);
        });
    });
}

// Show detailed part information
function showPartDetails(partId) {
    // Fetch part details from API
    fetch(`/api/part/${partId}`)
        .then(response => response.json())
        .then(data => {
            // After showing modal, fetch AI recommendation
            showPartDetailsModal(data);
            fetchAiRecommendationForPart(data);
        })
        .catch(() => {
            showPartDetailsModal({
                name: 'Unknown',
                status: 'Unknown',
                probability: 'N/A',
                machine_name: '',
                last_maintenance: 'N/A',
                notes: 'Failed to load details.'
            });
        });
}

function showPartDetailsModal(data) {
    // Remove existing modal if present
    const existing = document.getElementById('part-details-modal');
    if (existing) existing.remove();

    // Create modal HTML
    const modal = document.createElement('div');
    modal.id = 'part-details-modal';
    modal.className = 'modal fade show';
    modal.style.display = 'block';
    modal.style.background = 'rgba(0,0,0,0.4)';
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Part Details: ${data.name || ''}</h5>
                    <button type="button" class="close" id="close-part-modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <p><strong>Machine:</strong> ${data.machine_name || ''}</p>
                    <p><strong>Status:</strong> ${data.status || ''}</p>
                    <p><strong>Failure Probability:</strong> ${typeof data.probability === 'number' ? Math.round(data.probability * 100) + '%' : data.probability}</p>
                    <p><strong>Last Maintenance:</strong> ${data.last_maintenance || 'N/A'}</p>
                    <p><strong>Notes:</strong> ${data.notes || ''}</p>
                    <div id="ai-recommendation-modal" style="margin-top:18px;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="close-part-modal-footer">Close</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    // Close modal on click
    document.getElementById('close-part-modal').onclick = () => modal.remove();
    document.getElementById('close-part-modal-footer').onclick = () => modal.remove();
    // Dismiss modal on background click
    modal.onclick = e => { if (e.target === modal) modal.remove(); };
}

function fetchAiRecommendationForPart(data) {
    // Compose a short context for Gemini
    const question = 'Give 2-3 line actionable maintenance recommendations for this part.';
    const assetDetails = {
        name: data.name,
        type: data.part_type,
        status: data.status,
        machine_name: data.machine_name,
        probability: data.probability,
        last_maintenance: data.last_maintenance,
        notes: data.notes
    };
    const aiDiv = document.getElementById('ai-recommendation-modal');
    if (aiDiv) {
        aiDiv.innerHTML = '<div class="text-center"><div class="spinner-border text-danger" role="status"></div><p class="mt-2">Getting AI recommendation...</p></div>';
    }
    fetch('/api/ask-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            question: question,
            part_id: data.id
        })
    })
    .then(res => res.json())
    .then(res => {
        if (aiDiv) {
            aiDiv.innerHTML = '<div class="mb-2"><strong>AI Recommendation:</strong></div>' + (res.response || '<em>No recommendation available.</em>');
        }
    })
    .catch(() => {
        if (aiDiv) {
            aiDiv.innerHTML = '<em>Failed to get AI recommendation.</em>';
        }
    });
}

// Function to render the what-if simulator
// This would be a more complex implementation in a real application
function renderWhatIfSimulator() {
    const container = document.getElementById('what-if-simulator');
    
    if (!container) return;
    
    container.innerHTML = `
        <div class="card">
            <div class="card-header">
                What-If Simulator
            </div>
            <div class="card-body">
                <p>Adjust the parameters below to simulate different operating conditions:</p>
                
                <div class="form-group">
                    <label for="operating-hours">Daily Operating Hours</label>
                    <input type="range" class="form-control-range" id="operating-hours" min="1" max="24" value="8">
                    <small class="form-text text-muted">Current value: <span id="hours-value">8</span> hours/day</small>
                </div>
                
                <div class="form-group">
                    <label for="load-factor">Load Factor</label>
                    <input type="range" class="form-control-range" id="load-factor" min="10" max="100" value="70">
                    <small class="form-text text-muted">Current value: <span id="load-value">70</span>%</small>
                </div>
                
                <div class="form-group">
                    <label for="maintenance-interval">Preventive Maintenance Interval (days)</label>
                    <input type="range" class="form-control-range" id="maintenance-interval" min="7" max="180" value="30">
                    <small class="form-text text-muted">Current value: <span id="interval-value">30</span> days</small>
                </div>
                
                <button id="simulate-btn" class="btn btn-primary">Run Simulation</button>
                
                <div id="simulation-results" class="mt-4"></div>
            </div>
        </div>
    `;
    
    // Add event listeners for the range inputs
    const operatingHours = document.getElementById('operating-hours');
    const loadFactor = document.getElementById('load-factor');
    const maintenanceInterval = document.getElementById('maintenance-interval');
    
    operatingHours.addEventListener('input', function() {
        document.getElementById('hours-value').textContent = this.value;
    });
    
    loadFactor.addEventListener('input', function() {
        document.getElementById('load-value').textContent = this.value;
    });
    
    maintenanceInterval.addEventListener('input', function() {
        document.getElementById('interval-value').textContent = this.value;
    });
    
    // Add event listener for the simulate button
    document.getElementById('simulate-btn').addEventListener('click', function() {
        runSimulation(
            parseInt(operatingHours.value),
            parseInt(loadFactor.value),
            parseInt(maintenanceInterval.value)
        );
    });
}

// Simple simulation function
function runSimulation(hours, load, interval) {
    const resultsContainer = document.getElementById('simulation-results');
    
    // Show loading state
    resultsContainer.innerHTML = '<div class="text-center"><div class="spinner-border text-danger" role="status"></div><p class="mt-2">Running simulation...</p></div>';
    
    // Simulate API call delay
    setTimeout(() => {
        // For demo purposes, just calculate a simple result
        const baselineLifeHours = 10000;
        const loadFactor = load / 70; // Normalize to baseline of 70%
        const adjustedLifeHours = baselineLifeHours / (loadFactor * (hours / 8));
        const daysToFailure = adjustedLifeHours / hours;
        
        // Calculate maintenance impact
        const maintenanceEfficiency = Math.min(1, 30 / interval);
        const adjustedDaysWithMaintenance = daysToFailure / maintenanceEfficiency;
        
        // Calculate costs
        const dailyCost = hours * 50; // $50 per hour operating cost
        const maintenanceCost = 2000 / interval * 30; // Monthly maintenance cost
        const totalMonthlyCost = dailyCost * 30 + maintenanceCost;
        
        // Render results
        resultsContainer.innerHTML = `
            <h5>Simulation Results</h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Estimated Days to Failure (No Maintenance)</th>
                        <td>${Math.round(daysToFailure)} days</td>
                    </tr>
                    <tr>
                        <th>Estimated Days to Failure (With Maintenance)</th>
                        <td>${Math.round(adjustedDaysWithMaintenance)} days</td>
                    </tr>
                    <tr>
                        <th>Estimated Monthly Operating Cost</th>
                        <td>$${Math.round(dailyCost * 30).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <th>Estimated Monthly Maintenance Cost</th>
                        <td>$${Math.round(maintenanceCost).toLocaleString()}</td>
                    </tr>
                    <tr>
                        <th>Estimated Total Monthly Cost</th>
                        <td>$${Math.round(totalMonthlyCost).toLocaleString()}</td>
                    </tr>
                </table>
            </div>
            <div class="alert alert-info">
                <strong>Recommendation:</strong> Based on your parameters, we recommend a maintenance interval of 
                ${Math.round(daysToFailure * 0.7)} days to optimize cost and reliability.
            </div>
        `;
    }, 1500);
}
