/**
 * AeroOptima.ai - Debrief Module
 * Handles incident analysis and root cause analysis
 */

// Keep track of current incidents
let currentIncidents = [];
let selectedIncidentId = null;

// Initialize on document load
document.addEventListener('DOMContentLoaded', function() {
    // Load incidents
    loadIncidents();
    
    // Setup incident creation form
    setupIncidentForm();
    
    // Initialize timeline chart
    initTimelineChart();
});

/**
 * Load incidents from the API
 */
function loadIncidents() {
    const incidentsContainer = document.getElementById('incidents-container');
    if (!incidentsContainer) return;
    
    // Show loading state
    incidentsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading incidents...</p>';
    
    // Fetch incidents
    fetch('/api/incidents')
        .then(response => response.json())
        .then(data => {
            // Store current incidents
            currentIncidents = data;
            
            if (data.length === 0) {
                incidentsContainer.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No incidents recorded yet. Create your first incident to begin analysis.
                    </div>
                `;
                return;
            }
            
            // Create HTML
            let html = '';
            
            // Group by category
            const groupedIncidents = {};
            data.forEach(incident => {
                if (!groupedIncidents[incident.category]) {
                    groupedIncidents[incident.category] = [];
                }
                groupedIncidents[incident.category].push(incident);
            });
            
            // Add incidents by category
            for (const category in groupedIncidents) {
                html += `
                    <div class="mb-3">
                        <h6 class="mb-2">${category}</h6>
                `;
                
                // Add incidents for this category
                groupedIncidents[category].forEach(incident => {
                    const severityClass = incident.severity === 'critical' ? 'critical' : 
                                         incident.severity === 'major' ? 'warning' : 'info';
                                         
                    html += `
                        <div class="incident-card card mb-2 ${severityClass} ${selectedIncidentId === incident.id ? 'active' : ''}"
                             data-id="${incident.id}"
                             data-category="${incident.category}"
                             data-severity="${incident.severity}"
                             data-start-time="${incident.start_time}"
                             onclick="selectIncident(${incident.id})">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h5 class="card-title">${incident.title}</h5>
                                    <span class="badge ${incident.severity === 'critical' ? 'bg-danger' : 
                                                        incident.severity === 'major' ? 'bg-warning' : 'bg-info'}">
                                        ${incident.severity}
                                    </span>
                                </div>
                                <p class="card-text small">${truncateText(incident.description || '', 100)}</p>
                                <div class="small text-muted">
                                    Started: ${formatDate(incident.start_time)}
                                    ${incident.end_time ? ` • Ended: ${formatDate(incident.end_time)}` : ''}
                                </div>
                            </div>
                        </div>
                    `;
                });
                
                html += '</div>';
            }
            
            // Update container
            incidentsContainer.innerHTML = html;
            
            // Select first incident if none selected
            if (!selectedIncidentId && data.length > 0) {
                selectIncident(data[0].id);
            }
        })
        .catch(error => {
            incidentsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading incidents: ${error.message}
                </div>
            `;
            console.error('Failed to load incidents:', error);
        });
}

/**
 * Setup incident creation form
 */
function setupIncidentForm() {
    const incidentForm = document.getElementById('incident-form');
    
    if (incidentForm) {
        // Initialize datetime pickers
        const startTimePicker = document.getElementById('incident-start-time');
        const endTimePicker = document.getElementById('incident-end-time');
        
        if (startTimePicker && endTimePicker) {
            // Set default values to today
            const now = new Date();
            const nowStr = now.toISOString().slice(0, 16);
            startTimePicker.value = nowStr;
            
            // End time defaults to 2 hours later
            const twoHoursLater = new Date(now.getTime() + 2 * 60 * 60 * 1000);
            const twoHoursLaterStr = twoHoursLater.toISOString().slice(0, 16);
            endTimePicker.value = twoHoursLaterStr;
        }
        
        // Handle form submission
        incidentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const title = document.getElementById('incident-title').value;
            const description = document.getElementById('incident-description').value;
            const startTime = document.getElementById('incident-start-time').value;
            const endTime = document.getElementById('incident-end-time').value;
            const category = document.getElementById('incident-category').value;
            const severity = document.getElementById('incident-severity').value;
            
            // Validate
            if (!title || !startTime || !category || !severity) {
                showToast('Title, start time, category, and severity are required', 'warning');
                return;
            }
            
            // Create incident data
            const incidentData = {
                title,
                description,
                start_time: startTime,
                end_time: endTime || null,
                category,
                severity
            };
            
            // Show loading state
            const submitBtn = incidentForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating...';
            
            // Send to API
            fetch('/api/incidents', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(incidentData)
            })
            .then(response => response.json())
            .then(data => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                if (data.error) {
                    throw new Error(data.error);
                }
                
                // Show success message
                showToast('Incident created successfully', 'success');
                
                // Reset form
                incidentForm.reset();
                
                // Set default dates again
                const now = new Date();
                const nowStr = now.toISOString().slice(0, 16);
                startTimePicker.value = nowStr;
                
                const twoHoursLater = new Date(now.getTime() + 2 * 60 * 60 * 1000);
                const twoHoursLaterStr = twoHoursLater.toISOString().slice(0, 16);
                endTimePicker.value = twoHoursLaterStr;
                
                // Close modal if open
                const modal = bootstrap.Modal.getInstance(document.getElementById('new-incident-modal'));
                if (modal) {
                    modal.hide();
                }
                
                // Reload incidents and select the new one
                loadIncidents();
                setTimeout(() => {
                    selectIncident(data.id);
                }, 500);
            })
            .catch(error => {
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
                
                // Show error message
                showToast('Failed to create incident: ' + error.message, 'danger');
                console.error('Incident creation error:', error);
            });
        });
    }
}

/**
 * Initialize the timeline chart
 */
function initTimelineChart() {
    // This will be populated when an incident is selected
    const timelineContainer = document.getElementById('timeline-chart');
    if (timelineContainer) {
        timelineContainer.innerHTML = `
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Select an incident to view its timeline.
            </div>
        `;
    }
}

/**
 * Select an incident and show its details
 * @param {number} incidentId - ID of the incident to select
 */
function selectIncident(incidentId) {
    selectedIncidentId = incidentId;
    
    // Update UI to show selected incident
    const incidentCards = document.querySelectorAll('.incident-card');
    incidentCards.forEach(card => {
        if (parseInt(card.dataset.id, 10) === incidentId) {
            card.classList.add('active');
        } else {
            card.classList.remove('active');
        }
    });
    
    // Load incident details
    loadIncidentDetails(incidentId);
}

/**
 * Load details for a specific incident
 * @param {number} incidentId - ID of the incident
 */
function loadIncidentDetails(incidentId) {
    const detailsContainer = document.getElementById('incident-details-container');
    const timelineContainer = document.getElementById('timeline-chart');
    
    if (!detailsContainer) return;
    
    // Show loading state
    detailsContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading incident details...</p>';
    
    // Clear timeline
    if (timelineContainer) {
        timelineContainer.innerHTML = '<div class="spinner"></div><p class="text-center">Loading timeline...</p>';
    }
    
    // Fetch incident details
    fetch(`/api/incidents/${incidentId}`)
        .then(response => response.json())
        .then(incident => {
            // Create timeline events HTML
            let timelineEventsHtml = '';
            if (incident.timeline && incident.timeline.length > 0) {
                timelineEventsHtml = '<div class="mt-4"><h6>Timeline Events</h6>';
                
                // Sort events by timestamp
                const sortedEvents = [...incident.timeline].sort((a, b) => 
                    new Date(a.timestamp) - new Date(b.timestamp)
                );
                
                timelineEventsHtml += '<div class="timeline-container">';
                sortedEvents.forEach(event => {
                    const eventCategory = event.category || 'event';
                    const eventCategoryClass = eventCategory === 'critical' ? 'text-danger' : 
                                              eventCategory === 'warning' ? 'text-warning' : 'text-info';
                    
                    timelineEventsHtml += `
                        <div class="timeline-item">
                            <div class="timeline-item-time small text-muted">
                                ${formatDate(event.timestamp, true)}
                            </div>
                            <div class="timeline-item-content">
                                <span class="${eventCategoryClass}">${event.event}</span>
                                ${event.metadata ? `<div class="small text-muted">${JSON.stringify(event.metadata)}</div>` : ''}
                            </div>
                        </div>
                    `;
                });
                timelineEventsHtml += '</div>';
                
                // Add button to add new event
                timelineEventsHtml += `
                    <div class="mt-3">
                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#add-event-form">
                            <i class="fas fa-plus"></i> Add Event
                        </button>
                        
                        <div class="collapse mt-3" id="add-event-form">
                            <div class="card card-body">
                                <form id="timeline-event-form">
                                    <div class="mb-3">
                                        <label for="event-description" class="form-label">Event Description</label>
                                        <input type="text" class="form-control" id="event-description" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="event-timestamp" class="form-label">Timestamp</label>
                                        <input type="datetime-local" class="form-control" id="event-timestamp" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="event-category" class="form-label">Category</label>
                                        <select class="form-select" id="event-category">
                                            <option value="general">General</option>
                                            <option value="crew">Crew</option>
                                            <option value="aircraft">Aircraft</option>
                                            <option value="passenger">Passenger</option>
                                            <option value="weather">Weather</option>
                                            <option value="maintenance">Maintenance</option>
                                            <option value="critical">Critical</option>
                                            <option value="warning">Warning</option>
                                        </select>
                                    </div>
                                    <button type="button" class="btn btn-primary" onclick="addTimelineEvent(${incidentId})">
                                        Add Event
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                `;
                
                timelineEventsHtml += '</div>';
                
                // Render the timeline chart if we have events
                if (timelineContainer) {
                    // Generate a Gantt chart for the timeline
                    renderTimelineGantt(sortedEvents, 'timeline-chart');
                }
            } else {
                timelineEventsHtml = `
                    <div class="alert alert-info mt-4">
                        <i class="fas fa-info-circle"></i> No timeline events recorded yet.
                        <button class="btn btn-sm btn-outline-primary float-end" data-bs-toggle="collapse" data-bs-target="#add-event-form">
                            <i class="fas fa-plus"></i> Add Event
                        </button>
                    </div>
                    
                    <div class="collapse mt-3" id="add-event-form">
                        <div class="card card-body">
                            <form id="timeline-event-form">
                                <div class="mb-3">
                                    <label for="event-description" class="form-label">Event Description</label>
                                    <input type="text" class="form-control" id="event-description" required>
                                </div>
                                <div class="mb-3">
                                    <label for="event-timestamp" class="form-label">Timestamp</label>
                                    <input type="datetime-local" class="form-control" id="event-timestamp" required>
                                </div>
                                <div class="mb-3">
                                    <label for="event-category" class="form-label">Category</label>
                                    <select class="form-select" id="event-category">
                                        <option value="general">General</option>
                                        <option value="crew">Crew</option>
                                        <option value="aircraft">Aircraft</option>
                                        <option value="passenger">Passenger</option>
                                        <option value="weather">Weather</option>
                                        <option value="maintenance">Maintenance</option>
                                        <option value="critical">Critical</option>
                                        <option value="warning">Warning</option>
                                    </select>
                                </div>
                                <button type="button" class="btn btn-primary" onclick="addTimelineEvent(${incidentId})">
                                    Add Event
                                </button>
                            </form>
                        </div>
                    </div>
                `;
                
                // Show empty timeline
                if (timelineContainer) {
                    timelineContainer.innerHTML = `
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> No timeline events available. Add events to visualize the timeline.
                        </div>
                    `;
                }
            }
            
            // Create affected entities HTML
            let entitiesHtml = '';
            if (incident.affected_entities && incident.affected_entities.length > 0) {
                entitiesHtml = `
                    <div class="mt-4">
                        <h6>Affected Entities</h6>
                        <div>
                `;
                
                incident.affected_entities.forEach(entity => {
                    entitiesHtml += `<span class="badge bg-secondary me-1 mb-1">${entity}</span>`;
                });
                
                entitiesHtml += '</div></div>';
            }
            
            // Create root cause analysis HTML
            let rootCauseHtml = '';
            if (incident.root_cause) {
                rootCauseHtml = `
                    <div class="mt-4">
                        <h6>Root Cause Analysis</h6>
                        <div class="card bg-light">
                            <div class="card-body">
                                <p>${incident.root_cause.replace(/\n/g, '<br>')}</p>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                rootCauseHtml = `
                    <div class="mt-4">
                        <h6>Root Cause Analysis</h6>
                        <div class="alert alert-secondary">
                            <i class="fas fa-robot"></i> No root cause analysis yet. 
                            <button class="btn btn-sm btn-primary ms-2" onclick="generateRootCause(${incidentId})">
                                Generate Analysis
                            </button>
                        </div>
                    </div>
                `;
            }
            
            // Create lessons learned HTML
            let lessonsHtml = '';
            if (incident.lessons_learned) {
                lessonsHtml = `
                    <div class="mt-4">
                        <h6>Lessons Learned</h6>
                        <div class="card bg-light">
                            <div class="card-body">
                                <p>${incident.lessons_learned.replace(/\n/g, '<br>')}</p>
                            </div>
                        </div>
                    </div>
                `;
            } else if (incident.root_cause) {
                // Only show this if we have a root cause but no lessons
                lessonsHtml = `
                    <div class="mt-4">
                        <h6>Lessons Learned</h6>
                        <div class="alert alert-secondary">
                            <i class="fas fa-file-alt"></i> No lessons learned yet. 
                            <button class="btn btn-sm btn-primary ms-2" onclick="generatePostmortem(${incidentId})">
                                Generate Postmortem
                            </button>
                        </div>
                    </div>
                `;
            }
            
            // No more what-if section
            
            // Create the details HTML
            const detailsHtml = `
                <div class="mb-3">
                    <h4>${incident.title}</h4>
                    <p>${incident.description || ''}</p>
                </div>
                
                <div class="mb-3">
                    <span class="badge ${incident.severity === 'critical' ? 'bg-danger' : 
                                      incident.severity === 'major' ? 'bg-warning' : 'bg-info'} me-2">
                        ${incident.severity}
                    </span>
                    <small class="text-muted">
                        Started: ${formatDate(incident.start_time, true)}
                        ${incident.end_time ? ` • Ended: ${formatDate(incident.end_time, true)}` : ''}
                    </small>
                </div>
                
                ${timelineEventsHtml}
                ${entitiesHtml}
                ${rootCauseHtml}
                ${lessonsHtml}
            `;
            
            // Update container
            detailsContainer.innerHTML = detailsHtml;
            
            // Setup datetime for new event to default to the incident start time
            const eventTimestamp = document.getElementById('event-timestamp');
            if (eventTimestamp) {
                const incidentDate = new Date(incident.start_time);
                const dateStr = incidentDate.toISOString().slice(0, 16);
                eventTimestamp.value = dateStr;
            }
        })
        .catch(error => {
            detailsContainer.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> Error loading incident details: ${error.message}
                </div>
            `;
            console.error('Failed to load incident details:', error);
        });
}

/**
 * Add an event to the incident timeline
 * @param {number} incidentId - ID of the incident
 */
function addTimelineEvent(incidentId) {
    const eventDescription = document.getElementById('event-description')?.value;
    const eventTimestamp = document.getElementById('event-timestamp')?.value;
    const eventCategory = document.getElementById('event-category')?.value;
    
    if (!eventDescription || !eventTimestamp) {
        showToast('Event description and timestamp are required', 'warning');
        return;
    }
    
    // Create event data
    const eventData = {
        event: eventDescription,
        timestamp: eventTimestamp,
        category: eventCategory || 'general'
    };
    
    // Show loading state in the form
    const addEventBtn = document.querySelector('#timeline-event-form button');
    const originalBtnText = addEventBtn.innerHTML;
    addEventBtn.disabled = true;
    addEventBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...';
    
    // Send to API
    fetch(`/api/incidents/${incidentId}/timeline`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(eventData)
    })
    .then(response => response.json())
    .then(data => {
        // Reset button state
        addEventBtn.disabled = false;
        addEventBtn.innerHTML = originalBtnText;
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Event added successfully', 'success');
        
        // Clear form
        document.getElementById('event-description').value = '';
        
        // Collapse the form
        const addEventForm = document.getElementById('add-event-form');
        const bsCollapse = bootstrap.Collapse.getInstance(addEventForm);
        if (bsCollapse) {
            bsCollapse.hide();
        }
        
        // Reload incident details
        loadIncidentDetails(incidentId);
    })
    .catch(error => {
        // Reset button state
        addEventBtn.disabled = false;
        addEventBtn.innerHTML = originalBtnText;
        
        // Show error message
        showToast('Failed to add event: ' + error.message, 'danger');
        console.error('Event addition error:', error);
    });
}

/**
 * Generate root cause analysis for an incident
 * @param {number} incidentId - ID of the incident
 */
function generateRootCause(incidentId) {
    const rootCauseSection = document.querySelector('div:has(> h6:contains("Root Cause Analysis"))');
    if (!rootCauseSection) return;
    
    // Show loading state
    rootCauseSection.innerHTML = `
        <h6>Root Cause Analysis</h6>
        <div class="card bg-light">
            <div class="card-body text-center">
                <div class="spinner"></div>
                <p>Generating root cause analysis...</p>
                <p class="small text-muted">This may take a moment while our AI analyzes the incident.</p>
            </div>
        </div>
    `;
    
    // Call API to generate root cause
    fetch(`/api/incidents/${incidentId}/root-cause`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Root cause analysis generated successfully', 'success');
        
        // Reload incident details
        loadIncidentDetails(incidentId);
    })
    .catch(error => {
        // Show error message
        rootCauseSection.innerHTML = `
            <h6>Root Cause Analysis</h6>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error generating analysis: ${error.message}
                <button class="btn btn-sm btn-primary ms-2" onclick="generateRootCause(${incidentId})">
                    Try Again
                </button>
            </div>
        `;
        console.error('Root cause generation error:', error);
    });
}

/**
 * Generate postmortem for an incident
 * @param {number} incidentId - ID of the incident
 */
function generatePostmortem(incidentId) {
    const lessonsSection = document.querySelector('div:has(> h6:contains("Lessons Learned"))');
    if (!lessonsSection) return;
    
    // Show loading state
    lessonsSection.innerHTML = `
        <h6>Lessons Learned</h6>
        <div class="card bg-light">
            <div class="card-body text-center">
                <div class="spinner"></div>
                <p>Generating postmortem analysis...</p>
                <p class="small text-muted">This may take a moment while our AI analyzes the incident.</p>
            </div>
        </div>
    `;
    
    // Call API to generate postmortem
    fetch(`/api/incidents/${incidentId}/postmortem`, {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Show success message
        showToast('Postmortem analysis generated successfully', 'success');
        
        // Reload incident details
        loadIncidentDetails(incidentId);
    })
    .catch(error => {
        // Show error message
        lessonsSection.innerHTML = `
            <h6>Lessons Learned</h6>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error generating postmortem: ${error.message}
                <button class="btn btn-sm btn-primary ms-2" onclick="generatePostmortem(${incidentId})">
                    Try Again
                </button>
            </div>
        `;
        console.error('Postmortem generation error:', error);
    });
}

// What-if methods have been removed as per user request

/**
 * Truncate text with ellipsis if it exceeds max length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
function truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Format a date string into a readable format
 * @param {string} dateString - ISO date string
 * @param {boolean} includeTime - Whether to include time in the output
 * @returns {string} Formatted date string
 */
function formatDate(dateString, includeTime = false) {
    if (!dateString) return '';
    
    try {
        const date = new Date(dateString);
        
        // Check if date is valid
        if (isNaN(date.getTime())) {
            return 'Invalid date';
        }
        
        // Format with options
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };
        
        if (includeTime) {
            options.hour = '2-digit';
            options.minute = '2-digit';
            options.hour12 = true;
        }
        
        return date.toLocaleDateString('en-US', options);
    } catch (error) {
        console.error('Error formatting date:', error);
        return 'Date error';
    }
}

/**
 * Render a timeline as a Mermaid.js Gantt chart
 * @param {Array} events - Timeline events
 * @param {string} containerId - ID of the container to render in
 */
function renderTimelineGantt(events, containerId) {
    if (!events || events.length === 0) {
        return;
    }
    
    const container = document.getElementById(containerId);
    if (!container) {
        console.error('Timeline container not found:', containerId);
        return;
    }
    
    // Show loading state
    container.innerHTML = '<div class="spinner"></div><p class="text-center">Generating timeline chart...</p>';
    
    // Format events for API
    const formattedEvents = events.map(event => ({
        timestamp: event.timestamp,
        event: event.event,
        category: event.category || 'general'
    }));
    
    // Call the API to generate the chart
    fetch('/api/generate-timeline-chart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ events: formattedEvents })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            throw new Error(data.error);
        }
        
        if (!data.chart) {
            throw new Error('No chart data received');
        }
        
        // Clean the mermaid chart data - remove any asterisk or unexpected characters
        const cleanChart = data.chart
            .replace(/\*/g, '')
            .replace(/```mermaid/g, '')
            .replace(/```/g, '')
            .trim();
            
        // Render the chart using Mermaid
        container.innerHTML = `<div class="mermaid">${cleanChart}</div>`;
        
        // Initialize Mermaid with config
        if (window.mermaid) {
            // Reset mermaid to clear any previous configurations
            window.mermaid.mermaidAPI.reset();
            
            // Configure mermaid
            window.mermaid.initialize({
                startOnLoad: true,
                theme: 'neutral',
                gantt: {
                    titleTopMargin: 25,
                    barHeight: 20,
                    barGap: 4,
                    topPadding: 50,
                    leftPadding: 75,
                    gridLineStartPadding: 35,
                    fontSize: 12,
                    fontFamily: '"Roboto", sans-serif',
                    numberSectionStyles: 4
                }
            });
            
            // Try-catch to handle mermaid parsing errors
            try {
                window.mermaid.init(undefined, '.mermaid');
            } catch (error) {
                console.error('Mermaid parsing error:', error);
                container.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Error rendering chart: ${error.message}
                        <hr>
                        <pre class="small text-muted">${cleanChart}</pre>
                    </div>
                `;
            }
        } else {
            console.error('Mermaid library not loaded');
            container.innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> Unable to render timeline chart. Mermaid library not loaded.
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error generating timeline chart:', error);
        container.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle"></i> Error generating timeline chart: ${error.message}
            </div>
        `;
    });
}
