from fastapi import APIRouter, HTTPException, status
from .models import JobRequest, JobResponse, JobListResponse
from .services import job_service

router = APIRouter()

@router.post("/jobs", response_model=JobResponse)
async def create_job(request: JobRequest):
    """Create a new scheduled job."""
    try:
        job_data = request.dict()
        job_id = job_service.create_job(job_data)
        return JobResponse(success=True, job_id=job_id, message="Job created successfully")
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.get("/jobs", response_model=JobListResponse)
async def get_jobs():
    """Get all scheduled jobs."""
    try:
        jobs = job_service.get_jobs()
        return JobListResponse(jobs=jobs)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.put("/jobs/{job_id}", response_model=JobResponse)
async def update_job(job_id: int, request: JobRequest):
    """Update an existing job."""
    try:
        job_data = request.dict()
        success = job_service.update_job(job_id, job_data)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Job not found"
            )
        return JobResponse(success=True, job_id=job_id, message="Job updated successfully")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@router.delete("/jobs/{job_id}", response_model=JobResponse)
async def delete_job(job_id: int):
    """Delete a job."""
    try:
        success = job_service.delete_job(job_id)
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Job not found"
            )
        return JobResponse(success=True, message="Job deleted successfully")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        ) 