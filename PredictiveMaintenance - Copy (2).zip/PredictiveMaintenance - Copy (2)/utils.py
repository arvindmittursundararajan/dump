import os
import re
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from config import GEMINI_API_KEY
from models import SensorData

# Set up the Gemini API URL
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key={GEMINI_API_KEY}"

def clean_text(text):
    """Convert Markdown to HTML and clean up text from Gemini API response"""
    # Remove code block markers like ```html or ```
    text = re.sub(r'^```[a-zA-Z]*\s*', '', text)
    text = re.sub(r'```$', '', text)
    # Convert Markdown to HTML
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)  # Bold
    text = re.sub(r'\*(.*?)\*', r'<em>\1</em>', text)  # Italic
    text = re.sub(r'# (.*?)(?:\n|$)', r'<h3>\1</h3>', text)  # H1 to H3 (smaller heading)
    text = re.sub(r'## (.*?)(?:\n|$)', r'<h4>\1</h4>', text)  # H2 to H4
    text = re.sub(r'### (.*?)(?:\n|$)', r'<h5>\1</h5>', text)  # H3 to H5
    
    # Handle lists
    text = re.sub(r'(?<=\n)- (.*?)(?:\n|$)', r'<li>\1</li>', text)
    text = re.sub(r'(?<=\n)\d+\. (.*?)(?:\n|$)', r'<li>\1</li>', text)
    text = re.sub(r'(<li>.*?</li>)+', r'<ul>\g<0></ul>', text)
    
    # Handle paragraphs (any text block that's not already in an HTML tag)
    text = re.sub(r'(?<=>)([^<>]+)(?=<)', lambda m: f"<p>{m.group(1).strip()}</p>" if m.group(1).strip() else "", text)
    text = re.sub(r'^([^<>]+)(?=<)', lambda m: f"<p>{m.group(1).strip()}</p>" if m.group(1).strip() else "", text)
    text = re.sub(r'(?<=>)([^<>]+)$', lambda m: f"<p>{m.group(1).strip()}</p>" if m.group(1).strip() else "", text)
    
    # Ensure proper spacing
    text = re.sub(r'<\/p>\s*<p>', '</p><p>', text)
    text = re.sub(r'<\/li>\s*<li>', '</li><li>', text)
    
    # Final cleanup
    text = re.sub(r'\s+', ' ', text)
    text = text.replace('<p> ', '<p>').replace(' </p>', '</p>')
    
    # Wrap in a div with class for styling
    return f'<div class="ai-response">{text}</div>'

def clean_gemini_output(text):
    """Remove any line that is exactly '```html' from Gemini output."""
    if not text:
        return text
    lines = text.splitlines()
    cleaned = [line for line in lines if line.strip() != '```html']
    return '\n'.join(cleaned)

def get_gemini_response(question, asset_details=None):
    """Get response from Gemini API, including asset details for context if provided."""
    headers = {'Content-Type': 'application/json'}
    # Build context string from asset_details
    context_str = ""
    if asset_details:
        if 'name' in asset_details:
            context_str += f"\nAsset Name: {asset_details['name']}"
        if 'type' in asset_details:
            context_str += f"\nAsset Type: {asset_details['type']}"
        if 'status' in asset_details:
            context_str += f"\nStatus: {asset_details['status']}"
        if 'alerts' in asset_details and asset_details['alerts']:
            context_str += "\nRecent Alerts: " + ", ".join([f"{a['type']} ({a['severity']}) - {a['message']}" for a in asset_details['alerts']])
        if 'sensor_data' in asset_details and asset_details['sensor_data']:
            for s_type, s_info in asset_details['sensor_data'].items():
                context_str += f"\nSensor: {s_type} | Min: {s_info.get('min')} | Max: {s_info.get('max')} | Mean: {s_info.get('mean')} | Anomalies: {s_info.get('anomaly_count')}"
        if 'maintenance_history' in asset_details and asset_details['maintenance_history']:
            context_str += "\nRecent Maintenance: " + ", ".join([f"{m['type']} ({m['status']}) on {m['start_date']}" for m in asset_details['maintenance_history']])
    # Custom prompt for HTML output, no markdown, no asterisks, beautiful card with color bar
    prompt = f'''
You are an AI assistant specialized in industrial predictive maintenance. 
Below is detailed information about the asset and its recent activity. Use this context to provide a highly relevant, actionable, and specific answer. 
{context_str}

Provide your answer as beautiful HTML only (no markdown, no asterisks, no bullet symbols). 
Format your response as a visually appealing card with a colored bar on the left, a clear title, and well-structured sections. 
Use <ul> and <li> for lists, <h4> for the title, and <div> for sections. 
Do not use * or markdown. Make the output visually attractive and easy to read. 

Question: {question}
'''
    data = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.7, 
            "topK": 40, 
            "topP": 0.95, 
            "maxOutputTokens": 2048
        }
    }
    try:
        response = requests.post(GEMINI_URL, headers=headers, json=data)
        if response.status_code == 200:
            content = response.json().get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
            return content if content else "No valid content in response."
        return f"Error: {response.status_code}"
    except Exception as e:
        return f"Error connecting to Gemini API: {str(e)}"

def process_with_gemini(question, asset_details=None):
    """Process a question with Gemini API, passing asset details for context if available, and clean output."""
    raw = get_gemini_response(question, asset_details=asset_details)
    return clean_gemini_output(raw)

def allowed_file(filename, allowed_extensions=None):
    """Check if the file extension is allowed"""
    if allowed_extensions is None:
        from config import ALLOWED_EXTENSIONS
        allowed_extensions = ALLOWED_EXTENSIONS
        
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

def detect_anomalies(machine_id, part_id, sensor_type, value):
    """
    Simple anomaly detection based on historical data
    Returns True if the value is anomalous, False otherwise
    """
    # Define query filters
    filters = {'sensor_type': sensor_type}
    if machine_id:
        filters['machine_id'] = machine_id
    if part_id:
        filters['part_id'] = part_id
    
    # Get historical data for this sensor
    from app import db
    historical_data = SensorData.query.filter_by(**filters).order_by(SensorData.timestamp.desc()).limit(100).all()
    
    if len(historical_data) < 5:
        # Not enough data to determine anomalies
        return False
    
    # Calculate mean and standard deviation
    values = [sd.value for sd in historical_data]
    mean = sum(values) / len(values)
    std_dev = (sum((x - mean) ** 2 for x in values) / len(values)) ** 0.5
    
    # Z-score anomaly detection
    z_score = abs(value - mean) / (std_dev if std_dev > 0 else 1)
    
    # If z-score is greater than 3, consider it an anomaly
    return z_score > 3

def calculate_failure_probability(part_id):
    """
    Calculate the probability of failure for a part
    Returns a value between 0 and 1
    """
    from app import db
    from models import Part, SensorData, MaintenanceRecord
    
    part = Part.query.get(part_id)
    if not part:
        return 0
    
    # Base factors
    probability = 0.0
    
    # Factor 1: Age since installation
    if part.installation_date:
        days_since_installation = (datetime.utcnow().date() - part.installation_date).days
        if part.expected_lifetime_hours:
            # Assuming 8 hours per day operation
            expected_lifetime_days = part.expected_lifetime_hours / 8
            age_factor = min(days_since_installation / max(expected_lifetime_days, 1), 1.0)
            probability += age_factor * 0.4  # 40% weight
        else:
            # If no expected lifetime, estimate based on days (1 year = 365 days)
            age_factor = min(days_since_installation / 365, 1.0)
            probability += age_factor * 0.3  # 30% weight
    
    # Factor 2: Status
    if part.status == 'warning':
        probability += 0.25
    elif part.status == 'critical':
        probability += 0.5
    
    # Factor 3: Recent anomalies
    recent_anomalies = SensorData.query.filter_by(part_id=part_id, is_anomaly=True).filter(
        SensorData.timestamp > (datetime.utcnow() - timedelta(days=30))
    ).count()
    
    anomaly_factor = min(recent_anomalies / 10, 1.0)  # Cap at 10 anomalies
    probability += anomaly_factor * 0.3  # 30% weight
    
    # Factor 4: Maintenance history
    recent_maintenance = MaintenanceRecord.query.filter_by(
        machine_id=part.machine_id,
        status='completed'
    ).filter(
        MaintenanceRecord.end_date > (datetime.utcnow() - timedelta(days=90))
    ).count()
    
    # More maintenance might indicate recurring problems
    maintenance_factor = min(recent_maintenance / 5, 1.0)  # Cap at 5 maintenances
    probability += maintenance_factor * 0.1  # 10% weight
    
    # Ensure probability is within [0, 1]
    return min(max(probability, 0.0), 1.0)

def analyze_sensor_data(part_id, sensor_type=None, days=30):
    """
    Analyze sensor data for trends and patterns
    Returns a dictionary with analysis results
    """
    from app import db
    from models import SensorData
    
    # Define query filters
    filters = {'part_id': part_id}
    if sensor_type:
        filters['sensor_type'] = sensor_type
    
    # Get data for the specified period
    start_date = datetime.utcnow() - timedelta(days=30)
    data = SensorData.query.filter_by(**filters).filter(
        SensorData.timestamp > start_date
    ).order_by(SensorData.timestamp).all()
    
    if not data:
        return {
            'status': 'insufficient_data',
            'message': 'Not enough data for analysis'
        }
    
    # Group data by sensor type
    sensor_data = {}
    for record in data:
        if record.sensor_type not in sensor_data:
            sensor_data[record.sensor_type] = []
        
        sensor_data[record.sensor_type].append({
            'timestamp': record.timestamp,
            'value': record.value,
            'is_anomaly': record.is_anomaly
        })
    
    results = {}
    for s_type, values in sensor_data.items():
        # Extract values and timestamps
        just_values = [v['value'] for v in values]
        timestamps = [v['timestamp'] for v in values]
        anomalies = [v['is_anomaly'] for v in values]
        
        # Basic statistics
        stats = {
            'min': min(just_values),
            'max': max(just_values),
            'mean': sum(just_values) / len(just_values),
            'anomaly_count': sum(anomalies),
            'sample_count': len(just_values),
            'first_timestamp': min(timestamps),
            'last_timestamp': max(timestamps)
        }
        
        # Calculate trend (simple linear regression)
        if len(just_values) > 1:
            x = np.array(range(len(just_values)))
            y = np.array(just_values)
            slope = np.polyfit(x, y, 1)[0]
            
            stats['trend'] = {
                'slope': slope,
                'direction': 'increasing' if slope > 0 else 'decreasing',
                'magnitude': abs(slope)
            }
        
        results[s_type] = stats
    
    return {
        'status': 'success',
        'sensor_types': list(sensor_data.keys()),
        'analysis': results
    }

def process_csv_data(file_path, machine_id=None, part_id=None):
    """
    Process CSV data and insert into the database
    Returns the number of records processed and any errors
    """
    from app import db
    
    # Read CSV file
    try:
        df = pd.read_csv(file_path)
        required_columns = ['timestamp', 'sensor_type', 'value']
        
        # Check for required columns
        for col in required_columns:
            if col not in df.columns:
                return {'success': False, 'message': f'Missing required column: {col}'}
        
        # Optional columns
        if 'unit' not in df.columns:
            df['unit'] = ''
        
        # Process each row
        record_count = 0
        for _, row in df.iterrows():
            try:
                # Parse timestamp
                timestamp = pd.to_datetime(row['timestamp'])
                
                # Process value
                value = float(row['value'])
                
                # Determine if value is anomalous
                is_anomaly = detect_anomalies(machine_id, part_id, row['sensor_type'], value)
                
                # Create new sensor data record
                sensor_data = SensorData(
                    machine_id=machine_id,
                    part_id=part_id,
                    sensor_type=row['sensor_type'],
                    timestamp=timestamp,
                    value=value,
                    unit=row['unit'],
                    is_anomaly=is_anomaly
                )
                
                db.session.add(sensor_data)
                
                # Create alert if anomaly is detected
                if is_anomaly:
                    from models import Alert
                    
                    # Determine severity based on how far the value deviates from historical norms
                    filters = {'sensor_type': row['sensor_type']}
                    if machine_id:
                        filters['machine_id'] = machine_id
                    if part_id:
                        filters['part_id'] = part_id
                    
                    historical_data = SensorData.query.filter_by(**filters).order_by(SensorData.timestamp.desc()).limit(100).all()
                    values = [sd.value for sd in historical_data if sd is not None]
                    
                    if values:
                        mean = sum(values) / len(values)
                        std_dev = (sum((x - mean) ** 2 for x in values) / len(values)) ** 0.5
                        z_score = abs(value - mean) / (std_dev if std_dev > 0 else 1)
                        
                        # Determine severity based on z-score
                        severity = 'low'
                        if z_score > 5:
                            severity = 'critical'
                        elif z_score > 4:
                            severity = 'high'
                        elif z_score > 3:
                            severity = 'medium'
                        
                        # Create alert message
                        message = f"Anomaly detected for {row['sensor_type']} sensor. Value of {value} {row['unit']} is outside normal operating range."
                        
                        # Create and save alert
                        alert = Alert(
                            machine_id=machine_id,
                            part_id=part_id,
                            alert_type='anomaly_detection',
                            severity=severity,
                            message=message,
                            timestamp=timestamp,
                            is_acknowledged=False
                        )
                        
                        db.session.add(alert)
                
                record_count += 1
                
            except Exception as e:
                db.session.rollback()
                return {'success': False, 'message': f'Error processing row: {str(e)}'}
        
        # Commit all records
        db.session.commit()
        
        return {'success': True, 'count': record_count}
    
    except Exception as e:
        return {'success': False, 'message': f'Error reading CSV file: {str(e)}'}
